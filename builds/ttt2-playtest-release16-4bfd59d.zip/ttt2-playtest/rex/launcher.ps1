# The TTT2 launcher: a small window with four buttons (install tools, choose game, build, play)
# over rex\setup-steps.ps1. Started by "Start Here.cmd" at the top of the package.

param([string]$UpdateUrl = 'https://raw.githubusercontent.com/avim2/BlueSpark/main/latest.json', [switch]$AutoBuild, [switch]$InstallUpdate, [switch]$UninstallDryRun)
$DefaultUpdateUrl = 'https://raw.githubusercontent.com/avim2/BlueSpark/main/latest.json'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
# (4.5, the owner: no hidden-window flag where Start Here or its steps are started, a "dropper" signal a scanner's model may
# weigh. 4.5.1: no compiled C# either (4.5's hid Start Here's console through the Windows API, another): Start Here.cmd
# starts this minimized, and the steps run with no window of their own (CreateNoWindow), their output copied to the step
# logs as it comes (the logs are read as they grow), by .NET's own stream copy.)
$script:ttt2Copies = @{}   # a program's id: its output copies (the tasks and the files they write)
function Start-Ttt2Program([string]$exe, [string]$arguments, [string]$outPath, [string]$errPath) {
    $si = New-Object System.Diagnostics.ProcessStartInfo($exe, $arguments)
    $si.UseShellExecute = $false
    $si.CreateNoWindow = $true
    $si.RedirectStandardOutput = [bool]$outPath
    $si.RedirectStandardError = [bool]$errPath
    $p = [System.Diagnostics.Process]::Start($si)
    $copies = @()
    foreach ($pair in @(@($outPath, $(if ($outPath) { $p.StandardOutput.BaseStream })), @($errPath, $(if ($errPath) { $p.StandardError.BaseStream })))) {
        if (-not $pair[0]) { continue }
        $to = New-Object System.IO.FileStream($pair[0], [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, ([System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete), 1)
        $copies += [pscustomobject]@{ Task = $pair[1].CopyToAsync($to, 4096); File = $to }
    }
    # (Copies of programs that have ended: their files closed.)
    foreach ($id in @($script:ttt2Copies.Keys)) {
        if (@($script:ttt2Copies[$id] | Where-Object { -not $_.Task.IsCompleted }).Count -eq 0) {
            foreach ($c in $script:ttt2Copies[$id]) { $c.File.Dispose() }
            $script:ttt2Copies.Remove($id)
        }
    }
    $script:ttt2Copies[$p.Id] = $copies
    return $p
}
# Until the program has ended and its output is all in the files.
function Wait-Ttt2Program($p) {
    $p.WaitForExit()
    $copies = $script:ttt2Copies[$p.Id]
    if (-not $copies) { return }
    foreach ($c in $copies) { $null = $c.Task.Wait(5000); $c.File.Dispose() }
    $script:ttt2Copies.Remove($p.Id)
}

$Rex = $PSScriptRoot
$Steps = Join-Path $Rex 'setup-steps.ps1'
$PidFile = Join-Path $Rex 'start-here.pid'   # (this install's open Start Here: its process id, start time and state; one Start Here a folder, 4.5.1)
function Write-StartHerePid([string]$state) {
    try { [IO.File]::WriteAllText($PidFile, "$PID $((Get-Process -Id $PID).StartTime.ToFileTimeUtc()) $state") } catch { }
}
$Logs = Join-Path $env:LOCALAPPDATA 'TTT2Native\logs'
New-Item -ItemType Directory -Force $Logs | Out-Null
# (Where the tools and game files go, the free space and synced-folder checks: the lead's E and F, 27 Oct. Our missing
# files: D2 and G3. The toolchain's script, in the prebuilt package, for the tools' files.)
. (Join-Path $Rex 'tools\data-folder.ps1')
if (Test-Path -LiteralPath (Join-Path $Rex 'tools\toolchain.ps1')) { . (Join-Path $Rex 'tools\toolchain.ps1') }
. (Join-Path $Rex 'tools\missing-files.ps1')

$script:proc = $null
$script:logFile = $null
$script:logPos = 0
$script:current = ''
$script:partial = ''
$script:phase = ''
$script:lastTen = -1

# --- the window -------------------------------------------------------------------------------
$form = New-Object Windows.Forms.Form
$form.Text = 'Tekken Tag Tournament 2: native'
$form.ClientSize = New-Object Drawing.Size(640, 716)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$font = New-Object Drawing.Font('Segoe UI', 10)
$big = New-Object Drawing.Font('Segoe UI', 12, [Drawing.FontStyle]::Bold)
$form.Font = $font

# (4.5.1, the owner's new layout of 30 Oct: two tabs. The front page: 1. Choose my game + update, 2. Install (the tools, the game
# files and the build, back to back), the Play buttons, every other button and the log. Settings: every checkbox and the display.
# The tabs have a fixed size and the form scrolls them, as A's sizing rules at the end expect.)
$tabs = New-Object Windows.Forms.TabControl
$tabs.Location = New-Object Drawing.Point(0, 0)
$front = New-Object Windows.Forms.TabPage
$front.Text = 'Start Here'
$front.UseVisualStyleBackColor = $true
$settingsPage = New-Object Windows.Forms.TabPage
$settingsPage.Text = 'Settings'
$settingsPage.UseVisualStyleBackColor = $true
$tabs.TabPages.Add($front)
$tabs.TabPages.Add($settingsPage)
$form.Controls.Add($tabs)

$intro = New-Object Windows.Forms.Label
# (The prebuilt package, rex\prebuilt: a portable compiler is downloaded; no Visual Studio, no Git.)
$script:prebuilt = Test-Path -LiteralPath (Join-Path $Rex 'prebuilt\manifest.txt')
$intro.Text = if ($script:prebuilt) {
    'Choose your game and its update, then click Install: it downloads a compiler (about 1.1 GB, no Visual Studio needed), copies the game files and builds the game on this PC. The first time takes a while; leave this window open.'
} else { 'Choose your game and its update, then click Install (the tools, the game files and the build). The first time takes a while; leave this window open.' }
$intro.SetBounds(16, 6, 608, 40)
$front.Controls.Add($intro)

function New-StepButton($y, $text) {
    $b = New-Object Windows.Forms.Button
    $b.Text = $text
    $b.Font = $big
    $b.SetBounds(16, $y, 300, 44)
    $front.Controls.Add($b)
    $l = New-Object Windows.Forms.Label
    $l.SetBounds(330, $y + 4, 294, 38)
    $front.Controls.Add($l)
    return @($b, $l)
}
# (The front page's rows, top to bottom: the intro, the profile row, the data folder row, then these.)
$ProfileTop = 48; $DataTop = 100
$choose, $chooseState = New-StepButton 136 '1.  Choose my game + update'
$install, $installState = New-StepButton 186 '2.  Install'
$PlayTop = 238
$play = New-Object Windows.Forms.Button
$play.Text = 'Play TTT2'
$play.Font = $big
$play.SetBounds(16, $PlayTop, 196, 44)
$front.Controls.Add($play)
$playState = New-Object Windows.Forms.Label
$front.Controls.Add($playState)
# The fast client (the lead's I, 26 Oct; the owner: "combine fast client into start here through a second play button";
# fastclient/PACKAGING.md 4-8): a second way to play, beside Play, once Build is done; Play itself is unchanged. A package
# without the client (fastclient\bin\) shows it greyed, "coming soon" (the owner, 26 Oct: "grey out the fast client play
# button, i want to tease players with it"). Play's own line goes under the row.
$script:fastClientExe = Join-Path (Split-Path $Rex -Parent) 'fastclient\bin\ttt2-fastclient.exe'
$script:fastClientReady = Test-Path -LiteralPath $script:fastClientExe
$fastPlay = New-Object Windows.Forms.Button
$fastPlay.Text = if ($script:fastClientReady) { 'Play BlueSpark' } else { 'Play BlueSpark (coming soon)' }
$fastPlay.Font = if ($script:fastClientReady) { $big } else { New-Object Drawing.Font('Segoe UI', 10, [Drawing.FontStyle]::Bold) }
$fastPlay.SetBounds(220, $PlayTop, 200, 44)
if ($script:fastClientReady) { $fastPlay.Font = New-Object Drawing.Font('Segoe UI', 11, [Drawing.FontStyle]::Bold) }
$front.Controls.Add($fastPlay)
# Settings, where "Play offline (no internet)" was (the owner's design of 1 Nov, docs/design/start-here-settings-20261101.png: players
# missed the small tab). Playing offline is now Settings' "Play online" unticked. A gear from the system's icon font, or drawn without it.
function New-GearImage([int]$size) {
    $bmp = New-Object Drawing.Bitmap($size, $size)
    $g = [Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'
    $g.TextRenderingHint = 'AntiAliasGridFit'
    $installed = (New-Object Drawing.Text.InstalledFontCollection).Families | ForEach-Object { $_.Name }
    $iconFont = @('Segoe Fluent Icons', 'Segoe MDL2 Assets') | Where-Object { $installed -contains $_ -and -not $env:TTT2_TEST_NO_ICON_FONT } | Select-Object -First 1
    if ($iconFont) {
        $f = New-Object Drawing.Font($iconFont, ($size * 0.72), [Drawing.FontStyle]::Regular, [Drawing.GraphicsUnit]::Pixel)
        $sf = New-Object Drawing.StringFormat; $sf.Alignment = 'Center'; $sf.LineAlignment = 'Center'
        $g.DrawString([string][char]0xE713, $f, [Drawing.Brushes]::White, (New-Object Drawing.RectangleF(0, 0, $size, $size)), $sf)
        $f.Dispose(); $sf.Dispose()
    } else {
        $c = $size / 2.0; $r = $size * 0.27; $tooth = $size * 0.14
        $pen = New-Object Drawing.Pen([Drawing.Color]::White, [single]($size * 0.13))
        foreach ($n in 0..7) {
            $a = $n * [Math]::PI / 4
            $g.DrawLine($pen, [single]($c + [Math]::Cos($a) * $r), [single]($c + [Math]::Sin($a) * $r), [single]($c + [Math]::Cos($a) * ($r + $tooth)), [single]($c + [Math]::Sin($a) * ($r + $tooth)))
        }
        $g.DrawEllipse($pen, [single]($c - $r), [single]($c - $r), [single]($r * 2), [single]($r * 2))
        $pen.Dispose()
    }
    $g.Dispose()
    return $bmp
}
$settingsButton = New-Object Windows.Forms.Button
$settingsButton.Text = 'Settings'
$settingsButton.Font = $big
$settingsButton.SetBounds(428, $PlayTop, 196, 44)
$settingsButton.FlatStyle = 'Flat'
$settingsButton.UseVisualStyleBackColor = $false
$settingsButton.BackColor = [Drawing.ColorTranslator]::FromHtml('#0067C0')
$settingsButton.ForeColor = [Drawing.Color]::White
$settingsButton.FlatAppearance.BorderColor = [Drawing.ColorTranslator]::FromHtml('#004E93')
$settingsButton.FlatAppearance.BorderSize = 1
$settingsButton.FlatAppearance.MouseOverBackColor = [Drawing.ColorTranslator]::FromHtml('#1A7FD6')
$settingsButton.FlatAppearance.MouseDownBackColor = [Drawing.ColorTranslator]::FromHtml('#004E93')
$settingsButton.Cursor = [Windows.Forms.Cursors]::Hand
$settingsGear = New-GearImage $big.Height
$settingsButton.Add_Click({ $tabs.SelectedTab = $settingsPage })
$settingsButton.Add_Paint({   # (the word stays centred on the button, the gear left of it; a flat button's own focus mark barely shows on this blue)
    param($sender, $e)
    $wordWidth = [Windows.Forms.TextRenderer]::MeasureText($sender.Text, $sender.Font).Width
    $e.Graphics.DrawImage($settingsGear, [int](($sender.ClientSize.Width - $wordWidth) / 2 - $settingsGear.Width - 2), [int](($sender.ClientSize.Height - $settingsGear.Height) / 2))
    if ($sender.Focused) {
        $pen = New-Object Drawing.Pen([Drawing.Color]::White, 2)
        $e.Graphics.DrawRectangle($pen, 4, 4, $sender.ClientSize.Width - 9, $sender.ClientSize.Height - 9)
        $pen.Dispose()
    }
})
$front.Controls.Add($settingsButton)
$playState.SetBounds(16, ($PlayTop + 47), 608, 15)
# (the owner, 27 Oct: both buttons run the same game; players on either match each other)
$bothPlay = New-Object Windows.Forms.Label
$bothPlay.Text = 'Both run the same game: players on either match each other, with the same account, rating and saves.'
$bothPlay.ForeColor = [Drawing.Color]::DimGray
$bothPlay.Font = New-Object Drawing.Font('Segoe UI', 9)
$bothPlay.SetBounds(16, ($PlayTop + 62), 608, 15)
$front.Controls.Add($bothPlay)
$playState.Font = New-Object Drawing.Font('Segoe UI', 8)

$log = New-Object Windows.Forms.TextBox
$log.Multiline = $true
$log.ReadOnly = $true
$log.ScrollBars = 'Vertical'
$log.Font = New-Object Drawing.Font('Consolas', 9)
$log.MaxLength = 0
$log.SetBounds(16, ($PlayTop + 82), 608, 150)   # (under the two buttons' note)
$front.Controls.Add($log)
$ButtonsTop = $PlayTop + 238
$FrontHeight = $ButtonsTop + 146   # (the front page's last row, the update banner, ends at $ButtonsTop + 140)

$openLogs = New-Object Windows.Forms.Button
$openLogs.Text = 'Open log folder'
$openLogs.SetBounds(16, $ButtonsTop, 150, 32)
# (The setup's logs, and the game's own: one window each.)
$GameLogs = Join-Path $Rex 'out\build\win-amd64-release\logs'
$openLogs.Add_Click({
    Start-Process explorer.exe $Logs
    if (Test-Path -LiteralPath $GameLogs) { Start-Process explorer.exe $GameLogs }
})
$front.Controls.Add($openLogs)

# Packs the logs, any crash dumps, the build's version and the PC's parts into one zip on the Desktop
# (problem-report.ps1: never the identity, the saves or the rest of rex\userdata), in a window of its own.
$problemReport = New-Object Windows.Forms.Button
$problemReport.Text = 'Report a problem'
$problemReport.SetBounds(176, $ButtonsTop, 160, 32)
$problemReport.Add_Click({
    Start-Process powershell -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$(Join-Path $Rex 'problem-report.ps1')`"")
})
$front.Controls.Add($problemReport)

# Plays the game with its sound recorders on and packs a report for whoever gave out the build
# (sound-report.ps1), in a window of its own.
$soundReport = New-Object Windows.Forms.Button
$soundReport.Text = 'Report a sound problem'
$soundReport.SetBounds(444, $ButtonsTop, 180, 32)
$soundReport.Add_Click({
    Start-Process powershell -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$(Join-Path $Rex 'sound-report.ps1')`"")
})
$front.Controls.Add($soundReport)

$oldSdk = New-Object Windows.Forms.Button
$oldSdk.Text = 'Delete the old SDK folder'
$oldSdk.SetBounds(444, ($ButtonsTop + 84), 180, 28)   # (in the updates row, at its right)
$oldSdk.Visible = $false
$oldSdk.Add_Click({
    $folders = @(Get-ChildItem -LiteralPath $env:USERPROFILE -Directory -Filter 'rexsdk-playtest*' -ErrorAction SilentlyContinue)
    $gb = [math]::Round(($folders | ForEach-Object { (Get-ChildItem -LiteralPath $_.FullName -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum } | Measure-Object -Sum).Sum / 1GB, 1)
    $text = "This package doesn't use the SDK folder older packages built ($(($folders | ForEach-Object { $_.FullName }) -join ', '), $gb GB).`r`n`r`nDelete it? (No: it stays, and this isn't asked again.)"
    $answer = [Windows.Forms.MessageBox]::Show($form, $text, 'The old SDK folder', 'YesNo', 'Question')
    if ($answer -eq 'Yes') { Start-Step 'cleanup' @() } else { Write-Setting 'oldsdk' 'kept'; Refresh-Buttons }
})
$front.Controls.Add($oldSdk)
$oldSdk.BringToFront()

$busy = New-Object Windows.Forms.Label
$busy.SetBounds(16, ($ButtonsTop + 36), 608, 20)
$front.Controls.Add($busy)

# Shown while a step reports progress ("PROGRESS <percent> <text>" lines, e.g. extracting the ISO).
$bar = New-Object Windows.Forms.ProgressBar
$bar.SetBounds(16, ($ButtonsTop + 58), 608, 22)
$bar.Minimum = 0
$bar.Maximum = 100
$bar.Visible = $false
$front.Controls.Add($bar)

# --- state ------------------------------------------------------------------------------------
function Read-Status {
    $s = @{}
    $out = & powershell -NoProfile -ExecutionPolicy Bypass -File $Steps -Step status 2>$null
    foreach ($line in $out) { if ($line -match '^(\w+)=(True|False)$') { $s[$Matches[1]] = $Matches[2] -eq 'True' } }
    return $s
}

function Show-State($label, $done, $text) {
    if ($done) { $label.Text = 'Done'; $label.ForeColor = [Drawing.Color]::Green }
    else { $label.Text = $text; $label.ForeColor = [Drawing.Color]::DimGray }
}

# --- 1. Choose and 2. Install (4.5.1) ---------------------------------------------------------------
# Choose keeps the picks (game-source=, game-update= in launcher-settings.txt) for Install's game files part; picking again
# when the game files are done marks them to be made again (files-stale=true). Install runs the parts still to do, back to
# back: the tools (old step 1), the game files (old step 2's work), the build (old step 3); a part that runs makes the build run
# after it. A failure stops Install; clicking it again goes on from that part.
$InstallParts = [ordered]@{ tools = 'the tools'; files = 'the game files'; build = 'the build' }
$script:installRun = $null   # (while Install runs: @{ Parts = the parts left, this one first; Auto = after an update })
function Get-PartNumber($part) { [array]::IndexOf(@($InstallParts.Keys), $part) + 1 }
function Get-PartLabel($part) { "Install, part $(Get-PartNumber $part) of $($InstallParts.Count): $($InstallParts[$part])" }
function Test-FilesDone($s) { [bool]$s.files -and (Read-Setting 'files-stale' '') -ne 'true' }
function Get-Picks { @{ Source = Read-Setting 'game-source' ''; Update = Read-Setting 'game-update' '' } }
function Test-PicksValid {
    $p = Get-Picks
    if (-not $p.Source -or -not $p.Update) { return $false }
    $sourceOk = if (Test-Path -LiteralPath $p.Source -PathType Leaf) { $true } else { Test-Path -LiteralPath (Join-Path $p.Source 'default.xex') }
    return $sourceOk -and -not (Get-UpdateFileProblem $p.Update $p.Source)
}
function Test-ChooseDone($s) { (Test-FilesDone $s) -or (Test-PicksValid) }
function Get-InstallParts($s) {
    $parts = [Collections.Generic.List[string]]::new()
    $later = $false
    if (-not $s.tools) { $parts.Add('tools'); $later = $true }
    if (-not (Test-FilesDone $s)) { $parts.Add('files'); $later = $true }
    if ($later -or -not $s.build -or -not $s.buildcurrent) { $parts.Add('build') }
    return ,$parts
}
function Refresh-Buttons {
    $s = Read-Status
    $chosen = Test-ChooseDone $s
    if (Test-FilesDone $s) { Show-State $chooseState $true '' }
    elseif ($chosen) { $chooseState.Text = 'Picked: Install copies them'; $chooseState.ForeColor = [Drawing.Color]::Green }
    else { Show-State $chooseState $false 'Not done yet' }
    $left = Get-InstallParts $s
    if ($script:installRun) { $installState.Text = 'Working...'; $installState.ForeColor = [Drawing.Color]::DarkOrange }
    elseif (-not $left.Count) { Show-State $installState $true '' }
    elseif ($s.build -and $left.Count -eq 1 -and $left[0] -eq 'build') { $installState.Text = 'Rebuild: this update needs the build again (click Install)'; $installState.ForeColor = [Drawing.Color]::DarkOrange }
    elseif ($left.Count -lt $InstallParts.Count) { $installState.Text = "Left to do: $(($left | ForEach-Object { $InstallParts[$_] }) -join ', ')"; $installState.ForeColor = [Drawing.Color]::DimGray }
    else { Show-State $installState $false 'Not done yet' }
    $playState.Text = ''
    $idle = -not $script:proc
    $choose.Enabled = $idle
    $install.Enabled = $idle -and $chosen
    $play.Enabled = $idle -and $s.build
    $fastPlay.Enabled = $idle -and $s.build -and $script:fastClientReady   # (greyed, "coming soon", in a package without the client)
    # (The prebuilt package, once it built: the old Visual Studio-era SDK folders can go; asked, never automatic.)
    $oldSdk.Visible = [bool]$s.oldsdk -and (Read-Setting 'oldsdk' '') -ne 'kept'
    $oldSdk.Enabled = $idle
    if ($changeData) { $changeData.Enabled = $idle }
    if ($uninstallButton) { $uninstallButton.Enabled = $idle }
}

# --- running a step in the background ---------------------------------------------------------
function Start-Step($name, [string[]]$extra) {
    $script:current = $name
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $script:logFile = Join-Path $Logs "$stamp-$name.log"
    $script:logPos = 0
    $script:partial = ''
    $script:phase = ''
    $script:lastTen = -1
    $bar.Visible = $false
    $log.Clear()
    $arguments = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$Steps`"", '-Step', $name) + $extra
    $script:proc = Start-Ttt2Program 'powershell.exe' ($arguments -join ' ') $script:logFile "$($script:logFile).err"
    Write-StartHerePid 'busy'   # (one Start Here a folder: a second start leaves this one at its step)
    $null = $script:proc.Handle   # without this, Windows PowerShell may not report the exit code
    $what = if ($script:installRun) { Get-PartLabel $name } else { "Working on step: $name" }
    $busy.Text = if ($name -eq 'build') { "$what ... (the first build after an update takes about 3 to 5 minutes, more on an older PC; leave this window open)" } else { "$what ... (leave this window open)" }
    $busy.ForeColor = [Drawing.Color]::DarkOrange
    Refresh-Buttons
}

# A failed build's first error (the lead's F, 27 Oct: a player saw only "ninja: build stopped: subcommand failed"): the
# first compiler or linker error line in the step's log, else Ninja's or CMake's own; with the file Ninja was making.
function Get-FirstBuildError([string]$file) {
    if (-not $file -or -not (Test-Path -LiteralPath $file)) { return $null }
    $lines = @(Get-Content -LiteralPath $file -ErrorAction SilentlyContinue)
    $first = $null; $failed = $null
    foreach ($l in $lines) {
        if (-not $failed -and $l -match '^FAILED: (.+)$') { $failed = $Matches[1] }
        if ($l -match '(?i)(^|[\s:)])(fatal )?error( [A-Z]+\d+)?\s*:' -and $l -notmatch '^\s*\[\d+/\d+\]') { $first = $l.Trim(); break }
    }
    if (-not $first) { $first = ($lines | Where-Object { $_ -match '^ninja: error|CMake Error|^FAILED:' } | Select-Object -First 1) }
    if (-not $first) { return $null }
    if ($first.Length -gt 400) { $first = $first.Substring(0, 400) + '...' }
    [pscustomobject]@{ Line = $first; Making = $failed }
}
function Show-BuildFailure([string]$file) {
    # (4.5.1: build-windows.ps1's own message after the compiler crashed twice, in the step's .err log: it says what to do, and the
    # disk/OneDrive/antivirus causes below don't apply. Without this the box showed clang's "error: ... failed due to signal".)
    $crash = @(Get-Content -LiteralPath "$file.err" -ErrorAction SilentlyContinue)
    $at = [Array]::FindIndex([string[]]$crash, [Predicate[string]]{ param($l) $l -match '^The compiler crashed' })
    if ($at -ge 0) {
        $text = (@($crash[$at..($crash.Count - 1)] | ForEach-Object { $_ } | Select-Object -First 12) -join "`n") -replace '(?s)\n(At .+:\d+ char:\d+|\s*\+ ).*$', '' -replace '\s*\n\s*', ' '
        [void][Windows.Forms.MessageBox]::Show($form, $text.Trim(), 'The build failed', 'OK', 'Warning')
        return
    }
    $e = Get-FirstBuildError $file
    $what = if ($e) { "The first error:`r`n$($e.Line)" + $(if ($e.Making) { "`r`n(while making $($e.Making))" }) } else { 'The build stopped without naming an error.' }
    if ($e) { $log.AppendText("`r`nThe build's first error: $($e.Line)`r`n") }
    $free = Get-Ttt2FreeGB $ThisInstall
    $causes = "The usual causes:`r`n" +
        ("- The disk is full: the build needs about 1 GB free on {0} (it has {1:N1} GB).`r`n" -f (Get-Ttt2DriveName $ThisInstall), $free) +
        "- The folder is inside OneDrive or another synced folder (the Desktop and Documents often are): move the whole folder to C:\ttt2 or another drive and start Start Here from there.`r`n" +
        "- An antivirus blocked or removed a file: look in Windows Security, Protection history, restore it there, then click Install again."
    $synced = Get-Ttt2SyncedFolder $ThisInstall
    if ($synced) { $causes = "This folder is inside $synced, the most likely cause: move it to C:\ttt2 or another drive.`r`n`r`n$causes" }
    if ($pathNote = Get-Ttt2NonAsciiPathNote $ThisInstall) { $causes = "$pathNote`r`n`r`n$causes" }
    [void][Windows.Forms.MessageBox]::Show($form, "$what`r`n`r`n$causes`r`n`r`nIf it still fails, click Report a problem: it sends us the build's log.", 'The build failed', 'OK', 'Warning')
}

$timer = New-Object Windows.Forms.Timer
$timer.Interval = 700
$timer.Add_Tick({
    Finish-UpdateCheck
    if ($script:logFile -and (Test-Path -LiteralPath $script:logFile)) {
        try {
            $fs = [IO.File]::Open($script:logFile, 'Open', 'Read', 'ReadWrite')
            $fs.Seek($script:logPos, 'Begin') | Out-Null
            $reader = New-Object IO.StreamReader($fs)
            $new = $reader.ReadToEnd()
            $script:logPos = $fs.Position
            $reader.Close()
            if ($new) {
                # Whole lines only. PROGRESS lines and Ninja's "[done/total]" lines drive the bar.
                $text = $script:partial + $new.Replace("`r", '')
                $lines = $text.Split("`n")
                $script:partial = $lines[-1]
                $whole = if ($lines.Count -gt 1) { $lines[0..($lines.Count - 2)] } else { @() }
                foreach ($line in $whole) {
                    if ($line -match '^PROGRESS (\d+) ?(.*)$') {
                        # A step's own progress (extracting the ISO): the bar, and a line in the
                        # text at every tenth.
                        $pct = [math]::Min(100, [int]$Matches[1])
                        $what = if ($Matches[2]) { $Matches[2] } else { 'Working' }
                        if ($script:installRun) { $what = Get-PartLabel $script:current }   # ("Install, part 2 of 3: the game files: 45%")
                        $bar.Value = $pct
                        $bar.Visible = $true
                        $busy.Text = "${what}: $pct%"
                        if ([int][math]::Floor($pct / 10) -gt $script:lastTen) {
                            $script:lastTen = [int][math]::Floor($pct / 10)
                            $log.AppendText("${what}: $pct%`r`n")
                        }
                        continue
                    }
                    $log.AppendText($line + "`r`n")
                    if ($line -match '^== (.+)$') { $script:phase = $Matches[1] }
                    if ($line -match '^\[(\d+)/(\d+)\]') {
                        # The build's progress, from Ninja's "[done/total]" lines.
                        $done = [int]$Matches[1]; $total = [math]::Max(1, [int]$Matches[2])
                        $bar.Value = [math]::Min(100, [int](100 * $done / $total))
                        $bar.Visible = $true
                        $what = if ($script:phase) { $script:phase } else { 'Building' }
                        if ($script:installRun) { $what = Get-PartLabel $script:current }
                        $busy.Text = "${what}: $done of $total"
                    }
                }
            }
            # A build writes thousands of lines: keep the window's text to the last part.
            if ($log.TextLength -gt 300000) { $log.Text = $log.Text.Substring($log.TextLength - 150000); $log.SelectionStart = $log.TextLength; $log.ScrollToCaret() }
        } catch { }
    }
    if ($script:proc -and $script:proc.HasExited) {
        if ($script:current -eq 'play') { Update-DisplayNote }
        $code = $script:proc.ExitCode
        $err = "$($script:logFile).err"
        $script:proc = $null
        Write-StartHerePid 'idle'
        $bar.Visible = $false
        if ($script:partial -and $script:partial -notmatch '^PROGRESS ') { $log.AppendText($script:partial + "`r`n") }
        $script:partial = ''
        if ($code -eq 0) {
            $busy.Text = "Step finished: $($script:current)"
            $busy.ForeColor = [Drawing.Color]::Green
            if ($script:current -eq 'update') { Restart-AfterUpdate; return }
            if ($script:current -eq 'update-file') { Finish-FileUpdate; return }
            if ($script:current -eq 'adopt') { Finish-Adopt; return }
            if ($script:current -eq 'move') { Update-DataRow }
            if ($script:current -eq 'files') { Write-Setting 'files-stale' 'false' }
            if ($script:installRun) {
                # (Install: the next part at once; the last one done says so.)
                $script:installRun.Parts.RemoveAt(0)
                if ($script:installRun.Parts.Count) { Start-Step $script:installRun.Parts[0] (Get-PartArgs $script:installRun.Parts[0]); return }
                $script:installRun = $null
                $busy.Text = 'Install finished: press Play.'
            }
        } else {
            $stepWord = if ($script:installRun) { "$(Get-PartLabel $script:current) stopped" } else { "Step failed: $($script:current)" }
            if ($script:installRun) {
                $part = $script:current
                $script:installRun = $null
                $log.AppendText("`r`n$(Get-PartLabel $part) stopped. Fix what the messages say, then click Install again: it goes on from this part.`r`n")
            }
            $busy.Text = if ($stepWord -like "Install*") { "$stepWord. See the messages above; then click Install again (it goes on from this part)." } else { "$stepWord. See the messages above." }
            $busy.ForeColor = [Drawing.Color]::Red
            $errText = if (Test-Path -LiteralPath $err) { "$(Get-Content -LiteralPath $err -Raw)" } else { '' }
            if ($errText) { $log.AppendText("`r`n" + $errText) }
            # (A step that fails in a folder whose path has characters outside plain ASCII: that line too, the likely cause.)
            $pathNote = Get-Ttt2NonAsciiPathNote $ThisInstall
            if ($pathNote) {
                $log.AppendText("`r`n$pathNote`r`n")
                $busy.Text = "$stepWord. This folder's path has special characters: move it to C:\ttt2."
            }
            # (An antivirus took xexpatch.exe, the title update's patcher: what to do, in a box as well; the lead's G1.)
            $tail = $log.Text.Substring([Math]::Max(0, $log.TextLength - 4000))
            $shown = $false
            if (($errText + $tail) -match 'may have removed xexpatch\.exe') {
                [Windows.Forms.MessageBox]::Show($form, $XexpatchMissingNote, 'A file was removed', 'OK', 'Warning') | Out-Null
                $shown = $true
            }
            # (D2 and G3: any of our files gone.)
            if (-not $shown -and ($missingNote = Get-Ttt2MissingFilesNote $ThisInstall)) {
                [Windows.Forms.MessageBox]::Show($form, $missingNote, 'Files are missing', 'OK', 'Warning') | Out-Null
                $shown = $true
            }
            # (The lead's F: a failed build says its first error, not only Ninja's last line, and the usual causes.)
            if (-not $shown -and $script:current -eq 'build') { Show-BuildFailure $script:logFile; $shown = $true }
            if (-not $shown -and $pathNote) { [void][Windows.Forms.MessageBox]::Show($form, $pathNote, $stepWord, 'OK', 'Warning') }
        }
        Refresh-Buttons
    }
})
$timer.Start()

# --- the buttons ------------------------------------------------------------------------------
# What is wrong with the file picked as the title update, or $null (the same check as setup-steps.ps1's, whose
# param block can't be loaded here; keep the two alike). A friend picked the ISO again (23 Oct).
function Get-UpdateFileProblem([string]$update, [string]$source) {
    if (-not (Test-Path -LiteralPath $update -PathType Leaf)) { return 'Choose your title update file (named like TU_174Q22P_...).' }
    $full = [IO.Path]::GetFullPath($update)
    if (($source -and $full -eq [IO.Path]::GetFullPath($source)) -or $full -match '(?i)\.iso$') {
        return "That's your game's disc image, not the title update. The second file is the game's update from your Xbox 360. It's named like TU_174Q22P_0000008000000.00000000000O2 and is about 3 MB. See `"The title update`" in README.txt."
    }
    $size = (Get-Item -LiteralPath $full).Length
    if ($size -gt 100MB) { return ("That file is {0:N0} MB, but the title update is about 3 MB and named like TU_174Q22P_... See `"The title update`" in README.txt." -f ($size / 1MB)) }
    $head = New-Object byte[] 4
    $f = [IO.File]::OpenRead($full)
    try { $n = $f.Read($head, 0, 4) } finally { $f.Close() }
    $magic = [Text.Encoding]::ASCII.GetString($head, 0, $n)
    if ($magic -notin @('CON ', 'LIVE', 'PIRS')) {
        return "That file isn't an Xbox 360 update package (it should start with LIVE, CON or PIRS). Pick the file named like TU_174Q22P_0000008000000.00000000000O2, copied off the console as it is."
    }
    return $null
}

# 1. Choose my game + update: the picks only, with their checks; nothing runs. (Old step 2's dialogs.)
$choose.Add_Click({
    # (TTT2_TEST_PICKS=<game ISO or folder>|<title update file>: test only, the two pickers' answers given, the checks as always.)
    if ($env:TTT2_TEST_PICKS) {
        $source, $update = $env:TTT2_TEST_PICKS -split '\|', 2
        if ($problem = Get-UpdateFileProblem $update $source) { [void][Windows.Forms.MessageBox]::Show($form, $problem, 'Your title update', 'OK', 'Warning'); return }
        if ((Test-Path -LiteralPath $source -PathType Leaf) -and -not (Confirm-StepSpace 2 (Get-Ttt2DataFolder) (Get-Ttt2FolderGB (Join-Path (Get-Ttt2DataFolder) 'game')))) { return }
        Write-Setting 'game-source' $source
        Write-Setting 'game-update' $update
        if ((Read-Status).files) { Write-Setting 'files-stale' 'true' }
        $busy.Text = 'Your game and its update are picked: click Install.'
        $busy.ForeColor = [Drawing.Color]::Green
        Refresh-Buttons
        return
    }
    $choice = [Windows.Forms.MessageBox]::Show(
        "Do you have an ISO file of your TTT2 disc?`n`nYes: pick the .iso file.`nNo: pick the folder that has default.xex and the data*.bin files.",
        'Your game', 'YesNoCancel', 'Question')
    if ($choice -eq 'Cancel') { return }
    $source = $null
    if ($choice -eq 'Yes') {
        $d = New-Object Windows.Forms.OpenFileDialog
        $d.Title = 'Your TTT2 ISO'
        $d.Filter = 'Disc images (*.iso)|*.iso|All files (*.*)|*.*'
        if ($d.ShowDialog() -eq 'OK') { $source = $d.FileName }
    } else {
        $d = New-Object Windows.Forms.FolderBrowserDialog
        $d.Description = 'The folder with default.xex and the data*.bin files'
        if ($d.ShowDialog() -eq 'OK') { $source = $d.SelectedPath }
        if ($source -and -not (Test-Path -LiteralPath (Join-Path $source 'default.xex'))) {
            [void][Windows.Forms.MessageBox]::Show($form, "That folder has no default.xex. Pick the folder with default.xex and the data*.bin files (your game's disc, copied as it is).", 'Your game', 'OK', 'Warning')
            return
        }
    }
    if (-not $source) { return }
    $u = New-Object Windows.Forms.OpenFileDialog
    $u.Title = 'Your title update file (named like TU_174Q22P_...)'
    $u.Filter = 'All files (*.*)|*.*'
    # (Checked before anything runs, so a wrong pick costs no ISO extraction: setup-steps.ps1's
    # Get-UpdateFileProblem checks the same again. Asked again until it's right or cancelled.)
    while ($true) {
        if ($u.ShowDialog() -ne 'OK') { return }
        $problem = Get-UpdateFileProblem $u.FileName $source
        if (-not $problem) { break }
        [void][Windows.Forms.MessageBox]::Show($form, $problem, 'Your title update', 'OK', 'Warning')
    }
    # (An ISO is extracted into the data folder: room for it first; the old extraction there is replaced.)
    if ((Test-Path -LiteralPath $source -PathType Leaf) -and -not (Confirm-StepSpace 2 (Get-Ttt2DataFolder) (Get-Ttt2FolderGB (Join-Path (Get-Ttt2DataFolder) 'game')))) { return }
    Write-Setting 'game-source' $source
    Write-Setting 'game-update' $u.FileName
    if ((Read-Status).files) { Write-Setting 'files-stale' 'true' }   # (new picks: Install makes the game files again)
    $busy.Text = 'Your game and its update are picked: click Install.'
    $busy.ForeColor = [Drawing.Color]::Green
    Refresh-Buttons
})

# A part's switches for setup-steps.ps1.
function Get-PartArgs($part) {
    switch ($part) {
        'tools' { if ($script:prebuilt) { , @('-AcceptMicrosoftLicense') } else { , @() } }
        'files' { $p = Get-Picks; , @('-Source', "`"$($p.Source)`"", '-Update', "`"$($p.Update)`"") }
        default { , @() }
    }
}
# 2. Install: the parts left, each asked about first (room, Microsoft's license, the folder), then run back to back.
# -Auto (after an update): no "how long" box; Microsoft's license is still asked when the tools must be downloaded.
function Start-Install([switch]$Auto, [switch]$Again) {
    $s = Read-Status
    if (-not (Test-ChooseDone $s)) {
        if (-not $Auto) { [void][Windows.Forms.MessageBox]::Show($form, 'Click 1. Choose my game + update first.', 'Install', 'OK', 'Information') }
        return
    }
    $parts = Get-InstallParts $s
    if (-not $parts.Count) {
        if ($Auto) { return }
        $r = [Windows.Forms.MessageBox]::Show($form, "Everything is installed and up to date.`r`n`r`nBuild the game again anyway?", 'Install', 'YesNo', 'Question')
        if ($r -ne 'Yes') { return }
        $parts.Add('build')
    }
    if (-not $Auto) {
        $times = @{
            tools = 'the tools: a compiler, about 1.1 GB to download and 5 GB unpacked (about 5-15 minutes)'
            files = 'the game files: your game copied or extracted, about 8 GB (about 5-10 minutes)'
            build = 'the build: the game built on this PC (about 3 to 5 minutes the first time, more on an older PC; later builds are quicker)'
        }
        $list = ($parts | ForEach-Object { "- $($times[$_])" }) -join "`r`n"
        $r = [Windows.Forms.MessageBox]::Show($form, "Install does, one after the other:`r`n$list`r`n`r`nLeave this window open until it says it's finished. Start now?", 'Install', 'OKCancel', 'Information')
        if ($r -ne 'OK') { return }
    }
    if ($parts.Contains('tools') -and $script:prebuilt) {
        # (The lead's E: room for the compiler first, unless it is all there; what is there counts as taken.)
        $root = Get-Ttt2ToolchainRoot
        if (-not (Test-Path -LiteralPath (Join-Path (Get-Ttt2PinFolder $root $script:Ttt2ToolchainPins.llvm) 'ttt2-unpacked.txt')) -and
            -not (Confirm-StepSpace 1 (Get-Ttt2DataFolder) (Get-Ttt2FolderGB $root))) { return }
        # The prebuilt package's compiler needs Microsoft's C++ runtime libraries and Windows SDK, downloaded from
        # Microsoft: only after the player accepts Microsoft's license.
        $text = "Install downloads a compiler: LLVM, CMake and Ninja from their official releases, and Microsoft's C++ runtime libraries and Windows SDK from Microsoft.`r`n`r`n" +
                "Microsoft's parts come under Microsoft's license terms:`r`nhttps://go.microsoft.com/fwlink/?LinkId=2086102`r`n`r`n" +
                "Do you accept Microsoft's license terms? (No: nothing is downloaded.)"
        if ([Windows.Forms.MessageBox]::Show($form, $text, "Microsoft's license", 'YesNo', 'Question') -ne 'Yes') { return }
    }
    if ($parts.Contains('build') -and -not $Auto) {
        # (The lead's F: a build inside OneDrive or another synced folder failed with only "ninja: build stopped"; E: its room.)
        if ($note = Get-Ttt2SyncedFolderNote $ThisInstall 'This folder') {
            $r = [Windows.Forms.MessageBox]::Show($form, "$note`r`n`r`nBuild here anyway?", 'A synced folder', 'YesNo', 'Warning')
            if ($r -ne 'Yes') { return }
        }
        if (-not (Confirm-StepSpace 3 $ThisInstall)) { return }
        # (A path with a character outside plain ASCII: the build's code generator can't read it, 27 Oct. Said before it starts.)
        if ($name = Get-Ttt2NonAsciiFolder $ThisInstall) {
            [void][Windows.Forms.MessageBox]::Show($form, "This folder's path has characters the build's tools can't handle ($name): the build would fail.`r`n`r`nMove the whole folder to C:\ttt2 and start Start Here from there.", 'A folder name with special characters', 'OK', 'Warning')
            return
        }
    }
    $script:installRun = @{ Parts = $parts; Auto = [bool]$Auto }
    Start-Step $parts[0] (Get-PartArgs $parts[0])
}
$install.Add_Click({ Start-Install })
# The player's name (the gamertag the game shows): kept in player-name.txt in the profile folder
# (%LOCALAPPDATA%\TTT2Native\profile, tools\profile-folder.ps1; rex\userdata\player-name.txt before 23 October, copied
# over once), asked for the first time Play is pressed, changed from the button below. 1 to 15 letters, digits and
# spaces (the game refuses anything else and shows "User").
. (Join-Path $Rex 'tools\profile-folder.ps1')
$NameFile = Join-Path (Get-ProfileFolder) 'player-name.txt'
if (-not (Test-Path -LiteralPath $NameFile) -and (Test-Path -LiteralPath (Join-Path $Rex 'userdata\player-name.txt'))) {
    New-Item -ItemType Directory -Force (Split-Path $NameFile -Parent) | Out-Null
    Copy-Item -LiteralPath (Join-Path $Rex 'userdata\player-name.txt') $NameFile -ErrorAction SilentlyContinue
}
function Get-PlayerName {
    if (Test-Path -LiteralPath $NameFile) { return "$(Get-Content -LiteralPath $NameFile -Raw)".Trim() }
    return ''
}
function Ask-PlayerName {
    $dialog = New-Object Windows.Forms.Form
    $dialog.Text = 'Your name'
    $dialog.ClientSize = New-Object Drawing.Size(360, 120)
    $dialog.StartPosition = 'CenterParent'
    $dialog.FormBorderStyle = 'FixedDialog'
    $dialog.MaximizeBox = $false; $dialog.MinimizeBox = $false
    $dialog.Font = $font
    $label = New-Object Windows.Forms.Label
    $label.Text = 'The name the game shows for you (1 to 15 letters, digits and spaces):'
    $label.SetBounds(12, 10, 340, 36)
    $dialog.Controls.Add($label)
    $box = New-Object Windows.Forms.TextBox
    $box.Text = Get-PlayerName
    $box.MaxLength = 15
    $box.SetBounds(12, 50, 336, 26)
    $dialog.Controls.Add($box)
    $ok = New-Object Windows.Forms.Button
    $ok.Text = 'OK'; $ok.SetBounds(188, 84, 76, 28); $ok.DialogResult = 'OK'
    $cancel = New-Object Windows.Forms.Button
    $cancel.Text = 'Cancel'; $cancel.SetBounds(272, 84, 76, 28); $cancel.DialogResult = 'Cancel'
    $dialog.Controls.Add($ok); $dialog.Controls.Add($cancel)
    $dialog.AcceptButton = $ok; $dialog.CancelButton = $cancel
    while ($true) {
        if ($dialog.ShowDialog($form) -ne 'OK') { return $false }
        $name = $box.Text.Trim()
        if ($name -match '^[A-Za-z0-9 ]{1,15}$') {
            New-Item -ItemType Directory -Force (Split-Path $NameFile -Parent) | Out-Null
            [IO.File]::WriteAllText($NameFile, $name)
            return $true
        }
        [Windows.Forms.MessageBox]::Show('1 to 15 letters, digits and spaces, please.', 'Your name', 'OK', 'Information') | Out-Null
    }
}
# (The "Your name..." button that was here is "Change name..." in the profile row since 24 October: further down.)

# --- keeping itself up to date (the lead's order of 17 Oct, the owner's word) --------------------------
# At every launch, in the background: rex\package-info.txt (track, patch) against the feed's latest.json
# (-UpdateUrl: the public feed by default, or a local folder for a test). A newer patch of this track is
# downloaded, checked, unzipped and copied over this folder by setup-steps.ps1 -Step update (the saves, the
# game files, the builds and rex\game-folder.txt never touched), then Start Here restarts and builds.
# "Update automatically" (rex\userdata\launcher-settings.txt) off: a banner and an "Update now" button
# instead. Not while the game runs (the game lock): deferred to the next launch.
. (Join-Path $Rex 'tools\game-lock.ps1')
$SettingsFile = Join-Path $Rex 'userdata\launcher-settings.txt'
$UpdateLog = Join-Path $Logs 'update-check.log'
$script:package = @{ track = 'main'; patch = 0; commit = '' }
$script:latest = $null
$script:checkJob = $null
$script:updating = $false

function Read-Package {
    $info = @{ track = 'main'; patch = 0; commit = '' }
    $file = Join-Path $Rex 'package-info.txt'
    if (Test-Path -LiteralPath $file) {
        foreach ($line in Get-Content -LiteralPath $file) { if ($line -match '^(\w+)=(.*)$') { $info[$Matches[1]] = $Matches[2].Trim() } }
        $info.patch = [int]$info.patch
    }
    return $info
}
function Read-Setting($name, $default) {
    if (Test-Path -LiteralPath $SettingsFile) {
        foreach ($line in Get-Content -LiteralPath $SettingsFile) { if ($line -match "^$name=(.*)$") { return $Matches[1].Trim() } }
    }
    return $default
}
function Write-Setting($name, $value) {
    $lines = @()
    if (Test-Path -LiteralPath $SettingsFile) { $lines = @(Get-Content -LiteralPath $SettingsFile | Where-Object { $_ -notmatch "^$name=" }) }
    New-Item -ItemType Directory -Force (Split-Path $SettingsFile -Parent) | Out-Null
    Set-Content -LiteralPath $SettingsFile ($lines + "$name=$value")
}
# --- the display (the lead's item A, 17 Oct; the sizes and the greying, 19 Oct) ----------------------
# "Display": Borderless fullscreen (a borderless window over the monitor; the default), Fullscreen (the
# display taken over in its own mode), or a window of a set size: 1280x720 and 1920x1080, and 2560x1440 and
# 3840x2160 only where the monitor the game opens on (the main one) is at least that big. The sizes are the
# window's inside in real pixels (--window_pixel_width/height, runtime patch 32); the game draws at its own
# 1280x720 as on the console and the runtime scales the finished frame to the window.
# "Allow tearing": each frame goes to the screen the moment it is ready (vsync off, the lowest lag); a window
# never tears: while a window size is chosen the box is unticked and greyed (a fullscreen choice again makes it
# tickable; it stays unticked). The window sizes are always in the list (the owner, 21 October: ticking the box
# hid them, and they couldn't be found). Both kept in launcher-settings.txt (display=,
# tearing=), read by run-windows.ps1 and passed to the game as switches. F11 or Alt+Enter toggles fullscreen
# in the game for that run only. When the game's log says the PC can't do tearing, a note says so here.
Add-Type -Namespace TTT2 -Name Screen -MemberDefinition @'
[DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr h);
[DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr h, IntPtr dc);
[DllImport("gdi32.dll")] public static extern int GetDeviceCaps(IntPtr dc, int index);
'@
# The main monitor's size in real pixels (DESKTOPHORZRES, DESKTOPVERTRES: not scaled by Windows' text size).
$dc = [TTT2.Screen]::GetDC([IntPtr]::Zero)
$script:screenWidth = [TTT2.Screen]::GetDeviceCaps($dc, 118)
$script:screenHeight = [TTT2.Screen]::GetDeviceCaps($dc, 117)
[void][TTT2.Screen]::ReleaseDC([IntPtr]::Zero, $dc)
$DisplayNames = [ordered]@{ borderless = 'Borderless fullscreen'; fullscreen = 'Fullscreen' }
foreach ($size in @(@(1280, 720), @(1920, 1080), @(2560, 1440), @(3840, 2160))) {
    $w, $h = $size
    if ($w -gt 1920 -and ($w -gt $script:screenWidth -or $h -gt $script:screenHeight)) { continue }
    $DisplayNames["windowed-${w}x$h"] = "Windowed ${w}x$h"
}
function Is-Windowed($key) { return "$key" -like 'windowed*' }
$backButton = New-Object Windows.Forms.Button
$backButton.Text = '<- Back to Start Here'
$backButton.Font = New-Object Drawing.Font('Segoe UI', 10, [Drawing.FontStyle]::Bold)
$backButton.SetBounds(16, 12, 180, 32)
$backButton.Add_Click({ $tabs.SelectedTab = $front })
$settingsPage.Controls.Add($backButton)
# (The page's sections, the owner's design: a small blue header, then its rows; $SetY is the next free row.)
function Add-SettingsHeader([string]$text) {
    $h = New-Object Windows.Forms.Label
    $h.Text = $text
    $h.Font = New-Object Drawing.Font('Segoe UI', 9, [Drawing.FontStyle]::Bold)
    $h.ForeColor = [Drawing.ColorTranslator]::FromHtml('#0067C0')
    $h.SetBounds(16, $script:SetY, 600, 18)
    $settingsPage.Controls.Add($h)
    $script:SetY += 20
}
$SetY = 52
Add-SettingsHeader 'DISPLAY'
$displayBox = New-Object Windows.Forms.ComboBox
$displayBox.DropDownStyle = 'DropDownList'
$displayBox.SetBounds(16, $SetY, 230, 24)
$settingsPage.Controls.Add($displayBox)
$allowTearing = New-Object Windows.Forms.CheckBox
$allowTearing.Text = 'Allow tearing (lowest lag, vsync off)'
$allowTearing.SetBounds(260, $SetY, 364, 24)
$allowTearing.Checked = (Read-Setting 'tearing' 'false') -eq 'true'
$settingsPage.Controls.Add($allowTearing)
$displayNote = New-Object Windows.Forms.Label
$displayNote.SetBounds(16, ($SetY + 28), 608, 20)
$displayNote.ForeColor = [Drawing.Color]::Gray
$settingsPage.Controls.Add($displayNote)
$script:displayChoice = "$(Read-Setting 'display' 'borderless')".ToLower()
# (An old "windowed" is the 1920x1080 window, or 1280x720 on a monitor too small for it.)
if ($script:displayChoice -eq 'windowed') {
    $script:displayChoice = if ($DisplayNames.Contains('windowed-1920x1080') -and $script:screenWidth -ge 1920 -and $script:screenHeight -ge 1080) { 'windowed-1920x1080' } else { 'windowed-1280x720' }
    Write-Setting 'display' $script:displayChoice
}
if (-not $DisplayNames.Contains($script:displayChoice)) { $script:displayChoice = 'borderless' }
if ($allowTearing.Checked -and (Is-Windowed $script:displayChoice)) { $allowTearing.Checked = $false; Write-Setting 'tearing' 'false' }
$script:filling = $false
function Fill-DisplayBox {
    $script:filling = $true
    $displayBox.Items.Clear()
    foreach ($key in $DisplayNames.Keys) {
        [void]$displayBox.Items.Add($DisplayNames[$key])
    }
    $displayBox.SelectedItem = $DisplayNames[$script:displayChoice]
    $script:filling = $false
}
function Update-TearingBox {
    # A window never tears: the box unticked and greyed while a window size is chosen.
    if (Is-Windowed $script:displayChoice) {
        if ($allowTearing.Checked) { $allowTearing.Checked = $false }
        $allowTearing.Enabled = $false
    } else {
        $allowTearing.Enabled = $true
    }
}
# The game's newest log says whether this PC can do tearing (the runtime asks DXGI at its start).
function Update-DisplayNote {
    $note = 'F11 or Alt+Enter toggles fullscreen in the game for that run (the choice here stays).'
    if (Is-Windowed $script:displayChoice) { $note = 'A window never tears: "Allow tearing" needs a fullscreen choice.' }
    $displayNote.ForeColor = [Drawing.Color]::Gray
    $last = Get-ChildItem -LiteralPath $GameLogs -Filter 'ttt2_*.log' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime | Select-Object -Last 1
    if ($last) {
        $line = Select-String -LiteralPath $last.FullName -Pattern 'DXGI tearing \(vertical sync off\): (NOT supported|supported)' | Select-Object -First 1
        if ($line -and $line.Matches[0].Groups[1].Value -eq 'NOT supported') {
            $note = "This PC can't do tearing (so says the game's log): frames are shown with vsync as usual."
            if ($allowTearing.Checked) { $displayNote.ForeColor = [Drawing.Color]::DarkOrange }
        }
    }
    $displayNote.Text = $note
}
Fill-DisplayBox
Update-TearingBox
Update-DisplayNote
$displayBox.Add_SelectedIndexChanged({
    if ($script:filling) { return }
    foreach ($key in $DisplayNames.Keys) { if ($DisplayNames[$key] -eq $displayBox.SelectedItem) { $script:displayChoice = $key } }
    Write-Setting 'display' $script:displayChoice
    Update-TearingBox
    Update-DisplayNote
})
$allowTearing.Add_CheckedChanged({
    Write-Setting 'tearing' $(if ($allowTearing.Checked) { 'true' } else { 'false' })
    if ($allowTearing.Checked -and (Is-Windowed $script:displayChoice)) { $script:displayChoice = 'borderless'; Write-Setting 'display' 'borderless' }
    Fill-DisplayBox
    Update-DisplayNote
})

# --- online (the lead's order of 19 Oct): one Play, training always on --------------------------------
# A build with the online code (rex\src\online, Themail's) shows "Play online" here, on by default
# (the owner, 21 Oct; unticked, online=false is kept); with it on, Play signs in to the game's Live
# menus over the internet (setup-steps.ps1's Step-Play adds the switches); unticked, Play plays without them.
# A build without the online code doesn't show it.
$script:hasOnline = (Test-Path -LiteralPath (Join-Path $Rex 'online-build.txt')) -or (Test-Path -LiteralPath (Join-Path $Rex 'src\online'))   # (the prebuilt package: the marker)
$onlineBox = New-Object Windows.Forms.CheckBox
$onlineBox.Text = 'Play online (untick to play offline, with no internet)'
$onlineBox.Checked = (Read-Setting 'online' 'true') -ne 'false'   # (on by default: the owner, 21 Oct; unticking keeps online=false)
$onlineBox.Add_CheckedChanged({ Write-Setting 'online' $(if ($onlineBox.Checked) { 'true' } else { 'false' }) })
$SetY += 54
Add-SettingsHeader 'PLAY'
if ($script:hasOnline) {
    $onlineBox.SetBounds(16, $SetY, 600, 24)
    $settingsPage.Controls.Add($onlineBox)
    $SetY += 26
}
# --- the keyboard as player one (the lead's order of 23 Oct, the owner's word): on by default (keyboard=false
# keeps it off); Play then gives the game --ttt2_keyboard=true, our keyboard layer with rex\userdata\keyboard.txt's keys,
# and the SDK's own keyboard always off (--mnk_mode=false; setup-steps.ps1's Step-Play).
$keyboardBox = New-Object Windows.Forms.CheckBox
$keyboardBox.Text = 'Keyboard (W A S D move, U I J K attack, P tag)'
$keyboardBox.Checked = (Read-Setting 'keyboard' 'true') -ne 'false'
$keyboardBox.Add_CheckedChanged({ Write-Setting 'keyboard' $(if ($keyboardBox.Checked) { 'true' } else { 'false' }) })
$keyboardRow = $SetY
$keyboardBox.SetBounds(16, $keyboardRow, 600, 24)
$settingsPage.Controls.Add($keyboardBox)
$SetY = $keyboardRow + 26
# --- who the keyboard plays (the controls update, 1 Nov): keyboard-player= gives Play --ttt2_keyboard_player; none is player 1.
$keyboardPlayerLabel = New-Object Windows.Forms.Label
$keyboardPlayerLabel.Text = 'Keyboard plays as:'
$keyboardPlayerLabel.SetBounds(34, ($SetY + 3), 120, 20)
$settingsPage.Controls.Add($keyboardPlayerLabel)
$keyboardPlayerBox = New-Object Windows.Forms.ComboBox
$keyboardPlayerBox.DropDownStyle = 'DropDownList'
[void]$keyboardPlayerBox.Items.AddRange(@('Player 1', 'Player 2', 'Both (two sets of keys)', 'Each keyboard its own player'))
$keyboardPlayerValues = @('1', '2', 'both', 'each')
$keyboardPlayerBox.SelectedIndex = [Math]::Max(0, [Array]::IndexOf($keyboardPlayerValues, (Read-Setting 'keyboard-player' '1')))
$keyboardPlayerBox.Add_SelectedIndexChanged({ Write-Setting 'keyboard-player' $keyboardPlayerValues[$keyboardPlayerBox.SelectedIndex] })
$keyboardPlayerBox.SetBounds(156, $SetY, 240, 24)
$settingsPage.Controls.Add($keyboardPlayerBox)
$SetY += 28
# --- controller vibration (the owner, 24 Oct: off by default, with an option): vibration=true gives Play --ttt2_vibration=true.
$vibrationBox = New-Object Windows.Forms.CheckBox
$vibrationBox.Text = 'Controller vibration'
$vibrationBox.Checked = (Read-Setting 'vibration' 'false') -eq 'true'
$vibrationBox.Add_CheckedChanged({ Write-Setting 'vibration' $(if ($vibrationBox.Checked) { 'true' } else { 'false' }) })
$vibrationRow = $SetY
$vibrationBox.SetBounds(16, $vibrationRow, 600, 24)
$settingsPage.Controls.Add($vibrationBox)
$SetY = $vibrationRow + 26
# --- No intro (the owner, 24 Oct: the splash, then straight to the main menu): on by default (nointro=false keeps the
# game's own intro); Play then gives --ttt2_no_intro=true (quick_boot.cpp).
$noIntroBox = New-Object Windows.Forms.CheckBox
$noIntroBox.Text = 'Skip the intro (straight to the main menu)'
$noIntroBox.Checked = (Read-Setting 'nointro' 'true') -ne 'false'
$noIntroBox.Add_CheckedChanged({ Write-Setting 'nointro' $(if ($noIntroBox.Checked) { 'true' } else { 'false' }) })
$noIntroRow = $SetY
$noIntroBox.SetBounds(16, $noIntroRow, 600, 24)
$settingsPage.Controls.Add($noIntroBox)
$SetY = $noIntroRow + 26
# --- Mute in the background (the owner, 4.5): on by default, the game's own --ttt2_mute_in_background (mute.cpp); unticked
# (mutebg=false) Play gives --ttt2_mute_in_background=false and the sound goes on while the game is behind another window.
$muteBgBox = New-Object Windows.Forms.CheckBox
$muteBgBox.Text = "Mute the game when it's in the background"
$muteBgBox.Checked = (Read-Setting 'mutebg' 'true') -ne 'false'
$muteBgBox.Add_CheckedChanged({ Write-Setting 'mutebg' $(if ($muteBgBox.Checked) { 'true' } else { 'false' }) })
$muteBgRow = $SetY
$muteBgBox.SetBounds(16, $muteBgRow, 600, 24)
$settingsPage.Controls.Add($muteBgBox)
$SetY = $muteBgRow + 26
# --- TEKKEN TUNES with the player's own MP3s (4.6; rex\src\tunes_hooks.cpp): off by default (tunes=true gives Play
# --ttt2_tekken_tunes=true). The music folder is Music\TTT2 Tunes, made if it isn't there, or the one the player chooses (the owner,
# 1 Nov; tunes-folder= gives Play --ttt2_tekken_tunes_folder; plain ASCII paths only, as the switch goes through the setting file's code page).
# The folder is the player's own (not in the game folder or the profile's backup), so updates and reinstalls leave it and its MP3s alone.
function Get-TunesDefaultFolder { Join-Path ([Environment]::GetFolderPath('MyMusic')) 'TTT2 Tunes' }
function Get-TunesFolder { $chosen = Read-Setting 'tunes-folder' ''; if ($chosen) { $chosen } else { Get-TunesDefaultFolder } }
$tunesBox = New-Object Windows.Forms.CheckBox
$tunesBox.Text = 'TEKKEN TUNES: my own music (MP3s)'
$tunesBox.Checked = (Read-Setting 'tunes' 'false') -eq 'true'
$tunesBox.Add_CheckedChanged({ Write-Setting 'tunes' $(if ($tunesBox.Checked) { 'true' } else { 'false' }) })
$tunesFolder = New-Object Windows.Forms.Button
$tunesFolder.Text = 'Open folder'
$tunesFolder.Add_Click({
    try {
        $music = Get-TunesFolder
        New-Item -ItemType Directory -Force -Path $music | Out-Null
        Invoke-Item -LiteralPath $music
    } catch {}
})
$tunesWhere = New-Object Windows.Forms.Label
$tunesWhere.ForeColor = [Drawing.Color]::Gray
$tunesWhere.AutoEllipsis = $true
$tunesWhere.Text = "Music folder: $(Get-TunesFolder)"
$tunesChoose = New-Object Windows.Forms.Button
$tunesChoose.Text = 'Choose folder...'
$tunesChoose.Add_Click({
    $d = New-Object Windows.Forms.FolderBrowserDialog
    $d.Description = 'The folder with your MP3s (its folders become albums). Files in it are only read.'
    $d.ShowNewFolderButton = $true
    $d.SelectedPath = Get-TunesFolder
    if ($d.ShowDialog($form) -ne 'OK') { return }
    if ($d.SelectedPath -match '[^\x20-\x7E]') {
        [void][Windows.Forms.MessageBox]::Show($form, "That folder's path has characters the game can't take here. Rename it, or use one with plain English letters and numbers.", 'TEKKEN TUNES', 'OK', 'Warning')
        return
    }
    Write-Setting 'tunes-folder' $(if ($d.SelectedPath -eq (Get-TunesDefaultFolder)) { '' } else { $d.SelectedPath })
    $tunesWhere.Text = "Music folder: $(Get-TunesFolder)"
})
$tunesRow = $SetY
$tunesBox.SetBounds(16, $tunesRow + 3, 290, 24)
$tunesChoose.SetBounds(310, $tunesRow, 150, 30)
$tunesFolder.SetBounds(468, $tunesRow, 150, 30)
$tunesWhere.SetBounds(34, $tunesRow + 31, 584, 18)
$settingsPage.Controls.Add($tunesBox)
$settingsPage.Controls.Add($tunesChoose)
$settingsPage.Controls.Add($tunesFolder)
$settingsPage.Controls.Add($tunesWhere)
$SetY = $tunesRow + 56
# --- VOICE CHAT (4.7, rex\src\online\voip.cpp; the owner, 1 Nov): off by default (voip=true gives Play --ttt2_voip=true). The microphone picker lists the recording devices
# present, by the names the game's SDL3 lists (rex\tools\voip-mics.ps1); voip-mic=<name> in the settings, empty = the Windows default. The chosen name reaches the game through
# a file (userdata\voip-mic.txt, setup-steps.ps1's Get-PlaySwitches), never the command line: a device name can hold a person's name ("Sam's AirPods"), and it must not
# land in a log or a report. Nothing here is sent anywhere.
. (Join-Path $Rex 'tools\voip-mics.ps1')
$voipBox = New-Object Windows.Forms.CheckBox
$voipBox.Text = 'Voice chat in online matches (off by default)'
$voipBox.Checked = (Read-Setting 'voip' 'false') -eq 'true'
$voipMicLabel = New-Object Windows.Forms.Label
$voipMicLabel.Text = 'Microphone:'
$voipMicLabel.TextAlign = 'MiddleLeft'
$voipMic = New-Object Windows.Forms.ComboBox
$voipMic.DropDownStyle = 'DropDownList'
$voipNote = New-Object Windows.Forms.Label
$voipNote.ForeColor = [Drawing.Color]::Gray
$voipNote.Text = 'Open microphone with a noise gate. Both players need it on. F8 mutes your opponent (Ctrl+F8 your own microphone). A headset is recommended. Nothing is recorded or sent anywhere but to your opponent.'
$script:voipMicValues = @('')
$script:voipMicFilling = $false
# (the list is read when the box is on and each time the drop-down opens, so a headset plugged in later shows; the saved choice stays selected, marked when it is not plugged in)
function Update-VoipMicList {
    $saved = Read-Setting 'voip-mic' ''
    $names = @(Get-VoipMicrophones)
    $script:voipMicFilling = $true
    $voipMic.Items.Clear()
    $script:voipMicValues = @('')
    [void]$voipMic.Items.Add('Windows default')
    foreach ($n in $names) { [void]$voipMic.Items.Add($n); $script:voipMicValues += $n }
    $pick = 0
    if ($saved) {
        $at = [Array]::IndexOf($script:voipMicValues, $saved)
        if ($at -lt 0) { [void]$voipMic.Items.Add("$saved (not plugged in)"); $script:voipMicValues += $saved; $at = $script:voipMicValues.Count - 1 }
        $pick = $at
    }
    $voipMic.SelectedIndex = $pick
    $script:voipMicFilling = $false
}
$voipMic.Enabled = $voipBox.Checked
[void]$voipMic.Items.Add('Windows default')
$voipMic.SelectedIndex = 0
if ($voipBox.Checked) { Update-VoipMicList }
$voipMic.Add_DropDown({ Update-VoipMicList })
$voipMic.Add_SelectedIndexChanged({
    if ($script:voipMicFilling -or $voipMic.SelectedIndex -lt 0 -or $voipMic.SelectedIndex -ge $script:voipMicValues.Count) { return }
    Write-Setting 'voip-mic' $script:voipMicValues[$voipMic.SelectedIndex]
})
$voipBox.Add_CheckedChanged({
    Write-Setting 'voip' $(if ($voipBox.Checked) { 'true' } else { 'false' })
    $voipMic.Enabled = $voipBox.Checked
    if ($voipBox.Checked) { Update-VoipMicList }
})
$voipRow = $SetY
$voipBox.SetBounds(16, $voipRow + 3, 590, 24)
$voipMicLabel.SetBounds(34, $voipRow + 30, 80, 24)
$voipMic.SetBounds(116, $voipRow + 31, 480, 24)
$voipNote.SetBounds(34, $voipRow + 60, 584, 34)
$settingsPage.Controls.Add($voipBox)
$settingsPage.Controls.Add($voipMicLabel)
$settingsPage.Controls.Add($voipMic)
$settingsPage.Controls.Add($voipNote)
$SetY = $voipRow + 100
# --- the logs sent by themselves (23 Oct, the owner: "make sure the log is still on, just with an option to turn it off"). Each online fight's log is OFF since the
# public launch (27 Oct) and has no box since the design of 1 Nov (Report a problem covers it): logupload=true in launcher-settings.txt still gives testers Play's --ttt2_log_autoupload.
# "Send crash logs" (crashlog=false keeps it off) is the game's --ttt2_log_autoupload_crash: a run that crashed has its log sent at the next start (setup-steps.ps1's Step-Play; rex\src\online\log_upload.cpp).
$crashLogBox = New-Object Windows.Forms.CheckBox
$crashLogBox.Text = 'Send crash logs (addresses and your name removed)'
$crashLogBox.Checked = (Read-Setting 'crashlog' 'true') -ne 'false'
$crashLogBox.Add_CheckedChanged({ Write-Setting 'crashlog' $(if ($crashLogBox.Checked) { 'true' } else { 'false' }) })
if ($script:hasOnline) {
    # --- Ranked fights' record (the owner, 30 Oct, 4.5.1; 1 Nov: this player's own only): the plates show wins only (--ttt2_ranked_record_wins_only, on); this box
    # (rankedrecord=full, off by default) shows this player's own losses and win rate, on this PC only: Play and play-switches.txt give the game
    # --ttt2_ranked_record_wins_only=false (setup-steps.ps1's Write-PlaySwitches). The opponent's line stays wins only. Nothing is sent; the opponent's screen is as before.
    Add-SettingsHeader 'RANKED'
    $rankedRecordBox = New-Object Windows.Forms.CheckBox
    $rankedRecordBox.Text = 'Show my own losses and win rate (only on my screen)'
    $rankedRecordBox.Checked = (Read-Setting 'rankedrecord' 'wins') -eq 'full'
    $rankedRecordBox.Add_CheckedChanged({ Write-Setting 'rankedrecord' $(if ($rankedRecordBox.Checked) { 'full' } else { 'wins' }) })
    $rankedRecordBox.SetBounds(16, $SetY, 600, 24)
    $settingsPage.Controls.Add($rankedRecordBox)
    $SetY += 32
}

function Note-Update($text) { Add-Content -LiteralPath $UpdateLog "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $text" }
function Game-Running { $l = Get-GameLock; return [bool]($l -and (Test-GameLockLive $l)) }
# This install's fast client is open (it runs its game hidden behind it; closing it closes the game). An update can't
# replace its exe or Qt's DLLs while it runs: it's closed first, or the update waits (fastclient/PACKAGING.md 5).
function FastClient-Running {
    $exe = $script:fastClientExe
    return [bool](Get-Process ttt2-fastclient -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path -eq $exe })
}
# (The client's files keep the zip's downloaded mark (4.5, the owner: clearing Mark of the Web is a known evasion signal; it
# was cleared here since 24 Oct). Start-FastClient starts the client directly, so Windows asks nothing (a shell-executed start with the
# mark asked at every start); opening ttt2-fastclient.exe by hand from Explorer may still ask, Windows' own way. Updates carry no mark.)

# (A release by its package-info name, "Release 4.1", as the Discord post calls it; else "Release <patch>".)
function Release-Label($p) { if ($p.name) { "$($p.name)" } else { "Release $($p.patch)" } }

$script:package = Read-Package
$form.Text = 'TTT2 native - ' + $(switch ($script:package.track) {
    'release' { Release-Label $script:package }
    'training' { "training Patch $($script:package.patch)" }
    default { "Patch $($script:package.patch) (main)" } })

$updateBanner = New-Object Windows.Forms.Label
$updateBanner.SetBounds(16, ($ButtonsTop + 116), 608, 24)
$updateBanner.ForeColor = [Drawing.Color]::DarkOrange
$updateBanner.Visible = $false
$front.Controls.Add($updateBanner)
$updateNow = New-Object Windows.Forms.Button
$updateNow.Text = 'Update now'
$updateNow.SetBounds(16, ($ButtonsTop + 84), 100, 28)
$updateNow.Visible = $false
$front.Controls.Add($updateNow)
$checkUpdates = New-Object Windows.Forms.Button
$checkUpdates.Text = 'Check for updates'
$checkUpdates.SetBounds(124, ($ButtonsTop + 84), 160, 28)
$front.Controls.Add($checkUpdates)
$autoUpdate = New-Object Windows.Forms.CheckBox
$autoUpdate.Text = 'Update automatically'
Add-SettingsHeader 'UPDATES AND PROBLEMS'
$autoUpdate.SetBounds(16, $SetY, 600, 24)
$SetY += 26
$autoUpdate.Checked = (Read-Setting 'auto-update' 'true') -ne 'false'
$autoUpdate.Add_CheckedChanged({ Write-Setting 'auto-update' $(if ($autoUpdate.Checked) { 'true' } else { 'false' }) })
$settingsPage.Controls.Add($autoUpdate)
if ($script:hasOnline) {
    $crashLogBox.SetBounds(16, $SetY, 600, 24)
    $settingsPage.Controls.Add($crashLogBox)
    $SetY += 26
}
# --- Uninstall (the owner, 31 Oct; docs/UNINSTALL_PLAN_20261031.md; rex\tools\uninstall.ps1 works out what, uninstall-finish.ps1 deletes): on this
# page, away from Play, and nothing goes until the last box's Uninstall.
$uninstallButton = New-Object Windows.Forms.Button
$uninstallButton.Text = 'Uninstall...'
$uninstallButton.SetBounds(16, $SetY + 6, 120, 28)
$settingsPage.Controls.Add($uninstallButton)
$SetY += 40

# --- the player's profile: name and icon (the owner, 24 October: a profile icon picker; native_port/PROFILE_ICONS_SPEC_20261024.md) ----------------
# A row under the intro: the player's icon, name, and "Change icon..." / "Change name...". The icon shows beside the name on the leaderboard website and in
# the game. The set is rex\assets\profile-icons (icons.json and a 64 x 64 PNG each: the designer's art, rex\tools\import-profile-icons.ps1). The choice is
# kept in profile-icon.txt in the profile folder (beside player-name.txt) and sent to the server signed with the player's key (rex\tools\identity.ps1);
# the server takes only an icon the player has: the free ones, and the ones it has unlocked for them (their rank in Ranked). Without internet, or before the
# game's first online start (no identity yet), the choice stays here and the game sends it at its next online start (live\icon.reg: the one the server took).
. (Join-Path $Rex 'tools\identity.ps1')
$IconDir = Join-Path $Rex 'assets\profile-icons'
$IconFile = Join-Path (Get-ProfileFolder) 'profile-icon.txt'
$IconCache = Join-Path (Get-ProfileFolder) 'icon-unlocks.json'
$IconSent = Join-Path (Get-ProfileFolder) 'live\icon.reg'
$Worker = if ($env:TTT2_WORKER) { $env:TTT2_WORKER } else { Read-Setting 'worker' 'https://elo.bluespark.site' }

function Read-IconSet {
    $f = Join-Path $IconDir 'icons.json'
    if (-not (Test-Path -LiteralPath $f)) { return @() }
    try { return @((Get-Content -LiteralPath $f -Raw | ConvertFrom-Json).icons | Where-Object { -not $_.retired -and (Test-Path -LiteralPath (Join-Path $IconDir $_.file)) }) } catch { return @() }
}
function Get-IconChoice {
    if (Test-Path -LiteralPath $IconFile) { $t = "$(Get-Content -LiteralPath $IconFile -Raw)".Trim(); if ($t -match '^\d{1,5}$') { return [int]$t } }
    return 0
}
function Open-IconBitmap($icon) {
    # (a copy in memory: the file is not kept open, so an update can replace it)
    try {
        $ms = New-Object IO.MemoryStream(, [IO.File]::ReadAllBytes((Join-Path $IconDir $icon.file)))
        $img = [Drawing.Image]::FromStream($ms); $bmp = New-Object Drawing.Bitmap($img); $img.Dispose(); $ms.Dispose()
        return $bmp
    } catch { return $null }
}
# A locked icon: dimmed (its colour kept: the set's icons differ by colour), with a padlock in the corner.
function New-LockedBitmap($bmp) {
    $out = New-Object Drawing.Bitmap(64, 64, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [Drawing.Graphics]::FromImage($out)
    $g.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
    [single[][]]$m = @([single[]](0.55, 0, 0, 0, 0), [single[]](0, 0.55, 0, 0, 0), [single[]](0, 0, 0.55, 0, 0), [single[]](0, 0, 0, 0.8, 0), [single[]](0, 0, 0, 0, 1))
    $attr = New-Object Drawing.Imaging.ImageAttributes
    $attr.SetColorMatrix((New-Object Drawing.Imaging.ColorMatrix(, $m)))
    $g.DrawImage($bmp, (New-Object Drawing.Rectangle(0, 0, 64, 64)), 0, 0, $bmp.Width, $bmp.Height, [Drawing.GraphicsUnit]::Pixel, $attr)
    $pen = New-Object Drawing.Pen([Drawing.Color]::White, 3)
    $g.DrawArc($pen, 42, 30, 14, 16, 180, 180)
    $g.FillRectangle((New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(235, 30, 30, 36))), 38, 38, 22, 18)
    $g.DrawRectangle((New-Object Drawing.Pen([Drawing.Color]::White, 2)), 38, 38, 22, 18)
    $g.FillEllipse([Drawing.Brushes]::White, 46, 43, 6, 6)
    $g.Dispose()
    return $out
}
# How to get a locked icon when the server hasn't said (offline): from the rule in icons.json.
function Get-LocalHint($icon) {
    $u = $icon.unlock
    if ($u -is [string]) { if ($u -eq 'manual') { return 'Given by the BlueSpark team' } else { return '' } }
    if ($u.rank) { if ($u.rank -eq 'True Tekken God') { return 'Reach True Tekken God in Ranked (top 20 on the leaderboard, 100+ games)' } else { return "Reach $($u.rank) in Ranked" } }
    if ($u.list) { if ($u.list -eq 'developers') { return 'Given to the BlueSpark developers' } else { return 'Given by the BlueSpark team' } }
    if ($null -ne $u.season) { $last = (@($u.season) | Measure-Object -Maximum).Maximum; if ($last -eq 1) { return 'Playtesters: play a Ranked match before the release reset' } else { return "Players of season $last" } }
    if ($u.games) { return "Play $($u.games) Ranked games" }
    if ($u.wins) { return "Win $($u.wins) Ranked games" }
    return ''
}
function Read-IconCache { if (Test-Path -LiteralPath $IconCache) { try { return (Get-Content -LiteralPath $IconCache -Raw | ConvertFrom-Json) } catch { } }; return $null }

# (The row under the intro, at $ProfileTop: the front page leaves room for it, 4.5.1.)
$profilePic = New-Object Windows.Forms.PictureBox
$profilePic.SetBounds(16, $ProfileTop, 48, 48)
$profilePic.SizeMode = 'Zoom'
$profilePic.Cursor = [Windows.Forms.Cursors]::Hand
$front.Controls.Add($profilePic)
$profileName = New-Object Windows.Forms.Label
$profileName.SetBounds(74, ($ProfileTop + 2), 300, 24)
$profileName.Font = $big
$front.Controls.Add($profileName)
$profileIcon = New-Object Windows.Forms.Label
$profileIcon.SetBounds(74, ($ProfileTop + 27), 300, 20)
$profileIcon.ForeColor = [Drawing.Color]::DimGray
$front.Controls.Add($profileIcon)
$changeIcon = New-Object Windows.Forms.Button
$changeIcon.Text = 'Change icon...'
$changeIcon.SetBounds(384, ($ProfileTop + 8), 120, 32)
$front.Controls.Add($changeIcon)
$changeName = New-Object Windows.Forms.Button
$changeName.Text = 'Change name...'
$changeName.SetBounds(510, ($ProfileTop + 8), 114, 32)
$front.Controls.Add($changeName)

# --- where the tools and game files go (the lead's E, 27 Oct; a player's C: was full): a row under the profile's. The
# choice is kept in %LOCALAPPDATA%\TTT2Native\data-folder.txt (rex\tools\data-folder.ps1); the profile, logs, backups
# and installs.txt stay where they are.
# (At $DataTop, under the profile row.)
$dataLabel = New-Object Windows.Forms.Label
$dataLabel.Text = 'Tools and game files:'
$dataLabel.SetBounds(16, ($DataTop + 8), 150, 22)
$front.Controls.Add($dataLabel)
$dataPath = New-Object Windows.Forms.Label
$dataPath.SetBounds(166, ($DataTop + 8), 336, 22)
$dataPath.AutoEllipsis = $true
$dataPath.ForeColor = [Drawing.Color]::DimGray
$front.Controls.Add($dataPath)
$changeData = New-Object Windows.Forms.Button
$changeData.Text = 'Change...'
$changeData.SetBounds(510, ($DataTop + 2), 114, 32)
$front.Controls.Add($changeData)
$dataTip = New-Object Windows.Forms.ToolTip
function Update-DataRow {
    $d = Get-Ttt2DataFolder
    $free = Get-Ttt2FreeGB $d
    $dataPath.Text = if ($free -ge 0) { "{0} {1:N0} GB free   {2}" -f (Get-Ttt2DriveName $d), $free, $d } else { "(that drive isn't there)   $d" }
    $dataTip.SetToolTip($dataPath, "Where to put the tools and game files: the compiler (Install's tools, about 5 GB) and your extracted ISO (Install's game files, about 8 GB).`r`n$d")
}
# The player picks a folder; a TTT2Native folder is made in it (unless it is one). The tools and game files already in
# the old folder: moved there (setup-steps.ps1 -Step move, in the background, with the bar), or left and installed again.
# A folder that already has the tools: used as it is.
function Choose-DataFolder {
    if ($script:proc) { return $false }
    $old = Get-Ttt2DataFolder
    $d = New-Object Windows.Forms.FolderBrowserDialog
    $d.Description = 'Where to put the tools and game files (about 13 GB: the compiler and your extracted ISO). A TTT2Native folder is made in the folder you pick.'
    $d.ShowNewFolderButton = $true
    if ($d.ShowDialog($form) -ne 'OK') { return $false }
    $picked = $d.SelectedPath.TrimEnd('\')
    $new = if ((Split-Path $picked -Leaf) -eq 'TTT2Native') { $picked } else { Join-Path $picked 'TTT2Native' }
    if ($new -eq $old.TrimEnd('\')) { return $false }
    if ($note = Get-Ttt2SyncedFolderNote $new 'That folder') {
        [void][Windows.Forms.MessageBox]::Show($form, "$note`r`n`r`nChoose a folder that isn't synced.", 'Tools and game files', 'OK', 'Warning')
        return $false
    }
    $newTools = (Get-Command Get-Ttt2PinFolder -ErrorAction SilentlyContinue) -and
                (Test-Path -LiteralPath (Join-Path (Get-Ttt2PinFolder (Join-Path $new 'toolchain') $script:Ttt2ToolchainPins.llvm) 'ttt2-unpacked.txt'))
    if ($newTools) {
        $r = [Windows.Forms.MessageBox]::Show($form, "$new already has the tools. Use them?`r`n`r`n(What is in $old stays there; you can delete it yourself.)", 'Tools and game files', 'YesNo', 'Question')
        if ($r -ne 'Yes') { return $false }
        Set-Ttt2DataFolder $new; Update-DataRow; Refresh-Buttons
        return $true
    }
    $have = @($script:Ttt2DataParts | Where-Object { Test-Path -LiteralPath (Join-Path $old $_) })
    if ($have.Count) {
        $gb = ($have | ForEach-Object { Get-Ttt2FolderGB (Join-Path $old $_) } | Measure-Object -Sum).Sum
        $r = [Windows.Forms.MessageBox]::Show($form,
            ("Move the tools and game files you have ({0:N1} GB in {1}) to {2}?`r`n`r`nYes: move them (a few minutes to another drive).`r`nNo: leave them where they are and install again in the new folder (Install's tools and game files again; then you can delete {1} yourself)." -f $gb, $old, $new),
            'Tools and game files', 'YesNoCancel', 'Question')
        if ($r -eq 'Cancel') { return $false }
        if ($r -eq 'Yes') { Start-Step 'move' @('-From', "`"$old`"", '-To', "`"$new`""); return $true }
    }
    Set-Ttt2DataFolder $new; Update-DataRow; Refresh-Buttons
    return $true
}
$changeData.Add_Click({ [void](Choose-DataFolder) })
# Before steps 1, 2 and 3 (the lead's E): the drive's free space against what the step needs; short, the sentence and
# (steps 1 and 2) another folder offered. True when the step may start.
function Confirm-StepSpace([int]$n, [string]$path, [double]$haveGB = 0) {
    $problem = Get-Ttt2SpaceProblem $n $path $haveGB
    if (-not $problem) { return $true }
    if ($n -eq 3) {
        [void][Windows.Forms.MessageBox]::Show($form, "$problem The build goes in this folder. Free some space on that drive, then click Install again.", 'Not enough disk space', 'OK', 'Warning')
        return $false
    }
    $r = [Windows.Forms.MessageBox]::Show($form, "$problem`r`n`r`nChoose another folder for the tools and game files? (No: free some space on that drive yourself first.)", 'Not enough disk space', 'YesNo', 'Warning')
    if ($r -eq 'Yes') { [void](Choose-DataFolder) }
    return $false
}
Update-DataRow

function Update-ProfileRow {
    $set = Read-IconSet
    $id = Get-IconChoice
    $icon = $set | Where-Object { [int]$_.id -eq $id } | Select-Object -First 1
    if (-not $icon) { $icon = $set | Where-Object { [int]$_.id -eq 0 } | Select-Object -First 1 }
    if ($profilePic.Image) { $profilePic.Image.Dispose() }
    $profilePic.Image = if ($icon) { Open-IconBitmap $icon } else { $null }
    $n = Get-PlayerName
    $profileName.Text = if ($n) { $n } else { '(no name yet: Change name...)' }
    $profileIcon.Text = if ($icon) { "Icon: $($icon.name)" } else { 'Icon: none (this package has no icons)' }
    $changeIcon.Enabled = [bool]$set.Count
}
$changeName.Add_Click({ if (Ask-PlayerName) { Update-ProfileRow } })

# The picker: the player's icons first (the default emblem, the free ones, the ones earned), then the locked ones greyed with how to get them.
function Show-IconPicker {
    $set = Read-IconSet
    if (-not $set.Count) { return }
    $xuid = Read-IdentityXuid (Get-ProfileFolder)
    $dlg = New-Object Windows.Forms.Form
    $dlg.Text = 'Your profile icon'
    $dlg.ClientSize = New-Object Drawing.Size(600, 540)
    $dlg.StartPosition = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    $dlg.Font = $font
    $intro = New-Object Windows.Forms.Label
    $intro.Text = 'Shown beside your name on the leaderboard website and in the game. Locked icons unlock as you rank up in Ranked, and stay yours.'
    $intro.SetBounds(12, 10, 576, 40)
    $dlg.Controls.Add($intro)
    $lv = New-Object Windows.Forms.ListView
    $lv.View = 'LargeIcon'; $lv.MultiSelect = $false; $lv.HideSelection = $false
    $lv.SetBounds(12, 52, 576, 382)
    $images = New-Object Windows.Forms.ImageList
    $images.ImageSize = New-Object Drawing.Size(64, 64)
    $images.ColorDepth = 'Depth32Bit'
    $lv.LargeImageList = $images
    $gYours = New-Object Windows.Forms.ListViewGroup('Yours')
    $gLocked = New-Object Windows.Forms.ListViewGroup('Locked')
    [void]$lv.Groups.Add($gYours); [void]$lv.Groups.Add($gLocked)
    $dlg.Controls.Add($lv)
    $info = New-Object Windows.Forms.Label
    $info.SetBounds(12, 440, 576, 44)
    $dlg.Controls.Add($info)
    $status = New-Object Windows.Forms.Label
    $status.SetBounds(12, 488, 380, 44)
    $status.ForeColor = [Drawing.Color]::DimGray
    $dlg.Controls.Add($status)
    $ok = New-Object Windows.Forms.Button
    $ok.Text = 'Use this icon'; $ok.SetBounds(398, 496, 108, 32)
    $cancel = New-Object Windows.Forms.Button
    $cancel.Text = 'Cancel'; $cancel.SetBounds(512, 496, 76, 32); $cancel.DialogResult = 'Cancel'
    $dlg.Controls.Add($ok); $dlg.Controls.Add($cancel); $dlg.CancelButton = $cancel

    foreach ($icon in $set) {
        $bmp = Open-IconBitmap $icon
        if (-not $bmp) { continue }
        $images.Images.Add("u$($icon.id)", $bmp)
        $images.Images.Add("l$($icon.id)", (New-LockedBitmap $bmp))
    }
    # What the player has: the server's answer (GET /v1/icons), or the last one kept here, or (neither) only the free icons and the one chosen.
    $state = @{ answer = (Read-IconCache); fresh = $false; seen = @() }
    if ($state.answer -and $state.answer.xuid -ne $xuid) { $state.answer = $null }   # (another player's answer: not used)
    if ($state.answer) { $state.seen = @($state.answer.earned | ForEach-Object { [int]$_.id }) }
    $current = Get-IconChoice
    $fill = {
        $a = $state.answer
        $earned = @(); $locked = @{}
        if ($a) { $earned = @($a.earned | ForEach-Object { [int]$_.id }); foreach ($l in @($a.locked)) { $locked[[int]$l.id] = $l } }
        $keep = if ($lv.SelectedItems.Count) { [int]$lv.SelectedItems[0].Tag } else { $current }
        $lv.BeginUpdate(); $lv.Items.Clear()
        foreach ($icon in $set) {
            $id = [int]$icon.id
            if (-not $images.Images.ContainsKey("u$id")) { continue }
            $free = $icon.unlock -is [string] -and $icon.unlock -eq 'default'
            $have = $free -or ($earned -contains $id) -or (-not $a -and $id -eq $current)
            if ($a -and -not $have -and -not $locked.ContainsKey($id)) { continue }   # (the server doesn't list it: no longer offered, or given by hand)
            if (-not $a -and -not $have -and ($icon.unlock -eq 'manual' -or $icon.unlock.list)) { continue }   # (no answer: an icon only given by hand stays hidden)
            $text = "$($icon.name)"
            if ($have -and -not $free -and $state.fresh -and ($state.seen -notcontains $id)) { $text += ' (new!)' }
            $item = New-Object Windows.Forms.ListViewItem($text, $(if ($have) { "u$id" } else { "l$id" }))
            $item.Tag = $id
            $item.Group = if ($have) { $gYours } else { $gLocked }
            [void]$lv.Items.Add($item)
            if ($id -eq $keep) { $item.Selected = $true; $item.Focused = $true }
        }
        $lv.EndUpdate()
        if ($lv.SelectedItems.Count) { $lv.SelectedItems[0].EnsureVisible() }
    }
    $describe = {
        if (-not $lv.SelectedItems.Count) { $info.Text = ''; $ok.Enabled = $false; return }
        $item = $lv.SelectedItems[0]; $id = [int]$item.Tag
        $icon = $set | Where-Object { [int]$_.id -eq $id } | Select-Object -First 1
        if ($item.Group -eq $gYours) { $info.Text = "$($icon.name)$(if ($id -eq $current) { ' (your icon now)' })"; $ok.Enabled = $id -ne $current; return }
        $l = if ($state.answer) { @($state.answer.locked) | Where-Object { [int]$_.id -eq $id } | Select-Object -First 1 } else { $null }
        $hint = if ($l -and $l.hint) { $l.hint } else { Get-LocalHint $icon }
        $more = if ($l -and $l.now) { " You are $($l.now) now." } elseif ($l -and $l.need) { " $($l.have) / $($l.need) so far." } else { '' }
        $info.Text = "$($icon.name): locked. $hint.$more"
        $ok.Enabled = $false
    }
    $lv.Add_SelectedIndexChanged($describe)
    & $fill; & $describe

    # The server's answer, in the background (5 s).
    # (Handlers run in their own scope each time: what they change lives in these tables, never in plain variables.)
    $net = @{ job = $null }
    if (-not $xuid) { $status.Text = "Play online once and the icons you unlock in Ranked show here. Your choice is kept on this PC until then." }
    else {
        $status.Text = 'Checking what you have unlocked...'
        $net.job = Start-Job -ArgumentList $Worker, $xuid -ScriptBlock {
            param($worker, $x)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; return (Invoke-WebRequest -UseBasicParsing -Uri "$worker/v1/icons?x=$x" -TimeoutSec 6 -Headers @{ 'User-Agent' = 'ttt2-launcher' }).Content }
            catch { return 'ERROR ' + $_.Exception.Message }
        }
    }
    $saving = @{ job = $null; id = 0; at = $null }
    $tick = New-Object Windows.Forms.Timer
    $tick.Interval = 300
    $tick.Add_Tick({
        $j = $net.job
        if ($j -and $j.State -ne 'Running') {
            $text = "$(Receive-Job $j -ErrorAction SilentlyContinue | Select-Object -Last 1)"
            Remove-Job $j -Force -ErrorAction SilentlyContinue; $net.job = $null
            $a = $null; if ($text -and -not $text.StartsWith('ERROR')) { try { $a = $text | ConvertFrom-Json } catch { } }
            if ($a -and $a.ok) {
                $a | Add-Member -NotePropertyName xuid -NotePropertyValue $xuid -Force
                $state.answer = $a; $state.fresh = $true
                try { [IO.File]::WriteAllText($IconCache, ($a | ConvertTo-Json -Depth 5 -Compress)) } catch { }
                $status.Text = ''
                & $fill; & $describe
            } else {
                $status.Text = if ($state.answer) { "The server didn't answer: this is what this PC last heard." } else { "The server didn't answer: only the free icons are shown." }
            }
        }
        $s = $saving.job
        if ($s -and ($s.State -ne 'Running' -or ((Get-Date) - $saving.at).TotalSeconds -gt 10)) {
            $r = "$(Receive-Job $s -ErrorAction SilentlyContinue | Select-Object -Last 1)"
            Remove-Job $s -Force -ErrorAction SilentlyContinue; $saving.job = $null
            if ($r.StartsWith('OK')) {
                [IO.File]::WriteAllText($IconFile, "$($saving.id)")
                New-Item -ItemType Directory -Force (Split-Path $IconSent -Parent) | Out-Null
                [IO.File]::WriteAllText($IconSent, "$xuid $($saving.id)")
                $playState.Text = 'Icon saved. The leaderboard shows it soon.'
                $dlg.DialogResult = 'OK'; $dlg.Close()
            } elseif ($r.StartsWith('REFUSED')) {
                $status.Text = "The server didn't take it: $($r.Substring(8))"
                $lv.Enabled = $true; $cancel.Enabled = $true; & $describe
            } else {
                [IO.File]::WriteAllText($IconFile, "$($saving.id)")   # (offline: kept here; the game sends it at its next online start)
                $playState.Text = 'Icon saved here: sent when you next play online.'
                $dlg.DialogResult = 'OK'; $dlg.Close()
            }
        }
    })
    $tick.Start()
    $choose = {
        if (-not $ok.Enabled -or -not $lv.SelectedItems.Count) { return }
        $id = [int]$lv.SelectedItems[0].Tag
        New-Item -ItemType Directory -Force (Split-Path $IconFile -Parent) | Out-Null
        if (-not $xuid) {
            [IO.File]::WriteAllText($IconFile, "$id")
            $playState.Text = 'Icon saved here: sent when you next play online.'
            $dlg.DialogResult = 'OK'; $dlg.Close(); return
        }
        $ok.Enabled = $false; $lv.Enabled = $false; $cancel.Enabled = $false
        $status.Text = 'Saving...'
        $saving.id = $id; $saving.at = Get-Date
        $saving.job = Start-Job -ArgumentList $Rex, (Get-ProfileFolder), $Worker, $id -ScriptBlock {
            param($rex, $profile, $worker, $icon)
            . (Join-Path $rex 'tools\identity.ps1')
            $me = Read-Identity $profile
            if (-not $me) { return 'OFFLINE no key' }
            $ts = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
            $sig = Sign-Text $me.ec "TTT2-ICON`n1`n$($me.xuid)`n$icon`n$ts"
            $body = '{"xuid":"' + $me.xuid + '","icon":' + [int]$icon + ',"ts":' + $ts + ',"sig":"' + $sig + '"}'
            try {
                [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
                $null = Invoke-WebRequest -UseBasicParsing -Method Post -Uri "$worker/v1/icon" -Body $body -ContentType 'application/json' -TimeoutSec 8 -Headers @{ 'User-Agent' = 'ttt2-launcher' }
                return 'OK'
            } catch {
                $code = 0; try { $code = [int]$_.Exception.Response.StatusCode } catch { }
                if ($code -ge 400 -and $code -lt 500 -and $code -ne 429) {
                    $msg = "$($_.ErrorDetails.Message)"; try { $msg = ($msg | ConvertFrom-Json).msg } catch { }
                    return "REFUSED $msg"
                }
                return 'OFFLINE ' + $_.Exception.Message
            }
        }
    }
    $ok.Add_Click($choose)
    $lv.Add_ItemActivate($choose)
    [void]$dlg.ShowDialog($form)
    $tick.Stop(); $tick.Dispose()
    foreach ($j in @($net.job, $saving.job)) { if ($j) { Remove-Job $j -Force -ErrorAction SilentlyContinue } }
    # (what the player has now seen: no "new!" next time)
    if ($state.fresh -and $state.answer) { try { [IO.File]::WriteAllText($IconCache, ($state.answer | ConvertTo-Json -Depth 5 -Compress)) } catch { } }
    $dlg.Dispose()
    Update-ProfileRow
}
$changeIcon.Add_Click({ Show-IconPicker })
$profilePic.Add_Click({ Show-IconPicker })
Update-ProfileRow

# The check, in a job (5 s), its answer taken by the timer below.
function Start-UpdateCheck {
    if ($script:checkJob) { return }
    $updateBanner.Text = 'Checking for updates...'; $updateBanner.Visible = $true; $updateNow.Visible = $false
    $script:checkJob = Start-Job -ArgumentList $UpdateUrl, $script:package.track -ScriptBlock {
        param($url, $track)
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            if (Test-Path -LiteralPath $url -PathType Container) { $feed = Get-Content -LiteralPath (Join-Path $url 'latest.json') -Raw | ConvertFrom-Json }
            else { $feed = Invoke-RestMethod $url -TimeoutSec 5 -Headers @{ 'User-Agent' = 'ttt2-launcher' } }
            # (The public feed is flat: one build line, "release" N.)
            if ($feed.release) { return ($feed | ConvertTo-Json -Compress) }
            return 'ERROR: the feed has no release number'
        } catch { return 'ERROR: ' + $_.Exception.Message }
    }
}
function Finish-UpdateCheck {
    if (-not $script:checkJob -or $script:checkJob.State -eq 'Running') { return }
    $answer = Receive-Job $script:checkJob -ErrorAction SilentlyContinue | Select-Object -Last 1
    Remove-Job $script:checkJob -Force -ErrorAction SilentlyContinue
    $script:checkJob = $null
    # (A dropped zip being installed keeps its banner: the feed's answer only goes to the log then.)
    if ($script:zipUpdate) { Note-Update "The feed's answer (a dropped zip is being installed): $answer"; return }
    if (-not $answer -or "$answer" -like 'ERROR:*') {
        Note-Update "The check failed: $answer"
        $updateBanner.Visible = $false
        return
    }
    $script:latest = "$answer" | ConvertFrom-Json
    # (This folder's package-info read again at each check (4.5): a second Start Here window, or the one the game's "Close and
    # update" started, may have updated the folder since this one began, and the old number held here showed a false red line.)
    $script:package = Read-Package
    # (Only a public package, track=release with patch=N, updates itself: when the feed's release number is
    # higher. An internal one (main, training) only hears that a release is out.)
    $script:latest | Add-Member -NotePropertyName patch -NotePropertyValue ([int]$script:latest.release) -Force
    if ($script:package.track -ne 'release') {
        if ([int]$script:latest.patch -gt $script:package.patch) {
            Note-Update "$(Release-Label $script:latest) is out; this is an internal $($script:package.track) package (Patch $($script:package.patch)): it does not update from the public feed."
            $updateBanner.Text = "$(Release-Label $script:latest) is out (this is an internal build: it does not update itself)."
            $updateBanner.ForeColor = [Drawing.Color]::DarkOrange
        } else {
            Note-Update "$(Release-Label $script:latest) is the newest public build; this is an internal $($script:package.track) package (Patch $($script:package.patch))."
            $updateBanner.Visible = $false
        }
        return
    }
    if ([int]$script:latest.patch -le $script:package.patch) {
        Note-Update "$(Release-Label $script:latest) is the newest; this is $(Release-Label $script:package)."
        $updateBanner.Text = "You have the newest build ($(Release-Label $script:package))."
        $updateBanner.ForeColor = [Drawing.Color]::Green
        return
    }
    Note-Update "$(Release-Label $script:latest) is out (this is $(Release-Label $script:package))."
    # (Never the same package twice: an update that left the patch number behind (a feed and a zip that disagree)
    # would loop through restarts otherwise, 17 Oct.)
    if ((Read-Setting 'last-update' '') -eq "$($script:latest.commit)") {
        Note-Update "$(Release-Label $script:latest) ($($script:latest.commit)) was installed already and this folder still says $(Release-Label $script:package): not again."
        $updateBanner.Text = "The update to $(Release-Label $script:latest) didn't take: close every Start Here window, open it again."
        $updateBanner.ForeColor = [Drawing.Color]::Red
        $log.AppendText("The update to $(Release-Label $script:latest) was installed once, but this folder still says $(Release-Label $script:package).`r`n" +
                        "  1. Close the game and every Start Here window, then open Start Here again.`r`n" +
                        "  2. If this line comes back: download the $(Release-Label $script:latest) zip and drag it onto this window.`r`n" +
                        "  3. If that fails too: Report a problem.cmd, and send the report.`r`n")
        return
    }
    $updateBanner.ForeColor = [Drawing.Color]::DarkOrange
    if ((Game-Running) -or (FastClient-Running)) {
        $updateBanner.Text = "$(Release-Label $script:latest) is out: it will be installed after you close the game, at the next start."
        $updateNow.Visible = $true
        return
    }
    # (-InstallUpdate: the game's update popup started us, its "Close and update": installed whatever the box says.)
    if (($autoUpdate.Checked -or $InstallUpdate) -and -not $script:proc) { Start-Update; return }
    $updateBanner.Text = "$(Release-Label $script:latest) is out."
    $updateNow.Visible = $true
}
function Start-Update {
    if ($script:proc -or -not $script:latest) { return }
    if (Game-Running) { $updateBanner.Text = 'Update after you close the game.'; return }
    if (FastClient-Running) { $updateBanner.Text = 'Update after you close Play BlueSpark.'; return }
    $script:updating = $true
    $updateBanner.Text = "Updating to $(Release-Label $script:latest)..."; $updateNow.Visible = $false
    Start-Step 'update' @('-UpdateUrl', "`"$UpdateUrl`"", '-Patch', "$($script:latest.patch)")
    $log.AppendText("Updating to $(Release-Label $script:latest):`r`n")
    foreach ($note in @($script:latest.notes)) { $log.AppendText("  - $note`r`n") }
}
# After the update step: this launcher is the old one, so the new one is started (it builds by itself).
function Restart-AfterUpdate {
    $script:updating = $false
    Write-Setting 'last-update' "$($script:latest.commit)"   # (only an update that went through counts)
    $arguments = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$(Join-Path $Rex 'launcher.ps1')`"", '-AutoBuild')
    if ($UpdateUrl -ne $DefaultUpdateUrl) { $arguments += @('-UpdateUrl', "`"$UpdateUrl`"") }
    Start-Process powershell -ArgumentList $arguments
    $form.Close()
}
# --- updates from a downloaded zip (the lead's orders of 24 Oct, afdcf87 and 3db866c: the owner posts each release's zip
# on his Discord, whose links expire, so Start Here can't fetch it; and, on a hacker friend's advice, an update starts
# only when the player drags a zip onto this window: no Downloads scan, no file button). The zip is checked before
# anything else (rex\tools\package-check.ps1: the owner's signature over its file list, no entry outside its folder,
# this track), the player asked "Release N, built on <date>. Update now?", then the step (setup-steps.ps1 update-file)
# checks it again, unzips it in its work folder and copies it over this folder as an update does; then the zip can be
# deleted, and Start Here restarts and relinks. The GitHub feed above stays for when the builds repo is public.
. (Join-Path $Rex 'tools\package-check.ps1')
$script:zipUpdate = $null   # @{ path; patch; date; commit } of the zip being installed
function Start-FileUpdate([string]$path) {
    if ($script:proc) { [void][Windows.Forms.MessageBox]::Show($form, 'A step is running. Drop the zip again when it has finished.', 'TTT2'); return }
    if (FastClient-Running) { [void][Windows.Forms.MessageBox]::Show($form, 'Close Play BlueSpark first (its game closes with it), then drop the zip onto this window again.', 'TTT2'); return }
    if (Game-Running) { [void][Windows.Forms.MessageBox]::Show($form, 'Close the game first, then drop the zip onto this window again.', 'TTT2'); return }
    $check = Test-ReleaseZip $path
    if (-not $check.ok) { [void][Windows.Forms.MessageBox]::Show($form, $check.why, 'TTT2', 'OK', 'Warning'); return }
    $info = $check.info
    if ($info.track -ne $script:package.track) {
        [void][Windows.Forms.MessageBox]::Show($form, "$(Split-Path $path -Leaf) is a $($info.track) package, and this folder is a $($script:package.track) one, so it isn't installed here.", 'TTT2', 'OK', 'Warning')
        return
    }
    $built = if ($info.date) { ", built on $($info.date)" } else { '' }
    $older = $info.patch -le $script:package.patch
    $question = if ($older) { "$(Release-Label $info)$built. This folder has $(Release-Label $script:package), which is newer or the same.`r`n`r`nInstall $(Release-Label $info) anyway?" }
                else { "$(Release-Label $info)$built.`r`n`r`nUpdate now?" }
    if ([Windows.Forms.MessageBox]::Show($form, $question, 'TTT2', 'YesNo', 'Question') -ne 'Yes') { return }
    $info.path = $path
    $script:zipUpdate = $info
    $script:updating = $true
    $updateBanner.Text = "Updating to $(Release-Label $info)..."; $updateBanner.ForeColor = [Drawing.Color]::DarkOrange
    $updateBanner.Visible = $true; $updateNow.Visible = $false
    $extra = @('-ZipFile', "`"$path`"")
    if ($older) { $extra += '-AllowOlder' }
    $log.AppendText("Updating to $(Release-Label $info) from $(Split-Path $path -Leaf):`r`n")
    Start-Step 'update-file' $extra
}
# Whether a file is inside an install's folder (or a clone's, such as its rex\out\pkg): a folder above it holds
# rex\launcher.ps1, or is one installs.txt names. Such a zip isn't offered for deletion: in the owner's drop test of
# 24 Oct the zip dragged from rex\out\pkg was the package itself, and "Delete the downloaded zip?" took it.
function Test-InsideInstall([string]$path) {
    $full = [IO.Path]::GetFullPath($path)
    $lines = @(if (Test-Path -LiteralPath $InstallsFile) { Get-Content -LiteralPath $InstallsFile })
    $known = @($lines | Where-Object { $_ } | ForEach-Object { [IO.Path]::GetFullPath($_).TrimEnd('\') + '\' })
    if ($known | Where-Object { $full.StartsWith($_, [StringComparison]::OrdinalIgnoreCase) }) { return $true }
    $dir = Split-Path $full -Parent
    while ($dir) {
        if (Test-Path -LiteralPath (Join-Path $dir 'rex\launcher.ps1')) { return $true }
        $up = Split-Path $dir -Parent
        if ($up -eq $dir) { break }
        $dir = $up
    }
    return $false
}
# After the update-file step: "Updated to Release N", the zip offered for deletion (not one inside an install), then the
# new Start Here (relinks).
function Finish-FileUpdate {
    $script:updating = $false
    $info = $script:zipUpdate
    $now = Read-Package
    $log.AppendText("Updated to $(Release-Label $now).`r`n")
    if ($info -and (Test-Path -LiteralPath $info.path) -and -not (Test-InsideInstall $info.path)) {
        $r = [Windows.Forms.MessageBox]::Show($form, "Updated to $(Release-Label $now).`r`n`r`nDelete the downloaded zip ($(Split-Path $info.path -Leaf))?", 'TTT2', 'YesNo', 'Question')
        if ($r -eq 'Yes') {
            Remove-Item -LiteralPath $info.path -Force -ErrorAction SilentlyContinue
            Remove-Item -LiteralPath "$($info.path).sha256" -Force -ErrorAction SilentlyContinue
        }
    }
    if ($info) { Write-Setting 'last-update' "$($info.commit)" }
    $arguments = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$(Join-Path $Rex 'launcher.ps1')`"", '-AutoBuild')
    if ($UpdateUrl -ne $DefaultUpdateUrl) { $arguments += @('-UpdateUrl', "`"$UpdateUrl`"") }
    Start-Process powershell -ArgumentList $arguments
    $form.Close()
}
# (The drop works anywhere on the window: the form and every control on it take it.)
$onDragEnter = {
    $files = $_.Data.GetData([Windows.Forms.DataFormats]::FileDrop)
    if ($files -and @($files).Count -eq 1 -and "$(@($files)[0])" -like '*.zip') { $_.Effect = 'Copy' } else { $_.Effect = 'None' }
}
$onDragDrop = {
    $files = $_.Data.GetData([Windows.Forms.DataFormats]::FileDrop)
    if ($files) { Start-FileUpdate "$(@($files)[0])" }
}
foreach ($target in @($form, $tabs, $front, $settingsPage) + @($front.Controls) + @($settingsPage.Controls)) {   # (4.5.1: the tabs and their controls)
    $target.AllowDrop = $true
    $target.Add_DragEnter($onDragEnter)
    $target.Add_DragDrop($onDragDrop)
}

# --- the new-folder rescue (the lead's order of 24 Oct, B): every Start Here writes its folder to
# %LOCALAPPDATA%\TTT2Native\installs.txt. A folder with no build that finds an earlier install with one offers to
# update that install with this package instead (setup-steps.ps1 adopt: copied over it as an update is, so it only
# relinks; the game's build folder knows its own path, and copied here it would be built again from nothing), then
# opens that install's Start Here; this folder can be deleted then (asked, never by itself).
$InstallsFile = Join-Path (Join-Path $env:LOCALAPPDATA 'TTT2Native') 'installs.txt'
$ThisInstall = (Resolve-Path -LiteralPath (Split-Path $Rex -Parent)).Path
function Register-Install {
    $known = @(if (Test-Path -LiteralPath $InstallsFile) { Get-Content -LiteralPath $InstallsFile })
    if ($known -notcontains $ThisInstall) { Add-Content -LiteralPath $InstallsFile $ThisInstall }
}
function Find-PreviousInstall {
    $exe = 'rex\out\build\win-amd64-release\ttt2.exe'
    if (Test-Path -LiteralPath (Join-Path $ThisInstall $exe)) { return $null }
    $candidates = @(if (Test-Path -LiteralPath $InstallsFile) { Get-Content -LiteralPath $InstallsFile })
    # (Only the folders our own Start Here wrote there: nothing else on the PC is looked through, the lead's 24 Oct.)
    $found = @($candidates | Select-Object -Unique | Where-Object { $_ -and $_ -ne $ThisInstall -and (Test-Path -LiteralPath (Join-Path $_ $exe)) -and
                                                          (Test-Path -LiteralPath (Join-Path $_ 'rex\setup-steps.ps1')) -and -not (Test-Path -LiteralPath (Join-Path $_ '.git')) })
    if (-not $found.Count) { return $null }
    return ($found | Sort-Object { (Get-Item -LiteralPath (Join-Path $_ $exe)).LastWriteTime } | Select-Object -Last 1)
}
function Offer-PreviousInstall {
    $previous = Find-PreviousInstall
    if (-not $previous) { return }
    $r = [Windows.Forms.MessageBox]::Show($form, "This folder has no build yet, and you have a previous install:`r`n$previous`r`n`r`nUse your previous install? This package is copied over it, so your game files, settings, saves and build stay, and the game only needs a quick relink.`r`n`r`n(No: set this folder up from the start.)", 'TTT2', 'YesNo', 'Question')
    if ($r -ne 'Yes') { return }
    $script:adoptInto = $previous
    $log.AppendText("Copying this package over $previous...`r`n")
    Start-Step 'adopt' @('-Into', "`"$previous`"")
}
# Uninstall's boxes. Cancel is the default button in each.
function Show-UninstallBox([string]$text, [string[]]$buttons, [string]$checkText) {
    $dialog = New-Object Windows.Forms.Form
    $dialog.Text = 'Uninstall TTT2'
    $dialog.StartPosition = 'CenterParent'
    $dialog.FormBorderStyle = 'FixedDialog'
    $dialog.MaximizeBox = $false; $dialog.MinimizeBox = $false
    $dialog.Font = $font
    $label = New-Object Windows.Forms.Label
    $label.Text = $text
    $label.MaximumSize = New-Object Drawing.Size(500, 0)
    $label.AutoSize = $true
    $label.Location = New-Object Drawing.Point(14, 14)
    $dialog.Controls.Add($label)
    $y = 14 + $label.PreferredHeight + 12
    $check = $null
    if ($checkText) {
        $check = New-Object Windows.Forms.CheckBox
        $check.Text = $checkText
        $check.SetBounds(14, $y, 500, 24)
        $dialog.Controls.Add($check)
        $y += 32
    }
    $state = @{ answer = 'Cancel' }
    $x = 528
    [array]::Reverse($buttons)
    foreach ($name in $buttons) {
        $b = New-Object Windows.Forms.Button
        $b.Text = $name
        $x -= 118
        $b.SetBounds($x, $y, 110, 28)
        $b.Tag = $name
        $b.Add_Click({ param($s, $e) $state.answer = $s.Tag; $dialog.Close() }.GetNewClosure())
        $dialog.Controls.Add($b)
        if ($name -eq 'Cancel') { $dialog.AcceptButton = $b; $dialog.CancelButton = $b; $dialog.ActiveControl = $b }
    }
    $dialog.ClientSize = New-Object Drawing.Size(530, ($y + 40))
    [void]$dialog.ShowDialog($form)
    [pscustomobject]@{ answer = $state.answer; checked = [bool]($check -and $check.Checked) }
}

function Start-Uninstall {
    . (Join-Path $Rex 'tools\uninstall.ps1')
    # (No update or step may start under the boxes.)
    $timer.Stop()
    try {
        if (-not (Test-Ttt2IsInstall $ThisInstall)) {
            [void][Windows.Forms.MessageBox]::Show($form, "This folder is a developer's git clone, so Uninstall leaves it alone.", 'Uninstall TTT2', 'OK', 'Information')
            if (-not $UninstallDryRun) { return }
        }
        $others = @(Get-Ttt2OtherInstalls $ThisInstall)
        if (-not $UninstallDryRun) {
            $blockers = @(Get-Ttt2UninstallBlockers $others)
            if ($blockers.Count) {
                [void][Windows.Forms.MessageBox]::Show($form, "Close these first, then press Uninstall again:`r`n$($blockers -join "`r`n")", 'Uninstall TTT2', 'OK', 'Warning')
                return
            }
        }
        $scope = 'all'
        if ($others.Count) {
            $lines = @("TTT2 is installed in $($others.Count + 1) places on this PC:", "- $ThisInstall (this one$(if ($v = Get-Ttt2InstallLabel $ThisInstall) { ", $v" }))")
            foreach ($o in $others) { $lines += "- $o$(if ($v = Get-Ttt2InstallLabel $o) { " ($v)" })" }
            $first = Show-UninstallBox ($lines -join "`r`n") @('Just this one', 'All of them', 'Cancel') ''
            if ($first.answer -eq 'Cancel') { return }
            $scope = if ($first.answer -eq 'Just this one') { 'one' } else { 'all' }
        }
        $form.Cursor = 'WaitCursor'
        $plan = Get-Ttt2UninstallPlan $ThisInstall $scope   # (once: it walks the folders)
        $form.Cursor = 'Default'
        if ($scope -eq 'one') {
            $second = Show-UninstallBox "Delete this copy of TTT2 ($ThisInstall), its replays and its settings? Files you added to its folder stay. Your other copies, saves and Ranked account stay." @('Uninstall', 'Cancel') ''
        } else {
            $text = "This removes TTT2 from this PC: every copy, the build tools and the game files it extracted (about $([Math]::Round($plan.bytes / 1GB, 1)) GB), your saves, replays and your Ranked account on this PC (reinstalling starts a new one). Your own game disc image or folder, your music in Music\TTT2 Tunes, and files you added to a copy's folder are left alone."
            if (($n = Get-Ttt2OutboxCount) -gt 0) { $text += "`r`n`r`n$n Ranked result$(if ($n -ne 1) { 's' }) hasn't reached the server yet and will be lost." }
            $second = Show-UninstallBox $text @('Uninstall', 'Cancel') 'Keep my saves and Ranked account'
        }
        if ($second.answer -ne 'Uninstall') { return }
        if ($second.checked) { $plan = Set-Ttt2UninstallKeep $plan }
        if ($UninstallDryRun) {
            $lines = @("Dry run: scope $scope, keep the saves: $($second.checked), $([Math]::Round($plan.bytes / 1GB, 2)) GB. Nothing deleted.") +
                     @($plan.items | ForEach-Object { '{0,8:N2} GB  {1,-6} {2}{3}' -f ($_.bytes / 1GB), $_.kind, $_.path, $(if (Test-Ttt2UninstallItem $_ $plan) { '' } else { '   KEPT BY THE GUARD' }) }) +
                     @($plan.left | ForEach-Object { "left: $_" })
            Add-Content -LiteralPath $plan.log $lines -Encoding utf8
            [void][Windows.Forms.MessageBox]::Show($form, "Dry run: nothing deleted. The plan is in $($plan.log).", 'Uninstall TTT2', 'OK', 'Information')
            return
        }
        # (Again: something may have started while the boxes were up.)
        $blockers = @(Get-Ttt2UninstallBlockers $others)
        if ($blockers.Count -or ($script:proc -and -not $script:proc.HasExited)) {
            [void][Windows.Forms.MessageBox]::Show($form, "Close these first, then press Uninstall again:`r`n$(if ($blockers.Count) { $blockers -join "`r`n" } else { 'the step Start Here is running' })", 'Uninstall TTT2', 'OK', 'Warning')
            return
        }
        try {
            $temp = Join-Path $env:TEMP "ttt2-uninstall-$([guid]::NewGuid().ToString('N'))"
            New-Item -ItemType Directory -Force $temp | Out-Null
            foreach ($name in 'remove-folder.ps1', 'uninstall.ps1', 'uninstall-finish.ps1') { Copy-Item -LiteralPath (Join-Path $Rex "tools\$name") $temp }
            $planFile = Join-Path $temp 'plan.json'
            [IO.File]::WriteAllText($planFile, ($plan | ConvertTo-Json -Depth 5), (New-Object Text.UTF8Encoding $false))
        } catch {
            [void][Windows.Forms.MessageBox]::Show($form, "Nothing was uninstalled: the Windows temp folder can't be written ($($_.Exception.Message)).", 'Uninstall TTT2', 'OK', 'Warning')
            return
        }
        # (Started once the window has really closed: FormClosing can still say no.)
        $script:uninstallFinisher = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$(Join-Path $temp 'uninstall-finish.ps1')`"", '-Plan', "`"$planFile`"", '-WaitPid', "$PID")
        $script:uninstallFolder = $temp
        $form.Close()
    } finally {
        $form.Cursor = 'Default'
        if ($form.Visible -and -not $script:uninstallFinisher) { $timer.Start() }
    }
}
$form.Add_FormClosed({
    if (-not $script:uninstallFinisher) { return }
    try {
        Start-Process powershell -WindowStyle Hidden -WorkingDirectory $script:uninstallFolder -ArgumentList $script:uninstallFinisher -ErrorAction Stop
    } catch {
        [void][Windows.Forms.MessageBox]::Show("Nothing was uninstalled: the uninstaller couldn't start ($($_.Exception.Message)).", 'Uninstall TTT2', 'OK', 'Warning')
    }
})
$uninstallButton.Add_Click({ Start-Uninstall })

function Finish-Adopt {
    $previous = $script:adoptInto
    Start-Process powershell -WindowStyle Minimized -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$(Join-Path $previous 'rex\launcher.ps1')`"", '-AutoBuild')   # (4.5.1: its console minimized, as Start Here.cmd starts it)
    $r = [Windows.Forms.MessageBox]::Show($form, "Your previous install has this package now, and its Start Here is opening.`r`n`r`nDelete this new folder ($ThisInstall)?", 'TTT2', 'YesNo', 'Question')
    if ($r -eq 'Yes') {
        # (After this window closes: a hidden PowerShell waits for it, then removes the folder.)
        $me = $PID
        $script = "Wait-Process -Id $me -ErrorAction SilentlyContinue; Start-Sleep -Seconds 2; Remove-Item -LiteralPath '$ThisInstall' -Recurse -Force -ErrorAction SilentlyContinue"
        $null = Start-Ttt2Program 'powershell.exe' "-NoProfile -Command `"$script`"" $null $null
    }
    $form.Close()
}

$updateNow.Add_Click({ Start-Update })
$checkUpdates.Add_Click({ Start-UpdateCheck })

function Start-Play {
    if (-not (Get-PlayerName)) { Ask-PlayerName | Out-Null }
    $arguments = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$Steps`"", '-Step', 'play')
    # (A test feed reaches the game's update popup too, --ttt2_update_feed: rex\src\update_popup.cpp.)
    if ($UpdateUrl -ne $DefaultUpdateUrl) { $arguments += @('-UpdateUrl', "`"$UpdateUrl`"") }
    # (Hidden as before, but its output kept beside the other steps' logs, and an error shown: a Play that stopped
    # before the game started said nothing at all, 22 Oct.)
    $script:playLog = Join-Path $Logs "$(Get-Date -Format 'yyyyMMdd-HHmmss')-play.log"
    $script:playProc = Start-Ttt2Program 'powershell.exe' ($arguments -join ' ') $script:playLog "$($script:playLog).err"
    $null = $script:playProc.Handle   # (kept, or Windows PowerShell can't read its exit code later)
    $playWatch.Start()
    $playState.Text = 'Starting the game...'
}
# Play's step ends once the game is up (run-windows.ps1 hands the game lock to it); ending with an error, or with
# anything on its error stream, means the game didn't start: its last lines in a message box.
$playWatch = New-Object Windows.Forms.Timer
$playWatch.Interval = 1000
$playWatch.Add_Tick({
    $p = $script:playProc
    if (-not $p) { $playWatch.Stop(); return }
    if (-not $p.HasExited) { return }
    $playWatch.Stop()
    $script:playProc = $null
    $err = @(Get-Content -LiteralPath "$($script:playLog).err" -ErrorAction SilentlyContinue | Where-Object { "$_".Trim() })
    if ($p.ExitCode -ne 0 -or $err.Count) {
        $said = @(@(Get-Content -LiteralPath $script:playLog -ErrorAction SilentlyContinue) + $err | Where-Object { "$_".Trim() } | Select-Object -Last 12)
        $playState.Text = 'Play TTT2 stopped before the game started: see the message.'
        [void][Windows.Forms.MessageBox]::Show($form, "Play TTT2 stopped before the game started:`r`n`r`n$($said -join "`r`n")`r`n`r`n(All of it: $($script:playLog). Report a problem sends it.)", 'TTT2', 'OK', 'Warning')
    }
})
# (A path with a character outside plain ASCII: the game doesn't start from it, or puts its saves in another folder, 27 Oct.
# Both Play buttons say so instead; setup-steps.ps1's play step stops too.)
function Confirm-AsciiPathToPlay {
    $name = Get-Ttt2NonAsciiFolder $ThisInstall
    if (-not $name) { return $true }
    [void][Windows.Forms.MessageBox]::Show($form, "This folder's path has characters the game can't handle ($name): it would not start, or would put your saves in another folder.`r`n`r`nMove the whole folder to C:\ttt2, start Start Here from there, build again and play.", 'A folder name with special characters', 'OK', 'Warning')
    return $false
}
$play.Add_Click({ if (FastClient-Running) { [void][Windows.Forms.MessageBox]::Show($form, 'Play BlueSpark is open, with its game behind it. Close it first, then Play TTT2.', 'TTT2'); return }; if (-not (Confirm-AsciiPathToPlay)) { return }; Start-Play })

# "Play: Fast Client": Play's switches written first (setup-steps.ps1's 'switches' step: rex\userdata\play-switches.txt,
# the same list Play passes, which the client reads when it starts its game), then the
# client started from this click (a client started from a background process couldn't bring its game to the front:
# Windows' foreground rule). The client starts the game itself, hidden, and the game closes with it.
function Start-FastClient {
    if (FastClient-Running) { [void][Windows.Forms.MessageBox]::Show($form, 'Play BlueSpark is open already.', 'TTT2'); return }
    if (Game-Running) { [void][Windows.Forms.MessageBox]::Show($form, 'The game is running (from Play TTT2). Close it first, then start Play BlueSpark.', 'TTT2'); return }
    if (-not (Get-PlayerName)) { Ask-PlayerName | Out-Null }
    $out = Join-Path $Logs "$(Get-Date -Format 'yyyyMMdd-HHmmss')-switches.log"
    $p = Start-Ttt2Program 'powershell.exe' "-NoProfile -ExecutionPolicy Bypass -File `"$Steps`" -Step switches" $out "$out.err"
    Wait-Ttt2Program $p
    $err = @(Get-Content -LiteralPath "$out.err" -ErrorAction SilentlyContinue | Where-Object { "$_".Trim() })
    if ($p.ExitCode -ne 0 -or $err.Count) {
        [void][Windows.Forms.MessageBox]::Show($form, "Play BlueSpark didn't start: its switches couldn't be written.`r`n`r`n$($err -join "`r`n")", 'TTT2', 'OK', 'Warning')
        return
    }
    # (ProcessStartInfo, not Start-Process: Windows PowerShell's Start-Process reads -FilePath and -WorkingDirectory as wildcards, and an install
    # folder with [ or ] in its name, "...[RF]", couldn't start the client. 4.5.) Started directly (CreateProcess), not shell-executed: the client
    # keeps the zip's downloaded mark now (the owner, 4.5), and a shell-executed file with the mark gets Windows' "Open File - Security Warning"
    # at every start (its "Always ask" box ticked); measured in the package check: shell-executed, the warning; started directly, no prompt,
    # the mark kept, the client and its game up.
    $si = New-Object System.Diagnostics.ProcessStartInfo $script:fastClientExe
    $si.WorkingDirectory = Split-Path $script:fastClientExe
    $si.UseShellExecute = $false
    $null = [System.Diagnostics.Process]::Start($si)
    $playState.Text = 'Starting Play BlueSpark (it starts the game behind it)...'
}
$fastPlay.Add_Click({ if (-not (Confirm-AsciiPathToPlay)) { return }; Start-FastClient })

$form.Add_FormClosing({
    if ($script:proc -and -not $script:proc.HasExited) {
        $r = [Windows.Forms.MessageBox]::Show('A step is still running. Stop it and close?', 'TTT2', 'YesNo', 'Warning')
        if ($r -ne 'Yes') { $_.Cancel = $true; $script:uninstallFinisher = $null; return }
        try { $script:proc.Kill() } catch { }
    }
})

Refresh-Buttons
Register-Install
# (Started by the game's update popup: the game is closing; its lock given up to 30 s to go first, or the update waits.)
if ($InstallUpdate) {
    for ($i = 0; $i -lt 60 -and ((Game-Running) -or (FastClient-Running)); $i++) { Start-Sleep -Milliseconds 500 }
}
# (One Start Here a folder, 4.5.1: an update used to leave two open, the old window behind the new (the game's update popup,
# the fast client's Close and update, Start Here's own restart). The open one is the one rex\start-here.pid names (its
# process id, start time and state, kept by that window; no listing of the PC's processes and their command lines, a pattern
# antivirus models weigh). An update or a restart (-InstallUpdate, -AutoBuild), or the old window idle: the old one is asked
# to close, then this one takes over. The old one busy with a step: it stays, and this start says so and ends.)
$w = "$(Get-Content -LiteralPath $PidFile -TotalCount 1 -ErrorAction SilentlyContinue)" -split ' '
$old = if ($w.Count -ge 2) { Get-Process -Id ([int]$w[0]) -ErrorAction SilentlyContinue } else { $null }
if ($old -and $old.Id -ne $PID -and $(try { "$($old.StartTime.ToFileTimeUtc())" } catch { '' }) -eq $w[1]) {
    if (-not $InstallUpdate -and -not $AutoBuild -and $w.Count -ge 3 -and $w[2] -eq 'busy') {
        [void][Windows.Forms.MessageBox]::Show("Start Here is already open in this folder, working on a step: it's on the taskbar.", 'TTT2', 'OK', 'Information')
        exit 0
    }
    $null = $old.CloseMainWindow()
    if (-not $old.WaitForExit(5000)) { try { $old.Kill() } catch { } }
} elseif ($AutoBuild) {
    # (An update's restart from a Start Here older than 4.5.1, which keeps no pid file and whose own close after the restart doesn't
    # take: its window, titled with its older release, is asked to close. Only a Start Here window showing another release than this
    # one's; by the windows' titles, no listing of command lines.)
    foreach ($p in @(Get-Process powershell -ErrorAction SilentlyContinue | Where-Object { $_.Id -ne $PID -and $_.MainWindowTitle -like 'TTT2 native - Release *' -and $_.MainWindowTitle -ne $form.Text })) {
        $null = $p.CloseMainWindow()
        if (-not $p.WaitForExit(5000)) { try { $p.Kill() } catch { } }
    }
}
Write-StartHerePid 'idle'
if (-not $env:TTT2_TEST_SNAPSHOT) { Start-UpdateCheck }   # (the snapshot test: no update check)
# (After an update, the new Start Here runs what Install has left (the build, usually) by itself, as 4.5 built by itself.)
if ($AutoBuild) { Start-Install -Auto }
# (Once the window is up: the rescue for a new folder.)
# (Test only, TTT2_TEST_SNAPSHOT=<path without extension>: 2 s after the window shows, each tab is drawn to <path>-<tab>.png and the
# window's sizes to <path>.txt, then the window closes; nothing else at the start (no notes, no update check's boxes). 4.5.1's layout tests.)
function Save-Ttt2Snapshot {
    $script:snapBase = $env:TTT2_TEST_SNAPSHOT   # (script scope: the timer's block runs outside this function)
    $t = New-Object Windows.Forms.Timer
    $t.Interval = 2000
    $t.Add_Tick({
        $this.Stop()
        $out = @("form $($form.Width)x$($form.Height), client $($form.ClientSize.Width)x$($form.ClientSize.Height), tabs $($tabs.Width)x$($tabs.Height), front page $($front.ClientSize.Width)x$($front.ClientSize.Height), minimum $($form.MinimumSize.Width)x$($form.MinimumSize.Height), work area $([Windows.Forms.Screen]::FromControl($form).WorkingArea.Size), scrolls $($form.VerticalScroll.Visible)")
        foreach ($page in $tabs.TabPages) {
            $tabs.SelectedTab = $page
            [Windows.Forms.Application]::DoEvents()
            $bmp = New-Object Drawing.Bitmap($tabs.Width, $tabs.Height)
            $tabs.DrawToBitmap($bmp, (New-Object Drawing.Rectangle(0, 0, $tabs.Width, $tabs.Height)))
            $bmp.Save("$($script:snapBase)-$($page.Text -replace '\W', '').png", [Drawing.Imaging.ImageFormat]::Png)
            $bmp.Dispose()
            foreach ($c in $page.Controls) { if ($c.Visible -and ($c.Right -gt $page.ClientSize.Width -or $c.Bottom -gt $page.ClientSize.Height)) { $out += "outside its page: $($page.Text) $($c.GetType().Name) '$($c.Text)' $($c.Bounds)" } }
        }
        # (Settings and Back by their clicks, each page's keyboard order, and the Settings button's focus mark.)
        $tabs.SelectedTab = $front; [Windows.Forms.Application]::DoEvents()
        $settingsButton.PerformClick(); [Windows.Forms.Application]::DoEvents(); $out += "Settings clicked: the tab is $($tabs.SelectedTab.Text)"
        $backButton.PerformClick(); [Windows.Forms.Application]::DoEvents(); $out += "Back clicked: the tab is $($tabs.SelectedTab.Text)"
        foreach ($page in $tabs.TabPages) {
            $tabs.SelectedTab = $page; [Windows.Forms.Application]::DoEvents()
            $names = @(); $c = $page.GetNextControl($null, $true)
            while ($c) { if ($c.TabStop -and $c.Visible -and $c.Text) { $names += $c.Text } elseif ($c.TabStop -and $c.Visible) { $names += $c.GetType().Name }; $c = $page.GetNextControl($c, $true) }
            $out += "keyboard order, $($page.Text): $($names -join ' | ')"
        }
        $tabs.SelectedTab = $front; [void]$settingsButton.Focus(); [Windows.Forms.Application]::DoEvents()
        $bmp = New-Object Drawing.Bitmap($settingsButton.Width, $settingsButton.Height)
        $settingsButton.DrawToBitmap($bmp, (New-Object Drawing.Rectangle(0, 0, $settingsButton.Width, $settingsButton.Height)))
        $bmp.Save("$($script:snapBase)-focus.png", [Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose()
        $out += "busy: $($busy.Text)"; $out += "choose: $($chooseState.Text); install: $($installState.Text); install enabled: $($install.Enabled); play enabled: $($play.Enabled)"
        [IO.File]::WriteAllLines("$($script:snapBase).txt", [string[]]$out)
        $form.Close()
    })
    $t.Start()
}
$form.Add_Shown({
    if ($env:TTT2_TEST_SNAPSHOT) { Save-Ttt2Snapshot; return }
    # (The lead's F: an install folder inside OneDrive or another synced folder, said at every start.)
    if ($note = Get-Ttt2SyncedFolderNote $ThisInstall 'This folder') {
        [void][Windows.Forms.MessageBox]::Show($form, $note, 'A synced folder', 'OK', 'Warning')
    }
    # (A path with characters outside plain ASCII, said at every start: a player's step 2 failed under such a folder, 27 Oct.)
    if ($note = Get-Ttt2NonAsciiPathNote $ThisInstall) {
        $log.AppendText("$note`r`n")
        [void][Windows.Forms.MessageBox]::Show($form, $note, 'A folder name with special characters', 'OK', 'Warning')
    }
    # (D2 and G3: our files gone since the last start.)
    if ($missingNote = Get-Ttt2MissingFilesNote $ThisInstall) {
        $log.AppendText("$missingNote`r`n")
        [void][Windows.Forms.MessageBox]::Show($form, $missingNote, 'Files are missing', 'OK', 'Warning')
    }
    if (-not $AutoBuild -and -not $script:proc) { Offer-PreviousInstall }
})
# --- resizing (the owner, 25 Oct: "the launcher is getting pretty tall. can we support resizing?"): the window can be
# made shorter or taller, and wider; its rows keep their places, so a window shorter than them scrolls. It opens no
# taller than the screen's working area, and never narrower than its rows and a scroll bar.
# 4.5.1: on a short or scaled screen the rows are taller than the screen; WinForms then clamps the window's Height but
# keeps the asked ClientSize, so a frame measured at full height went negative and MinimumSize threw (Start Here never
# opened). The frame is measured at a small client height instead, every height is clamped, and nothing here can stop
# the window from opening.
try {
    # (4.5.1: the tabs at their content's height, the front page's rows; the form scrolls them when the screen is shorter.)
    $tabs.Size = New-Object Drawing.Size(640, 660)
    $tabs.Height += [Math]::Max($FrontHeight, $SetY + 8) - $tabs.DisplayRectangle.Height
    $form.ClientSize = New-Object Drawing.Size(640, $tabs.Height)
    $rowsHeight = $form.ClientSize.Height   # (the asked height, kept even when the window's Height was clamped)
    $scrollBar = [Windows.Forms.SystemInformation]::VerticalScrollBarWidth
    $form.FormBorderStyle = 'Sizable'
    $form.MaximizeBox = $true
    $form.AutoScroll = $true
    $form.AutoScrollMinSize = New-Object Drawing.Size(0, $rowsHeight)
    $form.ClientSize = New-Object Drawing.Size((640 + $scrollBar), 200)
    $frame = [Math]::Max(0, $form.Height - $form.ClientSize.Height)
    $work = [Windows.Forms.Screen]::FromControl($form).WorkingArea
    # (TTT2_TEST_WORK_HEIGHT: test only, the screen's usable height taken as this, in the window's units: 1366x768 at 125% is about 580.)
    if ($env:TTT2_TEST_WORK_HEIGHT -match '^\d+$') { $work = New-Object Drawing.Rectangle($work.X, $work.Y, $work.Width, [int]$env:TTT2_TEST_WORK_HEIGHT) }
    $clientHeight = [Math]::Max(120, [Math]::Min($rowsHeight, $work.Height - $frame))
    $form.ClientSize = New-Object Drawing.Size((640 + $scrollBar), $clientHeight)
    $form.MinimumSize = New-Object Drawing.Size($form.Width, [Math]::Min($form.Height, 240 + $frame))
} catch {
    try { $log.AppendText("(The window's size couldn't be set: $($_.Exception.Message))`r`n") } catch { }
}
if ($UninstallDryRun) { $form.Add_Shown({ Start-Uninstall }) }   # (test only: the boxes, then the plan in the log; nothing deleted)
[void]$form.ShowDialog()
