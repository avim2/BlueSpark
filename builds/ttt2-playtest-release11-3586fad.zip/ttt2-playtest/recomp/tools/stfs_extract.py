# Extracts the files of an Xbox 360 STFS package (CON, LIVE or PIRS: title updates, DLC,
# saved games).
#   python stfs_extract.py <package> <out-dir>
# Prints the package's title, content type and versions, then each file. Files are written
# flat (a saved game's are all in one folder). A file whose blocks are not consecutive (a
# saved game's often are not) is read by following the chain in the hash tables.
import os
import struct
import sys

CONTENT_TYPES = {0x000B0000: 'title update', 0x00000002: 'marketplace content (DLC)',
                 0x00000001: 'saved game'}


def main(path, out):
    # (The magic first, from 4 bytes: an ISO picked by mistake was read whole into memory before, 23 Oct.)
    with open(path, 'rb') as f:
        magic = f.read(4)
    if magic not in (b'CON ', b'LIVE', b'PIRS'):
        sys.exit('not an STFS package: %r' % magic)
    d = open(path, 'rb').read()
    header_size = struct.unpack('>I', d[0x340:0x344])[0]
    content_type = struct.unpack('>I', d[0x344:0x348])[0]
    version, base_version, title_id = struct.unpack('>III', d[0x358:0x364])
    name = d[0x411:0x411 + 0x80].decode('utf-16-be', 'ignore').split('\0')[0]
    print('%s: "%s", title %08X, %s, version %08X (base %08X)' % (
        magic.decode(), name, title_id, CONTENT_TYPES.get(content_type, '%08X' % content_type),
        version, base_version))

    vd = d[0x379:0x379 + 0x24]
    separation = vd[2]
    table_blocks = struct.unpack('<H', vd[3:5])[0]
    table_start = int.from_bytes(vd[5:8], 'little')
    total_blocks = struct.unpack('>I', vd[0x1C:0x20])[0]
    # One hash table between the groups of data blocks, or two (a package that is written to,
    # as a save is, keeps two and says in the level above which is the live one): by the
    # header's size and the "block separation" bit, whatever the kind of package.
    if ((header_size + 0xFFF) & 0xF000) == 0xB000 or separation & 1:
        shift = 0
    else:
        shift = 1
    first = (header_size + 0xFFF) & ~0xFFF
    step0 = 0xAB if shift == 0 else 0xAC
    step1 = 0x718F if shift == 0 else 0x723A

    def block_offset(index):
        # Data blocks are interleaved with hash tables: one per 170 blocks, one per 170 of
        # those, and so on.
        block, per = index, 170
        for _ in range(3):
            block += ((index + per) // per) << shift
            if index < per:
                break
            per *= 170
        return first + (block << 12)

    def hash_table(index, level, active):
        # The hash table of a level that covers a data block; "active" picks the second copy.
        if level == 0:
            number = (index // 170) * step0
            if index >= 170:
                number += ((index // 0x70E4) + 1) << shift
                if index >= 0x70E4:
                    number += 1 << shift
        elif level == 1:
            number = step0 if index < 0x70E4 else (index // 0x70E4) * step1 + (1 << shift)
        else:
            number = step1
        o = first + ((number + active) << 12)
        return d[o:o + 0x1000]

    top = 0 if total_blocks <= 170 else 1 if total_blocks <= 0x70E4 else 2

    def next_block(index):
        active = (separation >> 1) & 1 if shift else 0
        for level in range(top, 0, -1):
            entry = hash_table(index, level, active)[((index // 170 ** level) % 170) * 0x18:][:0x18]
            active = (entry[0x14] >> 6) & 1 if shift else 0
        entry = hash_table(index, 0, active)[(index % 170) * 0x18:][:0x18]
        return int.from_bytes(entry[0x15:0x18], 'big')

    def read_chain(start, blocks, consecutive):
        data = bytearray()
        block = start
        for k in range(blocks):
            o = block_offset(block)
            data += d[o:o + 0x1000]
            block = block + 1 if consecutive else next_block(block)
        return data

    os.makedirs(out, exist_ok=True)
    table = read_chain(table_start, table_blocks, False)
    for i in range(0, len(table), 0x40):
        e = table[i:i + 0x40]
        if not e[0]:
            continue
        flags = e[0x28]
        fname = e[:flags & 0x3F].decode('ascii', 'replace')
        blocks = int.from_bytes(e[0x29:0x2C], 'little')
        start = int.from_bytes(e[0x2F:0x32], 'little')
        size = struct.unpack('>I', e[0x34:0x38])[0]
        if not fname:
            continue
        if flags & 0x80:
            print('  directory %s (contents written flat)' % fname)
            continue
        try:
            data = read_chain(start, blocks, bool(flags & 0x40))
        except IndexError:
            print('  SKIPPED %s: its chain of blocks leaves the package' % fname)
            continue
        if len(data) < size:
            print('  SKIPPED %s: its chain of blocks ends early' % fname)
            continue
        with open(os.path.join(out, fname), 'wb') as f:
            f.write(data[:size])
        print('  %-16s %9d bytes%s' % (fname, size, '' if flags & 0x40 else ' (by its chain)'))


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
