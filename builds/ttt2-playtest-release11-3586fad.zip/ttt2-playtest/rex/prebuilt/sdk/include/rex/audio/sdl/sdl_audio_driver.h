/**
 ******************************************************************************
 * Xenia : Xbox 360 Emulator Research Project                                 *
 ******************************************************************************
 * Copyright 2020 Ben Vanik. All rights reserved.                             *
 * Released under the BSD license - see LICENSE in the root for more details. *
 ******************************************************************************
 *
 * @modified    Tom Clay, 2026 - Adapted for ReXGlue runtime
 */

#pragma once

#include <atomic>
#include <mutex>
#include <queue>
#include <stack>
#include <thread>

#include <rex/audio/audio_driver.h>
#include <rex/thread.h>

#include <SDL3/SDL.h>

namespace rex::audio::sdl {

class SDLAudioDriver : public AudioDriver {
 public:
  SDLAudioDriver(memory::Memory* memory, rex::thread::Semaphore* semaphore);
  ~SDLAudioDriver() override;

  bool Initialize();
  void SubmitFrame(uint32_t frame_ptr) override;
  void Shutdown();

  // A pooled SDL stream: what SDL's device thread calls back into. It lives for the whole process (never freed) and
  // names the driver now fed by the stream, so that a driver can come and go with no SDL object created or destroyed.
  struct Slot;

 protected:
  static void SDLCallback(void* userdata, SDL_AudioStream* stream, int additional_amount,
                          int total_amount);

  bool OpenDevice(bool quiet);
  bool StartSilent(const char* why);
  void SilentLoop();

  static constexpr uint32_t kAlive = 0x5D1A11E5u;  // magic_ while the driver lives; anything else: gone or never made
  static constexpr uint32_t kGone = 0xDEADD0D0u;
  uint32_t magic_ = kAlive;

  rex::thread::Semaphore* semaphore_ = nullptr;

  // --audio_silent_fallback: with no device, the thread that takes the game's frames at the device's pace.
  std::thread silent_thread_;
  std::atomic<bool> silent_stop_{false};

  SDL_AudioStream* sdl_stream_ = nullptr;  // (the slot's, for the log: owned by SDL and the pool)
  Slot* slot_ = nullptr;
  bool sdl_initialized_ = false;
  uint8_t sdl_device_channels_ = 0;

  static const uint32_t frame_frequency_ = 48000;
  static const uint32_t frame_channels_ = 6;
  static const uint32_t channel_samples_ = 256;
  static const uint32_t frame_samples_ = frame_channels_ * channel_samples_;
  static const uint32_t frame_size_ = sizeof(float) * frame_samples_;
  std::queue<float*> frames_queued_ = {};
  std::stack<float*> frames_unused_ = {};
  std::mutex frames_mutex_ = {};
};

}  // namespace rex::audio::sdl
