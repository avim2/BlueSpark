/**
 ******************************************************************************
 * Xenia : Xbox 360 Emulator Research Project                                 *
 ******************************************************************************
 * Copyright 2022 Ben Vanik. All rights reserved.                             *
 * Released under the BSD license - see LICENSE in the root for more details. *
 ******************************************************************************
 *
 * @modified    Tom Clay, 2026 - Adapted for ReXGlue runtime
 */

#pragma once

#include <array>
#include <atomic>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <deque>
#include <cstring>
#include <functional>
#include <memory>
#include <mutex>
#include <queue>
#include <string>
#include <unordered_map>
#include <vector>

#include <rex/graphics/register_file.h>
#include <rex/graphics/registers.h>
#include <rex/graphics/xenos.h>
#include <rex/memory.h>
#include <rex/memory/ring_buffer.h>
#include <rex/system/xthread.h>
#include <rex/thread.h>
#include <rex/ui/presenter.h>

namespace rex::stream {
class ByteStream;
}  // namespace rex::stream

namespace rex::graphics {

class GraphicsSystem;
class Shader;

// For --gpu_work_log_ms: the first-time work of a frame on the GPU command thread (and the
// pipeline creation threads), counted and timed, to say what a hitch is made of.
enum GpuWorkKind { kGpuWorkTextureCreate, kGpuWorkTextureLoad, kGpuWorkPipelineCreate, kGpuWorkMemoryUpload, kGpuWorkKinds };
struct GpuWorkStats {
  std::atomic<uint64_t> count[kGpuWorkKinds];
  std::atomic<uint64_t> micros[kGpuWorkKinds];
  std::atomic<uint64_t> amount[kGpuWorkKinds];
};
inline GpuWorkStats g_gpu_work_stats;
struct GpuWorkTimer {
  GpuWorkKind kind;
  uint64_t amount;
  std::chrono::steady_clock::time_point begun = std::chrono::steady_clock::now();
  explicit GpuWorkTimer(GpuWorkKind kind_, uint64_t amount_ = 0) : kind(kind_), amount(amount_) {}
  ~GpuWorkTimer() {
    g_gpu_work_stats.count[kind].fetch_add(1, std::memory_order_relaxed);
    g_gpu_work_stats.amount[kind].fetch_add(amount, std::memory_order_relaxed);
    g_gpu_work_stats.micros[kind].fetch_add(
        uint64_t(std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - begun)
                     .count()),
        std::memory_order_relaxed);
  }
};

enum class ReadbackResolveMode {
  kDisabled,
  kFast,
  kSome,
  kFull,
  kTransient,
};

struct SwapState {
  // Lock must be held when changing data in this structure.
  std::mutex mutex;
  // Dimensions of the framebuffer textures. Should match window size.
  uint32_t width = 0;
  uint32_t height = 0;
  // Current front buffer, being drawn to the screen.
  uintptr_t front_buffer_texture = 0;
  // Current back buffer, being updated by the CP.
  uintptr_t back_buffer_texture = 0;
  // Backend data
  void* backend_data = nullptr;
  // Whether the back buffer is dirty and a swap is pending.
  bool pending = false;
};

enum class SwapMode {
  kNormal,
  kIgnored,
};

enum class GammaRampType {
  kUnknown = 0,
  kTable,
  kPWL,
};

class CommandProcessor {
 public:
  enum class SwapPostEffect {
    kNone,
    kFxaa,
    kFxaaExtreme,
  };

  CommandProcessor(GraphicsSystem* graphics_system, system::KernelState* kernel_state);
  virtual ~CommandProcessor();

  uint32_t counter() const { return counter_; }
  void increment_counter() { counter_++; }
  // The guest's vertical blank interrupt has run: wakes a WAIT_REG_MEM, which is how a guest
  // holds its swap until the vertical blank.
  void OnGuestVblank() { vblank_event_->Set(); }
  // See GraphicsSystem::WaitForGuestVisibleProgress. Notified when the read pointer is written
  // back and after the vertical blank interrupt.
  uint32_t WaitForGuestVisibleProgress(uint32_t seen_count, uint32_t timeout_us);
  // See IGraphicsSystem::GuestGpuPosition (rex/patches/24). From any thread.
  void GuestGpuPosition(uint32_t out[7]) const;
  // See IGraphicsSystem::QueueTexturePrewarm. From any thread.
  void QueueTexturePrewarm(const uint32_t* fetch_words, uint32_t texture_count);
  // For the backend, on the command thread: the next texture asked for, if any.
  bool TakeTexturePrewarm(uint32_t fetch_words_out[6]);
  void NotifyGuestVisibleProgress() {
    progress_count_.fetch_add(1, std::memory_order_release);
    if (progress_waiters_.load(std::memory_order_acquire)) {
      { std::lock_guard<std::mutex> lock(progress_mutex_); }
      progress_condition_.notify_all();
    }
  }
  // The guest has written a swap packet (VdSwap) at this physical address.
  void OnGuestSwapQueued(uint32_t swap_packet_address) {
    swap_packet_queued_.store(swap_packet_address, std::memory_order_release);
    // A wait for the vertical blank may be what is ahead of it.
    vblank_event_->Set();
  }

  Shader* active_vertex_shader() const { return active_vertex_shader_; }
  Shader* active_pixel_shader() const { return active_pixel_shader_; }

  virtual bool Initialize();
  virtual void Shutdown();

  void CallInThread(std::function<void()> fn);

  virtual void ClearCaches();
  virtual void InvalidateGpuMemory();

  // "Desired" is for the external thread managing the post-processing effect.
  SwapPostEffect GetDesiredSwapPostEffect() const { return swap_post_effect_desired_; }
  void SetDesiredSwapPostEffect(SwapPostEffect swap_post_effect);
  // Implementations must not make assumptions that the front buffer will
  // necessarily be a resolve destination - it may be a texture generated by any
  // means like written to by the CPU or loaded from a file (the disclaimer
  // screen right in the beginning of 4D530AA4 is not a resolved render target,
  // for instance).
  virtual void IssueSwap(uint32_t frontbuffer_ptr, uint32_t frontbuffer_width,
                         uint32_t frontbuffer_height) = 0;

  // May be called not only from the command processor thread when the command
  // processor is paused, and the termination of this function may be explicitly
  // awaited.
  virtual void InitializeShaderStorage(const std::filesystem::path& cache_root, uint32_t title_id,
                                       bool blocking);

  void InitializeRingBuffer(uint32_t ptr, uint32_t size_log2);
  void EnableReadPointerWriteBack(uint32_t ptr, uint32_t block_size_log2);

  void UpdateWritePointer(uint32_t value);

  void ExecutePacket(uint32_t ptr, uint32_t count);

  bool is_paused() const { return paused_; }
  void Pause();
  void Resume();

  bool Save(::rex::stream::ByteStream* stream);
  bool Restore(::rex::stream::ByteStream* stream);

 protected:
  struct IndexBufferInfo {
    xenos::IndexFormat format = xenos::IndexFormat::kInt16;
    xenos::Endian endianness = xenos::Endian::kNone;
    uint32_t count = 0;
    uint32_t guest_base = 0;
    size_t length = 0;
  };

  void WorkerThreadMain();
  virtual bool SetupContext() = 0;
  virtual void ShutdownContext() = 0;

  virtual void WriteRegister(uint32_t index, uint32_t value);
  uint32_t ReadRegisterValue(uint32_t index) const;
  virtual void WriteRegistersFromMem(uint32_t start_index, uint32_t* base, uint32_t num_registers);
  virtual void WriteRegisterRangeFromRing(memory::RingBuffer* ring, uint32_t base,
                                          uint32_t num_registers);
  void WriteALURangeFromRing(memory::RingBuffer* ring, uint32_t base, uint32_t num_registers);
  void WriteFetchRangeFromRing(memory::RingBuffer* ring, uint32_t base, uint32_t num_registers);
  void WriteBoolRangeFromRing(memory::RingBuffer* ring, uint32_t base, uint32_t num_registers);
  void WriteLoopRangeFromRing(memory::RingBuffer* ring, uint32_t base, uint32_t num_registers);
  void WriteREGISTERSRangeFromRing(memory::RingBuffer* ring, uint32_t base, uint32_t num_registers);
  void WriteALURangeFromMem(uint32_t start_index, uint32_t* base, uint32_t num_registers);
  void WriteFetchRangeFromMem(uint32_t start_index, uint32_t* base, uint32_t num_registers);
  void WriteBoolRangeFromMem(uint32_t start_index, uint32_t* base, uint32_t num_registers);
  void WriteLoopRangeFromMem(uint32_t start_index, uint32_t* base, uint32_t num_registers);
  void WriteREGISTERSRangeFromMem(uint32_t start_index, uint32_t* base, uint32_t num_registers);

  const reg::DC_LUT_30_COLOR* gamma_ramp_256_entry_table() const {
    return gamma_ramp_256_entry_table_;
  }
  const reg::DC_LUT_PWL_DATA* gamma_ramp_pwl_rgb() const { return gamma_ramp_pwl_rgb_[0]; }
  virtual void OnGammaRamp256EntryTableValueWritten() {}
  virtual void OnGammaRampPWLValueWritten() {}

  virtual void MakeCoherent();
  virtual void PrepareForWait();
  virtual void ReturnFromWait();

  uint32_t ExecutePrimaryBuffer(uint32_t start_index, uint32_t end_index);
  virtual void OnPrimaryBufferEnd() {}
  void ExecuteIndirectBuffer(uint32_t ptr, uint32_t length);
  bool ExecutePacket(memory::RingBuffer* reader);
  bool ExecutePacketType0(memory::RingBuffer* reader, uint32_t packet);
  bool ExecutePacketType1(memory::RingBuffer* reader, uint32_t packet);
  bool ExecutePacketType2(memory::RingBuffer* reader, uint32_t packet);
  bool ExecutePacketType3(memory::RingBuffer* reader, uint32_t packet);
  bool ExecutePacketType3_ME_INIT(memory::RingBuffer* reader, uint32_t packet, uint32_t count);
  bool ExecutePacketType3_NOP(memory::RingBuffer* reader, uint32_t packet, uint32_t count);
  bool ExecutePacketType3_INTERRUPT(memory::RingBuffer* reader, uint32_t packet, uint32_t count);
  bool ExecutePacketType3_XE_SWAP(memory::RingBuffer* reader, uint32_t packet, uint32_t count);
  bool ExecutePacketType3_INDIRECT_BUFFER(memory::RingBuffer* reader, uint32_t packet,
                                          uint32_t count);
  bool ExecutePacketType3_WAIT_REG_MEM(memory::RingBuffer* reader, uint32_t packet, uint32_t count);
  bool ExecutePacketType3_REG_RMW(memory::RingBuffer* reader, uint32_t packet, uint32_t count);
  bool ExecutePacketType3_REG_TO_MEM(memory::RingBuffer* reader, uint32_t packet, uint32_t count);
  bool ExecutePacketType3_MEM_WRITE(memory::RingBuffer* reader, uint32_t packet, uint32_t count);
  bool ExecutePacketType3_COND_WRITE(memory::RingBuffer* reader, uint32_t packet, uint32_t count);
  bool ExecutePacketType3_EVENT_WRITE(memory::RingBuffer* reader, uint32_t packet, uint32_t count);
  bool ExecutePacketType3_EVENT_WRITE_SHD(memory::RingBuffer* reader, uint32_t packet,
                                          uint32_t count);
  bool ExecutePacketType3_EVENT_WRITE_EXT(memory::RingBuffer* reader, uint32_t packet,
                                          uint32_t count);
  virtual bool ExecutePacketType3_EVENT_WRITE_ZPD(memory::RingBuffer* reader, uint32_t packet,
                                                  uint32_t count);
  bool ExecutePacketType3Draw(memory::RingBuffer* reader, uint32_t packet, const char* opcode_name,
                              uint32_t viz_query_condition, uint32_t count_remaining);
  bool ExecutePacketType3_DRAW_INDX(memory::RingBuffer* reader, uint32_t packet, uint32_t count);
  bool ExecutePacketType3_DRAW_INDX_2(memory::RingBuffer* reader, uint32_t packet, uint32_t count);
  bool ExecutePacketType3_SET_CONSTANT(memory::RingBuffer* reader, uint32_t packet, uint32_t count);
  bool ExecutePacketType3_SET_CONSTANT2(memory::RingBuffer* reader, uint32_t packet,
                                        uint32_t count);
  bool ExecutePacketType3_LOAD_ALU_CONSTANT(memory::RingBuffer* reader, uint32_t packet,
                                            uint32_t count);
  bool ExecutePacketType3_SET_SHADER_CONSTANTS(memory::RingBuffer* reader, uint32_t packet,
                                               uint32_t count);
  bool ExecutePacketType3_IM_LOAD(memory::RingBuffer* reader, uint32_t packet, uint32_t count);
  bool ExecutePacketType3_IM_LOAD_IMMEDIATE(memory::RingBuffer* reader,

                                            uint32_t packet, uint32_t count);
  bool ExecutePacketType3_INVALIDATE_STATE(memory::RingBuffer* reader, uint32_t packet,
                                           uint32_t count);
  bool ExecutePacketType3_VIZ_QUERY(memory::RingBuffer* reader, uint32_t packet, uint32_t count);

  virtual Shader* LoadShader(xenos::ShaderType shader_type, uint32_t guest_address,
                             const uint32_t* host_address, uint32_t dword_count) = 0;

  virtual bool IssueDraw(xenos::PrimitiveType prim_type, uint32_t index_count,
                         IndexBufferInfo* index_buffer_info, bool major_mode_explicit) = 0;
  virtual bool IssueCopy() = 0;

  // Called while a WAIT_REG_MEM waits. If what follows it is the rest of the guest's swap (a
  // guest that holds its swap until the vertical blank), does the host's part of that at once:
  // the resolve to the front buffer and the present. The guest's part (events, interrupts, the
  // swap counter) still happens as the packets are reached after the wait. Returns whether it
  // did.
  bool TryIssueSwapBeforeWait(const memory::RingBuffer& reader);
  bool TryIssueSwapInLaterBufferBeforeWait(const memory::RingBuffer& reader);
  // Called while that wait goes on waiting, once the swap has been done ahead: does the host's
  // part of the packets the guest queues after the wait (its next frame's draws), up to the
  // first that cannot be split. They are done again for the guest only as they are reached.
  void ExecuteAheadOfWait(const memory::RingBuffer& reader);
  bool CanExecuteAhead(memory::RingBuffer& peek, uint32_t depth, bool only_padding);

  // "Actual" is for the command processor thread, to be read by the
  // implementations.
  SwapPostEffect GetActualSwapPostEffect() const { return swap_post_effect_actual_; }

  // Shared readback resolve mode with backend legacy-flag alias support.
  ReadbackResolveMode GetReadbackResolveMode(bool legacy_readback_resolve_enabled) const;
  // For ReadbackResolveMode::kTransient: counts this frame's resolve to the destination, and
  // returns whether to read it back. False once the destination has been resolved on more than
  // readback_resolve_transient_frames frames in a row, which is how the targets the game draws
  // every frame behave, and for a destination size not in readback_resolve_transient_sizes.
  bool IsResolveTransient(uint64_t frame, uint32_t written_address, uint32_t written_length);
  // For ReadbackResolveMode::kTransient: whether the destination's size is in
  // readback_resolve_delayed_sizes: such a resolve is read back every time, without waiting
  // for the GPU: what the game gets is the result of the time before to the same destination.
  bool IsResolveDelayedSize();
  // Logs a resolve and what readback did with it when readback_resolve_log is set.
  void LogResolve(uint64_t frame, uint32_t written_address, uint32_t written_length,
                  const char* readback) const;
  // Shared memexport readback enable state with backend legacy-flag override support.
  bool IsReadbackMemexportEnabled(bool legacy_backend_flag) const;

  memory::Memory* memory_ = nullptr;
  system::KernelState* kernel_state_ = nullptr;
  GraphicsSystem* graphics_system_ = nullptr;
  RegisterFile* register_file_ = nullptr;

  std::atomic<bool> worker_running_;
  system::object_ref<system::XHostThread> worker_thread_;

  std::queue<std::function<void()>> pending_fns_;

  // MicroEngine binary from PM4_ME_INIT
  std::vector<uint32_t> me_bin_;

  uint32_t counter_ = 0;
  // For TryIssueSwapBeforeWait: packets are being executed ahead of a wait for the host only,
  // or those same packets are now being executed for the guest only, up to the offset in the
  // buffer.
  enum class SwapAheadPass { kNone, kHost, kGuest };
  SwapAheadPass swap_ahead_pass_ = SwapAheadPass::kNone;
  const uint8_t* swap_ahead_buffer_ = nullptr;
  size_t swap_ahead_end_offset_ = 0;
  // For ExecuteAheadOfWait: the reader of the primary buffer being executed; whether and how
  // far past it the host's part has been done (an offset into the primary buffer, and the
  // bytes covered, which the normal execution then goes through for the guest only).
  memory::RingBuffer* primary_reader_ = nullptr;
  SwapAheadPass ahead_pass_ = SwapAheadPass::kNone;
  bool ahead_started_ = false;
  bool ahead_refused_ = false;
  // For CanExecuteAhead: the swap packet (its header's address) it may pass, once.
  uint32_t ahead_swap_header_ = 0;
  bool ahead_swap_found_ = false;
  // For TryIssueSwapInLaterBufferBeforeWait: the buffer with the swap packet, which is the
  // guest's only up to the swap's end when it is reached.
  const uint8_t* later_swap_buffer_ = nullptr;
  size_t later_swap_end_offset_ = 0;
  size_t ahead_offset_ = 0;
  size_t ahead_bytes_ = 0;
  // The swap packet the guest has written and this has not reached yet, 0 if none.
  std::atomic<uint32_t> swap_packet_queued_{0};

  uint32_t primary_buffer_ptr_ = 0;
  uint32_t primary_buffer_size_ = 0;

  uint32_t read_ptr_index_ = 0;
  uint32_t read_ptr_update_freq_ = 0;
  // For GuestGpuPosition (rex/patches/24): the read index as last set by the worker, and the
  // indirect buffer being executed (physical address, bytes, the read offset in it; 0 when none).
  std::atomic<uint32_t> position_read_index_{0};
  std::atomic<uint32_t> position_ib_ptr_{0};
  std::atomic<uint32_t> position_ib_bytes_{0};
  std::atomic<uint32_t> position_ib_offset_{0};
  uint32_t read_ptr_writeback_ptr_ = 0;

  std::unique_ptr<rex::thread::Event> write_ptr_index_event_;
  std::unique_ptr<rex::thread::Event> vblank_event_;
  // For WaitForGuestVisibleProgress.
  std::mutex progress_mutex_;
  std::condition_variable progress_condition_;
  std::atomic<uint32_t> progress_count_{0};
  std::atomic<uint32_t> progress_waiters_{0};
  std::atomic<uint32_t> write_ptr_index_;

  // Some titles submit writes beyond the emulated register file range in PM4
  // packets. Preserve these values so dependent packet logic can still observe
  // them instead of dropping the write entirely.
  std::unordered_map<uint32_t, uint32_t> extended_register_values_;

  uint64_t bin_select_ = 0xFFFFFFFFull;
  uint64_t bin_mask_ = 0xFFFFFFFFull;

  Shader* active_vertex_shader_ = nullptr;
  Shader* active_pixel_shader_ = nullptr;

  bool paused_ = false;

  // By default (such as for tools), post-processing is disabled.
  // "Desired" is for the external thread managing the post-processing effect.
  SwapPostEffect swap_post_effect_desired_ = SwapPostEffect::kNone;
  SwapPostEffect swap_post_effect_actual_ = SwapPostEffect::kNone;

  // For IsResolveTransient: by destination (address << 32 | length), the last frame it was
  // resolved on and for how many frames in a row up to that one.
  struct ResolveFrameRun {
    uint64_t last_frame = 0;
    uint32_t length = 0;
  };
  static constexpr size_t kMaxResolveFrameRuns = 1024;
  std::unordered_map<uint64_t, ResolveFrameRun> resolve_frame_runs_;
  // readback_resolve_transient_sizes as (width << 16) | height, and the string they came from.
  std::vector<uint32_t> resolve_transient_sizes_;
  std::string resolve_transient_sizes_parsed_from_;

  std::mutex texture_prewarm_mutex_;
  std::deque<std::array<uint32_t, 6>> texture_prewarm_queue_;
  std::vector<uint32_t> resolve_delayed_sizes_;
  std::string resolve_delayed_sizes_parsed_from_;

  // Set by backend command processors to their legacy memexport readback cvar
  // name (for explicit-override compatibility).
  const char* legacy_readback_memexport_cvar_name_ = nullptr;

 private:
  reg::DC_LUT_30_COLOR gamma_ramp_256_entry_table_[256] = {};
  reg::DC_LUT_PWL_DATA gamma_ramp_pwl_rgb_[128][3] = {};
  uint32_t gamma_ramp_rw_component_ = 0;
};

}  // namespace rex::graphics
