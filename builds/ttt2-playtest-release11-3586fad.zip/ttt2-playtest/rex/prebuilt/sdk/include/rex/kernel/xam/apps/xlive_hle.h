/**
 * Xbox Live service emulation (--live_signin): see xlive_hle.cpp.
 */
#pragma once

#include <cstdint>

#include <rex/cvar.h>
#include <rex/system/xtypes.h>

namespace rex {
namespace system {
class KernelState;
}
namespace kernel {
namespace xam {
namespace apps {

REXCVAR_DECLARE(int32_t, live_deployment);
REXCVAR_DECLARE(bool, live_trace);
void LiveBurstStart(int n);   // trace aid: the next n kernel calls are logged by the title-side observer
bool LiveBurstTake();
// --live_trace: one line for the first few messages of each kind.
void LiveTrace(const char* what, uint32_t app, uint32_t message, uint32_t a, uint32_t b, uint32_t result);

// Synchronous app messages (XMsgInProcessCall / the app's DispatchMessageSync). Returns true when the message was answered.
bool LiveHleSync(system::KernelState* ks, uint32_t app, uint32_t message, uint32_t arg1, uint32_t arg2, X_HRESULT* result);
// Asynchronous XRL requests to xlivebase (0xFC 0x0005xxxx: storage, string verify): result plus the extended error for the overlapped.
bool LiveHleXrl(system::KernelState* ks, uint32_t app, uint32_t message, uint32_t buffer_ptr, uint32_t buffer_length, uint32_t* result, uint32_t* ext);

}  // namespace apps
}  // namespace xam
}  // namespace kernel
}  // namespace rex
