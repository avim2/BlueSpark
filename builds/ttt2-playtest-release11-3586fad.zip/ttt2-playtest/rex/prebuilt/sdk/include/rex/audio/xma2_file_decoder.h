/**
 * Decodes the packets of an XMA2 file (a RIFF 'data' block: 2048-byte packets in order) with FFmpeg's stock
 * XMA2 decoder, for a player on the host side (ttt2's music copy, rex/src/music_copy.cpp). It has nothing to do
 * with the emulated XMA hardware (xma/context.h).
 */
#pragma once

#include <cstddef>
#include <cstdint>
#include <vector>

struct AVCodecContext;
struct AVPacket;
struct AVFrame;

namespace rex::audio {

class Xma2FileDecoder {
 public:
  Xma2FileDecoder() = default;
  ~Xma2FileDecoder();
  Xma2FileDecoder(const Xma2FileDecoder&) = delete;
  Xma2FileDecoder& operator=(const Xma2FileDecoder&) = delete;

  // `fmt_extra`: the bytes after the WAVEFORMATEX's cbSize in the RIFF's 'fmt ' block (34 for an
  // XMA2WAVEFORMATEX). False when FFmpeg refuses the stream (the reason is logged).
  bool Open(int channels, int sample_rate, const uint8_t* fmt_extra, size_t fmt_extra_size);
  // One packet in (2048 bytes); the samples it completes are appended to `out`, interleaved float.
  // False on a packet the decoder refused (the next one may still decode).
  bool Decode(const uint8_t* packet, size_t size, std::vector<float>& out);
  // The samples the decoder still holds back at the end of the data.
  void Drain(std::vector<float>& out);
  void Close();

  int channels() const { return channels_; }

 private:
  void Receive(std::vector<float>& out);

  AVCodecContext* context_ = nullptr;
  AVPacket* packet_ = nullptr;
  AVFrame* frame_ = nullptr;
  std::vector<uint8_t> padded_;
  int channels_ = 0;
};

}  // namespace rex::audio
