/**
 * @file        system/interfaces/graphics.h
 * @brief       Abstract graphics system interface for dependency injection
 *
 * @copyright   Copyright (c) 2026 Tom Clay <tomc@tctechstuff.com>
 *              All rights reserved.
 *
 * @license     BSD 3-Clause License
 *              See LICENSE file in the project root for full license text.
 */

#pragma once

#include <cstdint>
#include <filesystem>

#include <rex/system/xtypes.h>

// Forward declarations
namespace rex::runtime {
class FunctionDispatcher;
}
namespace rex::ui {
class GraphicsProvider;
class Presenter;
class WindowedAppContext;
}  // namespace rex::ui
namespace rex::system {
class KernelState;
}

namespace rex::system {

class IGraphicsSystem {
 public:
  virtual ~IGraphicsSystem() = default;

  // Build the provider + presenter. Safe to call standalone (without a
  // Runtime) to stand up a window + ImGui for an installer. Idempotent.
  // Must be called before SetupGuestGpu if presentation is desired: some
  // backends (e.g. Vulkan) bake swapchain support into the provider, and
  // a headless provider from SetupGuestGpu cannot be upgraded in place.
  virtual X_STATUS SetupPresentation(ui::WindowedAppContext* app_context) = 0;

  // Wire the GPU into the guest address space: MMIO, command processor,
  // vsync worker. Needs the Runtime's dispatcher + kernel state. If
  // SetupPresentation has not been called, a headless provider is built.
  virtual X_STATUS SetupGuestGpu(runtime::FunctionDispatcher* function_dispatcher,
                                 KernelState* kernel_state) = 0;

  virtual bool has_presentation() const = 0;

  // --- Optional capabilities, default no-op -------------------------------

  // Host presentation objects for ReXApp's overlay wiring; custom systems may
  // leave these null.
  virtual ui::GraphicsProvider* provider() const { return nullptr; }
  virtual ui::Presenter* presenter() const { return nullptr; }

  // Guest GPU services reached from the xboxkrnl Vd* exports.
  virtual void SetInterruptCallback(uint32_t callback, uint32_t user_data) {
    (void)callback;
    (void)user_data;
  }
  virtual void InitializeRingBuffer(uint32_t ptr, uint32_t size_log2) {
    (void)ptr;
    (void)size_log2;
  }
  virtual void EnableReadPointerWriteBack(uint32_t ptr, uint32_t block_size_log2) {
    (void)ptr;
    (void)block_size_log2;
  }

  // The guest has called VdSwap, which wrote the swap packet at this physical address, in a
  // command buffer the GPU may already have been given.
  virtual void OnGuestSwapQueued(uint32_t swap_packet_address) { (void)swap_packet_address; }

  // For a guest that spins until the GPU has got somewhere (Direct3D does, on the read pointer
  // the GPU writes back): sleeps until the GPU has written its read pointer back or run its
  // vertical blank interrupt since the count given, or for the time given, and returns the
  // count now. A caller passes back what it got the last time, so progress made
  // in between is never slept through.
  // Asks for the host's copies of textures to be made ahead of the first draw that uses them
  // (a few a frame, at the swap): fetch_words is 6 words a texture, a texture fetch constant
  // as the guest's Direct3D would write it to the GPU's registers (in the host's byte order).
  virtual void QueueTexturePrewarm(const uint32_t* fetch_words, uint32_t texture_count) {
    (void)fetch_words;
    (void)texture_count;
  }

  virtual uint32_t WaitForGuestVisibleProgress(uint32_t seen_count, uint32_t timeout_us) {
    (void)timeout_us;
    return seen_count;
  }

  // Where the command processor reads now, for a diagnostic of a title's rollback test
  // (rex/patches/24): out[0] the primary ring's read index as last set, [1] its write index,
  // [2] the ring's physical address, [3] its size in bytes, [4] the indirect buffer being
  // executed (its physical address; 0 when none), [5] its length in bytes, [6] the read offset
  // in it. False when there is no command processor. From any thread; the values are a moment's.
  virtual bool GuestGpuPosition(uint32_t out[7]) const {
    (void)out;
    return false;
  }

  // Persistent shader/pipeline storage under the cache root. Default: none.
  virtual void InitializeShaderStorage(const std::filesystem::path& cache_root, uint32_t title_id,
                                       bool blocking) {
    (void)cache_root;
    (void)title_id;
    (void)blocking;
  }

  // One-shot convenience for callers that don't care about the split.
  X_STATUS Setup(runtime::FunctionDispatcher* function_dispatcher, KernelState* kernel_state,
                 ui::WindowedAppContext* app_context, bool with_presentation) {
    if (with_presentation && !has_presentation()) {
      X_STATUS status = SetupPresentation(app_context);
      if (XFAILED(status)) {
        return status;
      }
    }
    return SetupGuestGpu(function_dispatcher, kernel_state);
  }

  virtual void Shutdown() = 0;
};

}  // namespace rex::system
