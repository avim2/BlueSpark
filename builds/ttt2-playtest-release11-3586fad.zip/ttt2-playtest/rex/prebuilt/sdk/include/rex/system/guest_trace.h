/**
 * @file        system/guest_trace.h
 * @brief       What each guest thread is doing: with guest_thread_log, a periodic log of the
 *              guest's threads, the processor time each used and the kernel calls each made.
 *
 * @license     BSD 3-Clause License
 *              See LICENSE file in the project root for full license text.
 */

#pragma once

#include <atomic>
#include <cstdint>

struct PPCContext;

namespace rex::system {

// For a title's own diagnostics and for what it must make the same on a re-run of a frame:
// a function called on entry to every kernel export, with its name (a string literal) and the
// guest registers (its arguments), and again when it has returned (its results); and one
// called with every reading of the guest's time base, the host address the reading is
// returned to, which may give another value in its place. One of each, nullptr for none.
using ExportObserver = void (*)(const char* name, ::PPCContext& ctx, bool returned);
using GuestTickObserver = uint64_t (*)(uint64_t ticks, void* return_address);
void SetExportObserver(ExportObserver observer);
void SetGuestTickObserver(GuestTickObserver observer);

namespace detail {
extern std::atomic<bool> g_guest_trace_enabled;
extern std::atomic<ExportObserver> g_export_observer;
uint64_t ObserveGuestTick(uint64_t ticks, void* return_address);
void TraceExportCallSlow(const char* name, uint32_t lr, uint32_t sp);
void TraceExportReturnSlow();
}  // namespace detail

// Takes up the guest_thread_log setting. Called once a guest frame.
void RefreshGuestTraceSetting();

// Called by every kernel export on entry, with its name (a string literal), the guest address
// it returns to and the guest stack pointer, and again when it returns. Each costs one load
// when guest_thread_log is off.
inline void TraceExportCall(const char* name, uint64_t lr, uint32_t sp) {
  if (detail::g_guest_trace_enabled.load(std::memory_order_relaxed)) {
    detail::TraceExportCallSlow(name, uint32_t(lr), sp);
  }
}
inline void TraceExportReturn() {
  if (detail::g_guest_trace_enabled.load(std::memory_order_relaxed)) {
    detail::TraceExportReturnSlow();
  }
}

inline void ObserveExport(const char* name, ::PPCContext& ctx, bool returned) {
  if (ExportObserver observer = detail::g_export_observer.load(std::memory_order_relaxed)) {
    observer(name, ctx, returned);
  }
}

}  // namespace rex::system
