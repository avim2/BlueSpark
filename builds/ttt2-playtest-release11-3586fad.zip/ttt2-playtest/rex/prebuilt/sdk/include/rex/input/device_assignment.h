#pragma once
/**
 * @file        rex/input/device_assignment.h
 * @brief       Policy assigning physical input devices to guest user indices.
 *
 * @copyright   Copyright (c) 2026 Tom Clay <tomc@tctechstuff.com>
 *              All rights reserved.
 *
 * @license     BSD 3-Clause License
 *              See LICENSE file in the project root for full license text.
 */

#include <cstdint>
#include <string>
#include <vector>

#include <rex/input/device.h>

namespace rex::input {

class ClaimAssignment;

class DeviceAssignment {
 public:
  virtual ~DeviceAssignment() = default;
  /// The claiming policy, if this is it (InputSystem lets unclaimed pads claim on their first input).
  virtual ClaimAssignment* AsClaim() { return nullptr; }

  /// Devices arrive sorted by ordinal.
  virtual void OnDevicesChanged(const std::vector<DeviceInfo>& devices) = 0;

  /// An empty result means the guest sees X_ERROR_DEVICE_NOT_CONNECTED.
  virtual void DevicesForUser(uint32_t user_index, std::vector<DeviceId>& out) const = 0;
};

/// Device ordinal N feeds guest user N. Synthetic devices feed user 0.
class SlotAssignment final : public DeviceAssignment {
 public:
  void OnDevicesChanged(const std::vector<DeviceInfo>& devices) override;
  void DevicesForUser(uint32_t user_index, std::vector<DeviceId>& out) const override;

 private:
  std::vector<std::vector<DeviceId>> users_ = std::vector<std::vector<DeviceId>>(kMaxGuestUsers);
};

/// The first device to send input claims guest user 0, the next user 1, and so on, whatever the
/// connection order (a pad plugged in second but pressed first is player one, so the signed-in
/// profile on user 0 is the player's). Until it claims, a device stays in its connection-order
/// slot (or the lowest free one). Claims last for the session: a claimed device that goes away
/// keeps its user reserved and a device with the same GUID and name gets it back. Synthetic
/// devices feed user 0.
class ClaimAssignment final : public DeviceAssignment {
 public:
  ClaimAssignment* AsClaim() override { return this; }
  void OnDevicesChanged(const std::vector<DeviceInfo>& devices) override;
  void DevicesForUser(uint32_t user_index, std::vector<DeviceId>& out) const override;
  bool IsClaimed(DeviceId id) const;
  /// The user the device now feeds, or -1 when every user is taken.
  int Claim(DeviceId id);

 private:
  struct Claimed {
    std::string key;  // GUID and name: a reconnected pad of the same kind takes the user back
    DeviceId id;      // kInvalid while the device is away
  };
  void Rebuild();
  std::vector<DeviceInfo> devices_;
  std::vector<Claimed> claims_;  // claim order = guest user
  std::vector<std::vector<DeviceId>> users_ = std::vector<std::vector<DeviceId>>(kMaxGuestUsers);
};

/// Every device feeds guest user 0. Users 1 and up report not connected. For
/// single-player titles that only ever poll user 0.
class SharedAssignment final : public DeviceAssignment {
 public:
  void OnDevicesChanged(const std::vector<DeviceInfo>& devices) override;
  void DevicesForUser(uint32_t user_index, std::vector<DeviceId>& out) const override;

 private:
  std::vector<DeviceId> user0_;
};

}  // namespace rex::input
