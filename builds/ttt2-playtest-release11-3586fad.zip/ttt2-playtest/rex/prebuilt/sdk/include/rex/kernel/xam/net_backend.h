/**
 * NetBackend: lets a title/game take over the guest's network calls (--live_signin family). See the TTT2 native project's xnet tunnel (src/online/).
 */
#pragma once

#include <cstdint>
#include <vector>

#include <rex/system/xtypes.h>

namespace rex {
namespace kernel {
namespace xam {

// All IN_ADDR values here are host-order numbers (10.255.0.1 = 0x0AFF0001), ports host order. Handles are the backend's own small numbers.
class NetBackend {
 public:
  virtual ~NetBackend() = default;
  virtual int32_t Socket(int af, int type, int proto) = 0;           // handle, or -1 with LastError()
  virtual int32_t Close(int32_t h) = 0;
  virtual int32_t Shutdown(int32_t h, int how) = 0;
  virtual int32_t Bind(int32_t h, uint16_t port) = 0;
  virtual int32_t Listen(int32_t h, int backlog) = 0;
  virtual int32_t Accept(int32_t h, uint32_t* peer_in_addr, uint16_t* peer_port) = 0;   // new handle or -1
  virtual int32_t Connect(int32_t h, uint32_t in_addr, uint16_t port) = 0;
  virtual int32_t Send(int32_t h, const uint8_t* data, uint32_t len) = 0;
  virtual int32_t Recv(int32_t h, uint8_t* data, uint32_t len) = 0;
  virtual int32_t SendTo(int32_t h, const uint8_t* data, uint32_t len, uint32_t in_addr, uint16_t port) = 0;
  virtual int32_t RecvFrom(int32_t h, uint8_t* data, uint32_t len, uint32_t* in_addr, uint16_t* port) = 0;
  virtual int32_t Available(int32_t h) = 0;                          // FIONREAD
  virtual int32_t GetSockName(int32_t h, uint32_t* in_addr, uint16_t* port) = 0;
  virtual int32_t SoError(int32_t h) = 0;                            // SO_ERROR
  // Each vector holds the handles to look at on entry and the ready ones on return; returns the ready count (or -1).
  virtual int32_t Select(std::vector<int32_t>& read, std::vector<int32_t>& write, std::vector<int32_t>& except, int64_t timeout_us) = 0;
  virtual int32_t LastError() = 0;                                   // the Winsock error of the last failed call on this thread
  // XNet identity and addressing
  virtual void FillXnAddr(uint8_t out[36]) = 0;
  virtual uint32_t XnAddrToInAddr(const uint8_t xnaddr[36]) = 0;     // 0 when not mappable
  virtual bool InAddrToXnAddr(uint32_t in_addr, uint8_t out[36]) = 0;
  virtual bool XnAddrToMachineId(const uint8_t xnaddr[36], uint64_t* id) = 0;
  // Xbox Live session messages (XGI app 0xFB, XamApp/XLiveBase extras): true when answered.
  virtual bool XgiMessage(uint32_t message, uint32_t buffer_ptr, uint32_t buffer_length, X_HRESULT* result) = 0;
};

void SetNetBackend(NetBackend* backend);
NetBackend* GetNetBackend();

}  // namespace xam
}  // namespace kernel
}  // namespace rex
