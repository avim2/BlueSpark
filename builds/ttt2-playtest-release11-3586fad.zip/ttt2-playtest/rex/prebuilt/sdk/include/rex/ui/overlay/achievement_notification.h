/**
 * @file        rex/ui/overlay/achievement_notification.h
 * @brief       Replaceable achievement notification dialog interface.
 *
 * @copyright   Copyright (c) 2026 Rien Gupta <rgupta9@scu.edu>
 *              All rights reserved.
 *
 * @license     BSD 3-Clause License
 *              See LICENSE file in the project root for full license text.
 */
#pragma once

#include <functional>
#include <utility>

#include <rex/system/achievement_manager.h>
#include <rex/ui/imgui_dialog.h>

namespace rex::ui {

class AchievementNotificationDialog : public ImGuiDialog {
 public:
  ~AchievementNotificationDialog() override = default;

  // Thread-safe implementations may receive events from guest threads.
  virtual void Push(const rex::system::AchievementEvent& event) = 0;

  // Whether there is nothing left to show. The owner destroys an idle dialog, because any
  // dialog, drawn or not, makes the presenter paint from the UI thread rather than straight
  // from the guest's swap. Called in the UI thread.
  virtual bool IsIdle() const { return false; }
  // Called in the UI thread when the dialog becomes idle.
  void SetIdleCallback(std::function<void()> callback) { idle_callback_ = std::move(callback); }

 protected:
  explicit AchievementNotificationDialog(ImGuiDrawer* drawer) : ImGuiDialog(drawer) {}

  void NotifyIdle() {
    if (idle_callback_) {
      idle_callback_();
    }
  }

 private:
  std::function<void()> idle_callback_;
};

}  // namespace rex::ui
