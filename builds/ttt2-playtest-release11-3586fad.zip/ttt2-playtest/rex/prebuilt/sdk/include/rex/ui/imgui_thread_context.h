/**
 * Dear ImGui's user config (IMGUI_USER_CONFIG, set on the imgui target): its current context
 * per thread rather than one for the process, so that a drawer on the thread presenting the
 * guest output (Presenter::SetGuestOutputThreadDrawer) can use a context of its own while the
 * UI thread draws its dialogs with theirs. Every ImGui user sets its context on its own thread
 * before use, as ImGuiDrawer does.
 */

#pragma once

struct ImGuiContext;
extern thread_local ImGuiContext* RexImGuiCurrentContext;
#define GImGui RexImGuiCurrentContext
