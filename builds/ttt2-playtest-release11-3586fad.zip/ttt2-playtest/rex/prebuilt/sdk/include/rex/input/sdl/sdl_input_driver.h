/**
 ******************************************************************************
 * Xenia : Xbox 360 Emulator Research Project                                 *
 ******************************************************************************
 * Copyright 2020 Ben Vanik. All rights reserved.                             *
 * Released under the BSD license - see LICENSE in the root for more details. *
 ******************************************************************************
 *
 * @modified    Tom Clay, 2026 - Adapted for ReXGlue runtime
 */

#pragma once

#include <atomic>
#include <thread>
#include <mutex>
#include <optional>
#include <vector>

#include <rex/input/input_driver.h>

#include <SDL3/SDL.h>

#define HID_SDL_THUMB_THRES 0x4E00
#define HID_SDL_TRIGG_THRES 0x1F
#define HID_SDL_REPEAT_DELAY 400
#define HID_SDL_REPEAT_RATE 100

namespace rex::input::sdl {

class SDLInputDriver final : public InputDriver, public rex::ui::WindowListener {
 public:
  explicit SDLInputDriver(rex::ui::Window* window, size_t window_z_order);
  ~SDLInputDriver() override;

  X_STATUS Setup() override;

  void EnumerateDevices(std::vector<DeviceInfo>& out) override;
  X_RESULT GetDeviceState(DeviceId id, X_INPUT_STATE* out_state) override;
  X_RESULT GetDeviceCapabilities(DeviceId id, uint32_t flags,
                                 X_INPUT_CAPABILITIES* out_caps) override;
  X_RESULT SetDeviceVibration(DeviceId id, X_INPUT_VIBRATION* vibration) override;
  X_RESULT GetDeviceKeystroke(DeviceId id, uint32_t flags,
                              X_INPUT_KEYSTROKE* out_keystroke) override;
  void OnWindowAvailable(rex::ui::Window* window) override;

 private:
  enum class RepeatState {
    Idle,       // no buttons pressed or repeating has ended
    Waiting,    // a button is held and the delay is awaited
    Repeating,  // actively repeating at a rate
  };
  struct KeystrokeState {
    uint64_t buttons;
    RepeatState repeat_state;
    // the button number that was pressed last:
    uint8_t repeat_butt_idx;
    // the last time (ms) a down (and/or repeat) event for that button was send:
    uint32_t repeat_time;
  };

  struct ControllerState {
    SDL_Gamepad* sdl;
    X_INPUT_CAPABILITIES caps;
    X_INPUT_STATE state;
    bool state_changed;
    bool is_active;
    DeviceId id;
    // Per pad rather than per guest user, so it survives reassignment.
    KeystrokeState keystroke;
    // sdl_latch_presses: the presses since the game's last read, reported at the next one.
    uint16_t latched_buttons;
    uint8_t latched_left_trigger;
    uint8_t latched_right_trigger;
    bool latch_reported;
    // sdl_latch_directions=false / sdl_latch_debounce_ms (patch 53): the buttons and triggers last handed to the
    // game, and SDL's time of each button's last release (by its bit), so a release's bounce isn't latched.
    uint16_t reported_buttons;
    uint8_t reported_left_trigger;
    uint8_t reported_right_trigger;
    uint64_t released_ns[16];
    // SDL's time (SDL_GetTicksNS) of the newest state change, for the latency log.
    uint64_t last_change_ns;
  };

  // WindowListener
  void OnClosing(rex::ui::UIEvent& e) override;
  void OnLostFocus(rex::ui::UISetupEvent& e) override;
  void OnGotFocus(rex::ui::UISetupEvent& e) override;

  void HandleEvent(const SDL_Event& event);
  std::unique_lock<std::mutex> DrainAndLock();
  void ProcessEventLocked(const SDL_Event& event);
  void OnControllerDeviceAddedLocked(const SDL_Event& event);
  void OnControllerDeviceRemovedLocked(const SDL_Event& event);
  void OnControllerDeviceAxisMotionLocked(const SDL_Event& event);
  void OnControllerDeviceButtonChangedLocked(const SDL_Event& event);

  inline uint64_t AnalogToKeyfield(const X_INPUT_GAMEPAD& gamepad) const;
  std::optional<size_t> GetControllerIndexFromInstanceID(SDL_JoystickID instance_id);
  ControllerState* FindController(DeviceId id);
  DeviceId AllocateDeviceId();
  bool TestSDLVersion() const;
  void UpdateXCapabilities(ControllerState& state);
  void QueueControllerUpdate();

  rex::ui::Window* attached_window_ = nullptr;
  bool sdl_events_initialized_;
  bool SDL_Gamepad_initialized_;
  std::atomic<int> sdl_events_unflushed_;
  std::atomic<bool> sdl_pumpevents_queued_;
  // Appended in connection order, never re-sorted, and unbounded: the
  // assignment decides how many the guest sees.
  std::vector<ControllerState> controllers_;
  std::mutex controllers_mutex_;
  std::mutex event_queue_mutex_;
  std::vector<SDL_Event> pending_events_;
  // Never rewound, so a handle held past a disconnect resolves to nothing.
  uint64_t next_device_id_ = 1;

  // sdl_poll_thread_us: a thread of its own polling SDL's gamepads between the game's reads.
  void StartPollThread();
  void StopPollThread();
  std::thread poll_thread_;
  std::atomic<bool> poll_thread_running_{false};

  // sdl_tap_test_ms: a virtual pad tapped and held by a thread, the game's reads of it counted.
  void StartTapTest();
  void StopTapTest();
  void CountTapTestRead(uint16_t buttons);
  std::thread tap_thread_;
  std::atomic<bool> tap_thread_running_{false};
  SDL_JoystickID tap_pad_id_ = 0;
  std::atomic<uint32_t> tap_number_{0};   // the newest tap's number
  std::atomic<uint32_t> tap_phase_{0};    // 0 nothing down, 1 a tap down, 2 a hold down
  std::atomic<uint32_t> taps_injected_{0};
  std::atomic<uint32_t> holds_injected_{0};
  std::atomic<uint64_t> tap_length_ns_{0};
  uint32_t tap_last_seen_ = 0;
  uint32_t taps_seen_ = 0;
  uint32_t tap_reads_extra_ = 0;
  uint32_t hold_reads_ = 0;
  uint64_t tap_last_log_ns_ = 0;
};

}  // namespace rex::input::sdl
