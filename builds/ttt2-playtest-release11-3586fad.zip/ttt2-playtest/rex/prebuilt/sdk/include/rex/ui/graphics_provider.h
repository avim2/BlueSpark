#pragma once
/**
 ******************************************************************************
 * Xenia : Xbox 360 Emulator Research Project                                 *
 ******************************************************************************
 * Copyright 2015 Ben Vanik. All rights reserved.                             *
 * Released under the BSD license - see LICENSE in the root for more details. *
 ******************************************************************************
 *
 * @modified    Tom Clay, 2026 - Adapted for ReXGlue runtime
 */

#include <memory>

#include <rex/ui/immediate_drawer.h>
#include <rex/ui/presenter.h>

namespace rex {
namespace ui {

class Window;

// Factory for graphics contexts.
// All contexts created by the same provider will be able to share resources
// according to the rules of the backing graphics API.
class GraphicsProvider {
 public:
  enum class GpuVendorID {
    kAMD = 0x1002,
    kApple = 0x106B,
    kArm = 0x13B5,
    kImagination = 0x1010,
    kIntel = 0x8086,
    kMicrosoft = 0x1414,
    kNvidia = 0x10DE,
    kQualcomm = 0x5143,
  };

  GraphicsProvider(const GraphicsProvider&) = delete;
  GraphicsProvider& operator=(const GraphicsProvider&) = delete;
  GraphicsProvider(GraphicsProvider&&) = delete;
  GraphicsProvider& operator=(GraphicsProvider&&) = delete;

  virtual ~GraphicsProvider() = default;

  // It's safe to reinitialize the presenter in the host GPU loss callback if it
  // was called from the UI thread as specified in the arguments.
  virtual std::unique_ptr<Presenter> CreatePresenter(
      Presenter::HostGpuLossCallback host_gpu_loss_callback =
          Presenter::FatalErrorHostGpuLossCallback) = 0;

  virtual std::unique_ptr<ImmediateDrawer> CreateImmediateDrawer() = 0;

 protected:
  GraphicsProvider() = default;
};

}  // namespace ui
}  // namespace rex
