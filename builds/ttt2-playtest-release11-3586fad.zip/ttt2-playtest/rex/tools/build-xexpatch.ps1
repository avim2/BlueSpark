# xexpatch.exe (XenonRecomp's XEX patcher, recomp\tools\xexpatch.cpp: it applies the player's title update to
# default.xex) with the clang-cl on PATH (the pinned portable toolchain): /MT, so it needs no runtime.
#
# Since the owner's G3 of 26 Oct no release ships xexpatch.exe: a player's Windows Defender quarantined 4.2.1's (a new
# unsigned exe from the internet). The release ships the patcher's source instead (source\xexpatch\: xexpatch.cpp and
# the part of XenonRecomp it compiles, with their licences), and step 2 builds it on the player's PC with step 1's
# compiler (prepare-game.ps1). rex\build-prebuilt.ps1 lays that folder out (Copy-XexpatchSources) and proves it
# compiles; a developer's clone builds from XenonRecomp at the pinned commit (Build-Xexpatch).
#
#   . rex\tools\build-xexpatch.ps1
#   Build-Xexpatch -Repo <the repo> -Work <a folder of its own> -Out <xexpatch.exe>          (returns the XenonRecomp commit)
#   Compile-Xexpatch -XenonRecomp <folder> -XexpatchCpp <xexpatch.cpp> -Work <folder> -Out <xexpatch.exe>
#   Copy-XexpatchSources -Repo <the repo> -Work <folder> -Dest <source\xexpatch>
$script:XenonRecompUrl = 'https://github.com/hedge-dev/XenonRecomp.git'
. (Join-Path $PSScriptRoot 'remove-folder.ps1')

function Invoke-XexpatchNative {
    $saved = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $out = @()
    try { $out = @(& $args[0] $args[1..($args.Count - 1)] 2>&1 | ForEach-Object { "$_" }) } finally { $ErrorActionPreference = $saved }
    if ($LASTEXITCODE -ne 0) {
        # (The compiler's own words, its last 40 lines, on screen and in the error: a player's step 2 said only "Failed (1):
        # clang-cl ...", and the cause, an older Visual Studio's MSVC version taken by clang, was lost, 27 Oct.)
        $tail = @($out | Where-Object { $_ -and $_ -notmatch '^\s*$' } | Select-Object -Last 40)
        $tail | ForEach-Object { Write-Host $_ }
        throw "Failed ($LASTEXITCODE): $($args -join ' ')`n$($tail -join "`n")"
    }
    $out
}

# XenonRecomp at the pinned commit (recomp\XENONRECOMP_COMMIT) with only the three libraries the patcher needs, in
# <Work>\XenonRecomp (fetched again only when the commit changes).
function Get-XexpatchXenonRecomp([string]$Repo, [string]$Work) {
    $commit = (Get-Content (Join-Path $Repo 'recomp\XENONRECOMP_COMMIT') -Raw).Trim()
    $xr = Join-Path $Work 'XenonRecomp'
    $stamp = Join-Path $xr 'ttt2-commit.txt'
    if (-not ((Test-Path $stamp) -and (Get-Content $stamp -Raw).Trim() -eq $commit -and (Test-Path (Join-Path $xr 'XenonUtils\xex_patcher.cpp')))) {
        Remove-Ttt2Folder $xr
        New-Item -ItemType Directory -Force $xr | Out-Null
        Push-Location $xr
        try {
            Invoke-XexpatchNative git init -q | ForEach-Object { Write-Host "  git: $_" }
            Invoke-XexpatchNative git remote add origin $script:XenonRecompUrl | ForEach-Object { Write-Host "  git: $_" }
            Invoke-XexpatchNative git fetch -q --depth 1 origin $commit | ForEach-Object { Write-Host "  git: $_" }
            Invoke-XexpatchNative git checkout -q FETCH_HEAD | ForEach-Object { Write-Host "  git: $_" }
            Invoke-XexpatchNative git submodule update -q --init --depth 1 thirdparty/libmspack thirdparty/tiny-AES-c thirdparty/simde | ForEach-Object { Write-Host "  git: $_" }
        } finally { Pop-Location }
        Set-Content $stamp $commit
    }
    $xr
}

# The patcher's own files in XenonRecomp's tree (relative to it), compiled as below.
$script:XexpatchUnits = @('thirdparty\libmspack\libmspack\mspack\lzxd.c', 'thirdparty\tiny-AES-c\aes.c',
    'XenonUtils\xex_patcher.cpp', 'XenonUtils\xex.cpp', 'XenonUtils\image.cpp', 'XenonUtils\memory_mapped_file.cpp')
# Their licences, shipped beside them.
$script:XexpatchLicences = @('LICENSE.md', 'thirdparty\libmspack\libmspack\COPYING.LIB', 'thirdparty\tiny-AES-c\unlicense.txt')

# Compiles xexpatch.exe from a XenonRecomp tree (a checkout, or the release's source\xexpatch\XenonRecomp) and
# xexpatch.cpp. -ListSources: returns the files of the tree the compile read (its units and every header it included,
# relative to the tree), for Copy-XexpatchSources.
function Compile-Xexpatch([string]$XenonRecomp, [string]$XexpatchCpp, [string]$Work, [string]$Out, [switch]$ListSources) {
    $obj = Join-Path $Work 'obj'
    Remove-Ttt2Folder $obj
    New-Item -ItemType Directory -Force $obj | Out-Null
    $u = Join-Path $XenonRecomp 'XenonUtils'
    $t = Join-Path $XenonRecomp 'thirdparty'
    $includes = @("/I$u", "/I$t\simde", "/I$t\libmspack\libmspack\mspack", "/I$t\tiny-AES-c", "/I$t\TinySHA1")
    $flags = @('/nologo', '/c', '/O2', '/MT', '/DNOMINMAX', '/D_CRT_SECURE_NO_WARNINGS')
    if ($ListSources) { $flags += '/showIncludes' }
    $units = @($script:XexpatchUnits | ForEach-Object { Join-Path $XenonRecomp $_ })
    $said = @()
    Push-Location $obj
    try {
        $said += Invoke-XexpatchNative clang-cl @flags @includes $units[0] $units[1]
        $said += Invoke-XexpatchNative clang-cl @flags /EHsc /std:c++20 @includes $units[2] $units[3] $units[4] $units[5] $XexpatchCpp
        $objects = @(Get-ChildItem $obj -Filter *.obj | ForEach-Object { $_.FullName })
        # (lld, the pinned toolchain's own linker: without it clang-cl looks for Visual Studio's link.exe, which a PC
        # with only the portable toolchain doesn't have; 22 Oct, the fast client's PC.)
        Invoke-XexpatchNative clang-cl /nologo /MT -fuse-ld=lld /Fexexpatch.exe @objects | Out-Null
        New-Item -ItemType Directory -Force (Split-Path $Out) | Out-Null
        Move-Item -Force (Join-Path $obj 'xexpatch.exe') $Out
    } finally { Pop-Location }
    if ($ListSources) {
        $root = (Resolve-Path $XenonRecomp).Path.TrimEnd('\') + '\'
        $headers = @($said | Where-Object { $_ -match '^Note: including file:\s*(.+)$' } | ForEach-Object { $Matches[1].Trim() } |
            Where-Object { $_.StartsWith($root, [StringComparison]::OrdinalIgnoreCase) } | ForEach-Object { $_.Substring($root.Length) })
        return @($script:XexpatchUnits + $headers | Sort-Object -Unique)
    }
}

# A developer's clone: XenonRecomp fetched at the pinned commit, then compiled.
function Build-Xexpatch([string]$Repo, [string]$Work, [string]$Out) {
    $xr = Get-XexpatchXenonRecomp $Repo $Work
    Compile-Xexpatch -XenonRecomp $xr -XexpatchCpp (Join-Path $Repo 'recomp\tools\xexpatch.cpp') -Work $Work -Out $Out
    (Get-Content (Join-Path $Repo 'recomp\XENONRECOMP_COMMIT') -Raw).Trim()
}

# The release's source\xexpatch\ (build-prebuilt.ps1): xexpatch.cpp, the XenonRecomp commit, and from XenonRecomp at that
# commit exactly the files the compile reads, with the licences; then compiled again from that folder alone, so a
# missing file stops the release here and never on a player's PC. Returns the XenonRecomp commit.
function Copy-XexpatchSources([string]$Repo, [string]$Work, [string]$Dest) {
    $xr = Get-XexpatchXenonRecomp $Repo $Work
    $used = Compile-Xexpatch -XenonRecomp $xr -XexpatchCpp (Join-Path $Repo 'recomp\tools\xexpatch.cpp') -Work $Work `
        -Out (Join-Path $Work 'listed\xexpatch.exe') -ListSources
    New-Item -ItemType Directory -Force $Dest | Out-Null
    Copy-Item (Join-Path $Repo 'recomp\tools\xexpatch.cpp') $Dest
    Copy-Item (Join-Path $Repo 'recomp\XENONRECOMP_COMMIT') $Dest
    $tree = Join-Path $Dest 'XenonRecomp'
    foreach ($rel in @($used) + $script:XexpatchLicences) {
        $to = Join-Path $tree $rel
        # (The licences as .txt: XenonRecomp's LICENSE.md as LICENSE.txt, the package ships no markdown (the owner, 25 Oct);
        # libmspack's COPYING.LIB as COPYING.LIB.txt, the packager takes any .lib for a binary.)
        if ($script:XexpatchLicences -contains $rel) { $to = if ($rel -match '\.md$') { $to -replace '\.md$', '.txt' } elseif ($rel -notmatch '\.txt$') { "$to.txt" } else { $to } }
        New-Item -ItemType Directory -Force (Split-Path $to) | Out-Null
        Copy-Item (Join-Path $xr $rel) $to
    }
    Compile-Xexpatch -XenonRecomp $tree -XexpatchCpp (Join-Path $Dest 'xexpatch.cpp') -Work (Join-Path $Work 'check') `
        -Out (Join-Path $Work 'check\xexpatch.exe')
    $files = @(Get-ChildItem $tree -Recurse -File)
    Write-Host ("xexpatch's source: {0} files of XenonRecomp, {1:N0} KB, compiled from that folder alone" -f $files.Count, (($files | Measure-Object Length -Sum).Sum / 1KB))
    (Get-Content (Join-Path $Repo 'recomp\XENONRECOMP_COMMIT') -Raw).Trim()
}
