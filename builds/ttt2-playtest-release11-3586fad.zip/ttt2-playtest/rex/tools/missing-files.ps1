# Our files that should be there and aren't (the lead's D2 and G3, 27 Oct): the box Start Here shows at its start and
# after a failed step, and the problem report's missing-files.txt. From the package's own list (rex\package-signature.txt)
# and the compiler's files once step 1 recorded them unpacked: no antivirus is asked anything (4.4.2: 4.4.1's whole zip
# was flagged by players' antivirus; this file's earlier form read the antivirus's detections and event log, which a
# script scanner can take for reconnaissance).
#
#   . rex\tools\missing-files.ps1

# The install's files (rex\package-signature.txt lists every file of the package), and the tools' that the compiler
# needs once step 1 recorded them unpacked (G3: a tool file the unpack put there and that went afterwards).
function Get-Ttt2MissingFiles([string]$install) {
    $missing = New-Object System.Collections.Generic.List[string]
    $sig = Join-Path $install 'rex\package-signature.txt'
    if (Test-Path $sig) {
        foreach ($line in Get-Content $sig) {
            if ($line -notmatch '^[0-9a-f]{64} [^/]+/(.+)$') { continue }   # (the zip's paths: its top folder first)
            $p = Join-Path $install ($Matches[1] -replace '/', '\')
            if (-not (Test-Path -LiteralPath $p)) { $missing.Add($p) }
        }
    }
    if (Get-Command Get-Ttt2ToolchainRoot -ErrorAction SilentlyContinue) {
        $root = Get-Ttt2ToolchainRoot
        $need = @{ llvm = @('bin\clang.exe', 'bin\clang-cl.exe', 'bin\lld-link.exe', 'bin\llvm-lib.exe', 'bin\llvm-rc.exe'); cmake = @('bin\cmake.exe'); ninja = @('ninja.exe') }
        foreach ($k in $need.Keys) {
            $folder = Get-Ttt2PinFolder $root $script:Ttt2ToolchainPins[$k]
            if (-not (Test-Path (Join-Path $folder 'ttt2-unpacked.txt'))) { continue }
            foreach ($f in $need[$k]) { $p = Join-Path $folder $f; if (-not (Test-Path -LiteralPath $p)) { $missing.Add($p) } }
        }
    }
    @($missing)
}

# The box's text for missing files; $null when none is missing.
function Get-Ttt2MissingFilesNote([string]$install) {
    $missing = @(Get-Ttt2MissingFiles $install)
    if (-not $missing.Count) { return $null }
    $lines = @($missing | Select-Object -First 8 | ForEach-Object { "- $_" })
    if ($missing.Count -gt 8) { $lines += "- and $($missing.Count - 8) more" }
    "$($missing.Count) of TTT2's files are missing:`r`n$($lines -join "`r`n")`r`n`r`n" +
        "An antivirus may have removed them: look in Windows Security, Protection history, restore them there, then run this step again.`r`n`r`n" +
        "Or: files in the tools folder: click Install tools again. Files of this package: download the release again and drop the zip onto this window, or unzip it over this folder."
}
