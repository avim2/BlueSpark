# Remove-Ttt2Folder: deletes folders (with everything in them) and files through .NET ([IO.Directory]::Delete,
# [IO.File]::Delete), not PowerShell's FileSystem provider. A player's step 2 under Desktop\<a non-ASCII name> stopped at
# prepare-game.ps1's Remove-Item -Recurse with "An object at the specified path ... does not exist" although Test-Path had
# found the folder (Windows PowerShell 5.1, 27 Oct). Paths are taken as they are (no wildcards), relative ones from the
# current location. Read-only files are made writable first (Directory.Delete refuses them). Nothing there: nothing done.
#
#   . rex\tools\remove-folder.ps1
#   Remove-Ttt2Folder $path [-Quiet]      (-Quiet: a failure is not thrown; it returns $false)

function Remove-Ttt2Folder {
    param([Parameter(Mandatory, Position = 0)][string[]]$Path, [switch]$Quiet)
    $ok = $true
    foreach ($p in $Path) {
        try {
            $full = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($p)
            if ([IO.Directory]::Exists($full)) {
                foreach ($f in [IO.Directory]::GetFiles($full, '*', [IO.SearchOption]::AllDirectories)) {
                    if (([IO.File]::GetAttributes($f) -band [IO.FileAttributes]::ReadOnly) -ne 0) { [IO.File]::SetAttributes($f, [IO.FileAttributes]::Normal) }
                }
                [IO.Directory]::Delete($full, $true)
            } elseif ([IO.File]::Exists($full)) {
                [IO.File]::SetAttributes($full, [IO.FileAttributes]::Normal)
                [IO.File]::Delete($full)
            }
        } catch {
            $ok = $false
            if (-not $Quiet) { throw "Could not delete ${p}: $($_.Exception.GetBaseException().Message)" }
        }
    }
    if ($Quiet) { return $ok }
}
