# Uploads this PC's online replays to the server (themail2/ttt2-server: POST /v1/replays; its REPLAY_STORAGE_SPEC_20261021.md, and
# training/ONLINE_REPLAY_INGEST.md on the training-mode branch). run-windows.ps1 starts it hidden beside the game when the game goes online,
# and it ends when the game does. It runs outside the game on purpose: no network code in the game process.
#
#   powershell -ExecutionPolicy Bypass -File rex\tools\replay-uploader.ps1 -UserData <the game's user data root> [-Worker https://elo.bluespark.site] [-GamePid <pid>] [-Once]
#
# What it does:
#   - looks at <user data>\replays and <user data>\replays\saved every few seconds for *-online.ttt2replay files (the game writes <name>.partial and
#     then renames it, so *.partial is never sent);
#   - sends each one whole and unchanged, signed with this install's identity key (<user data>\live\identity.key, DPAPI-protected; its XUID is in
#     identity.reg), the same key the game signs its match results with. The server keeps one copy per match and adds the other PC as its second player;
#   - keeps a list of what was sent (<user data>\live\replays-uploaded.txt: the file's name, its SHA-256, the server's answer) and never moves, renames
#     or deletes anything in the replays folder (the game's own list reads it);
#   - at its start, sends the online replays the list doesn't have yet (matches played while it wasn't running);
#   - tries a failure again later (no network, 429, 5xx: after 1, 5, 15 then 60 minutes), gives up on a file the server refuses (another 4xx,
#     noted in the list) and logs to <user data>\live\replay-uploader.log.
# -Once: one pass over the folder, then it ends (a test, or a manual catch-up). Turned off by "replay_upload=false" in the user data's
# launcher-settings.txt (run-windows.ps1 then doesn't start it).

param(
    [Parameter(Mandatory)][string]$UserData,
    [string]$ProfileDir = '',   # the profile folder (run-windows.ps1's --profile_data_root, 23 October): the identity lives in its live\ folder
    [string]$Worker = 'https://elo.bluespark.site',
    [int]$GamePid = 0,
    [switch]$Once,
    [int]$PollSeconds = 5
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Security
Add-Type -AssemblyName System.Core
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

$live = Join-Path $UserData 'live'
$replays = Join-Path $UserData 'replays'
$listFile = Join-Path $live 'replays-uploaded.txt'
$logFile = Join-Path $live 'replay-uploader.log'
$Worker = $Worker.TrimEnd('/')
New-Item -ItemType Directory -Force $live | Out-Null

function Log([string]$text) {
    try {
        if ((Test-Path $logFile) -and (Get-Item $logFile).Length -gt 1MB) { Move-Item -Force $logFile ($logFile + '.old') }
        Add-Content -Path $logFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $text) -Encoding UTF8
    } catch {}
}

# One uploader per user data folder (a second start, from a second launch of the game, ends at once).
$sha = [Security.Cryptography.SHA256]::Create()
$tag = -join ($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes((Resolve-Path $UserData).Path.ToLowerInvariant())) | Select-Object -First 8 | ForEach-Object { $_.ToString('x2') })
$mutex = [Threading.Mutex]::new($false, 'Local\ttt2-replay-uploader-' + $tag)
if (-not $mutex.WaitOne(0)) { exit 0 }

function Hex([byte[]]$b) { -join ($b | ForEach-Object { $_.ToString('x2') }) }
function B64Url([byte[]]$b) { [Convert]::ToBase64String($b).TrimEnd('=').Replace('+', '-').Replace('/', '_') }

# The identity: the game makes it at its first online start and registers it with the server (identity.reg is written once that's done).
$script:ec = $null; $script:xuid = $null
# Where: the profile folder's live\ (since 23 October the identity is kept in %LOCALAPPDATA%\TTT2Native\profile, outside the game folder;
# without this the uploader looked only in the user data folder, found nothing and sent nothing), else the user data's (older installs, tests),
# else the default profile folder (a run-windows.ps1 from before this change, which doesn't pass -ProfileDir).
function IdentityDir {
    $dirs = @()
    if ($ProfileDir) { $dirs += (Join-Path $ProfileDir 'live') }
    $dirs += $live
    if ($env:LOCALAPPDATA) { $dirs += (Join-Path $env:LOCALAPPDATA 'TTT2Native\profile\live') }
    foreach ($d in $dirs) { if ((Test-Path (Join-Path $d 'identity.reg')) -and (Test-Path (Join-Path $d 'identity.key'))) { return $d } }
    return $null
}
function LoadIdentity {
    $dir = IdentityDir
    if (-not $dir) { return $false }
    $reg = Join-Path $dir 'identity.reg'; $keyFile = Join-Path $dir 'identity.key'
    $x = ((Get-Content $reg -Raw) -split '\s+')[0].Trim().ToLowerInvariant()
    if ($x -notmatch '^0009[0-9a-f]{12}$') { Log "identity.reg holds no XUID"; return $false }
    $raw = [Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($keyFile), $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
    $key = [Security.Cryptography.CngKey]::Import($raw, [Security.Cryptography.CngKeyBlobFormat]::EccPrivateBlob)
    $e = New-Object Security.Cryptography.ECDsaCng($key)
    $e.HashAlgorithm = [Security.Cryptography.CngAlgorithm]::Sha256
    $script:ec = $e; $script:xuid = $x
    return $true
}

# The list of what was sent: name <tab> sha256 <tab> answer <tab> time. A file is done once the server stored it, already had it, or refused it.
$done = @{}
if (Test-Path $listFile) {
    foreach ($line in Get-Content $listFile) { $f = $line -split "`t"; if ($f.Count -ge 3) { $done[$f[1]] = $f[2] } }
}
function Note([string]$name, [string]$hash, [string]$answer) {
    $done[$hash] = $answer
    Add-Content -Path $listFile -Value ($name + "`t" + $hash + "`t" + $answer + "`t" + (Get-Date -Format 'yyyy-MM-ddTHH:mm:ss')) -Encoding UTF8
}

$retry = @{}   # path -> @{at = when to try again; n = tries so far}
$waits = @(1, 5, 15, 60)

function Send([string]$path) {
    $name = Split-Path $path -Leaf
    try { $bytes = [IO.File]::ReadAllBytes($path) } catch { return 'later' }   # (gone already, or still being written: the next pass sees it again)
    $hash = Hex ($sha.ComputeHash($bytes))
    if ($done.ContainsKey($hash)) { return 'done' }
    if ($bytes.Length -gt 256KB) { Note $name $hash 'too-large'; Log "$name not sent: $($bytes.Length) bytes"; return 'done' }
    $ts = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
    $text = "TTT2-REPLAY`n1`n$($script:xuid)`n$ts`n$($bytes.Length)`n$hash"
    $sig = B64Url ($script:ec.SignData([Text.Encoding]::UTF8.GetBytes($text)))
    try {
        $req = [Net.HttpWebRequest]::Create("$Worker/v1/replays")
        $req.Method = 'POST'; $req.ContentType = 'application/octet-stream'; $req.ContentLength = $bytes.Length; $req.Timeout = 30000
        $req.UserAgent = 'ttt2-replay-uploader/1'
        $req.Headers.Add('X-TTT2-Xuid', $script:xuid); $req.Headers.Add('X-TTT2-Ts', [string]$ts); $req.Headers.Add('X-TTT2-Sig', $sig)
        $s = $req.GetRequestStream(); $s.Write($bytes, 0, $bytes.Length); $s.Close()
        $res = $req.GetResponse(); $code = [int]$res.StatusCode
        $body = (New-Object IO.StreamReader($res.GetResponseStream())).ReadToEnd(); $res.Close()
    } catch [Net.WebException] {
        $r = $_.Exception.Response
        if (-not $r) { Log "$name not sent: $($_.Exception.Message)"; return 'later' }
        $code = [int]$r.StatusCode; $body = (New-Object IO.StreamReader($r.GetResponseStream())).ReadToEnd(); $r.Close()
    }
    if ($code -eq 201 -or $code -eq 200) { Note $name $hash ($(if ($code -eq 201) { 'stored' } else { 'had' })); Log "$name sent: $code $body"; return 'done' }
    if ($code -eq 429 -or $code -ge 500) { Log "$name not sent yet: $code $body"; return 'later' }
    Note $name $hash ("refused-$code"); Log "$name refused: $code $body"; return 'done'
}

function Pass {
    $files = @()
    foreach ($d in @($replays, (Join-Path $replays 'saved'))) {
        if (Test-Path $d) { $files += @(Get-ChildItem -Path $d -Filter '*-online.ttt2replay' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime) }
    }
    $now = Get-Date
    foreach ($f in $files) {
        $p = $f.FullName
        if ($retry.ContainsKey($p) -and $retry[$p].at -gt $now) { continue }
        $r = Send $p
        if ($r -eq 'later') {
            $n = if ($retry.ContainsKey($p)) { $retry[$p].n + 1 } else { 1 }
            $retry[$p] = @{ at = $now.AddMinutes($waits[[Math]::Min($n, $waits.Count) - 1]); n = $n }
        } else { $retry.Remove($p) }
    }
}

Log "started: user data $UserData, server $Worker, game $GamePid"
try {
    while (-not (LoadIdentity)) {
        if ($Once -or ($GamePid -and -not (Get-Process -Id $GamePid -ErrorAction SilentlyContinue))) { Log 'no identity yet: nothing sent'; exit 0 }
        Start-Sleep -Seconds 30
    }
    Log "identity $($script:xuid)"
    Pass
    if ($Once) { exit 0 }
    while ($true) {
        Start-Sleep -Seconds $PollSeconds
        Pass
        if ($GamePid -and -not (Get-Process -Id $GamePid -ErrorAction SilentlyContinue)) { Start-Sleep -Seconds 3; Pass; Log 'the game ended: stopped'; break }
    }
} catch { Log "stopped by an error: $($_.Exception.Message)" } finally { $mutex.ReleaseMutex() }
