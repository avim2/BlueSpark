﻿# Builds TTT2 on Windows: the ReXGlue SDK (once), then the game.
#
# Run from the repo folder:
#   powershell -ExecutionPolicy Bypass -File rex\build-windows.ps1
#
# Needs Visual Studio with "Desktop development with C++" plus the "C++ Clang Compiler for
# Windows" (Clang 20 or newer) and "MSBuild support for LLVM (clang-cl) toolset" components,
# and Git. The SDK goes in %USERPROFILE%\rexsdk (a short path: its build has deep folders), with
# the changes in rex\patches applied to it. When those change, the SDK is rebuilt.
#
# Three ways (docs/PREBUILT_PACKAGE_PLAN.md):
#  - the source build (the default, dev work): rex\src compiled into the exe;
#  - -OursLib (rex\build-prebuilt.ps1, the owner's release build): rex\src as the static library ttt2_ours, linked whole;
#  - the player's package (rex\prebuilt\manifest.txt exists): no SDK build and no sources: rex\prebuilt\sdk and
#    rex\prebuilt\lib\ttt2_ours.lib, the pinned portable toolchain; the translation is checked against the release and
#    the link against the hook list.

# -Toolchain portable (or TTT2_TOOLCHAIN=portable): the pinned portable toolchain (rex\tools\toolchain.ps1) instead of
# Visual Studio, with its own SDK folder (%USERPROFILE%\rexsdk-portable unless rex\sdk-folder.txt names one).
param([ValidateSet('vs', 'portable')][string]$Toolchain = $(if ($env:TTT2_TOOLCHAIN -eq 'portable') { 'portable' } else { 'vs' }),
      [switch]$OursLib)

$ErrorActionPreference = 'Stop'
$SdkTag = 'v0.10.0'
$Repo = Split-Path -Parent $PSScriptRoot
$Rex = $PSScriptRoot
. (Join-Path $Rex 'tools\remove-folder.ps1')   # (Remove-Ttt2Folder: deletes through .NET, safe in a non-ASCII install folder)
$PrebuiltManifest = Join-Path $Rex 'prebuilt\manifest.txt'
$Prebuilt = Test-Path $PrebuiltManifest
if ($Prebuilt) { $Toolchain = 'portable'; $OursLib = $false }
# The SDK's folder: %USERPROFILE%\rexsdk, or what rex\sdk-folder.txt says (one line: a folder name
# under %USERPROFILE%, or a full path; this PC's, not part of the repo), so that two clones on
# branches with different rex\patches each keep their own SDK and don't rebuild each other's.
$SdkFolder = Join-Path $env:USERPROFILE $(if ($Toolchain -eq 'portable') { 'rexsdk-portable' } else { 'rexsdk' })
$sdkFolderFile = Join-Path $Rex 'sdk-folder.txt'
if (-not $Prebuilt -and (Test-Path $sdkFolderFile)) {
    $named = "$(Get-Content $sdkFolderFile -Raw)".Trim().Trim('"')
    if ($named) {
        $SdkFolder = if ([IO.Path]::IsPathRooted($named)) { $named } else { Join-Path $env:USERPROFILE $named }
    }
}
$SdkSource = Join-Path $SdkFolder 'src'
$SdkInstall = if ($Prebuilt) { Join-Path $Rex 'prebuilt\sdk' } else { Join-Path $SdkFolder 'install' }
Write-Host "ReXGlue SDK folder: $(if ($Prebuilt) { $SdkInstall } else { $SdkFolder })"

function Step($text) { Write-Host ''; Write-Host "== $text" -ForegroundColor Cyan }
function Run {
    # Native tools write progress to stderr. Windows PowerShell turns that into errors when its own
    # output is redirected (as in the launcher's steps), which $ErrorActionPreference = 'Stop' makes
    # fatal; so stderr is passed through as plain text, and only the exit code decides.
    $saved = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { & $args[0] $args[1..($args.Count - 1)] 2>&1 | ForEach-Object { "$_" } }
    finally { $ErrorActionPreference = $saved }
    if ($LASTEXITCODE -ne 0) { throw "Failed ($LASTEXITCODE): $($args -join ' ')" }
}
# key=value lines (the prebuilt manifest).
function Read-KeyValues([string]$file) {
    $map = [ordered]@{}
    if (Test-Path $file) {
        foreach ($line in Get-Content $file) {
            $i = $line.IndexOf('=')
            if ($i -gt 0) { $map[$line.Substring(0, $i)] = $line.Substring($i + 1) }
        }
    }
    $map
}
# A text file's SHA-256 with its line endings made \n (a checkout or an unzip may give either).
function Get-TextHash([string]$file) {
    $text = [IO.File]::ReadAllText($file) -replace "`r`n", "`n"
    $sha = [Security.Cryptography.SHA256]::Create()
    ($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($text)) | ForEach-Object { $_.ToString('x2') }) -join ''
}

# One run of the translation (the ttt2_codegen target): its exit code, its analysis errors (the "0x... from 0x..." lines of
# its ANALYSIS ERRORS report, sorted) and the partition's hash ('' when it made none). Its output is shown as Run shows it.
function Invoke-Ttt2Codegen([string]$Build, [string]$Partition) {
    $saved = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { $out = @(& cmake --build $Build --target ttt2_codegen 2>&1 | ForEach-Object { "$_" }) } finally { $ErrorActionPreference = $saved }
    $code = $LASTEXITCODE
    $out | ForEach-Object { Write-Host $_ }
    $errors = @($out | ForEach-Object { if ($_ -match '(0x[0-9A-Fa-f]{8}( from 0x[0-9A-Fa-f]{8})?: .*)$') { $Matches[1].Trim() } } | Sort-Object -Unique)
    $hash = if (Test-Path $Partition) { Get-TextHash (Resolve-Path $Partition) } else { '' }
    [pscustomobject]@{ Code = $code; Errors = $errors; Hash = $hash }
}
function Describe-Ttt2Codegen($r) {
    if ($r.Errors.Count) { return "$($r.Errors.Count) analysis error(s), the first: $($r.Errors[0])" }
    if ($r.Code -ne 0) { return "it failed ($($r.Code))" }
    "the translation $($r.Hash.Substring(0, [Math]::Min(12, $r.Hash.Length)))"
}
# The words when the same work gave two different answers (I, the lead's order of 27 Oct): the processor or the memory. The
# Intel lines only for a 13th or 14th generation Core i5/i7/i9 (their instability); others: the memory overclock and the BIOS.
function Get-Ttt2UnstablePcNote {
    $cpu = try { (Get-CimInstance Win32_Processor | Select-Object -First 1).Name } catch { '' }
    $intel1314 = "$cpu" -match 'Core\(TM\) i[579]-1[34]\d{2,3}|Core i[579]-1[34]\d{2,3}'
    $advice = if ($intel1314) {
        "Update your motherboard's BIOS, use Intel's default settings and turn XMP/EXPO off, then try again. Intel's Processor Diagnostic Tool can check the processor."
    } else {
        "Turn off any memory overclock (XMP/EXPO) and other overclocking, update your motherboard's BIOS, then try again."
    }
    "Your PC gave two different answers to the same work. Your game files are fine; this is the processor or the memory ($cpu). $advice"
}
# Every hooked sub_X must come from our code (ttt2_ours): read from ttt2.map, the linker's own record of where each
# symbol came from. A hook missing from it, or coming from the generated code, was dropped.
function Test-HookLink([string]$map, [string[]]$hooks) {
    if (-not (Test-Path $map)) { throw "No link map ($map): the hook check can't run." }
    $map = (Resolve-Path $map).ProviderPath   # (.NET reads relative paths from the process's folder, not this one)
    $from = @{}
    foreach ($line in [IO.File]::ReadLines($map)) {
        $f = $line.Trim() -split '\s+'
        if ($f.Count -ge 4 -and $f[1] -like 'sub_*') { $from[$f[1]] = $f[$f.Count - 1] }
    }
    $bad = @($hooks | Where-Object { -not $from.ContainsKey($_) -or $from[$_] -notmatch 'ttt2_ours' })
    if ($bad.Count) {
        throw "The link dropped $($bad.Count) of our $($hooks.Count) hooks ($(($bad | Select-Object -First 5) -join ', ')...): ttt2_ours.lib wasn't linked whole. The game would run without them; not used."
    }
    Write-Host "Hook check: all $($hooks.Count) hooks come from ttt2_ours."
}

if ($Toolchain -eq 'portable') {
Step 'The portable toolchain'
. (Join-Path $Rex 'tools\toolchain.ps1')
Use-Ttt2Toolchain
$llvm = Split-Path (Get-Command clang++).Source
} else {
Step 'Finding Visual Studio'
$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
if (-not (Test-Path $vswhere)) { throw 'Visual Studio Installer not found.' }
# The newest Visual Studio with the C++ tools and CMake (with Ninja); else the newest with the
# C++ tools (a PC can have several, e.g. a Community without CMake and our Build Tools).
$vs = & $vswhere -latest -prerelease -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 Microsoft.VisualStudio.Component.VC.CMake.Project -property installationPath
if (-not $vs) { $vs = & $vswhere -latest -prerelease -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath }
if (-not $vs) { throw 'No Visual Studio with the C++ tools. Add "Desktop development with C++" in the Visual Studio Installer.' }
Write-Host "Visual Studio: $vs"
Import-Module (Join-Path $vs 'Common7\Tools\Microsoft.VisualStudio.DevShell.dll')
Enter-VsDevShell -VsInstallPath $vs -SkipAutomaticLocation -DevCmdArguments '-arch=x64 -host_arch=x64' | Out-Null

# Visual Studio's own Clang, ahead of any other on PATH; or, when TTT2_LLVM names a standalone
# LLVM's bin folder (the launcher sets it when Visual Studio's Clang is older than 20), that one.
$llvm = Join-Path $vs 'VC\Tools\Llvm\x64\bin'
if ($env:TTT2_LLVM -and (Test-Path (Join-Path $env:TTT2_LLVM 'clang.exe'))) { $llvm = $env:TTT2_LLVM }
if (-not (Test-Path (Join-Path $llvm 'clang.exe'))) {
    throw 'Clang is missing. In the Visual Studio Installer, Modify, Individual components: tick "C++ Clang Compiler for Windows" and "MSBuild support for LLVM (clang-cl) toolset".'
}
$env:PATH = "$llvm;$env:PATH"
}
$clangVersion = (& clang --version | Select-Object -First 1)
Write-Host $clangVersion
if ($clangVersion -match 'version (\d+)\.' -and [int]$Matches[1] -lt 20) {
    throw "ReXGlue needs Clang 20 or newer; Visual Studio has $($Matches[1]). Update Visual Studio."
}
foreach ($tool in @(if (-not $Prebuilt) { 'git' }) + @('cmake', 'ninja')) {
    if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) { throw "$tool not found." }
}

$manifest = Read-KeyValues $PrebuiltManifest
if ($Prebuilt) {
    # The package's SDK, built by the owner with the patches the manifest names: checked, never rebuilt here.
    Step 'The prebuilt ReXGlue SDK'
    $patchRecord = Join-Path $SdkInstall 'ttt2-patches.txt'
    $built = if (Test-Path $patchRecord) { (Get-Content $patchRecord -Raw).Trim() } else { '' }
    if (-not (Test-Path (Join-Path $SdkInstall 'bin\rexglue.exe')) -or $built -ne $manifest['patches']) {
        throw "The package's SDK (rex\prebuilt\sdk) is not the one this release was made with. Unzip the package again."
    }
    if ((Get-FileHash (Join-Path $SdkInstall 'bin\rexglue.exe') -Algorithm SHA256).Hash -ne $manifest['codegen.rexglue']) {
        throw "rex\prebuilt\sdk\bin\rexglue.exe is not this release's. Unzip the package again."
    }
    Write-Host "Release $($manifest['release']), built with $($manifest['toolchain'])"
} else {
# The SDK is built with our patches. A file in the install folder records which ones, so that a
# new or changed patch rebuilds it.
$patches = @(Get-ChildItem (Join-Path $Rex 'patches') -Filter *.patch | Sort-Object Name)
# The SDK's build options of ours (no source change), recorded with the patches so that a new one rebuilds the SDK too.
# SPDLOG_PREVENT_CHILD_FD (the lead's word, 24 Oct): spdlog's own option, a PUBLIC define on its target, so it reaches every
# target that compiles or links spdlog, ours included: the log's handle is not inherited, and a child process (curl.exe)
# can't hold the log open through a rotation; a failed rename made spdlog truncate the log and lose its start (1879).
$sdkOptions = @('-DSPDLOG_PREVENT_CHILD_FD=ON')
$patchList = (@($patches | ForEach-Object { "$($_.Name) $((Get-FileHash $_.FullName).Hash)" }) + @($sdkOptions)) -join ';'
$patchRecord = Join-Path $SdkInstall 'ttt2-patches.txt'
$patchesBuilt = if (Test-Path $patchRecord) { (Get-Content $patchRecord -Raw).Trim() } else { '' }

if (-not (Test-Path (Join-Path $SdkInstall 'bin\rexglue.exe')) -or $patchesBuilt -ne $patchList) {
    if (-not (Test-Path (Join-Path $SdkSource '.git'))) {
        Step "Downloading the ReXGlue SDK $SdkTag (with its libraries, about 400 MB)"
        Run git -c core.longpaths=true clone --branch $SdkTag --recursive --depth 1 --shallow-submodules https://github.com/rexglue/rexglue-sdk.git $SdkSource
    }
    # libmspack's cabextract/mspack holds symbolic links to its libmspack/mspack sources. Git
    # on Windows checks those out as small text files holding the link's target unless
    # symbolic links are enabled, and the build then fails on lzxd.c. Copy the real files over.
    # Real links (symbolic links enabled: Developer Mode, or an administrator) are left alone:
    # copying through one is copying a file onto itself, which Windows refuses.
    $links = Join-Path $SdkSource 'thirdparty\libmspack\cabextract\mspack'
    $sources = Join-Path $SdkSource 'thirdparty\libmspack\libmspack\mspack'
    $reparse = [IO.FileAttributes]::ReparsePoint
    if (-not ((Get-Item $links).Attributes -band $reparse)) {
        Get-ChildItem $links -File | Where-Object { $_.Length -lt 200 -and -not ($_.Attributes -band $reparse) } | ForEach-Object {
            $real = Join-Path $sources $_.Name
            if (Test-Path $real) { Copy-Item $real $_.FullName -Force }
        }
    }

    Push-Location $SdkSource
    try {
        Step 'Applying rex\patches to the ReXGlue SDK'
        # Back to the SDK as released first, so that a changed patch applies cleanly. This drops
        # any other change under the SDK's include and src folders, files a patch added included.
        Run git checkout HEAD -- include src
        Run git clean -fdq -- include src
        # (A patch of patches\ may name a file of the SDL submodule (thirdparty\sdl3, 60-sdl-audio-stream-lifetime): back to its commit too,
        # or that patch would not apply a second time.)
        if (Test-Path 'thirdparty\sdl3\.git') { Run git -C thirdparty/sdl3 checkout -- . }
        foreach ($patch in $patches) {
            Write-Host $patch.Name
            Run git apply --ignore-whitespace $patch.FullName
        }

        Step 'Building the ReXGlue SDK (the first time takes a while)'
        # (The portable toolchain has no debug C++ runtime: CMake's own test programs are built as Release.)
        $sdkExtra = @(if ($Toolchain -eq 'portable') { '-DCMAKE_TRY_COMPILE_CONFIGURATION=Release' })
        if ($Toolchain -eq 'portable') { $null = Reset-Ttt2BuildForMsvc (Join-Path $SdkSource 'out\build\win-amd64') 'The SDK' }   # (the MSVC version pin)
        Run cmake --preset win-amd64 "-DCMAKE_INSTALL_PREFIX=$SdkInstall" @sdkExtra @sdkOptions
        Run cmake --build out/build/win-amd64 --config Release --target install
        if ($Toolchain -eq 'portable') { Write-Ttt2BuildMsvc (Join-Path $SdkSource 'out\build\win-amd64') }
        Set-Content -Path $patchRecord -Value $patchList
    } finally { Pop-Location }
} else {
    Write-Host "ReXGlue SDK already built: $SdkInstall"
}

# The build id for netplay (rex\src\netplay.cpp: two instances must be the same build): the commit, and
# hashes of rex\src, rex\patches and the generated code's manifest, in rex\src\build_id.h (not in git).
# (In the player's package it is baked into ttt2_ours.lib: "this release's libraries".)
Step 'The build id'
$idParts = @()
try { $idParts += (git -C $Repo rev-parse --short HEAD 2>$null) } catch { $idParts += 'nogit' }
foreach ($set in @(@('src', '*.cpp', '*.h'), @('patches', '*.patch'), @('generated\default', 'codegen.partition.json'))) {
    $folder = Join-Path $Rex $set[0]
    $lines = Get-ChildItem $folder -File -Include $set[1..($set.Count - 1)] -Recurse -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -ne 'build_id.h' } | Sort-Object FullName |
        ForEach-Object { "$($_.Name) $((Get-FileHash $_.FullName -Algorithm SHA1).Hash)" }
    $sha = [Security.Cryptography.SHA1]::Create()
    $hash = ($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes(($lines -join "`n"))) | ForEach-Object { $_.ToString('x2') }) -join ''
    $idParts += $hash.Substring(0, 12)
}
$idText = $idParts -join ' '
$idHeader = Join-Path $Rex 'src\build_id.h'
$idContent = "// Written by build-windows.ps1 before every build; not in git.`n#pragma once`n#define TTT2_BUILD_ID_TEXT `"$idText`"`n"
if (-not (Test-Path $idHeader) -or (Get-Content $idHeader -Raw) -ne $idContent) { [IO.File]::WriteAllText($idHeader, $idContent) }
Write-Host "Build id: $idText"
}

# Files dated in the future by this PC's clock make Ninja re-run CMake for ever ("manifest
# 'build.ninja' still dirty after 100 tries"). A zip's dates have no time zone and unpack as
# local time, so a package made east of here has them. Date such files now.
$now = Get-Date
$future = @(Get-ChildItem $Rex -Force | Where-Object { $_.Name -ne 'out' } | ForEach-Object {
        if ($_.PSIsContainer) { Get-ChildItem $_.FullName -Recurse -File -Force } else { $_ }
    } | Where-Object { $_.LastWriteTime -gt $now.AddMinutes(1) })
if ($future.Count) {
    Write-Host "$($future.Count) files were dated in the future by this PC's clock; dating them now."
    foreach ($f in $future) { $f.LastWriteTime = $now }
}

Push-Location $Rex
try {
    $build = 'out/build/win-amd64-release'
    # CMake remembers where it found the SDK's packages. If that is another SDK folder than the
    # one in use (rex\sdk-folder.txt was added or changed), forget it: the game would otherwise
    # be compiled and linked against that one and run with this one's DLLs.
    $cache = Join-Path $build 'CMakeCache.txt'
    if (Test-Path $cache) {
        $found = Select-String -Path $cache -Pattern '^rexglue_DIR:PATH=(.*)$' | Select-Object -First 1
        $wanted = ($SdkInstall -replace '\\', '/').TrimEnd('/')
        if ($found -and -not $found.Matches[0].Groups[1].Value.StartsWith("$wanted/", [StringComparison]::OrdinalIgnoreCase)) {
            Write-Host "The game was configured for another SDK folder ($($found.Matches[0].Groups[1].Value)): configuring it anew."
            Remove-Item -LiteralPath $cache -Force
        }
    }
    # Likewise for another compiler (Visual Studio's against the portable one): its linker's folder names it.
    if (Test-Path $cache) {
        $linker = Select-String -Path $cache -Pattern '^CMAKE_LINKER:FILEPATH=(.*)$' | Select-Object -First 1
        $wantedLlvm = ($llvm -replace '\\', '/').TrimEnd('/')
        if ($linker -and -not $linker.Matches[0].Groups[1].Value.StartsWith("$wantedLlvm/", [StringComparison]::OrdinalIgnoreCase)) {
            Write-Host "The game was configured with another compiler ($($linker.Matches[0].Groups[1].Value)): configuring it anew."
            Remove-Item -LiteralPath $cache -Force
        }
    }
    # The player's package: the zip's dates are the commit's minus two days, so Ninja doesn't see a new library or
    # new address files. When the shipped manifest differs from the one the last build used, the exe is relinked, and
    # if the translation's inputs differ the translation is made again.
    $usedManifest = Join-Path $build 'prebuilt-manifest.txt'
    if ($Prebuilt) {
        $used = Read-KeyValues $usedManifest
        if ((Test-Path $usedManifest) -and (Get-Content $usedManifest -Raw) -ne (Get-Content $PrebuiltManifest -Raw)) {
            Write-Host 'A new release: the game is linked anew.'
            Remove-Item -LiteralPath (Join-Path $build 'ttt2.exe') -Force -ErrorAction SilentlyContinue
            $codegenNow = ($manifest.Keys | Where-Object { $_ -like 'codegen.*' } | ForEach-Object { "$_=$($manifest[$_])" }) -join ';'
            $codegenUsed = ($used.Keys | Where-Object { $_ -like 'codegen.*' } | ForEach-Object { "$_=$($used[$_])" }) -join ';'
            if ($codegenNow -ne $codegenUsed -and (Test-Path 'generated\default')) {
                Write-Host 'Its translation differs too: the game code is translated anew.'
                Remove-Ttt2Folder 'generated\default'
            }
        }
    }
    # (The portable toolchain pins clang's MSVC version (toolchain.ps1, 27 Oct): a build folder made at another version is
    # built again from the start, once, as its precompiled headers would otherwise refuse the new one.)
    if ($Toolchain -eq 'portable') { $null = Reset-Ttt2BuildForMsvc (Join-Path $Rex $build) 'The game' }
    Step 'Configuring TTT2'
    $gameExtra = @(if ($Toolchain -eq 'portable') { '-DCMAKE_TRY_COMPILE_CONFIGURATION=Release' })   # (no debug C++ runtime)
    $gameExtra += "-DTTT2_PREBUILT=$(if ($Prebuilt) { 'ON' } else { 'OFF' })"
    $gameExtra += "-DTTT2_OURS_LIB=$(if ($OursLib) { 'ON' } else { 'OFF' })"
    Run cmake --preset win-amd64-release "-DCMAKE_PREFIX_PATH=$SdkInstall" @gameExtra

    $partition = 'generated\default\codegen.partition.json'
    if (-not (Test-Path 'generated\default\sources.cmake')) {
        Step 'Recompiling the game code from gamedata\default_tu.xex (a couple of minutes)'
        $first = Invoke-Ttt2Codegen $build $partition
        # (Test only, TTT2_TEST_CODEGEN_FLAKY=1: the first run's translation changed after it, as a PC that computes wrong would.)
        if ($env:TTT2_TEST_CODEGEN_FLAKY -eq '1' -and (Test-Path $partition)) {
            Add-Content -LiteralPath $partition ' '
            $first.Hash = Get-TextHash (Resolve-Path $partition)
            Write-Host 'Test: the first translation changed (TTT2_TEST_CODEGEN_FLAKY)'
        }
        # (I, the lead's order of 27 Oct: a translation that fails, by its analysis errors or, in a release, by its hash, is
        # made once more (~30 s). The same files gave a player 8 unresolved calls, then 3 different ones, then other output,
        # with call targets no PowerPC branch can have: the PC computing wrong, not the files.)
        $bad = { param($r) $r.Code -ne 0 -or ($Prebuilt -and $r.Hash -ne $manifest['codegen.partition']) }
        if (& $bad $first) {
            Write-Host "The translation didn't come out right ($(Describe-Ttt2Codegen $first)): it is made once more, to see whether this PC gives the same answer (about 30 s)."
            Remove-Ttt2Folder 'generated\default'
            $second = Invoke-Ttt2Codegen $build $partition
            if ($second.Hash -ne $first.Hash -or (($second.Errors -join "`n") -ne ($first.Errors -join "`n")) -or $second.Code -ne $first.Code) {
                Write-Host "The two translations differ: first $(Describe-Ttt2Codegen $first), then $(Describe-Ttt2Codegen $second)."
                throw (Get-Ttt2UnstablePcNote)
            }
            Write-Host "The second translation came out the same ($(Describe-Ttt2Codegen $second)): this PC is consistent; the files or the package aren't the expected ones."
        }
        if ($first.Code -ne 0 -and -not $Prebuilt) { throw "The translation failed ($(Describe-Ttt2Codegen $first))." }
        # The generated file list only exists now, so CMake has to read it again.
        if (Test-Path 'generated\default\sources.cmake') { Run cmake $build }
    }
    if ($Prebuilt) {
        # The library was made for one translation of the game: this PC's must be the same.
        if (-not (Test-Path $partition) -or (Get-TextHash (Resolve-Path $partition)) -ne $manifest['codegen.partition']) {
            throw "The translation didn't match this release (your game files or the package are not the expected ones)."
        }
        Write-Host 'The translation matches this release.'
    }

    Step 'Building TTT2 (the first time takes a while)'
    Run cmake --build $build
    if ($Toolchain -eq 'portable') { Write-Ttt2BuildMsvc (Join-Path $Rex $build) }
    # The build copies the SDK's DLLs next to ttt2.exe only when it links ttt2.exe, which a
    # rebuilt SDK does not always cause.
    Copy-Item (Join-Path $SdkInstall 'bin\*.dll') $build -Force
    if ($Prebuilt -or $OursLib) {
        # (Every sub_X the library defines: REX_HOOK_RAW and the macros made of it. The package names them in its
        # manifest; the owner's build reads them from the library just made.)
        $hooks = if ($Prebuilt) { @($manifest['hooks'] -split ' ' | Where-Object { $_ }) } else {
            @(& llvm-nm --defined-only (Join-Path $build 'ttt2_ours.lib') 2>$null | ForEach-Object { if ($_ -match '\sT\s(sub_[0-9A-Fa-f]+)$') { $Matches[1] } } | Sort-Object -Unique) }
        if ($hooks.Count -lt 100) { throw "Only $($hooks.Count) hooks to check: the hook list is wrong." }
        try { Test-HookLink (Join-Path $build 'ttt2.map') $hooks }
        catch { Remove-Item -LiteralPath (Join-Path $build 'ttt2.exe') -Force -ErrorAction SilentlyContinue; throw }
    }
    if ($Prebuilt) { Copy-Item $PrebuiltManifest $usedManifest -Force }
} finally { Pop-Location }

Step 'Done'
Write-Host "Game: $Rex\$($build -replace '/', '\')\ttt2.exe"
Write-Host 'Start it with:  powershell -ExecutionPolicy Bypass -File rex\run-windows.ps1'
