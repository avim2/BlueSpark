TTT2 Native: play test
======================

This is Tekken Tag Tournament 2 for the Xbox 360, running natively on Windows, with less input lag than
the console. The package holds no game files. Your PC translates the game's code from your own copy of
TTT2 and links it with our code, which comes prebuilt. You don't need Visual Studio or Git: Start Here
downloads a compiler for you.

What's changed: see CHANGELOG.txt.


Getting started
---------------

1. Unzip this package to a short path, for example C:\ttt2.
2. Double-click Start Here. A window opens with four steps.
3. Click the steps in order. Each one turns green when it's done.
   1. Install tools. This downloads a compiler (about 1.3 GB, a few minutes on a fast connection). It
      asks you to accept Microsoft's license for their C++ libraries first. If Windows asks to install
      the Visual C++ runtime, click Yes.
   2. Choose my game + update. Pick your TTT2 disc image (or the folder with your game files), then your
      title update file. If the second file isn't the title update, this step tells you so and asks
      again. See "Getting your game files" below.
   3. Build the game. Your PC translates and compiles the game's code. It takes about 3 minutes on a
      6-core PC, longer on fewer cores.
   4. Play TTT2 (or Play BlueSpark, below).

Next time, double-click Start Here and click Play TTT2.

If a step fails, the window says why. Open log folder opens the logs. Send them to the friend who gave
you this.


What you need
-------------

- Windows 10 or 11, 64-bit, with a DirectX 12 graphics card.
- Your own TTT2 game files: default.xex and all the data*.bin files from your Xbox 360 disc, in one
   folder, or an image of the disc.
- Your title update: the game's update file from your Xbox 360, named like
   TU_174Q22P_0000008000000.00000000000O2 (about 3 MB).
- About 7 GB of free disk space for the compiler and the build, plus your game files.
- A controller or a keyboard. Xbox and PlayStation controllers work, and so do most other pads, fight
   sticks and adapters. See "Controllers" and "Playing on a keyboard" below.

Your game files must be the release this build was made for: title 4E4D0859 with update 0.0.3.2. Step 2
checks this and stops if they don't match.

If your antivirus removes TTT2's files (Start Here then says some are missing), restore them in Windows
Security, Protection history. If it keeps happening, you can add this folder and the tools folder (Start
Here's "Tools and game files") to Windows Security's exclusions.


Getting your game files
-----------------------

From an image of your disc

You can extract a disc image with extract-xiso:

1. Download it from https://github.com/XboxDev/extract-xiso/releases and unzip it, for example to
   C:\tools\extract-xiso.
2. In PowerShell, run:
   C:\tools\extract-xiso\extract-xiso.exe -x "C:\path\to\TTT2.iso" -d C:\games\ttt2
3. C:\games\ttt2 now holds default.xex and the data*.bin files. That's your game folder.

If extract-xiso can't read your image, a program with a window, such as Xbox 360 ISO Extract, does the
same job. You need an image of your own disc. Most PC drives can't read Xbox 360 discs, so it's usually
made with a modified console or drive.

The title update

The update is on your Xbox 360's hard drive, in Content\0000000000000000\4E4D0859\000B0000\. The
console's menus can't copy it, so read the drive on a PC with a tool like FATXplorer and copy the file
out. Your console has it if you ever played TTT2 online.


Playing
-------

- EXIT GAME, the last entry of the main menu, closes the game.
- The first start makes a new save with every character, stage and item unlocked.
- No intro: after the splash the game goes straight to the main menu. Untick No intro in Start Here for the game's own
   logos, opening movie and PRESS START. The controller you press a button on while it loads is player 1.
- Start Here asks for your name the first time you press Play TTT2 or Play BlueSpark. The Your name... button changes it.


Play BlueSpark
--------------

Play BlueSpark, next to Play TTT2 in Start Here, is a second way to play: a window of its own for Ranked, lobbies,
Training and replays, with the game ready behind it.

Play TTT2 and Play BlueSpark run the same game. Players on either one match each other in Quick Match, Ranked and
lobbies, and your account, rating and saves are the same on both. Both players just need the same release.

- It starts the game itself and keeps it running hidden and muted behind its window, so a match or a Practice
  session starts in seconds. That's the ttt2.exe you see in Task Manager while the client is open.
- When you close the client, the game closes with it. Nothing keeps running.
- It uses the same game, profile, saves, settings and keys as Play TTT2. Use one or the other, not both at once.
- Close the client before you update.
- It's built with Qt (fastclient\bin\). See THIRD_PARTY_NOTICES.txt.


Your profile and saves
----------------------

Your profile is your online identity, your saves and your name. It lives in
%LOCALAPPDATA%\TTT2Native\profile, outside the game folder. A new build or a deleted game folder doesn't
lose it. The first time you play this build, your profile is copied there from the game folder. Older
builds still find their own copy.


Display
-------

Start Here's Display list has these choices:

- Borderless fullscreen, the default.
- Fullscreen. The game takes the display over in its own mode.
- Windowed 1280x720 or 1920x1080, and bigger sizes if your monitor has room. The game draws at 1280x720,
   as on the console, and scales up to the window.

F11 or Alt+Enter switches fullscreen on and off while you play.

Allow tearing (lowest lag, vsync off) shows each frame the moment it's ready. You get about 3 ms less lag,
but a tear line moves across the screen. It's off by default and needs a fullscreen choice.

For the lowest lag, play fullscreen on a 60 Hz display with nothing drawn over the game.


Online
------

Online play is on by default. Untick Online play (test: training on as well) in Start Here to play
offline, or click Play offline (no internet).

- Everyone playing online needs this build. Players on different builds are never matched.
- Ranked Match plays sets, first to 2 games. Your rating changes once per set, and leaving between games
   loses the set.
- To fight the same opponent again: REMATCH on Quick Match's results menu, or the 10-second vote after a
   lobby fight.
- The first time you play online, Windows asks if TTT2 may use the network. Allow it.
- When you host a match, your public IP address and your name are listed on a public board so others can
   find your game.
- Online play works over IPv4 only for now.


What we receive from you
------------------------

Start Here has two boxes for what the game sends us. Both are on by default:

- Send each online fight's log (play test). After each online fight, that fight's log goes to our
   server. It helps us find problems.
- Send crash logs. If the game crashed or froze, its log goes to our server the next time you start it.

We take IP addresses, invite codes and your Windows user name out of each log before it's sent. Untick a
box to stop sending that kind of log. The details are in our privacy note, PRIVACY, in the server's repository:
https://github.com/Themail2/ttt2-server


Updates
-------

To update:

1. Download the new zip from the Discord post. Don't unzip it yourself.
2. Open Start Here.
3. Drag the zip onto the Start Here window.
4. Click Yes.

Start Here checks that the zip is an official TTT2 playtest package, puts it over this folder and relinks the
game, which takes a minute or two. Your saves, game files and settings stay. When it's done, it asks if you want
to delete the zip.

If you unzipped a new build into a new folder by mistake, open its Start Here: it offers to use your previous
install instead, so you don't have to build again. It only knows installs from Release 4.1 on.

Coming from Release 4 or older (once): older Start Heres can't take a dropped zip. Unzip Release 4.1 into the
same folder as your old install, over it, and click Build in Start Here: your saves and game files stay, so you
skip step 2, and the build takes about 3 minutes. If you unzip it into a new folder instead, you need step 2 too.

An update waits until you close the game.


Controllers
-----------

- Xbox controllers work right away, and so do most fight sticks in Xbox or PC mode.
- PlayStation 4 controllers work right away. PlayStation 5 and Switch Pro controllers should too.
- Other pads, sticks and adapters work once the game knows their button layout. The package includes a
   community list of about 870 layouts, so most work right away.
- If yours isn't in the list, or a button is wrong, make a mapping line for it with a tool like SDL2
   Gamepad Tool. Put the line in rex\userdata\my-controllers.txt, one line per controller. Updates leave
   that file alone.
- A press shorter than a frame still counts.
- A cable is a little faster than Bluetooth.
- The first controller you press a button on is player 1.
- Vibration is off. Tick Controller vibration in Start Here to turn it on.


Playing on a keyboard
---------------------

The keyboard is player 1 while Start Here's Keyboard (player 1) box is ticked. It's ticked by default.
The keyboard works with or without a controller. With a controller plugged in, both drive player 1, and
a second controller is player 2. The game window must be in front for the keys to reach it.

The keys are Tekken's PC layout:

   W A S D           up, back, down, forward
   U I J K           1 2 3 4
   P                 Tag
   O                 Tag as well (the game's layout has two Tag buttons)
   ; and L           RT and LT. In Practice, V + ; remembers a position and V + L goes back to it.
   Return, Escape    Start
   V, Tab            Select. In Practice, V + J restarts and V + O rewinds.
   N and M           R3 and L3

Holding left and right together counts as neither, and so do up and down, as in Tekken 8. S + A + D
still crouches.

1 2 3 4 and Tag follow Controller Setup. If you change the layout there, the keyboard follows it.

To change a key, use Controller Setup (below), or open rex\userdata\keyboard.txt in Notepad. Start Here
writes it the first time you press Play TTT2. Each line is an action and its keys, for example "1 = Shift" or
"1+2 = Space". Any key works, including Shift, Ctrl and Alt. Save the file and start the game again.
Delete the file to get the keys above back. Updates never change it.


Controller Setup
----------------

Controller Setup opens our own page in place of the game's: from Options on the main menu, from the pause
menu in a fight or in Practice, and from Fight Lab. Online fights keep the game's own screen.

The left half is the controller. Each row is an action (1, 2, 3, 4, Tag and the combinations, 1+2+3+4 too)
with the buttons it's on. Press A on a row, then press the button you want for it within 5 seconds. Start clears
the row and Select cancels. LB and RB switch between player 1 and player 2. TYPE A, B and C are the game's
presets. Restore Default and Undo Changes are at the bottom, and Confirm and Exit saves.

The right half is the keyboard (player 1): every pad button and action, RB included. Press A on a line,
then press the key. Any key works, including Shift and Ctrl. Escape cancels and Delete leaves the line
with no key. A key you give to one line comes off any other line it was on. When you leave the page, it
asks whether to save the keyboard's changes.

Left and right move between the two halves. B saves the controller's changes and closes the page.


About the input lag
-------------------

Two delays are gone:

- The game's own input delay. The original game holds every press back 2 frames (33 ms) before your
   fighter acts on it, on the console too. Here it acts on the next frame.
- The runtime's delays. From the game reading your controller to the frame on screen takes about 29 ms
   here, against about 45 ms before our changes.

Your display and controller add their own lag on top.


Report a problem
----------------

For a crash, a freeze, a failed build or anything else, double-click Report a problem. Start Here has a
button with the same name. It doesn't start the game or change anything. It puts one zip on your Desktop,
named ttt2-problem-report-....zip. Send it to the friend who gave you this, with a few words about what
went wrong. Make it right after the problem, before you play again.

The zip holds the game's newest 3 logs, any crash dumps and freeze reports from the last two weeks, Start
Here's logs, the build's version, your display choice, and your PC's parts (Windows, processor, memory,
graphics card and driver, monitors).

It never holds your identity or its key, your saves, your replays, or anything else from your user data.


If the sound is wrong
---------------------

For crackling, music that stops or anything else you hear, double-click Report a sound problem. It starts
the game with sound recording on.

1. Play until you hear the problem.
2. Each time you hear it, press F9, or click both sticks in on your controller.
3. A few seconds later, close the game and answer the four short questions.

Two zips appear on your Desktop: a small report and the sound clips around each F9 press. Send both to the
friend who gave you this. Keep the session under ten minutes: the recording uses about 200 MB of disk a
minute.


If something goes wrong
-----------------------

- Step 2 says a file "is not the one this build was made for". Your disc or update is a different region
   or version. This build only works with the release it was made for.
- The build fails with a very long path. Unzip the package to a short path like C:\ttt2.

If you're stuck, send the friend who gave you this the zip from Report a problem.


Doing it by hand
----------------

Start Here's steps are PowerShell scripts you can run yourself, from the package folder, after Install
tools has run once:

1. Prepare your game files. It asks for your game folder and your title update, checks them and applies
   the update:
   powershell -ExecutionPolicy Bypass -File rex\prepare-game.ps1
2. Build the game:
   powershell -ExecutionPolicy Bypass -File rex\build-windows.ps1
3. Play:
   powershell -ExecutionPolicy Bypass -File rex\run-windows.ps1


Licenses
--------

THIRD_PARTY_NOTICES.txt lists the open-source parts of our prebuilt code. SOURCE_OFFER.txt and the source
folder give the source of its GPL and LGPL parts.
