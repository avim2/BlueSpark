@echo off
rem Plays the game with its sound recorders on and packs a report: see rex\sound-report.ps1.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0rex\sound-report.ps1"
if errorlevel 1 pause
