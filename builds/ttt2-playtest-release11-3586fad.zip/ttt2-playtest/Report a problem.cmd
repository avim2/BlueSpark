@echo off
rem Packs the logs, any crash dumps, the build's version and the PC's parts into one zip on the Desktop: see rex\problem-report.ps1.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0rex\problem-report.ps1"
if errorlevel 1 pause
