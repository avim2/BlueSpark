@echo off
rem Opens the TTT2 launcher window.
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0rex\launcher.ps1"
