Step 2 of Start Here fills this folder from your own game files.
