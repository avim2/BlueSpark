/**
 * Xbox Live service emulation (--live_signin): see xlive_hle.cpp.
 */
#pragma once

#include <cstdint>
#include <string>

#include <rex/cvar.h>
#include <rex/system/xtypes.h>

namespace rex {
namespace system {
class KernelState;
}
namespace kernel {
namespace xam {
namespace apps {

REXCVAR_DECLARE(int32_t, live_deployment);
REXCVAR_DECLARE(bool, live_trace);
void LiveBurstStart(int n);   // trace aid: the next n kernel calls are logged by the title-side observer
bool LiveBurstTake();
// --live_trace: one line for the first few messages of each kind.
void LiveTrace(const char* what, uint32_t app, uint32_t message, uint32_t a, uint32_t b, uint32_t result);

// Synchronous app messages (XMsgInProcessCall / the app's DispatchMessageSync). Returns true when the message was answered.
bool LiveHleSync(system::KernelState* ks, uint32_t app, uint32_t message, uint32_t arg1, uint32_t arg2, X_HRESULT* result);
// Asynchronous XRL requests to xlivebase (0xFC 0x0005xxxx: storage, string verify): result plus the extended error for the overlapped.
bool LiveHleXrl(system::KernelState* ks, uint32_t app, uint32_t message, uint32_t buffer_ptr, uint32_t buffer_length, uint32_t* result, uint32_t* ext);

// (Patch 63) Storage requests (xlivebase 0x00050009 download / 0x0005000B upload) answered off the title's thread; see xlive_hle.cpp.
// True when the request is taken: with an overlapped the title is answered "pending" and the overlapped is completed later; without one
// *sync_result is the answer (after at most --live_storage_timeout_ms).
bool LiveStorageStart(system::KernelState* ks, uint32_t app, uint32_t message, uint32_t overlapped_ptr, uint32_t buffer_ptr, uint32_t* sync_result);
// XMsgCancelIORequest: true when a pending storage request on this overlapped was retired.
bool LiveStorageCancel(uint32_t overlapped_ptr);
// The XAM messages in flight on guest threads (XMsgInProcessCall / XMsgStartIORequest ...) and where the storage file work stands, for the
// game's stall report ("thread 06 in XMsgStartIORequest app FC message 0005000B for 8123 ms; the storage upload file work is in 'fopen' ...").
std::string LiveXamInflightReport();
class LiveXamCallScope {
 public:
  LiveXamCallScope(const char* what, uint32_t app, uint32_t message, uint32_t overlapped);
  ~LiveXamCallScope();
  LiveXamCallScope(const LiveXamCallScope&) = delete;
  LiveXamCallScope& operator=(const LiveXamCallScope&) = delete;

 private:
  uint32_t slot_;
};

}  // namespace apps
}  // namespace xam
}  // namespace kernel
}  // namespace rex
