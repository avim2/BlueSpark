# The pipeline seed (helper Task 4, A2): the runtime's stored pipeline descriptions (cache\shaders\shareable\
# 4E4D0859.rtv.d3d12.xpso, and .rov. on the ROV path) gathered on other PCs, shipped as rex\pipelines-seed.rtv.xpso and
# rex\pipelines-seed.rov.xpso. With --d3d12_pipeline_prewarm_stored a shader's first load queues the seed's pipelines
# that use it, and from the second start the start-up makes every one whose shaders are known.
#
# A file: a 12-byte header ('XEPS', 'DXRT' or 'DXRO', the version: the SDK's PipelineDescription / translator
# Modification kVersion, big-endian), then 72-byte records (an XXH3 hash of the description, then the 64-byte
# description: the shaders' hashes and modifications and the render state). No shader code, no driver data. A file
# whose header isn't the exe's is cut to 0 bytes by the runtime, so a seed made with another SDK translator version
# does nothing (docs: rex/PIPELINE_SEED.md says how to tell and how to make it again).
#
#   . rex\tools\pipeline-seed.ps1
#   Merge-PipelineFiles -Out <file> -In <file>, <file>, ...   # one file, each record once (making the seed)
#   Add-PipelineSeed -Seed <file> -Target <file>               # Play's: copied when absent, the missing records appended
#   Get-PipelineFileInfo <file>                                # its kind, version and record count

$script:PipelineHeaderBytes = 12
$script:PipelineRecordBytes = 72

# (The .NET file calls take a relative path from the process's folder, not PowerShell's: every path made full first.)
function Get-PipelineFullPath([string]$Path) { $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Path) }

function Get-PipelineFileInfo([string]$Path) {
    $Path = Get-PipelineFullPath $Path
    $bytes = [IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -lt $script:PipelineHeaderBytes) { return [pscustomobject]@{ Path = $Path; Valid = $false; Why = 'shorter than its header' } }
    $magic = [Text.Encoding]::ASCII.GetString($bytes, 0, 4)
    $api = [Text.Encoding]::ASCII.GetString($bytes, 4, 4)
    $version = '{0:X2}{1:X2}{2:X2}{3:X2}' -f $bytes[8], $bytes[9], $bytes[10], $bytes[11]
    $body = $bytes.Length - $script:PipelineHeaderBytes
    [pscustomobject]@{
        Path = $Path; Valid = ($magic -eq 'XEPS' -and ($api -eq 'DXRT' -or $api -eq 'DXRO'))
        Kind = $(if ($api -eq 'DXRO') { 'rov' } elseif ($api -eq 'DXRT') { 'rtv' } else { $api }); Version = $version
        Records = [Math]::Floor($body / $script:PipelineRecordBytes); Tail = $body % $script:PipelineRecordBytes
        Why = $(if ($magic -ne 'XEPS') { "not a pipeline file ($magic)" } else { '' })
    }
}

# The records of a file, as a list of 72-byte keys (base64) in file order; the header's 12 bytes.
function Read-PipelineRecords([string]$Path) {
    $Path = Get-PipelineFullPath $Path
    $bytes = [IO.File]::ReadAllBytes($Path)
    $header = New-Object byte[] $script:PipelineHeaderBytes
    [Array]::Copy($bytes, 0, $header, 0, $script:PipelineHeaderBytes)
    $records = New-Object System.Collections.Generic.List[string]
    for ($at = $script:PipelineHeaderBytes; $at + $script:PipelineRecordBytes -le $bytes.Length; $at += $script:PipelineRecordBytes) {
        $records.Add([Convert]::ToBase64String($bytes, $at, $script:PipelineRecordBytes))
    }
    @{ Header = $header; Records = $records }
}

function Merge-PipelineFiles([string]$Out, [string[]]$In) {
    $Out = Get-PipelineFullPath $Out
    $header = $null; $seen = New-Object 'System.Collections.Generic.HashSet[string]'; $order = New-Object System.Collections.Generic.List[string]
    foreach ($file in $In) {
        $info = Get-PipelineFileInfo $file
        if (-not $info.Valid) { throw "$file`: $($info.Why)" }
        $read = Read-PipelineRecords $file
        if ($null -eq $header) { $header = $read.Header }
        elseif ([Convert]::ToBase64String($header) -ne [Convert]::ToBase64String($read.Header)) {
            throw "$file`: its header ($($info.Kind) $($info.Version)) isn't the first file's: not merged"
        }
        $added = 0
        foreach ($r in $read.Records) { if ($seen.Add($r)) { $order.Add($r); ++$added } }
        "{0}: {1} records, {2} new" -f $file, $read.Records.Count, $added
    }
    $stream = [IO.File]::Create($Out)
    try {
        $stream.Write($header, 0, $header.Length)
        foreach ($r in $order) { $b = [Convert]::FromBase64String($r); $stream.Write($b, 0, $b.Length) }
    } finally { $stream.Dispose() }
    "{0}: {1} records ({2} bytes)" -f $Out, $order.Count, (Get-Item $Out).Length
}

# Play's step: the seed into the player's cache. Absent: copied. Present with the same header: the seed's records it
# lacks appended (the runtime appends its own the same way: header, then records). Left alone when its header differs
# (another translator version: the runtime keeps whichever matches the exe) or it ends in part of a record.
# Returns a line for the log, or nothing.
function Add-PipelineSeed([string]$Seed, [string]$Target) {
    $Seed = Get-PipelineFullPath $Seed; $Target = Get-PipelineFullPath $Target
    if (-not (Test-Path -LiteralPath $Seed)) { return }
    if (-not (Test-Path -LiteralPath $Target)) {
        New-Item -ItemType Directory -Force (Split-Path $Target -Parent) | Out-Null
        Copy-Item -LiteralPath $Seed $Target
        return "Pipeline seed: $(Split-Path $Target -Leaf) made from the seed ($((Get-PipelineFileInfo $Seed).Records) records)"
    }
    $have = Get-PipelineFileInfo $Target
    $seedInfo = Get-PipelineFileInfo $Seed
    # (A file the runtime would discard at the start: empty or shorter than its header (the runtime cuts a file of another
    # version to 0 bytes, and a game quit before its buffered header was written leaves 0 too), not a pipeline file, or of an
    # older version than the seed (an update changed the translator: the seed is the new one). It is replaced by the seed;
    # without this, a player's file cut once would never get the seed again. A newer one than the seed (a stale seed) is
    # left alone, as is one ending in part of a record.)
    if (-not $have.Valid -or ($have.Kind -eq $seedInfo.Kind -and $have.Version -lt $seedInfo.Version)) {
        Copy-Item -LiteralPath $Seed $Target -Force
        $why = if (-not $have.Valid) { $have.Why } else { "version $($have.Version), the seed's $($seedInfo.Version)" }
        return "Pipeline seed: $(Split-Path $Target -Leaf) replaced by the seed ($($seedInfo.Records) records; it was $why)"
    }
    if ($have.Tail -ne 0 -or $have.Kind -ne $seedInfo.Kind -or $have.Version -ne $seedInfo.Version) { return }
    $mine = Read-PipelineRecords $Target
    $known = New-Object 'System.Collections.Generic.HashSet[string]'
    foreach ($r in $mine.Records) { [void]$known.Add($r) }
    $missing = @((Read-PipelineRecords $Seed).Records | Where-Object { -not $known.Contains($_) })
    if (-not $missing.Count) { return }
    $stream = [IO.File]::Open($Target, [IO.FileMode]::Append, [IO.FileAccess]::Write)
    try { foreach ($r in $missing) { $b = [Convert]::FromBase64String($r); $stream.Write($b, 0, $b.Length) } } finally { $stream.Dispose() }
    "Pipeline seed: $($missing.Count) of the seed's records added to $(Split-Path $Target -Leaf)"
}
