# The steps behind the TTT2 launcher (rex\launcher.ps1), one per call:
#   setup-steps.ps1 -Step tools                      install what the build needs
#   setup-steps.ps1 -Step files -Source <iso or folder> -Update <title update file>
#   setup-steps.ps1 -Step build
#   setup-steps.ps1 -Step play
#   setup-steps.ps1 -Step status                     what is done (one line each)
#   setup-steps.ps1 -Step cleanup                    the prebuilt package: delete the old SDK folders
#   setup-steps.ps1 -Step move -From <folder> -To <folder>   the tools and game files to another data folder
# Everything it downloads goes to the data folder (rex\tools\data-folder.ps1: %LOCALAPPDATA%\TTT2Native unless Start
# Here's "Where to put the tools and game files" says another; the lead's E, 27 Oct). Only installing Visual Studio's
# compiler asks Windows for permission (one prompt).
#
# The prebuilt package (rex\prebuilt\manifest.txt; docs/PREBUILT_PACKAGE_PLAN.md): the tools are the pinned portable
# compiler (rex\tools\toolchain.ps1; Microsoft's part only with -AcceptMicrosoftLicense, the launcher's license screen),
# the VC++ runtime (its one Windows prompt) and Python; no Git, no Visual Studio.

param(
    [Parameter(Mandatory)][ValidateSet('tools', 'files', 'build', 'play', 'switches', 'status', 'update', 'update-file', 'adopt', 'cleanup', 'move')][string]$Step,
    [string]$From = '',       # move: the data folder the tools and game files are in now
    [string]$To = '',         # move: the data folder they go to
    [string]$ZipFile = '',    # update-file: a release zip the player dropped onto Start Here's window
    [string]$Sha256 = '',     # update-file: the zip's SHA-256 if the player has it (else <zip>.sha256 beside it, if there)
    [switch]$AllowOlder,      # update-file: an older or the same release, the player having said yes
    [string]$Into = '',       # adopt: the previous install folder this package is copied over (Start Here's rescue)
    [switch]$AcceptMicrosoftLicense,   # tools: the player accepted Microsoft's license in Start Here
    [string]$Source = '',
    [string]$Update = '',
    [switch]$Offline,         # play: without the online switches (Start Here's "Play offline (no internet)")
    [string]$UpdateUrl = '',   # update: the feed (a URL, or a local folder holding latest.json and the zip)
    [int]$Patch = 0             # update: the patch number the launcher saw in the feed
)

$ErrorActionPreference = 'Stop'
# (No script these steps run may ask on the console: there is none to answer it. 4.5.)
$env:TTT2_NO_PROMPT = '1'
$ProgressPreference = 'SilentlyContinue'   # Invoke-WebRequest is many times slower with its progress bar
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Rex = $PSScriptRoot
. (Join-Path $Rex 'tools\remove-folder.ps1')   # (Remove-Ttt2Folder: deletes through .NET, safe in a non-ASCII install folder)
$Repo = Split-Path -Parent $Rex
$Base = Join-Path $env:LOCALAPPDATA 'TTT2Native'   # (the steps' markers, logs, the profile: always here)
. (Join-Path $Rex 'tools\data-folder.ps1')
$Data = Get-Ttt2DataFolder                          # (the tools and the game files: here, or where the player chose)
$Tools = Join-Path $Data 'tools'
$PinnedLlvm = 'https://github.com/llvm/llvm-project/releases/download/llvmorg-20.1.8/clang+llvm-20.1.8-x86_64-pc-windows-msvc.tar.xz'
if ($Step -notin 'status', 'move') { New-Item -ItemType Directory -Force $Tools | Out-Null }
$Prebuilt = Test-Path -LiteralPath (Join-Path $Rex 'prebuilt\manifest.txt')
if ($Prebuilt) { . (Join-Path $Rex 'tools\toolchain.ps1') }
# A package with the online code: the marker (the prebuilt package has no rex\src), or the sources (dev).
$HasOnline = (Test-Path -LiteralPath (Join-Path $Rex 'online-build.txt')) -or (Test-Path -LiteralPath (Join-Path $Rex 'src\online'))

function Run {
    # Native tools write progress to stderr. Windows PowerShell turns that into errors when its own
    # output is redirected (as in the launcher's steps), which $ErrorActionPreference = 'Stop' makes
    # fatal; so stderr is passed through as plain text, and only the exit code decides.
    $saved = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { & $args[0] $args[1..($args.Count - 1)] 2>&1 | ForEach-Object { "$_" } }
    finally { $ErrorActionPreference = $saved }
    if ($LASTEXITCODE -ne 0) { throw "Failed ($LASTEXITCODE): $($args -join ' ')" }
}

function Say($text) { Write-Host "[$(Get-Date -Format HH:mm:ss)] $text" }

# The download of the latest release's first file matching the first pattern that matches any. Through GitHub's API
# (api.github.com): the developer's source path only (MinGit, LLVM). A player's steps use pinned URLs (report 115937,
# 27 Oct: api.github.com didn't resolve on a player's PC, a DNS filter, while raw.githubusercontent.com did).
function Latest-Asset($repo, [string[]]$patterns) {
    $release = Invoke-RestMethod "https://api.github.com/repos/$repo/releases/latest" -Headers @{ 'User-Agent' = 'ttt2-launcher' }
    foreach ($pattern in $patterns) {
        $asset = $release.assets | Where-Object { $_.name -match $pattern } | Select-Object -First 1
        if ($asset) { return $asset.browser_download_url }
    }
    throw "No download matching $($patterns -join ' or ') in $repo's latest release."
}

# A download, its SHA-256 checked when one is given. A failure to reach the host is said plainly (Get-Ttt2NetProblem):
# the host, and what to try; -ByHand: where its file can be put by hand instead.
function Download($url, $file, [string]$Sha256 = '', [string]$ByHand = '') {
    Say "Downloading $(Split-Path $url -Leaf)"
    try { Invoke-WebRequest $url -OutFile $file -UseBasicParsing }
    catch { throw (Get-Ttt2NetProblem $url $_.Exception $ByHand) }
    if ($Sha256) {
        $got = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
        if ($got -ne $Sha256.ToUpper()) {
            Remove-Item -LiteralPath $file -Force
            throw "The download of $url isn't the expected file (its SHA-256 is $got, not $($Sha256.ToUpper())): not used. Something between this PC and the internet changed it, or the download broke: try again later.$(if ($ByHand) { " $ByHand" })"
        }
    }
}

# extract-xiso, pinned like the compiler (no GitHub API call; report 115937): its release asset and SHA-256 (the release of
# 11 Sep 2026, checked on 27 Oct: GitHub's digest and a download agree). The Windows 64-bit release build (the debug one
# can need Visual Studio's debug libraries). $env:TTT2_TEST_XISO_URL / _SHA256: test only, another URL or hash.
$ExtractXisoUrl = 'https://github.com/XboxDev/extract-xiso/releases/download/build-202609111233/extract-xiso-Win64_Release.zip'
$ExtractXisoSha256 = 'fc891dfa72f08e3838a2f8b7ec34a8e4d61678da1cc8fee879677f00bf114ce3'
if ($env:TTT2_TEST_XISO_URL) { $ExtractXisoUrl = $env:TTT2_TEST_XISO_URL }
if ($env:TTT2_TEST_XISO_SHA256) { $ExtractXisoSha256 = $env:TTT2_TEST_XISO_SHA256 }

function Find-VisualStudio {
    $vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
    if (-not (Test-Path -LiteralPath $vswhere)) { return $null }
    # The newest Visual Studio with the C++ tools and CMake (with Ninja); else the newest with the
    # C++ tools (a PC can have several, e.g. a Community without CMake and our Build Tools).
    $found = & $vswhere -latest -prerelease -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 Microsoft.VisualStudio.Component.VC.CMake.Project -property installationPath
    if (-not $found) { $found = & $vswhere -latest -prerelease -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath }
    return $found
}

function Clang-Major($bin) {
    $clang = Join-Path $bin 'clang.exe'
    if (-not (Test-Path -LiteralPath $clang)) { return 0 }
    if ((& $clang --version | Select-Object -First 1) -match 'version (\d+)\.') { return [int]$Matches[1] }
    return 0
}

# The tools this machine has from earlier runs, put on PATH for this process and its children.
function Use-Tools {
    $git = Join-Path $Tools 'mingit\cmd'
    $python = Join-Path $Tools 'python'
    $llvm = Join-Path $Tools 'llvm\bin'
    foreach ($dir in $git, $python) { if (Test-Path -LiteralPath $dir) { $env:PATH = "$dir;$env:PATH" } }
    if (Test-Path -LiteralPath (Join-Path $python 'python.exe')) { $env:TTT2_PYTHON = Join-Path $python 'python.exe' }
    if (Test-Path -LiteralPath (Join-Path $llvm 'clang.exe')) { $env:TTT2_LLVM = $llvm }
}

function Step-ToolsPrebuilt {
    Say "The tools go in $Data"
    # (The lead's E: the drive's free space before anything is downloaded; what is already there counts as taken.)
    $root = Get-Ttt2ToolchainRoot
    if (-not (Test-Path -LiteralPath (Join-Path (Get-Ttt2PinFolder $root $script:Ttt2ToolchainPins.llvm) 'ttt2-unpacked.txt'))) {
        if ($problem = Get-Ttt2SpaceProblem 1 $Data (Get-Ttt2FolderGB $root)) {
            throw "$problem Free some space on that drive, or choose another folder for the tools and game files (Change...), then click Install again."
        }
    }
    # Python (portable), for reading the title update package.
    if (-not (Test-Path -LiteralPath (Join-Path $Tools 'python\python.exe'))) {
        $zip = Join-Path $Tools 'python.zip'
        Download 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-embed-amd64.zip' $zip
        Expand-Archive -LiteralPath $zip (Join-Path $Tools 'python') -Force
        Remove-Item -LiteralPath $zip
    }
    Say 'Python: ready'
    # The compiler: LLVM, CMake and Ninja (about 1 GB), and Microsoft's C++ runtime and Windows SDK (from Microsoft,
    # about 85 MB), each checked against its pinned SHA-256.
    Say 'The compiler: downloading what is missing (about 1.1 GB the first time; unpacked, about 5 GB).'
    Install-Ttt2Toolchain -AcceptMicrosoftLicense:$AcceptMicrosoftLicense
    Install-Ttt2VcRuntime (Join-Path (Get-Ttt2ToolchainRoot) 'downloads')
    Use-Tools
    # (The pins in the marker: a Visual Studio-era tools.done doesn't count for this package.)
    Set-Content -LiteralPath (Join-Path $Base 'tools.done') "prebuilt $(Get-Ttt2ToolchainPinText) $(Get-Date -Format s)"
    Say 'Tools: all ready.'
}

function Step-Tools {
    if ($Prebuilt) { Step-ToolsPrebuilt; return }
    # Git (portable, no installer), for downloading the runtime's source.
    if (-not (Get-Command git -ErrorAction SilentlyContinue) -and -not (Test-Path -LiteralPath (Join-Path $Tools 'mingit\cmd\git.exe'))) {
        $zip = Join-Path $Tools 'mingit.zip'
        Download (Latest-Asset 'git-for-windows/git' '^MinGit-[\d.]+-64-bit\.zip$') $zip
        Expand-Archive -LiteralPath $zip (Join-Path $Tools 'mingit') -Force
        Remove-Item -LiteralPath $zip
    }
    Say 'Git: ready'

    # Python (portable), for reading the title update package.
    if (-not (Test-Path -LiteralPath (Join-Path $Tools 'python\python.exe'))) {
        $zip = Join-Path $Tools 'python.zip'
        Download 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-embed-amd64.zip' $zip
        Expand-Archive -LiteralPath $zip (Join-Path $Tools 'python') -Force
        Remove-Item -LiteralPath $zip
    }
    Say 'Python: ready'

    # Visual Studio's C++ build tools with CMake, Ninja and Clang (one Windows permission prompt).
    $vs = Find-VisualStudio
    $hasClang = $vs -and (Test-Path -LiteralPath (Join-Path $vs 'VC\Tools\Llvm\x64\bin\clang.exe')) -and
                (Test-Path -LiteralPath (Join-Path $vs 'Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe'))
    if (-not $hasClang) {
        $installer = Join-Path $Tools 'vs_BuildTools.exe'
        Download 'https://aka.ms/vs/17/release/vs_BuildTools.exe' $installer
        Say 'Installing Visual Studio''s C++ build tools. Windows will ask for permission. This takes a while (often 15 to 40 minutes); the window may look idle meanwhile.'
        $arguments = @('--quiet', '--wait', '--norestart', '--nocache',
            '--add', 'Microsoft.VisualStudio.Workload.VCTools',
            '--add', 'Microsoft.VisualStudio.Component.VC.Tools.x86.x64',
            '--add', 'Microsoft.VisualStudio.Component.Windows11SDK.22621',
            '--add', 'Microsoft.VisualStudio.Component.VC.CMake.Project',
            '--add', 'Microsoft.VisualStudio.Component.VC.Llvm.Clang',
            '--add', 'Microsoft.VisualStudio.Component.VC.Llvm.ClangToolset')
        $p = Start-Process $installer -ArgumentList $arguments -Verb RunAs -Wait -PassThru
        if ($p.ExitCode -ne 0 -and $p.ExitCode -ne 3010) { throw "The Visual Studio installer stopped with code $($p.ExitCode)." }
        $vs = Find-VisualStudio
        if (-not $vs) { throw 'Visual Studio''s build tools did not install.' }
    }
    Say "Visual Studio: $vs"

    # The build needs Clang 20 or newer; if Visual Studio's is older, a standalone LLVM.
    $vsClang = Clang-Major (Join-Path $vs 'VC\Tools\Llvm\x64\bin')
    if ($vsClang -lt 20 -and (Clang-Major (Join-Path $Tools 'llvm\bin')) -lt 20) {
        Say "Visual Studio's Clang is version $vsClang; getting a newer one (about 1 GB)."
        $archive = Join-Path $Tools 'llvm.tar.xz'
        # Clang 20, the version the game is built with; the newest only if that download fails.
        try { Download $PinnedLlvm $archive }
        catch {
            Say "Clang 20's download failed ($($_.Exception.Message)); taking the newest instead."
            Download (Latest-Asset 'llvm/llvm-project' '^clang\+llvm-[\d.]+-x86_64-pc-windows-msvc\.tar\.xz$') $archive
        }
        $unpack = Join-Path $Tools 'llvm-unpack'
        Remove-Ttt2Folder $unpack
        New-Item -ItemType Directory -Force $unpack | Out-Null
        # Unpacked with the portable Python (Windows' own tar can't always read .xz).
        Run (Join-Path $Tools 'python\python.exe') -c "import sys, tarfile; tarfile.open(sys.argv[1]).extractall(sys.argv[2])" $archive $unpack
        $root = Get-ChildItem -LiteralPath $unpack -Directory | Select-Object -First 1
        $target = Join-Path $Tools 'llvm'
        Remove-Ttt2Folder $target
        Move-Item -LiteralPath $root.FullName $target
        Remove-Ttt2Folder $unpack, $archive
    }
    Use-Tools
    Say "Clang: version $([math]::Max($vsClang, (Clang-Major (Join-Path $Tools 'llvm\bin'))))"
    Set-Content -LiteralPath (Join-Path $Base 'tools.done') (Get-Date -Format s)
    Say 'Tools: all ready.'
}

# What is wrong with the file picked as the title update, or $null: a friend picked the ISO again in the second
# dialog (23 Oct), which cost a whole ISO extraction before the update was read. Start Here checks the same.
function Get-UpdateFileProblem([string]$update, [string]$source) {
    if (-not (Test-Path -LiteralPath $update -PathType Leaf)) { return 'Choose your title update file (named like TU_174Q22P_...).' }
    $full = [IO.Path]::GetFullPath($update)
    if (($source -and $full -eq [IO.Path]::GetFullPath($source)) -or $full -match '(?i)\.iso$') {
        return "That's your game's disc image, not the title update. The second file is the game's update from your Xbox 360. It's named like TU_174Q22P_0000008000000.00000000000O2 and is about 3 MB. See `"The title update`" in README.txt."
    }
    $size = (Get-Item -LiteralPath $full).Length
    if ($size -gt 100MB) { return ("That file is {0:N0} MB, but the title update is about 3 MB and named like TU_174Q22P_... See `"The title update`" in README.txt." -f ($size / 1MB)) }
    $head = New-Object byte[] 4
    $f = [IO.File]::OpenRead($full)
    try { $n = $f.Read($head, 0, 4) } finally { $f.Close() }
    $magic = [Text.Encoding]::ASCII.GetString($head, 0, $n)
    if ($magic -notin @('CON ', 'LIVE', 'PIRS')) {
        return "That file isn't an Xbox 360 update package (it should start with LIVE, CON or PIRS). Pick the file named like TU_174Q22P_0000008000000.00000000000O2, copied off the console as it is."
    }
    return $null
}

function Step-Files {
    Use-Tools
    if (-not $Source) { throw 'Choose your game: an ISO of your disc, or a folder with default.xex.' }
    if ($problem = Get-UpdateFileProblem $Update $Source) { throw $problem }
    $game = $Source
    if (Test-Path -LiteralPath $Source -PathType Leaf) {
        # An ISO: extracted with extract-xiso into <the data folder>\game (the old extraction there is replaced: it
        # counts as space already taken).
        if ($problem = Get-Ttt2SpaceProblem 2 $Data (Get-Ttt2FolderGB (Join-Path $Data 'game'))) {
            throw "$problem Your ISO is extracted there. Free some space on that drive, or choose another folder in `"Where to put the tools and game files`" (or pick a folder with the game's files instead of the ISO: nothing is copied then)."
        }
        $xiso = Get-ChildItem -LiteralPath (Join-Path $Tools 'extract-xiso') -Recurse -Filter 'extract-xiso.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
        if (-not $xiso) {
            $zip = Join-Path $Tools 'extract-xiso.zip'
            Download $ExtractXisoUrl $zip -Sha256 $ExtractXisoSha256 -ByHand ("Or download it yourself, $ExtractXisoUrl, and unzip it into $(Join-Path $Tools 'extract-xiso') (Install looks there first), then click Install again.")
            Expand-Archive -LiteralPath $zip (Join-Path $Tools 'extract-xiso') -Force
            Remove-Item -LiteralPath $zip
            $xiso = Get-ChildItem -LiteralPath (Join-Path $Tools 'extract-xiso') -Recurse -Filter 'extract-xiso.exe' | Select-Object -First 1
        }
        $game = Join-Path $Data 'game'
        Remove-Ttt2Folder $game
        Say 'Extracting your ISO (a few minutes)'
        New-Item -ItemType Directory -Force $game | Out-Null
        # extract-xiso takes its options before the image ("-x -d <folder> <iso>"); run from the
        # target folder too, so that its default ("<iso name>\" in the current folder) lands there.
        # It says nothing while it works, so progress is the size written against the image's size,
        # as "PROGRESS <percent> <text>" lines that the launcher shows as a bar.
        $isoSize = [math]::Max([double]1, [double](Get-Item -LiteralPath $Source).Length)   # doubles: images are over 4 GB
        $out = Join-Path $Base 'extract-xiso.out.txt'
        $p = Start-Process $xiso.FullName -ArgumentList @('-x', '-d', "`"$game`"", "`"$Source`"") -WorkingDirectory $game `
            -NoNewWindow -PassThru -RedirectStandardOutput $out -RedirectStandardError "$out.err"
        $null = $p.Handle   # without this, Windows PowerShell may not report the exit code
        while (-not $p.HasExited) {
            $written = [double](Get-ChildItem -LiteralPath $game -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
            Write-Host ("PROGRESS {0} Extracting your ISO" -f [math]::Min(99, [int](100 * $written / $isoSize)))
            Start-Sleep -Seconds 1
        }
        $p.WaitForExit()
        $code = $p.ExitCode
        Write-Host 'PROGRESS 100 Extracted'
        foreach ($f in $out, "$out.err") { if (Test-Path -LiteralPath $f) { Get-Content -LiteralPath $f | Select-Object -Last 5 | ForEach-Object { Say "extract-xiso: $_" } } }
        # extract-xiso can end with a non-zero code when everything came out (e.g. over the disc's
        # $SystemUpdate folder), and may put the files one folder down: go by what is there. The
        # files' fingerprints are checked in the next step anyway.
        $xex = Get-ChildItem -LiteralPath $game -Recurse -Depth 2 -Filter 'default.xex' -ErrorAction SilentlyContinue |
            Sort-Object { $_.FullName.Length } | Select-Object -First 1
        if (-not $xex) {
            throw "Could not extract the ISO (extract-xiso ended with code $code and no default.xex came out). Make sure it is an image of the TTT2 Xbox 360 disc."
        }
        $game = $xex.DirectoryName
        if ($code -ne 0) { Say "extract-xiso ended with code $code, but the game's files are there: going on." }
        Say "Game files: $game"
    }
    & (Join-Path $Rex 'prepare-game.ps1') -GameFolder $game -UpdatePackage $Update
    Set-Content -LiteralPath (Join-Path $Base 'files.done') (Get-Date -Format s)
    Say 'Game files: ready.'
}

# A prebuilt package over an older source-layout folder (by the updater, or unzipped over it by hand: an older
# package's updater copies files and knows nothing of this): the old sources go, and the old build (a stale exe and
# objects made by Visual Studio's compiler). Once: only while the old sources are there.
function Convert-ToPrebuiltLayout {
    if (-not (Test-Path -LiteralPath (Join-Path $Rex 'src')) -and -not (Test-Path -LiteralPath (Join-Path $Rex 'patches'))) { return }
    # (Never in a git checkout: a developer's clone keeps its sources, whatever was unzipped over it.)
    if (Test-Path -LiteralPath (Join-Path $Repo '.git')) {
        throw "$Repo is a git checkout (it has a .git folder): its rex\src and rex\patches are not removed. Unzip the package into its own folder."
    }
    foreach ($old in 'rex\src', 'rex\patches', 'recomp\tools\xexpatch.cpp', 'recomp\XENONRECOMP_COMMIT', 'rex\sdk-folder.txt', 'rex\out\build') {
        $path = Join-Path $Repo $old
        if (Test-Path -LiteralPath $path) { Say "The prebuilt layout: removing the old $old"; Remove-Ttt2Folder $path }
    }
}

function Step-Build {
    if ($Prebuilt) { Convert-ToPrebuiltLayout }
    Use-Tools
    # (A path with any character outside plain ASCII: the SDK's code generator, rexglue.exe, takes its paths through the code
    # page and reads them as UTF-8, so even a folder named U+00FF failed with "...\?\...\ttt2_manifest.toml is not a manifest"
    # (27 Oct). Said plainly before anything is built.)
    if ($name = Get-Ttt2NonAsciiFolder $Repo) {
        throw "This folder's path has characters the build's tools can't handle ($name): the build would fail. Move the whole folder to C:\ttt2, start Start Here from there and click Install again."
    }
    # (The lead's E and F: the build goes in this install folder; a synced folder is said again here, Start Here asks first.)
    if ($problem = Get-Ttt2SpaceProblem 3 $Repo) { throw "$problem The build goes in this folder ($Repo). Free some space on that drive, then click Install again." }
    if ($service = Get-Ttt2SyncedFolder $Repo) { Say "Warning: this folder is inside $service ($Repo): if the build fails, move the folder out of $service (to C:\ttt2 or another drive)." }
    # A package unzipped over an older one: its files carry dates in the past (the packager's,
    # for CMake), often older than the objects already built, so an incremental build would see
    # nothing new and keep the old game. When the package's VERSION.txt differs from the one the
    # last build was made from, our sources are marked as changed (only rex\src: the game's
    # generated code doesn't change between packages and isn't rebuilt; CMake is configured at
    # every build and the SDK's patches are compared by hash). From the training branch, 6833fb1.
    $version = Join-Path $Repo 'VERSION.txt'
    $built = Join-Path $Rex 'out\build\win-amd64-release\package-version.txt'
    $now = if (Test-Path -LiteralPath $version) { (Get-Content -LiteralPath $version -Raw).Trim() } else { '' }
    $was = if (Test-Path -LiteralPath $built) { (Get-Content -LiteralPath $built -Raw).Trim() } else { '' }
    # (A source package: its sources dated now, so that Ninja rebuilds them. The prebuilt package needs nothing here:
    # build-windows.ps1 relinks when the release's manifest changed.)
    if ($now -and $now -ne $was -and (Test-Path -LiteralPath (Split-Path $built)) -and (Test-Path -LiteralPath (Join-Path $Rex 'src'))) {
        Say "A new package ($now): its sources rebuilt."
        Get-ChildItem -LiteralPath (Join-Path $Rex 'src') -Recurse -File | ForEach-Object { $_.LastWriteTime = Get-Date }
    }
    & (Join-Path $Rex 'build-windows.ps1')
    if ($now) { Set-Content -LiteralPath $built $now }
    Set-Content -LiteralPath (Join-Path $Base 'build.done') (Get-Date -Format s)
    Invoke-PipelineWarmup   # (Install's build part ends with it, 4.5.1; it never fails the part)
    Say 'Build: done.'
}

# The pipeline warm-up (the helper's Task 4, A4): the new exe started once, through run-windows.ps1 as Play starts it (the
# game folder, the user data, the pipeline seed), with --ttt2_pipeline_warmup_quit: it quits as soon as the start has made
# the stored pipelines, before the game runs (pipeline_warmup.cpp). A cold GPU driver (after an update that changes how
# shaders are translated) compiles them here, not at the next Play. With no shader file yet (a new player) there is nothing
# to make and it takes a few seconds. Never fails the Build.
function Invoke-PipelineWarmup {
    if (-not (Test-Path -LiteralPath (Join-Path $Rex 'game-folder.txt'))) { return }
    . (Join-Path $Rex 'tools/game-lock.ps1')
    # (A game already running, this install's or another's, or a live lock: skipped, never waited for. run-windows.ps1
    # would wait for the lock, and the game to wait on must be the one started here.)
    $lock = Get-GameLock
    if ((Get-Process ttt2 -ErrorAction SilentlyContinue) -or ($lock -and (Test-GameLockLive $lock) -and [int]$lock.pid -ne $PID)) {
        Say 'Build: a game is running, so the pipeline warm-up is skipped (Play makes them instead).'
        return
    }
    $prompt = $env:TTT2_NO_PROMPT
    $pidFileWas = $env:TTT2_GAME_PID_FILE
    # (The started game's id and start time go into a file of the warm-up's own: the process waited on, and stopped if it
    # must be, is that one and never another.)
    $pidFile = Join-Path $Rex 'out\warmup-pid.txt'
    try {
        Say 'Build: warming up the graphics pipelines (the game''s window shows for a moment)...'
        $env:TTT2_NO_PROMPT = '1'   # (no game folder: run-windows.ps1 throws instead of asking)
        $env:TTT2_GAME_PID_FILE = $pidFile
        Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue
        $started = Get-Date
        # (Its own log file, made again each time: with --log_file the SDK writes no numbered log, so the warm-up's quit
        # (no "Title terminated") is never taken for a crash's leftover log by the next online start, nor packed into a
        # problem report.)
        $warmupLog = Join-Path $Rex 'out\pipeline-warmup.log'
        Remove-Item -LiteralPath $warmupLog -Force -ErrorAction SilentlyContinue   # (the SDK appends to a --log_file)
        & (Join-Path $Rex 'run-windows.ps1') '--ttt2_pipeline_warmup_quit=true' "--log_file=$warmupLog" | Out-Null
        $game = $null
        if (Test-Path -LiteralPath $pidFile) {
            $parts = "$(Get-Content -LiteralPath $pidFile -Raw)".Trim() -split ' '
            $p = Get-Process -Id ([int]$parts[0]) -ErrorAction SilentlyContinue
            if ($p -and $p.ProcessName -eq 'ttt2') { try { if ($p.StartTime.ToFileTimeUtc() -eq [long]$parts[1]) { $game = $p } } catch {} }
        }
        if ($game -and -not $game.WaitForExit(600000)) {
            Stop-Process -Id $game.Id -Force -ErrorAction SilentlyContinue
            Say 'Build: the pipeline warm-up took over 10 minutes and was stopped (Play makes them instead).'
            return
        }
        Say "Build: graphics pipelines warmed up in $([int]((Get-Date) - $started).TotalSeconds) s."
    } catch {
        Say "Build: the pipeline warm-up was skipped ($($_.Exception.Message)); Play makes them instead."
    } finally {
        $env:TTT2_NO_PROMPT = $prompt
        $env:TTT2_GAME_PID_FILE = $pidFileWas
        Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue
    }
}

# The logs every play-test run keeps (rex\out\build\win-amd64-release\logs): only the cheap ones,
# a line a second or a line when something changes, so they cost no frames. Left out: the
# per-resolve and per-input traces (hundreds of lines a second), the sound and XMA dumps
# (gigabytes; "Report a sound problem" makes them and turns the XMA trace on, which at about
# 1,500 lines a second rolled the log over in minutes) and the rollback diagnostics.
$PlayLogSwitches = @(
    '--latency_log=true',        # input-to-present delays and the frame pacing, once a second
    '--ttt2_frame_times=true',   # the update's and the draw's time, every 300 frames
    '--gpu_work_log_ms=8',       # a hitch's first-time GPU work (textures, pipelines, uploads) over 8 ms
    '--ttt2_hang_dump=true',     # where every thread is, if the game stops updating for 2.5 s
    '--ttt2_window_report=true', # a line when the window is minimized, restored or loses the focus, or the steps or the timer drop
    '--audio_stats=true',        # sound frames submitted, played and missed, once a second
    '--ttt2_xmsg_trace=true',    # the game's messages to the console's system services
    '--ttt2_file_trace=true',    # every file the game opens (loads)
    '--ttt2_crash_dump=true'     # a crash nothing else explains: its guest calls logged and a minidump in rex\out\dumps (for Report a problem)
)

function Step-Play {
    Use-Tools
    # (A path with a character outside plain ASCII (27 Oct): a CJK or emoji folder ends the game at its start with a C runtime
    # fail-fast (0xC0000409) and no log; a U+00FF folder plays, but the game made its user data (the saves too) in another
    # folder, the name read in the wrong encoding (C:\ptest\U+00C3 U+00BF\...\rex\userdata). Said plainly instead.)
    if ($name = Get-Ttt2NonAsciiFolder $Repo) {
        throw "This folder's path has characters the game can't handle ($name): it would not start, or would put your saves in another folder. Move the whole folder to C:\ttt2, start Start Here from there, click Install again, then Play."
    }
    # Old logs past the newest 20 go, so the folder can't grow without end.
    $logs = Join-Path $Rex 'out\build\win-amd64-release\logs'
    Get-ChildItem -LiteralPath $logs -Filter 'ttt2_*.log' -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -Skip 20 |
        Remove-Item -Force -ErrorAction SilentlyContinue
    $switches = Get-PlaySwitches
    Write-PlaySwitches $switches
    & (Join-Path $Rex 'run-windows.ps1') @switches
}

# The switches Play gives the game. One list for both ways of playing (the lead's I, 26 Oct): Play passes it, and it's
# written to rex\userdata\play-switches.txt (Write-PlaySwitches), which the fast client reads when it starts the game
# (fastclient/app/src/gamestart.cpp, StartHereSwitches), so the two can't drift apart. Start Here's "Play: Fast
# Client" writes it first (the 'switches' step) and then starts the client.
function Get-PlaySwitches {
    # The training mode is always on (the owner, 19 October: training is never off): its opponent,
    # Status Record, and the menu's settings kept between sessions in the user data folder.
    $training = @()
    $logSwitches = $PlayLogSwitches
    if ($true) {
        $settings = Join-Path $Rex 'userdata\training-settings.txt'
        # Easy's slowing in Throw Break Training: on in the play test for the owner to judge
        # (it skips one fight frame in five of the break window, the pause's own way).
        # Rewind and take over (Select + L3): allowed; how far back is the menu's Rewind
        # (Restart Settings, 3 seconds to start with). About 10 MB a second kept and 3 ms once a
        # second (training/STATUS.md, the fourteenth and fifteenth rounds).
        # Replays: every offline Versus match recorded into the user data folder's replays (the
        # newest 50, about 300 KB each), watched from our menu's Replays with the recorded
        # profiles (costumes) installed as the fight is made (the eighteenth round).
        $training = @('--ttt2_training=true', '--ttt2_training_dummy=true', '--ttt2_status_record=true',
                      '--ttt2_training_easy_slow=true', '--ttt2_training_rewind=3',
                      '--ttt2_training_replay=true', '--ttt2_match_setup=true', '--ttt2_match_setup_profiles=true',
                      "--ttt2_training_settings=$settings")
        # --ttt2_frame_times times the update itself and returns before Status Record's branch
        # (run_ahead.cpp), so with it R3 / L3 did nothing (the owner, 16 October): left out here.
        $logSwitches = @($PlayLogSwitches | Where-Object { $_ -notlike '--ttt2_frame_times*' })
    }
    # Online (the lead's order of 19 October): a build with the online code (rex\src\online, Themail's),
    # Start Here's "Online play (test)" on (on by default since the owner's word of 21 October: only online=false
    # in launcher-settings.txt turns it off), and not "Play offline": the game's Live sign-in, its
    # network layer and the fight splice, with the player's name as the lobby's gamertag (the same name
    # --user_name gives the game, from run-windows.ps1).
    $online = @()
    $settingsFile = Join-Path $Rex 'userdata\launcher-settings.txt'
    $onlineWanted = -not ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'online=false'))
    if ($HasOnline -and $onlineWanted -and -not $Offline) {
        $online = @('--live_signin=true', '--ttt2_live_net=true', '--ttt2_fight_splice=3')
        # The play test's logs (22 October): after each online fight its log lines go to the server's log
        # dropbox by themselves (rex\src\online\log_upload.cpp: signed with the player's key, other players'
        # addresses and the Windows user name taken out, from a thread of their own after the fight). OFF since the
        # public launch (27 Oct): only logupload=true in launcher-settings.txt turns it on (Start Here's "Send each
        # online fight's log"). Crash logs are separate (below) and stay on.
        if ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'logupload=true')) {
            $online += '--ttt2_log_autoupload=true'
        }
        # A crash's log (23 October): the game sends the run before's log at the start when it crashed, on by
        # itself with the online switches; crashlog=false (Start Here's "Send crash logs") turns it off.
        if ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'crashlog=false')) {
            $online += '--ttt2_log_autoupload_crash=false'
        }
        # (The name is the profile folder's since #30, tools\profile-folder.ps1; the game folder's copy is the one before
        # 23 October, read when the profile has none yet. A new install had no gamertag passed: a reader, 24 Oct.)
        . (Join-Path $Rex 'tools\profile-folder.ps1')
        $nameFile = Join-Path (Get-ProfileFolder) 'player-name.txt'
        if (-not (Test-Path -LiteralPath $nameFile)) { $nameFile = Join-Path $Rex 'userdata\player-name.txt' }
        if (Test-Path -LiteralPath $nameFile) {
            $name = "$(Get-Content -LiteralPath $nameFile -Raw)".Trim()
            if ($name) { $online += "--ttt2_live_gamertag=$name" }
        }
        Say "Online: $($online -join ' ')"
    } elseif ($Offline) {
        Say 'Offline: the online switches left out.'
    }
    # The keyboard as player one (the lead's orders of 23 Oct, the owner's word): our own layer (src/keyboard_input.cpp,
    # the keys in rex\userdata\keyboard.txt), on unless Start Here's "Keyboard (player 1)" is off (keyboard=false). The
    # SDK's own keyboard (--mnk_mode) always off: given outright, as F4's "Save to config" can have kept mnk_mode = true
    # in ttt2.toml and the command line wins over it.
    $keyboardOn = -not ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'keyboard=false'))
    $keyboard = @('--mnk_mode=false', "--ttt2_keyboard=$(if ($keyboardOn) { 'true' } else { 'false' })",
                  "--ttt2_keyboard_file=$(Join-Path $Rex 'userdata\keyboard.txt')")
    # (The build's name beside CLOSED ALPHA TEST in online fights, the owner, 24 Oct: package-info's name ("Release 4.1"),
    # or "Release N"; an internal build "internal <commit>".)
    $pkg = Read-PackageInfo
    $releaseName = if ($pkg.name) { $pkg.name } elseif ($pkg.track -eq 'release' -and $pkg.patch) { "Release $($pkg.patch)" }
                   else {
                       $commit = $pkg.commit
                       if (-not $commit -and (Test-Path -LiteralPath (Join-Path $Repo '.git'))) { $commit = "$(& git -C $Repo rev-parse --short HEAD 2>$null)".Trim() }
                       "internal $commit".Trim()
                   }
    $keyboard += "--ttt2_release_name=$releaseName"
    # (Controller vibration: off unless Start Here's "Controller vibration" box is ticked, vibration=true; 24 Oct.)
    if ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'vibration=true')) { $keyboard += '--ttt2_vibration=true' }
    # (No intro: the splash, then straight to the main menu; on unless Start Here's "No intro" is unticked, nointro=false. 24 Oct.)
    if (-not ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'nointro=false'))) { $keyboard += '--ttt2_no_intro=true' }
    # (Mute in the background: the game's default (on) unless Start Here's box is unticked, mutebg=false; offline and online alike. 4.5.)
    if ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'mutebg=false')) { $keyboard += '--ttt2_mute_in_background=false' }
    # (Ranked fights' record: wins only unless Start Here's "Show losses and win rate" box is ticked, rankedrecord=full; this PC's
    # screen only, nothing sent. The owner, 30 Oct; rex\src\ranked_hud_record.cpp.)
    if ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'rankedrecord=full')) { $keyboard += '--ttt2_ranked_record_wins_only=false' }
    # (The in-game update popup, 27 Oct: the feed Start Here checks, given only when it isn't the public one, a test
    # URL or folder; the game's own default is the public latest.json. rex\src\update_popup.cpp.)
    if ($UpdateUrl -and $UpdateUrl -ne 'https://raw.githubusercontent.com/avim2/BlueSpark/main/latest.json') { $keyboard += "--ttt2_update_feed=$UpdateUrl" }
    @($logSwitches) + $training + $online + $keyboard
}
function Write-PlaySwitches([string[]]$switches) {
    $file = Join-Path $Rex 'userdata\play-switches.txt'
    New-Item -ItemType Directory -Force (Split-Path $file) | Out-Null
    $lines = @("# The switches Start Here's Play gives the game, written at each Play and before the fast client starts; the fast",
               "# client reads them (rex\setup-steps.ps1, Get-PlaySwitches). Written again each time: don't edit.") + $switches
    [IO.File]::WriteAllLines($file, [string[]]$lines, (New-Object Text.UTF8Encoding $false))
}
function Step-Switches {
    $switches = Get-PlaySwitches
    Write-PlaySwitches $switches
    Say "Play's switches written for the fast client ($($switches.Count))."
}

function Step-Status {
    $exe = Join-Path $Rex 'out\build\win-amd64-release\ttt2.exe'
    $toolsDone = Join-Path $Base 'tools.done'
    if ($Prebuilt) {
        # (A marker naming this package's pins: the toolchain changes with the pins. And the tools where the data folder
        # says: a folder changed without moving them, or emptied by hand, is "not done".)
        $there = (Test-Path -LiteralPath (Join-Path (Get-Ttt2PinFolder (Get-Ttt2ToolchainRoot) $script:Ttt2ToolchainPins.llvm) 'ttt2-unpacked.txt')) -and [bool](Get-Ttt2Python)
        "tools=$((Test-Path -LiteralPath $toolsDone) -and (Get-Content -LiteralPath $toolsDone -Raw) -like "prebuilt $(Get-Ttt2ToolchainPinText) *" -and $there)"
        "oldsdk=$((Test-Path -LiteralPath $exe) -and @(Get-OldSdkFolders).Count -gt 0)"
    } else {
        "tools=$(Test-Path -LiteralPath $toolsDone)"
    }
    # (The game folder rex\game-folder.txt names must still have the game: a data folder emptied or moved by hand.)
    $gameFile = Join-Path $Rex 'game-folder.txt'
    $gameNamed = if (Test-Path -LiteralPath $gameFile) { "$(Get-Content -LiteralPath $gameFile -TotalCount 1)".Trim() } else { '' }
    $gameThere = -not $gameNamed -or (Test-Path -LiteralPath (Join-Path $gameNamed 'default.xex'))
    "files=$((Test-Path -LiteralPath (Join-Path $Base 'files.done')) -and (Test-Path -LiteralPath (Join-Path $Repo 'gamedata\default_tu.xex')) -and $gameThere)"
    "build=$(Test-Path -LiteralPath $exe)"
    # (4.5.1's Install: the build is out of date when the package's VERSION.txt isn't the one the last build was made from
    # (Step-Build writes package-version.txt after it); Start Here then shows "Rebuild". A folder without VERSION.txt (git): current.)
    $version = Join-Path $Repo 'VERSION.txt'
    $built = Join-Path $Rex 'out\build\win-amd64-release\package-version.txt'
    $current = Test-Path -LiteralPath $exe
    if ($current -and (Test-Path -LiteralPath $version)) {
        $current = (Test-Path -LiteralPath $built) -and "$(Get-Content -LiteralPath $built -Raw)".Trim() -eq "$(Get-Content -LiteralPath $version -Raw)".Trim()
    }
    "buildcurrent=$current"
}

# The update (the lead's order of 17 Oct, the owner's word): the newest package of this track from the feed
# (latest.json; -UpdateUrl a URL or a local folder holding latest.json and the zip), downloaded, checked
# (the size and the SHA-256), unzipped, and its top folder's contents copied over this install folder,
# whatever the player named it. Never a file deleted; rex\userdata, gamedata\, rex\out\ and
# rex\game-folder.txt never touched. The launcher restarts itself afterwards and runs Build.
$NeverTouched = @('rex\userdata', 'gamedata', 'rex\out', 'rex\game-folder.txt')

function Read-PackageInfo {
    $info = @{ track = 'main'; patch = 0; commit = '' }
    $file = Join-Path $Rex 'package-info.txt'
    if (Test-Path -LiteralPath $file) {
        foreach ($line in Get-Content -LiteralPath $file) {
            if ($line -match '^(\w+)=(.*)$') { $info[$Matches[1]] = $Matches[2].Trim() }
        }
        $info.patch = [int]$info.patch
    }
    return $info
}
# (A release by its package-info name, "Release 4.1", as players know it; else "Release <patch>". The lead's 77cdf86.)
function Release-Label($p) { if ($p.name) { "$($p.name)" } else { "Release $($p.patch)" } }

# The feed: a local folder's latest.json, or the URL's (5 s).
function Read-Feed($updateUrl) {
    if (Test-Path -LiteralPath $updateUrl -PathType Container) {
        return (Get-Content -LiteralPath (Join-Path $updateUrl 'latest.json') -Raw | ConvertFrom-Json)
    }
    return Invoke-RestMethod $updateUrl -TimeoutSec 5 -Headers @{ 'User-Agent' = 'ttt2-launcher' }
}

function Feed-Base($updateUrl) {
    if (Test-Path -LiteralPath $updateUrl -PathType Container) { return $updateUrl }
    return $updateUrl.Substring(0, $updateUrl.LastIndexOf('/') + 1)
}

function Copy-Over($from, $to, $relative) {
    # Every file of the unzipped package copied over the install folder, the untouched paths skipped,
    # nothing deleted.
    foreach ($item in Get-ChildItem -LiteralPath $from -Force) {
        $rel = if ($relative) { "$relative\$($item.Name)" } else { $item.Name }
        if ($NeverTouched -contains $rel) { continue }
        $target = Join-Path $to $item.Name
        if ($item.PSIsContainer) {
            New-Item -ItemType Directory -Force $target | Out-Null
            Copy-Over $item.FullName $target $rel
        } else {
            Copy-Item -LiteralPath $item.FullName $target -Force
        }
    }
}

function Step-Update {
    $info = Read-PackageInfo
    $feed = Read-Feed $UpdateUrl
    # (The public feed is flat: one build line, "release" N; only a public package, track=release, takes it.)
    if ($info.track -ne 'release') { throw "This is an internal $($info.track) package: it does not update from the public feed." }
    $entry = $feed
    if (-not $entry.release) { throw 'The feed has no release number.' }
    $entry | Add-Member -NotePropertyName patch -NotePropertyValue ([int]$entry.release) -Force
    if ([int]$entry.patch -le $info.patch) { Say "Release $($entry.patch) is out; this is Release $($info.patch): nothing to do."; return }
    if ($Patch -and [int]$entry.patch -ne $Patch) { Say "The feed says Patch $($entry.patch) now, not $Patch; taking it." }
    Say "Updating to Release $($entry.patch) (built from $($entry.commit), $($entry.date))."
    foreach ($note in @($entry.notes)) { Say "  - $note" }
    # (Its own folder: TTT2Native\update is where an ISO install keeps its title update, and this one is deleted.)
    $work = Join-Path $Base 'update-download'
    Remove-Ttt2Folder $work
    New-Item -ItemType Directory -Force $work | Out-Null
    $zip = Join-Path $work (Split-Path $entry.zip -Leaf)
    $base = Feed-Base $UpdateUrl
    if ("$($entry.zip)" -match '^https?://') {
        Download $entry.zip $zip   # (an absolute URL: a GitHub Release asset)
    } elseif (Test-Path -LiteralPath $base -PathType Container) {
        Copy-Item -LiteralPath (Join-Path $base $entry.zip) $zip
    } else {
        Download ($base + $entry.zip) $zip
    }
    $size = (Get-Item -LiteralPath $zip).Length
    if ([long]$entry.size -ne $size) { throw "The download is $size bytes, the feed says $($entry.size): the current build is kept. (It will be tried again at the next start.)" }
    $sha = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower()
    if ($sha -ne "$($entry.sha256)".ToLower()) { throw "The download's SHA-256 does not match the feed's: the current build is kept. (It will be tried again at the next start.)" }
    # (The feed's own SHA-256 says only that the zip is the one the feed names. As a dropped zip is (Step-UpdateFile),
    # the zip is checked too: the owner's signature over its file list, every file as listed, no entry outside its
    # folder, and a release of this track. The lead's 77cdf86: a must before the builds repo goes public.)
    . (Join-Path $Rex 'tools\package-check.ps1')
    $check = Test-ReleaseZip $zip
    if (-not $check.ok) { throw "$($check.why) The current build is kept." }
    if ($check.info.track -ne $info.track) { throw "The feed's zip is a $($check.info.track) package, and this folder is a $($info.track) one: the current build is kept." }
    Say "Downloaded and checked ($size bytes, signed)."
    Install-Zip $zip $work
    $now = Read-PackageInfo
    Say "Updated to $(Release-Label $now). Start Here restarts and builds."
}

# A checked package zip unzipped in $work and its top folder copied over this install (the update's and the
# downloaded zip's way alike): never a file deleted; rex\userdata, gamedata\, rex\out\, rex\game-folder.txt kept.
function Install-Zip($zip, $work) {
    $unzipped = Join-Path $work 'unzipped'
    Expand-Archive -LiteralPath $zip -DestinationPath $unzipped -Force
    $top = Get-ChildItem -LiteralPath $unzipped -Directory | Select-Object -First 1
    if (-not $top) { throw 'The package has no top folder.' }
    $newInfo = Join-Path $top.FullName 'rex\package-info.txt'
    if ((Test-Path -LiteralPath (Join-Path $Repo '.git')) -and (Test-Path -LiteralPath $newInfo) -and (@(Get-Content -LiteralPath $newInfo) -contains 'layout=prebuilt')) {
        throw "$Repo is a git checkout (it has a .git folder): a prebuilt package is not copied over it. Unzip it into its own folder."
    }
    Test-PrebuiltHashes $top.FullName
    Say "Copying $($top.Name) over $Repo (your saves, game files and builds are not touched)."
    Copy-Over $top.FullName $Repo ''
    # (The copy is checked before the step says it updated (4.5): this folder's package-info must now be the zip's. A copy
    # that silently left the old one (a file in use, a folder the player can't write) said "Updated" and Start Here then
    # showed "... was installed, but this folder says ..." with nothing the player could do.)
    if (Test-Path -LiteralPath $newInfo) {
        $installed = Join-Path $Rex 'package-info.txt'
        $want = (Get-Content -LiteralPath $newInfo -Raw).Trim()
        $have = if (Test-Path -LiteralPath $installed) { (Get-Content -LiteralPath $installed -Raw).Trim() } else { '' }
        if ($have -ne $want) {
            throw "The update was copied, but this folder's rex\package-info.txt is still the old one, so the copy did not go through. Close the game and every Start Here window, then drag the zip onto Start Here again. If it fails again, unzip the zip into a new folder and run Start Here there."
        }
    }
    # A prebuilt package over an older source-layout folder: the old sources and the old build go (a stale exe and
    # objects); the old SDK folder is offered for deletion after the first build, never deleted here.
    if ((Test-Path -LiteralPath $newInfo) -and (@(Get-Content -LiteralPath $newInfo) -contains 'layout=prebuilt')) { Convert-ToPrebuiltLayout }
    $null = Remove-Ttt2Folder $work -Quiet
}

# The package's own check (a zip from Discord has no feed to say its size and hash): each binary rex\prebuilt\manifest.txt
# names, unzipped, against its SHA-256 there. A damaged or partial download stops here, before anything is copied.
function Test-PrebuiltHashes($top) {
    $manifest = Join-Path $top 'rex\prebuilt\manifest.txt'
    if (-not (Test-Path -LiteralPath $manifest)) { return }
    $bad = 0; $checked = 0
    foreach ($line in Get-Content -LiteralPath $manifest) {
        if ($line -notmatch '^file\.(.+?)=([0-9a-fA-F]{64})$') { continue }
        $rel = $Matches[1]; $want = $Matches[2].ToLower()
        $path = Join-Path (Join-Path $top 'rex\prebuilt') $rel
        if (-not (Test-Path -LiteralPath $path)) { $found = @(Get-ChildItem -LiteralPath (Join-Path $top 'rex\prebuilt') -Recurse -File -Filter (Split-Path $rel -Leaf)); $path = if ($found.Count) { $found[0].FullName } else { '' } }
        if (-not $path -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower() -ne $want) { $bad++ } else { $checked++ }
    }
    if ($bad) { throw "$bad of the package's files don't match its own list: the download is damaged. Download the zip again. Your current build is kept." }
    Say "The package's $checked files match its own list."
}

# A release zip the player downloaded (the lead's order of 24 Oct: releases are posted on the owner's Discord, whose
# links expire, so Start Here can't fetch them): checked as ours, the same track, newer (or the player said yes), its
# SHA-256 if given (-Sha256, or a <zip>.sha256 beside it), then installed as an update.
function Step-UpdateFile {
    if (-not $ZipFile -or -not (Test-Path -LiteralPath $ZipFile -PathType Leaf)) { throw "There's no file at $ZipFile." }
    $info = Read-PackageInfo
    # (Start Here checked it before asking; checked again here, before it's unzipped: the owner's signature over its
    # file list, every file as listed, no entry outside its folder. rex\tools\package-check.ps1.)
    . (Join-Path $Rex 'tools\package-check.ps1')
    $check = Test-ReleaseZip $ZipFile
    if (-not $check.ok) { throw $check.why }
    $zipInfo = $check.info
    if ($zipInfo.track -ne $info.track) { throw "$(Split-Path $ZipFile -Leaf) is a $($zipInfo.track) package, and this folder is a $($info.track) one: it isn't installed here." }
    if ($zipInfo.patch -le $info.patch -and -not $AllowOlder) { throw "$(Split-Path $ZipFile -Leaf) is $(Release-Label $zipInfo), and this folder is $(Release-Label $info) already." }
    $want = $Sha256
    $side = "$ZipFile.sha256"
    if (-not $want -and (Test-Path -LiteralPath $side)) { $want = ((Get-Content -LiteralPath $side -Raw) -split '\s+')[0] }
    if ($want) {
        $sha = (Get-FileHash -LiteralPath $ZipFile -Algorithm SHA256).Hash
        if ($sha -ne $want.Trim()) { throw "The zip's fingerprint (SHA-256) isn't the one in the post: the download is damaged. Download it again." }
        Say 'The fingerprint matches the post.'
    }
    Say "Updating to $(Release-Label $zipInfo) from $(Split-Path $ZipFile -Leaf)."
    $work = Join-Path $Base 'update-download'
    Remove-Ttt2Folder $work
    New-Item -ItemType Directory -Force $work | Out-Null
    Install-Zip $ZipFile $work
    $now = Read-PackageInfo
    Say "Updated to $(Release-Label $now). Start Here restarts and builds."
}

# Start Here's rescue (the lead's order of 24 Oct, B): a new folder with no build, and an earlier install with one. This
# package is copied over that install, as an update is (its saves, game files and build kept), so it only relinks: the
# game's build folder knows its own folder's path, and copied into a new folder it would be built again from nothing.
function Step-Adopt {
    if (-not $Into -or -not (Test-Path -LiteralPath (Join-Path $Into 'rex\setup-steps.ps1'))) { throw "$Into isn't a TTT2 Native install." }
    if ((Resolve-Path -LiteralPath $Into).Path -eq (Resolve-Path -LiteralPath $Repo).Path) { throw 'That is this folder.' }
    if (Test-Path -LiteralPath (Join-Path $Into '.git')) { throw "$Into is a git checkout: nothing is copied over it." }
    Say "Copying this package over your previous install, $Into (its saves, game files and build are kept)."
    foreach ($item in Get-ChildItem -LiteralPath $Repo -Force) {
        if ($NeverTouched -contains $item.Name -or $item.Name -eq '.git') { continue }
        $target = Join-Path $Into $item.Name
        if ($item.PSIsContainer) { New-Item -ItemType Directory -Force $target | Out-Null; Copy-Over $item.FullName $target $item.Name }
        else { Copy-Item -LiteralPath $item.FullName $target -Force }
    }
    Say "Your previous install has this package now. Its Start Here opens and builds."
}

# The SDK folders a Visual Studio-era package built (several GB), which the prebuilt package doesn't use.
function Get-OldSdkFolders {
    @(Get-ChildItem -LiteralPath $env:USERPROFILE -Directory -Filter 'rexsdk-playtest*' -ErrorAction SilentlyContinue)
}

function Step-Cleanup {
    if (-not $Prebuilt) { throw 'Only the prebuilt package removes the old SDK folders.' }
    foreach ($d in Get-OldSdkFolders) {
        Say "Removing the old SDK folder $($d.FullName)"
        Remove-Ttt2Folder $d.FullName
    }
    Say 'Old SDK folders: removed.'
}

# The tools and game files to another data folder (Start Here's "Where to put the tools and game files", the lead's E):
# each of toolchain\, tools\, game\ and update\ moved (the same drive: renamed; another: robocopy /MOVE, with the bar),
# then the folder recorded and every install's rex\game-folder.txt that pointed into the old game folder pointed at the
# new one. Run again after a stop, it carries on (robocopy merges into what is there).
function Step-Move {
    if (-not $From -or -not $To) { throw 'move needs -From and -To.' }
    $from = [IO.Path]::GetFullPath($From).TrimEnd('\'); $to = [IO.Path]::GetFullPath($To).TrimEnd('\')
    if ($from -eq $to) { Set-Ttt2DataFolder $to; Say "The tools and game files: $to"; return }
    if ($to.StartsWith("$from\", [StringComparison]::OrdinalIgnoreCase)) { throw "The new folder can't be inside the old one ($from)." }
    New-Item -ItemType Directory -Force $to | Out-Null
    $parts = @($script:Ttt2DataParts | Where-Object { Test-Path -LiteralPath (Join-Path $from $_) })
    $sameDrive = (Get-Ttt2DriveName $from) -eq (Get-Ttt2DriveName $to)
    if (-not $sameDrive) {
        $gb = ($parts | ForEach-Object { Get-Ttt2FolderGB (Join-Path $from $_) } | Measure-Object -Sum).Sum
        $free = Get-Ttt2FreeGB $to
        if ($free -ge 0 -and $free -lt $gb + 0.5) { throw ("Moving the tools and game files needs about {0:N1} GB on {1}, which has {2:N1} GB free." -f ($gb + 0.5), (Get-Ttt2DriveName $to), $free) }
    }
    foreach ($part in $parts) {
        $src = Join-Path $from $part; $dst = Join-Path $to $part
        if ($sameDrive -and -not (Test-Path -LiteralPath $dst)) { Say "Moving $part"; Move-Item -LiteralPath $src $dst; continue }
        $total = [math]::Max([double]1, (Get-Ttt2FolderGB $src) * 1GB)
        Say ("Moving {0} ({1:N1} GB) to {2}" -f $part, ($total / 1GB), $to)
        $out = Join-Path $Base 'move.out.txt'
        $p = Start-Process robocopy.exe -ArgumentList @("`"$src`"", "`"$dst`"", '/E', '/MOVE', '/R:5', '/W:3', '/NFL', '/NDL', '/NP', '/NJH') `
            -NoNewWindow -PassThru -RedirectStandardOutput $out
        $null = $p.Handle
        while (-not $p.HasExited) {
            $left = [double](Get-ChildItem -LiteralPath $src -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
            Write-Host ("PROGRESS {0} Moving {1}" -f [math]::Min(99, [int](100 * (1 - $left / $total))), $part)
            Start-Sleep -Seconds 2
        }
        $p.WaitForExit()
        if ($p.ExitCode -ge 8) {
            Get-Content -LiteralPath $out -ErrorAction SilentlyContinue | Where-Object { $_.Trim() } | Select-Object -Last 6 | ForEach-Object { Say "robocopy: $_" }
            throw "Moving $part to $to failed (robocopy $($p.ExitCode)). What was moved is in $dst; click Change again to carry on."
        }
        $null = Remove-Ttt2Folder $src -Quiet   # (robocopy leaves the emptied folders)
        Write-Host "PROGRESS 100 Moved $part"
    }
    Set-Ttt2DataFolder $to
    # (Every install Start Here knows, and this one: its game folder, when it was inside the old data folder.)
    $installs = @($Repo) + @(if (Test-Path -LiteralPath (Join-Path $Base 'installs.txt')) { Get-Content -LiteralPath (Join-Path $Base 'installs.txt') })
    foreach ($install in ($installs | Where-Object { $_ } | Select-Object -Unique)) {
        $gf = Join-Path $install 'rex\game-folder.txt'
        if (-not (Test-Path -LiteralPath $gf)) { continue }
        $was = "$(Get-Content -LiteralPath $gf -TotalCount 1)".Trim()
        foreach ($part in 'game', 'update') {
            $old = Join-Path $from $part
            if ($was -eq $old -or $was.StartsWith("$old\", [StringComparison]::OrdinalIgnoreCase)) {
                $now = (Join-Path $to $part) + $was.Substring($old.Length)
                Set-Content -LiteralPath $gf $now
                Say "$install's game folder: $now"
            }
        }
    }
    Say "The tools and game files: $to"
}

switch ($Step) {
    'move' { Step-Move }
    'cleanup' { Step-Cleanup }
    'tools'  { Step-Tools }
    'files'  { Step-Files }
    'build'  { Step-Build }
    'play'   { Step-Play }
    'switches' { Step-Switches }
    'status' { Step-Status }
    'update' { Step-Update }
    'update-file' { Step-UpdateFile }
    'adopt' { Step-Adopt }
}
