# Prepares TTT2's game files from your own copy of the game, for rex\build-windows.ps1 and
# rex\run-windows.ps1. You need:
#   - your game folder: the files from your Tekken Tag Tournament 2 disc (Xbox 360), with
#     default.xex and the data*.bin files;
#   - your title update package from your console (a file named like TU_174Q22P_...).
#
#   powershell -ExecutionPolicy Bypass -File rex\prepare-game.ps1
#
# It checks that both are the release this build was made for (title 4E4D0859, version 0.0.0.2
# updated to 0.0.3.2), extracts the update next to your game folder, builds a small tool from
# XenonRecomp's XEX code and applies the update to default.xex, giving default_tu.xex: once in
# gamedata\ (the build reads it) and once in your game folder (the game runs it).

param([string]$GameFolder = '', [string]$UpdatePackage = '')

$ErrorActionPreference = 'Stop'
$Rex = $PSScriptRoot
. (Join-Path $Rex 'tools\remove-folder.ps1')   # (Remove-Ttt2Folder: deletes through .NET, safe in a non-ASCII install folder)
$Repo = Split-Path -Parent $Rex

# Fingerprints (SHA-256) of the files this build was made from.
$Expected = @{
    'default.xex'     = 'E74E57DE3E205517E5447CACDBA68624544FBD313DDB8C5F174B8E3FF43283D8'
    'Default.xexp'    = 'C413FDFB2BA547E93FD16FA571C047F9914C5194526DDFA37C481AC84376F0E9'
    'data100.bin'     = '3C9CA28BEA95423DA1E2D667FEA941B620D33433E375E11A5782939C34B9FC4D'
    'data100.ofs'     = 'E2985F8A45D404CA525696EDD7CDF1DF7678EFCEE2AF1A9E78F3E7CDD6474FCE'
    'default_tu.xex'  = '5AB29622D2DFB123DCA5894E5A9D7F21DC88BB52367056830EDD09DFAF162146'
}
$XenonRecompUrl = 'https://github.com/hedge-dev/XenonRecomp.git'
$commitFile = Join-Path $Repo 'recomp\XENONRECOMP_COMMIT'   # (not in the prebuilt package: it ships xexpatch.exe)
$XenonRecompCommit = if (Test-Path -LiteralPath $commitFile) { (Get-Content -LiteralPath $commitFile -Raw).Trim() } else { '' }

function Step($text) { Write-Host ''; Write-Host "== $text" -ForegroundColor Cyan }
function Run {
    # Native tools write progress to stderr. Windows PowerShell turns that into errors when its own
    # output is redirected (as in the launcher's steps), which $ErrorActionPreference = 'Stop' makes
    # fatal; so stderr is passed through as plain text, and only the exit code decides.
    $saved = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { & $args[0] $args[1..($args.Count - 1)] 2>&1 | ForEach-Object { "$_" } }
    finally { $ErrorActionPreference = $saved }
    if ($LASTEXITCODE -ne 0) { throw "Failed ($LASTEXITCODE): $($args -join ' ')" }
}
function Check($path, $name) {
    $hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
    if ($hash -ne $Expected[$name]) {
        throw "$name is not the one this build was made for (SHA-256 $hash). It has to be the " +
              "same release of the game (same region and disc) and the title update 0.0.3.2."
    }
}

Step 'Your game folder'
$saved = Join-Path $Rex 'game-folder.txt'
$game = $GameFolder
if (-not $game -and (Test-Path -LiteralPath $saved)) { $game = (Get-Content -LiteralPath $saved -Raw).Trim() }
while (-not $game -or -not (Test-Path -LiteralPath (Join-Path $game 'default.xex'))) {
    if ($game) { Write-Host "No default.xex in $game" -ForegroundColor Yellow }
    # (Start Here's steps (TTT2_NO_PROMPT): no window to type in, so a prompt would wait for ever (4.5: an ISO named "...[RF].iso").)
    if ($env:TTT2_NO_PROMPT) { throw "No default.xex in the game folder ($(if ($game) { $game } else { 'none chosen' })). In Start Here, click 1. Choose my game + update again and pick your game: the ISO or the folder with default.xex and the data*.bin files." }
    $game = (Read-Host 'Path to your TTT2 game folder (the one with default.xex and data*.bin)').Trim().Trim('"')
}
Check (Join-Path $game 'default.xex') 'default.xex'
$archives = @(Get-ChildItem -LiteralPath $game -Filter 'data*.bin')
if ($archives.Count -lt 20) {
    throw "Only $($archives.Count) data*.bin files in ${game}. Copy all of them from your disc."
}
Set-Content -LiteralPath $saved -Value $game
Write-Host "OK: $game ($($archives.Count) data files)"

Step 'Python'
# The first that really runs: the launcher's own portable Python (TTT2_PYTHON), then python, then
# the py launcher. Each is tried, as a PC can have the py launcher with no Python behind it, or
# Windows' "python" that only opens the Store.
$candidates = @()
if ($env:TTT2_PYTHON -and (Test-Path -LiteralPath $env:TTT2_PYTHON)) { $candidates += , @($env:TTT2_PYTHON) }
if (Get-Command python -ErrorAction SilentlyContinue) { $candidates += , @('python') }
if (Get-Command py -ErrorAction SilentlyContinue) { $candidates += , @('py', '-3') }
$python = $null
foreach ($c in $candidates) {
    $saved = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { $version = & $c[0] @($c | Select-Object -Skip 1) --version 2>&1 | ForEach-Object { "$_" } } catch { $version = $null }
    finally { $ErrorActionPreference = $saved }
    if ($LASTEXITCODE -eq 0 -and "$version" -match 'Python 3\.') {
        $python = $c[0]; $pythonArgs = @($c | Select-Object -Skip 1)
        Write-Host "$version ($python)"
        break
    }
}
if (-not $python) { throw 'Python 3 not found. In Start Here, click Install again, or install Python from python.org (tick "Add python.exe to PATH").' }

Step 'Extracting your title update'
$package = $UpdatePackage
while (-not $package -or -not (Test-Path -LiteralPath $package -PathType Leaf)) {
    if ($package) { Write-Host "No file at $package" -ForegroundColor Yellow }
    if ($env:TTT2_NO_PROMPT) { throw "No title update file ($(if ($package) { $package } else { 'none chosen' })). In Start Here, click 1. Choose my game + update again and pick your title update package (a file named like TU_174Q22P_...)." }
    $package = (Read-Host 'Path to your title update package (a file named like TU_174Q22P_...)').Trim().Trim('"')
}
$extracted = Join-Path $Rex 'out\title-update'
Remove-Ttt2Folder $extracted   # (not Remove-Item: a non-ASCII install folder, 27 Oct)
Run $python @pythonArgs (Join-Path $Repo 'recomp\tools\stfs_extract.py') $package $extracted
foreach ($name in 'Default.xexp', 'data100.bin', 'data100.ofs') {
    if (-not (Test-Path -LiteralPath (Join-Path $extracted $name))) { throw "The package has no ${name}, so it isn't TTT2's title update." }
    Check (Join-Path $extracted $name) $name
}
# The game opens these as update:\ ; run-windows.ps1 looks for a folder "update" beside the game folder.
$update = Join-Path (Split-Path $game -Parent) 'update'
New-Item -ItemType Directory -Force $update | Out-Null
foreach ($name in 'Default.xexp', 'data100.bin', 'data100.ofs') {
    Copy-Item -LiteralPath (Join-Path $extracted $name) (Join-Path $update $name) -Force
}
Write-Host "OK: $update"

$prebuiltPackage = Test-Path -LiteralPath (Join-Path $Rex 'prebuilt\manifest.txt')
if ($prebuiltPackage) {
    # (The prebuilt package: no xexpatch.exe ships since the owner's G3 of 26 Oct (a player's Windows Defender
    # quarantined 4.2.1's, a new unsigned exe from the internet): it's built here from the package's source\xexpatch with
    # step 1's compiler, rex\tools\build-xexpatch.ps1, about 15 s. Never with Visual Studio. If it's gone after the build
    # or can't start, Defender took it, and the player is told how to get it back (the lead's G1).)
    . (Join-Path $Rex 'tools\package-check.ps1')
    . (Join-Path $Rex 'tools\toolchain.ps1')
    . (Join-Path $Rex 'tools\build-xexpatch.ps1')
    Step 'Building the update tool (XenonRecomp''s XEX patcher) with the installed compiler'
    $src = Join-Path $Repo 'source\xexpatch'
    if (-not (Test-Path -LiteralPath (Join-Path $src 'XenonRecomp\XenonUtils\xex_patcher.cpp'))) { throw "The package's source\xexpatch folder is incomplete. Unzip the package again." }
    try { Use-Ttt2Toolchain } catch { throw "The compiler isn't installed ($_). In Start Here, click Install again." }
    $tool = Join-Path $Rex 'out\xexpatch\xexpatch.exe'
    try { Compile-Xexpatch -XenonRecomp (Join-Path $src 'XenonRecomp') -XexpatchCpp (Join-Path $src 'xexpatch.cpp') -Work (Join-Path $Rex 'out\xexpatch') -Out $tool }
    catch { throw "Building the title update's tool failed: $_`nIn Start Here, click Install again." }
    if (-not (Test-Path -LiteralPath $tool)) { throw $XexpatchMissingNote }
    Write-Host "OK: $tool"
} else {
Step 'Finding Visual Studio and its Clang'
$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
if (-not (Test-Path -LiteralPath $vswhere)) { throw 'Visual Studio Installer not found.' }
# The newest Visual Studio with the C++ tools and CMake (with Ninja); else the newest with the
# C++ tools (a PC can have several, e.g. a Community without CMake and our Build Tools).
$vs = & $vswhere -latest -prerelease -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 Microsoft.VisualStudio.Component.VC.CMake.Project -property installationPath
if (-not $vs) { $vs = & $vswhere -latest -prerelease -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath }
if (-not $vs) { throw 'No Visual Studio with the C++ tools. Add "Desktop development with C++" in the Visual Studio Installer.' }
Import-Module (Join-Path $vs 'Common7\Tools\Microsoft.VisualStudio.DevShell.dll')
Enter-VsDevShell -VsInstallPath $vs -SkipAutomaticLocation -DevCmdArguments '-arch=x64 -host_arch=x64' | Out-Null
$llvm = Join-Path $vs 'VC\Tools\Llvm\x64\bin'
# Or the standalone LLVM the launcher fetched (TTT2_LLVM), when Visual Studio has no Clang of its own.
if (-not (Test-Path -LiteralPath (Join-Path $llvm 'clang-cl.exe')) -and $env:TTT2_LLVM -and (Test-Path -LiteralPath (Join-Path $env:TTT2_LLVM 'clang-cl.exe'))) {
    $llvm = $env:TTT2_LLVM
}
if (-not (Test-Path -LiteralPath (Join-Path $llvm 'clang-cl.exe'))) {
    throw 'Clang is missing. In the Visual Studio Installer, Modify, Individual components: tick "C++ Clang Compiler for Windows" and "MSBuild support for LLVM (clang-cl) toolset".'
}
$env:PATH = "$llvm;$env:PATH"

Step 'Building the update tool (XenonRecomp''s XEX patcher)'
$tools = Join-Path $env:USERPROFILE 'rexsdk\xexpatch'
$xr = Join-Path $tools 'XenonRecomp'
$tool = Join-Path $tools 'xexpatch.exe'
if (-not (Test-Path -LiteralPath $tool)) {
    if (-not (Test-Path -LiteralPath (Join-Path $xr 'XenonUtils\xex_patcher.cpp'))) {
        Remove-Ttt2Folder $xr
        New-Item -ItemType Directory -Force $xr | Out-Null
        Push-Location -LiteralPath $xr
        try {
            # Only the commit we use, and only the three libraries the patcher needs.
            Run git init -q
            Run git remote add origin $XenonRecompUrl
            Run git fetch -q --depth 1 origin $XenonRecompCommit
            Run git checkout -q FETCH_HEAD
            Run git submodule update -q --init --depth 1 thirdparty/libmspack thirdparty/tiny-AES-c thirdparty/simde
        } finally { Pop-Location }
    }
    $obj = Join-Path $tools 'obj'
    New-Item -ItemType Directory -Force $obj | Out-Null
    $u = Join-Path $xr 'XenonUtils'
    $t = Join-Path $xr 'thirdparty'
    $includes = @("/I$u", "/I$t\simde", "/I$t\libmspack\libmspack\mspack", "/I$t\tiny-AES-c", "/I$t\TinySHA1")
    $flags = @('/nologo', '/c', '/O2', '/MT', '/DNOMINMAX', '/D_CRT_SECURE_NO_WARNINGS')
    # Compiled in the obj folder, so no output paths have to be passed (a user folder may have spaces).
    Push-Location -LiteralPath $obj
    try {
        Run clang-cl @flags @includes "$t\libmspack\libmspack\mspack\lzxd.c" "$t\tiny-AES-c\aes.c"
        Run clang-cl @flags /EHsc /std:c++20 @includes "$u\xex_patcher.cpp" "$u\xex.cpp" "$u\image.cpp" `
            "$u\memory_mapped_file.cpp" (Join-Path $Repo 'recomp\tools\xexpatch.cpp')
        $objects = @(Get-ChildItem -LiteralPath $obj -Filter *.obj | ForEach-Object { $_.FullName })
        Run clang-cl /nologo /MT /Fexexpatch.exe @objects
        Move-Item -Force -LiteralPath (Join-Path $obj 'xexpatch.exe') $tool
    } finally { Pop-Location }
}
Write-Host "OK: $tool"
}

Step 'Applying the title update to default.xex'
$gamedata = Join-Path $Repo 'gamedata'
New-Item -ItemType Directory -Force $gamedata | Out-Null
$patched = Join-Path $gamedata 'default_tu.xex'
if ($prebuiltPackage) {
    # (Defender may also block it as it starts, or take it while it runs: the process doesn't start, or the file is gone.)
    try { Run $tool (Join-Path $game 'default.xex') (Join-Path $update 'Default.xexp') $patched }
    catch { if (-not (Test-Path -LiteralPath $tool) -or "$_" -notmatch '^Failed \(') { throw $XexpatchMissingNote }; throw }
} else {
    Run $tool (Join-Path $game 'default.xex') (Join-Path $update 'Default.xexp') $patched
}
Check $patched 'default_tu.xex'
Copy-Item -LiteralPath $patched (Join-Path $game 'default_tu.xex') -Force
Write-Host "OK: $patched, and a copy in $game"

Step 'Done'
Write-Host 'Next: build the game (the last part of Install; the first time takes a while), then start it:'
Write-Host '  powershell -ExecutionPolicy Bypass -File rex\build-windows.ps1'
Write-Host '  powershell -ExecutionPolicy Bypass -File rex\run-windows.ps1'
