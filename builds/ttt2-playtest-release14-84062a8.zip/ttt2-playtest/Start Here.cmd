@echo off
rem Opens the TTT2 launcher window. Its PowerShell runs in a console of its own, started minimized (4.5.1: in 4.5 the
rem launcher hid its console through the Windows API, a pattern antivirus models weigh), so the console waits on the
rem taskbar while Start Here is open; a start that fails opens its error in Notepad.
if exist "%~dp0rex\launcher.ps1" goto found
echo.
echo   Start Here can't find rex\launcher.ps1 beside it.
echo   Unzip the WHOLE zip into a folder first (right-click the zip, Extract All),
echo   then run Start Here.cmd from that folder, not from inside the zip.
echo.
pause
exit /b 1
:found
if /i "%~1"=="/run" goto run
start "TTT2 Start Here" /min "%ComSpec%" /c ""%~f0" /run"
exit /b 0
:run
rem (Each run's errors in a file of its own: an open Start Here holds its file, 4.5.1. Kept as start-here-error.txt on a failure.)
set "TTT2LOGS=%LOCALAPPDATA%\TTT2Native\logs"
if not exist "%TTT2LOGS%" mkdir "%TTT2LOGS%"
set "TTT2RUN=%TTT2LOGS%\start-here-run-%RANDOM%%RANDOM%.txt"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0rex\launcher.ps1" 2> "%TTT2RUN%"
if not errorlevel 1 (
  del "%TTT2RUN%" 2>nul
  exit /b 0
)
set "TTT2ERR=%TTT2LOGS%\start-here-error.txt"
copy /y "%TTT2RUN%" "%TTT2ERR%" >nul
del "%TTT2RUN%" 2>nul
>> "%TTT2ERR%" echo.
>> "%TTT2ERR%" echo Start Here couldn't open. Send a screenshot of this to the Discord.
start "" notepad "%TTT2ERR%"
exit /b 1
