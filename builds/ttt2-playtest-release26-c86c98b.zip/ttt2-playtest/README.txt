TTT2 Native: play test
======================

This is Tekken Tag Tournament 2 for the Xbox 360, running natively on Windows, with less input lag than
the console. The package holds no game files. Your PC translates the game's code from your own copy of
TTT2 and links it with our code, which comes prebuilt. You don't need Visual Studio or Git: BlueSpark
downloads a compiler for you.

What's changed: see CHANGELOG.txt.


Getting started
---------------

1. Unzip this package to a short path, for example C:\ttt2.
2. Double-click BlueSpark.exe. A window opens with the setup pages (INSTALL, UPDATE, REPAIR, UNINSTALL, UPDATE FROM A FILE,
   MOVE DATA FOLDER). Once the game runs, BlueSpark's Settings tab in it has the display choice and the options.
3. Click INSTALL. A page asks for your files (see "Getting your game files" below):
   - CHOOSE ISO, your TTT2 disc image, or CHOOSE FOLDER, the folder with your extracted game (default.xex inside).
   - CHOOSE FILE, your title update file. If it isn't the title update, BlueSpark says so and you pick again.
   - CHANGE, if the tools and game files (about 13 GB) should go to another drive.
   When your picks say "This looks right.", click CONTINUE. Nothing is installed before that. INSTALL then does
   three parts, one after the other, and says which one it's on:
   - the tools: it downloads a compiler (about 1.3 GB, a few minutes on a fast connection). It asks
     you to accept Microsoft's license for their C++ libraries first. If Windows asks to install the
     Visual C++ runtime, click Yes.
   - the game files: your game is copied or extracted (about 8 GB).
   - the build: your PC translates and compiles the game's code. The first time it takes about 3 to
     5 minutes on a recent PC, more on an older one or with other programs open; later builds are quicker.
   If a part fails, INSTALL stops and says why. Fix it, then click INSTALL again: it goes on from
   that part. The parts already done are skipped.
4. Click START THE GAME.

Next time, double-click BlueSpark.exe: with the game installed and current it starts the game at once (otherwise START THE
GAME is on the page that opens). After an update, BlueSpark runs what INSTALL has left (usually the build) by itself.

If something fails, the window says why, and SHOW DETAILS shows more. Settings > Help > open the log folder shows
where the logs are. Send them to the friend who gave you this (see "Report a problem" below).


What you need
-------------

- Windows 10 or 11, 64-bit, with a DirectX 12 graphics card.
- Your own TTT2 game files: default.xex and all the data*.bin files from your Xbox 360 disc, in one
   folder, or an image of the disc.
- Your title update: the game's update file from your Xbox 360, named like
   TU_174Q22P_0000008000000.00000000000O2 (about 3 MB).
- About 7 GB of free disk space for the compiler and the build, plus your game files.
- A controller or a keyboard. Xbox and PlayStation controllers work, and so do most other pads, fight
   sticks and adapters. See "Controllers" and "Playing on a keyboard" below.

Your game files must be the release this build was made for: title 4E4D0859 with update 0.0.3.2. INSTALL
checks this (the game files part) and stops if they don't match.

If your antivirus removes TTT2's files (BlueSpark then says some are missing), restore them in Windows
Security, Protection history. If it keeps happening, you can add this folder and the data folder BlueSpark
set up (MOVE DATA FOLDER shows where it is; Settings > Storage shows how big each part is) to Windows Security's exclusions.


Getting your game files
-----------------------

From an image of your disc

You can extract a disc image with extract-xiso:

1. Download it from https://github.com/XboxDev/extract-xiso/releases and unzip it, for example to
   C:\tools\extract-xiso.
2. In PowerShell, run:
   C:\tools\extract-xiso\extract-xiso.exe -x "C:\path\to\TTT2.iso" -d C:\games\ttt2
3. C:\games\ttt2 now holds default.xex and the data*.bin files. That's your game folder.

If extract-xiso can't read your image, a program with a window, such as Xbox 360 ISO Extract, does the
same job. You need an image of your own disc. Most PC drives can't read Xbox 360 discs, so it's usually
made with a modified console or drive.

The title update

The update is on your Xbox 360's hard drive, in Content\0000000000000000\4E4D0859\000B0000\. The
console's menus can't copy it, so read the drive on a PC with a tool like FATXplorer and copy the file
out. Your console has it if you ever played TTT2 online.


Playing
-------

- EXIT GAME, the last entry of the main menu, closes the game.
- The first start makes a new save with every character, stage and item unlocked.
- No intro: after the splash the game goes straight to the main menu. Turn off Settings > Game > skip the intro for the game's own
   logos, opening movie and PRESS START. The controller you press a button on while it loads is player 1.
- BlueSpark asks for your name the first time you play. Settings > Profile > name changes it (it applies at the next start).


BlueSpark's pages
-----------------

BlueSpark is the game itself, with its pages over the game's main menu (RANKED, LOBBY, TRAINING, REPLAYS and LEADERBOARD
tabs at the top). Settings > Game > open on chooses whether the game starts on BlueSpark's pages or on its own menu; Select
switches between them while you play.

Players match each other in Quick Match, Ranked and lobbies, and your account, rating and saves are the same
whichever page you start on. Both players just need the same release.

- A search keeps going while you play Practice. From Practice the match is offered over your paused fight: decline,
  or let it run out, and the same fight carries on; accept, and it connects.
- From the home page it connects ahead, while it asks you to accept, so the fight comes sooner.
- An accepted match goes straight to the fight, without the game's own online menus.
- Run one game at a time: it is the same game, profile, saves, settings and keys however you start it.
- Its pages use the Libre Franklin typeface (rex\assets\bluespark\). See THIRD_PARTY_NOTICES.txt.
- If you used an earlier release's separate BlueSpark window: that app is gone, and the update removes
  its files from fastclient\. Anything else you put in that folder stays.


Your profile and saves
----------------------

Your profile is your online identity, your saves and your name. It lives in
%LOCALAPPDATA%\TTT2Native\profile, outside the game folder. A new build or a deleted game folder doesn't
lose it. The first time you play this build, your profile is copied there from the game folder. Older
builds still find their own copy.

To move to a new PC, close the game on both PCs and copy the whole %LOCALAPPDATA%\TTT2Native\profile
folder, with its live folder. live\identity.txt, identity.key and identity.reg are your Ranked account:
copying only your save gives you a new account with a new rating. Settings > Profile has "back up my
profile", which puts that folder in a zip on your desktop. Keep identity.key private: anyone who has it can
play as you.


Display
-------

Settings > Display > screen mode has these choices:

- Borderless fullscreen, the default.
- Fullscreen. The game takes the display over in its own mode.
- Windowed 1280x720 or 1920x1080, and bigger sizes if your monitor has room. The game draws at 1280x720,
   as on the console, and scales up to the window.

F11 or Alt+Enter switches fullscreen on and off while you play.

Settings > Display > VSync: turn it off (tearing allowed) to show each frame the moment it's ready. You get about
3 ms less lag, but a tear line can move across the screen. Turn it on if you see tearing.

For the lowest lag, play fullscreen on a 60 Hz display with nothing drawn over the game.


Online
------

Online play is on by default. To play offline, with no internet, turn off Settings > Game > online play
(it applies at the next start).

- Everyone playing online needs this build. Players on different builds are never matched.
- Ranked Match plays sets, first to 2 games. Your rating changes once per set, and leaving between games
   loses the set.
- To fight the same opponent again: REMATCH on Quick Match's results menu, or the 10-second vote after a
   lobby fight.
- The first time you play online, Windows asks if TTT2 may use the network. Allow it.
- Online matches connect your PC directly to your opponent's, so their PC can see your public IP address. If
   a direct connection can't be made, the match goes through a relay and neither side sees the other's address.
- When you host a lobby, your name and its invite code are listed on a board every online player can read, so
   others can find your game. The invite code contains your public IP address.
- Online play needs an IPv4 internet connection. Networks with IPv6 only can't play online yet (most home
   networks have both).


What we receive from you
------------------------

Settings > Privacy has the switches for what the game sends us:

- Send crash logs (on by default). If the game crashed or froze, its log goes to our server the next time you start it.
- Send each online fight's log (off by default). It helps us find problems in online matches.
- Upload replays (on by default). Your online fights' replays are kept on the server so you can watch them later.

We take IP addresses, invite codes and your Windows user name out of each log before it's sent. Turn a
switch off to stop sending that kind of data. The details are in our privacy note, PRIVACY, in the server's repository:
https://github.com/Themail2/ttt2-server


Updates
-------

To update:

1. Download the new zip from the Discord post. Don't unzip it yourself.
2. Open BlueSpark.exe.
3. Click UPDATE FROM A FILE and pick the zip.

BlueSpark checks that the zip is an official TTT2 playtest package, puts it over this folder and relinks the
game, which takes a minute or two. Your saves, game files and settings stay. You don't need the zip when the game
updates itself: BlueSpark offers a new release when it starts (UPDATE), and Settings > Help > check for updates reads the feed.

If you unzipped a new build into a new folder by mistake, open its BlueSpark.exe: it offers to use your previous
install instead, so you don't have to build again. It only knows installs from Release 4.1 on.

Coming from Release 4 or older (once): the older versions can't take an update file. Unzip Release 4.1 into the
same folder as your old install, over it, and click INSTALL in BlueSpark.exe: your saves and game files stay, so it
skips the game files and only builds. If you unzip it into a new folder instead, choose your game again too.

An update waits until you close the game.


Controllers
-----------

- Xbox controllers work right away, and so do most fight sticks in Xbox or PC mode.
- PlayStation 4 controllers work right away. PlayStation 5 and Switch Pro controllers should too.
- Other pads, sticks and adapters work once the game knows their button layout. The package includes a
   community list of about 870 layouts, so most work right away.
- If yours isn't in the list, or a button is wrong, make a mapping line for it with a tool like SDL2
   Gamepad Tool. Put the line in rex\userdata\my-controllers.txt, one line per controller. Updates leave
   that file alone.
- A press shorter than a frame still counts.
- A cable is a little faster than Bluetooth.
- The first controller you press a button on is player 1.
- Vibration is off. Turn on Settings > Controls > vibration to feel it.


Playing on a keyboard
---------------------

The keyboard is player 1 while Settings > Controls > keyboard is on. It's on by default. Settings > Controls > "keyboard plays as" can make it player 2, two players on one keyboard (arrows and the numpad for player 2), or give each separate keyboard its own player.
The keyboard works with or without a controller. With a controller plugged in, both drive player 1, and
a second controller is player 2. The game window must be in front for the keys to reach it.

The keys are Tekken's PC layout:

   W A S D           up, back, down, forward
   U I J K           1 2 3 4
   P                 Tag
   O                 Tag as well (the game's layout has two Tag buttons)
   ; and L           RT and LT. In Practice, V + ; remembers a position and V + L goes back to it.
   Return, Escape    Start
   V, Tab            Select. In Practice, V + J restarts and V + O rewinds.
   N and M           R3 and L3

Holding left and right together counts as neither, and so do up and down, as in Tekken 8. S + A + D
still crouches.

1 2 3 4 and Tag follow Controller Setup. If you change the layout there, the keyboard follows it.

To change a key, use Controller Setup (below), or open rex\userdata\keyboard.txt in Notepad. The game
writes it the first time it runs with the keyboard on. Each line is an action and its keys, for example "1 = Shift" or
"1+2 = Space". Any key works, including Shift, Ctrl and Alt. Save the file and start the game again.
Delete the file to get the keys above back. Updates never change it.


Controller Setup
----------------

Controller Setup opens our own page in place of the game's: from Options on the main menu, from the pause
menu in a fight or in Practice, and from Fight Lab. Online fights keep the game's own screen.

The left half is the controller. Each row is an action (1, 2, 3, 4, Tag and the combinations, 1+2+3+4 too)
with the buttons it's on. Press A on a row, then press the button you want for it within 5 seconds. Start clears
the row and Select cancels. LB and RB switch between player 1 and player 2. TYPE A, B and C are the game's
presets. Restore Default and Undo Changes are at the bottom, and Confirm and Exit saves.

The right half is the keyboard (player 1): every pad button and action, RB included. Press A on a line,
then press the key. Any key works, including Shift and Ctrl. Escape cancels and Backspace leaves the line
with no key. A key you give to one line comes off any other line it was on. When you leave the page, it
asks whether to save the keyboard's changes.

Left and right move between the two halves. B saves the controller's changes and closes the page.


About the input lag
-------------------

Two delays are gone:

- The game's own input delay. The original game holds every press back 2 frames (33 ms) before your
   fighter acts on it, on the console too. Here it acts on the next frame.
- The runtime's delays. From the game reading your controller to the frame on screen takes about 29 ms
   here, against about 45 ms before our changes.

Your display and controller add their own lag on top.


Play (old renderer)
-------------------

If the game shows a black window, or the new graphics give you trouble, double-click Play (old renderer): it starts the game with the old renderer, and the next start stays on it until you pick the native renderer again in Settings > Graphics > renderer.


Report a problem
----------------

For a crash, a freeze, a failed build or anything else, double-click Report a problem. Settings > Help > report a problem, and the REPORT button of a failed setup, do the same. It doesn't start the game or change anything. It puts one zip on your Desktop,
named ttt2-problem-report-....zip. Send it to the friend who gave you this, with a few words about what
went wrong. Make it right after the problem, before you play again.

If the picture freezes and the game stops drawing, restart it; it comes back on the old renderer.

The zip holds the game's newest 3 logs, any crash dumps and freeze reports from the last two weeks, BlueSpark's
logs, the build's version, your display choice, and your PC's parts (Windows, processor, memory,
graphics card and driver, monitors).

It never holds your identity or its key, your saves, your replays, or anything else from your user data.


If the sound is wrong
---------------------

For crackling, music that stops or anything else you hear, double-click Report a sound problem. It starts
the game with sound recording on.

1. Play until you hear the problem.
2. Each time you hear it, press F9, or click both sticks in on your controller.
3. A few seconds later, close the game and answer the four short questions.

Two zips appear on your Desktop: a small report and the sound clips around each F9 press. Send both to the
friend who gave you this. Keep the session under ten minutes: the recording uses about 200 MB of disk a
minute.


If something goes wrong
-----------------------

- INSTALL says a file "is not the one this build was made for". Your disc or update is a different region
   or version. This build only works with the release it was made for.
- The build fails with a very long path. Unzip the package to a short path like C:\ttt2.

If you're stuck, send the friend who gave you this the zip from Report a problem.


Doing it by hand
----------------

BlueSpark's setup steps are PowerShell scripts you can run yourself, from the package folder, after INSTALL's
tools part has run once:

1. Prepare your game files. It asks for your game folder and your title update, checks them and applies
   the update:
   powershell -ExecutionPolicy Bypass -File rex\prepare-game.ps1
2. Build the game:
   powershell -ExecutionPolicy Bypass -File rex\build-windows.ps1
3. Play:
   powershell -ExecutionPolicy Bypass -File rex\run-windows.ps1


Licenses
--------

THIRD_PARTY_NOTICES.txt lists the open-source parts of our prebuilt code. SOURCE_OFFER.txt and the source
folder give the source of its GPL and LGPL parts.
