Step 2 of BlueSpark fills this folder from your own game files.
