# The steps behind the TTT2 launcher (rex\launcher.ps1), one per call:
#   setup-steps.ps1 -Step tools                      install what the build needs
#   setup-steps.ps1 -Step files -Source <iso or folder> -Update <title update file>
#   setup-steps.ps1 -Step build
#   setup-steps.ps1 -Step play
#   setup-steps.ps1 -Step status                     what is done (one line each)
#   setup-steps.ps1 -Step cleanup                    the prebuilt package: delete the old SDK folders
#   setup-steps.ps1 -Step move -From <folder> -To <folder>   the tools and game files to another data folder
# Everything it downloads goes to the data folder (rex\tools\data-folder.ps1: %LOCALAPPDATA%\TTT2Native unless Start
# Here's "Where to put the tools and game files" says another; the lead's E, 27 Oct). Only installing Visual Studio's
# compiler asks Windows for permission (one prompt).
#
# The prebuilt package (rex\prebuilt\manifest.txt; docs/PREBUILT_PACKAGE_PLAN.md): the tools are the pinned portable
# compiler (rex\tools\toolchain.ps1; Microsoft's part only with -AcceptMicrosoftLicense, the launcher's license screen),
# the VC++ runtime (its one Windows prompt) and Python; no Git, no Visual Studio.

param(
    [Parameter(Mandatory)][ValidateSet('tools', 'files', 'build', 'play', 'switches', 'status', 'update', 'update-file', 'adopt', 'cleanup', 'oldsdk', 'move', 'pick', 'launchcheck', 'adoptfind', 'handover')][string]$Step,
    [string]$From = '',       # move: the data folder the tools and game files are in now
    [string]$To = '',         # move: the data folder they go to
    [string]$ZipFile = '',    # update-file: a release zip the player dropped onto Start Here's window
    [string]$Sha256 = '',     # update-file: the zip's SHA-256 if the player has it (else <zip>.sha256 beside it, if there)
    [switch]$AllowOlder,      # update-file: an older or the same release, the player having said yes
    [string]$Into = '',       # adopt: the previous install folder this package is copied over (Start Here's rescue)
    [switch]$AcceptMicrosoftLicense,   # tools: the player accepted Microsoft's license in Start Here
    [string]$Source = '',
    [string]$Update = '',
    [switch]$Commit,          # pick: keep the picks (game-source, game-update, the data folder) as Start Here's Choose does
    [switch]$BlueSpark,       # play: the same game with BlueSpark's pages (Start Here's Play BlueSpark)
    [switch]$Offline,         # play: without the online switches (Start Here's "Play offline (no internet)")
    [string]$UpdateUrl = '',   # update: the feed (a URL, or a local folder holding latest.json and the zip)
    [int]$Patch = 0             # update: the patch number the launcher saw in the feed
)

$ErrorActionPreference = 'Stop'
# (No script these steps run may ask on the console: there is none to answer it. 4.5.)
$env:TTT2_NO_PROMPT = '1'
$ProgressPreference = 'SilentlyContinue'   # Invoke-WebRequest is many times slower with its progress bar
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Rex = $PSScriptRoot
. (Join-Path $Rex 'tools\remove-folder.ps1')   # (Remove-Ttt2Folder: deletes through .NET, safe in a non-ASCII install folder)
$Repo = Split-Path -Parent $Rex
$Base = Join-Path $env:LOCALAPPDATA 'TTT2Native'   # (the steps' markers, logs, the profile: always here)
. (Join-Path $Rex 'tools\data-folder.ps1')
$Data = Get-Ttt2DataFolder                          # (the tools and the game files: here, or where the player chose)
$Tools = Join-Path $Data 'tools'
$PinnedLlvm = 'https://github.com/llvm/llvm-project/releases/download/llvmorg-20.1.8/clang+llvm-20.1.8-x86_64-pc-windows-msvc.tar.xz'
if ($Step -notin 'status', 'move', 'launchcheck', 'adoptfind', 'handover') { New-Item -ItemType Directory -Force $Tools | Out-Null }
$Prebuilt = Test-Path -LiteralPath (Join-Path $Rex 'prebuilt\manifest.txt')
if ($Prebuilt) { . (Join-Path $Rex 'tools\toolchain.ps1') }
# A package with the online code: the marker (the prebuilt package has no rex\src), or the sources (dev).
$HasOnline = (Test-Path -LiteralPath (Join-Path $Rex 'online-build.txt')) -or (Test-Path -LiteralPath (Join-Path $Rex 'src\online'))

function Run {
    # Native tools write progress to stderr. Windows PowerShell turns that into errors when its own
    # output is redirected (as in the launcher's steps), which $ErrorActionPreference = 'Stop' makes
    # fatal; so stderr is passed through as plain text, and only the exit code decides.
    $saved = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { & $args[0] $args[1..($args.Count - 1)] 2>&1 | ForEach-Object { "$_" } }
    finally { $ErrorActionPreference = $saved }
    if ($LASTEXITCODE -ne 0) { throw "Failed ($LASTEXITCODE): $($args -join ' ')" }
}

function Say($text) { Write-Host "[$(Get-Date -Format HH:mm:ss)] $text" }

# The download of the latest release's first file matching the first pattern that matches any. Through GitHub's API
# (api.github.com): the developer's source path only (MinGit, LLVM). A player's steps use pinned URLs (report 115937,
# 27 Oct: api.github.com didn't resolve on a player's PC, a DNS filter, while raw.githubusercontent.com did).
function Latest-Asset($repo, [string[]]$patterns) {
    $release = Invoke-RestMethod "https://api.github.com/repos/$repo/releases/latest" -Headers @{ 'User-Agent' = 'ttt2-launcher' }
    foreach ($pattern in $patterns) {
        $asset = $release.assets | Where-Object { $_.name -match $pattern } | Select-Object -First 1
        if ($asset) { return $asset.browser_download_url }
    }
    throw "No download matching $($patterns -join ' or ') in $repo's latest release."
}

# A download, its SHA-256 checked when one is given. A failure to reach the host is said plainly (Get-Ttt2NetProblem):
# the host, and what to try; -ByHand: where its file can be put by hand instead.
function Download($url, $file, [string]$Sha256 = '', [string]$ByHand = '') {
    Say "Downloading $(Split-Path $url -Leaf)"
    try { Invoke-WebRequest $url -OutFile $file -UseBasicParsing }
    catch { throw (Get-Ttt2NetProblem $url $_.Exception $ByHand) }
    if ($Sha256) {
        $got = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
        if ($got -ne $Sha256.ToUpper()) {
            Remove-Item -LiteralPath $file -Force
            throw "The download of $url isn't the expected file (its SHA-256 is $got, not $($Sha256.ToUpper())): not used. Something between this PC and the internet changed it, or the download broke: try again later.$(if ($ByHand) { " $ByHand" })"
        }
    }
}

# extract-xiso, pinned like the compiler (no GitHub API call; report 115937): its release asset and SHA-256 (the release of
# 11 Sep 2026, checked on 27 Oct: GitHub's digest and a download agree). The Windows 64-bit release build (the debug one
# can need Visual Studio's debug libraries). $env:TTT2_TEST_XISO_URL / _SHA256: test only, another URL or hash.
$ExtractXisoUrl = 'https://github.com/XboxDev/extract-xiso/releases/download/build-202609111233/extract-xiso-Win64_Release.zip'
$ExtractXisoSha256 = 'fc891dfa72f08e3838a2f8b7ec34a8e4d61678da1cc8fee879677f00bf114ce3'
if ($env:TTT2_TEST_XISO_URL) { $ExtractXisoUrl = $env:TTT2_TEST_XISO_URL }
if ($env:TTT2_TEST_XISO_SHA256) { $ExtractXisoSha256 = $env:TTT2_TEST_XISO_SHA256 }

function Find-VisualStudio {
    $vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
    if (-not (Test-Path -LiteralPath $vswhere)) { return $null }
    # The newest Visual Studio with the C++ tools and CMake (with Ninja); else the newest with the
    # C++ tools (a PC can have several, e.g. a Community without CMake and our Build Tools).
    $found = & $vswhere -latest -prerelease -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 Microsoft.VisualStudio.Component.VC.CMake.Project -property installationPath
    if (-not $found) { $found = & $vswhere -latest -prerelease -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath }
    return $found
}

function Clang-Major($bin) {
    $clang = Join-Path $bin 'clang.exe'
    if (-not (Test-Path -LiteralPath $clang)) { return 0 }
    if ((& $clang --version | Select-Object -First 1) -match 'version (\d+)\.') { return [int]$Matches[1] }
    return 0
}

# The tools this machine has from earlier runs, put on PATH for this process and its children.
function Use-Tools {
    $git = Join-Path $Tools 'mingit\cmd'
    $python = Join-Path $Tools 'python'
    $llvm = Join-Path $Tools 'llvm\bin'
    foreach ($dir in $git, $python) { if (Test-Path -LiteralPath $dir) { $env:PATH = "$dir;$env:PATH" } }
    if (Test-Path -LiteralPath (Join-Path $python 'python.exe')) { $env:TTT2_PYTHON = Join-Path $python 'python.exe' }
    if (Test-Path -LiteralPath (Join-Path $llvm 'clang.exe')) { $env:TTT2_LLVM = $llvm }
}

function Step-ToolsPrebuilt {
    Say "The tools go in $Data"
    # (24 Nov, Task 7, the lead: a fresh 5.0 install downloaded about 1.1 GB and then failed at toolchain.ps1's "Microsoft's license accepted first", its license page skipped. Microsoft's part is checked
    # first now: needed and not accepted stops here, before any download. TTT2_SETUP_LICENSE_GUARD=0 is the kill switch.)
    if ($env:TTT2_SETUP_LICENSE_GUARD -ne '0' -and -not $AcceptMicrosoftLicense) {
        if (-not (Test-Ttt2MsvcLayout (Join-Path (Get-Ttt2ToolchainRoot) $script:Ttt2MsvcFolder))) {
            throw "Microsoft's C++ runtime and Windows SDK need Microsoft's license accepted first. Nothing was downloaded: open Setup again and accept the license on its page, then click Install."
        }
    }
    # (The lead's E: the drive's free space before anything is downloaded; what is already there counts as taken.)
    $root = Get-Ttt2ToolchainRoot
    if (-not (Test-Path -LiteralPath (Join-Path (Get-Ttt2PinFolder $root $script:Ttt2ToolchainPins.llvm) 'ttt2-unpacked.txt'))) {
        if ($problem = Get-Ttt2SpaceProblem 1 $Data (Get-Ttt2FolderGB $root)) {
            throw "$problem Free some space on that drive, or choose another folder for the tools and game files (Change...), then click Install again."
        }
    }
    # Python (portable), for reading the title update package.
    if (-not (Test-Path -LiteralPath (Join-Path $Tools 'python\python.exe'))) {
        $zip = Join-Path $Tools 'python.zip'
        Download 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-embed-amd64.zip' $zip
        Expand-Archive -LiteralPath $zip (Join-Path $Tools 'python') -Force
        Remove-Item -LiteralPath $zip
    }
    Say 'Python: ready'
    # The compiler: LLVM, CMake and Ninja (about 1 GB), and Microsoft's C++ runtime and Windows SDK (from Microsoft,
    # about 85 MB), each checked against its pinned SHA-256.
    Say 'The compiler: downloading what is missing (about 1.1 GB the first time; unpacked, about 5 GB).'
    Install-Ttt2Toolchain -AcceptMicrosoftLicense:$AcceptMicrosoftLicense
    Install-Ttt2VcRuntime (Join-Path (Get-Ttt2ToolchainRoot) 'downloads')
    Use-Tools
    # (The pins in the marker: a Visual Studio-era tools.done doesn't count for this package.)
    $null = New-Item -ItemType Directory -Force -Path $Base
    Set-Content -LiteralPath (Join-Path $Base 'tools.done') "prebuilt $(Get-Ttt2ToolchainPinText) $(Get-Date -Format s)"
    Say 'Tools: all ready.'
}

function Step-Tools {
    if ($Prebuilt) { Step-ToolsPrebuilt; return }
    # Git (portable, no installer), for downloading the runtime's source.
    if (-not (Get-Command git -ErrorAction SilentlyContinue) -and -not (Test-Path -LiteralPath (Join-Path $Tools 'mingit\cmd\git.exe'))) {
        $zip = Join-Path $Tools 'mingit.zip'
        Download (Latest-Asset 'git-for-windows/git' '^MinGit-[\d.]+-64-bit\.zip$') $zip
        Expand-Archive -LiteralPath $zip (Join-Path $Tools 'mingit') -Force
        Remove-Item -LiteralPath $zip
    }
    Say 'Git: ready'

    # Python (portable), for reading the title update package.
    if (-not (Test-Path -LiteralPath (Join-Path $Tools 'python\python.exe'))) {
        $zip = Join-Path $Tools 'python.zip'
        Download 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-embed-amd64.zip' $zip
        Expand-Archive -LiteralPath $zip (Join-Path $Tools 'python') -Force
        Remove-Item -LiteralPath $zip
    }
    Say 'Python: ready'

    # Visual Studio's C++ build tools with CMake, Ninja and Clang (one Windows permission prompt).
    $vs = Find-VisualStudio
    $hasClang = $vs -and (Test-Path -LiteralPath (Join-Path $vs 'VC\Tools\Llvm\x64\bin\clang.exe')) -and
                (Test-Path -LiteralPath (Join-Path $vs 'Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe'))
    if (-not $hasClang) {
        $installer = Join-Path $Tools 'vs_BuildTools.exe'
        Download 'https://aka.ms/vs/17/release/vs_BuildTools.exe' $installer
        Say 'Installing Visual Studio''s C++ build tools. Windows will ask for permission. This takes a while (often 15 to 40 minutes); the window may look idle meanwhile.'
        $arguments = @('--quiet', '--wait', '--norestart', '--nocache',
            '--add', 'Microsoft.VisualStudio.Workload.VCTools',
            '--add', 'Microsoft.VisualStudio.Component.VC.Tools.x86.x64',
            '--add', 'Microsoft.VisualStudio.Component.Windows11SDK.22621',
            '--add', 'Microsoft.VisualStudio.Component.VC.CMake.Project',
            '--add', 'Microsoft.VisualStudio.Component.VC.Llvm.Clang',
            '--add', 'Microsoft.VisualStudio.Component.VC.Llvm.ClangToolset')
        $p = Start-Process $installer -ArgumentList $arguments -Verb RunAs -Wait -PassThru
        if ($p.ExitCode -ne 0 -and $p.ExitCode -ne 3010) { throw "The Visual Studio installer stopped with code $($p.ExitCode)." }
        $vs = Find-VisualStudio
        if (-not $vs) { throw 'Visual Studio''s build tools did not install.' }
    }
    Say "Visual Studio: $vs"

    # The build needs Clang 20 or newer; if Visual Studio's is older, a standalone LLVM.
    $vsClang = Clang-Major (Join-Path $vs 'VC\Tools\Llvm\x64\bin')
    if ($vsClang -lt 20 -and (Clang-Major (Join-Path $Tools 'llvm\bin')) -lt 20) {
        Say "Visual Studio's Clang is version $vsClang; getting a newer one (about 1 GB)."
        $archive = Join-Path $Tools 'llvm.tar.xz'
        # Clang 20, the version the game is built with; the newest only if that download fails.
        try { Download $PinnedLlvm $archive }
        catch {
            Say "Clang 20's download failed ($($_.Exception.Message)); taking the newest instead."
            Download (Latest-Asset 'llvm/llvm-project' '^clang\+llvm-[\d.]+-x86_64-pc-windows-msvc\.tar\.xz$') $archive
        }
        $unpack = Join-Path $Tools 'llvm-unpack'
        Remove-Ttt2Folder $unpack
        New-Item -ItemType Directory -Force $unpack | Out-Null
        # Unpacked with the portable Python (Windows' own tar can't always read .xz).
        Run (Join-Path $Tools 'python\python.exe') -c "import sys, tarfile; tarfile.open(sys.argv[1]).extractall(sys.argv[2])" $archive $unpack
        $root = Get-ChildItem -LiteralPath $unpack -Directory | Select-Object -First 1
        $target = Join-Path $Tools 'llvm'
        Remove-Ttt2Folder $target
        Move-Item -LiteralPath $root.FullName $target
        Remove-Ttt2Folder $unpack, $archive
    }
    Use-Tools
    Say "Clang: version $([math]::Max($vsClang, (Clang-Major (Join-Path $Tools 'llvm\bin'))))"
    $null = New-Item -ItemType Directory -Force -Path $Base
    Set-Content -LiteralPath (Join-Path $Base 'tools.done') (Get-Date -Format s)
    Say 'Tools: all ready.'
}

# What is wrong with the file picked as the title update, or $null: a friend picked the ISO again in the second
# dialog (23 Oct), which cost a whole ISO extraction before the update was read. Start Here checks the same.
function Get-UpdateFileProblem([string]$update, [string]$source) {
    if (-not (Test-Path -LiteralPath $update -PathType Leaf)) { return 'Choose your title update file (named like TU_174Q22P_...).' }
    $full = [IO.Path]::GetFullPath($update)
    if (($source -and $full -eq [IO.Path]::GetFullPath($source)) -or $full -match '(?i)\.iso$') {
        return "That's your game's disc image, not the title update. The second file is the game's update from your Xbox 360. It's named like TU_174Q22P_0000008000000.00000000000O2 and is about 3 MB. See `"The title update`" in README.txt."
    }
    $size = (Get-Item -LiteralPath $full).Length
    if ($size -gt 100MB) { return ("That file is {0:N0} MB, but the title update is about 3 MB and named like TU_174Q22P_... See `"The title update`" in README.txt." -f ($size / 1MB)) }
    $head = New-Object byte[] 4
    $f = [IO.File]::OpenRead($full)
    try { $n = $f.Read($head, 0, 4) } finally { $f.Close() }
    $magic = [Text.Encoding]::ASCII.GetString($head, 0, $n)
    if ($magic -notin @('CON ', 'LIVE', 'PIRS')) {
        return "That file isn't an Xbox 360 update package (it should start with LIVE, CON or PIRS). Pick the file named like TU_174Q22P_0000008000000.00000000000O2, copied off the console as it is."
    }
    return $null
}

# Whether the game files are there: the ONE rule of -Step status's "files=" line and of Step-Files with no game picked. files.done, the title update's
# file, and the game folder rex\game-folder.txt names must still have the game (a data folder emptied or moved by hand). A file that is there but names
# no usable folder (damaged: an illegal character, NULs, empty) is NOT there, as when the read threw here (18 Nov); no file at all: as ever, nothing to check.
function Test-GameFilesThere {
    $gameFile = Join-Path $Rex 'game-folder.txt'
    $gameNamed = Read-Ttt2GameFolderFile $gameFile
    $gameThere = if (Test-Path -LiteralPath $gameFile) { [bool]$gameNamed -and (Test-Path -LiteralPath (Join-Path $gameNamed 'default.xex')) } else { $true }
    return [bool]((Test-Path -LiteralPath (Join-Path $Base 'files.done')) -and (Test-Path -LiteralPath (Join-Path $Repo 'gamedata\default_tu.xex')) -and $gameThere)
}

function Step-Files {
    Use-Tools
    if (-not $Source) {
        # 22 Nov (the owner: "We fix it"; a tester's install of October, updated in place, failed three times here with the game files already extracted): no game
        # picked and the files are there = nothing to do. TTT2_SETUP_FILES_STRICT=1 is the kill switch: the old refusal, whatever is there.
        # PROPOSAL (the wording is the owner's): the two lines said below.
        if ($env:TTT2_SETUP_FILES_STRICT -eq '1') {
            Say 'Game files: no game picked (TTT2_SETUP_FILES_STRICT=1: the files are not looked at).'
        } elseif (Test-GameFilesThere) {
            Say 'Game files: already there, kept (no game was picked, none is needed).'
            return
        } else {
            Say 'Game files: not there, and no game was picked.'
        }
        throw 'Choose your game: an ISO of your disc, or a folder with default.xex.'
    }
    if ($problem = Get-UpdateFileProblem $Update $Source) { throw $problem }
    $game = $Source
    if (Test-Path -LiteralPath $Source -PathType Leaf) {
        # An ISO: extracted with extract-xiso into <the data folder>\game (the old extraction there is replaced: it
        # counts as space already taken).
        if ($problem = Get-Ttt2SpaceProblem 2 $Data (Get-Ttt2FolderGB (Join-Path $Data 'game'))) {
            throw "$problem Your ISO is extracted there. Free some space on that drive, or choose another folder in `"Where to put the tools and game files`" (or pick a folder with the game's files instead of the ISO: nothing is copied then)."
        }
        $xiso = Get-ChildItem -LiteralPath (Join-Path $Tools 'extract-xiso') -Recurse -Filter 'extract-xiso.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
        if (-not $xiso) {
            $zip = Join-Path $Tools 'extract-xiso.zip'
            Download $ExtractXisoUrl $zip -Sha256 $ExtractXisoSha256 -ByHand ("Or download it yourself, $ExtractXisoUrl, and unzip it into $(Join-Path $Tools 'extract-xiso') (Install looks there first), then click Install again.")
            Expand-Archive -LiteralPath $zip (Join-Path $Tools 'extract-xiso') -Force
            Remove-Item -LiteralPath $zip
            $xiso = Get-ChildItem -LiteralPath (Join-Path $Tools 'extract-xiso') -Recurse -Filter 'extract-xiso.exe' | Select-Object -First 1
        }
        $game = Join-Path $Data 'game'
        Remove-Ttt2Folder $game
        Say 'Extracting your ISO (a few minutes)'
        New-Item -ItemType Directory -Force $game | Out-Null
        # extract-xiso takes its options before the image ("-x -d <folder> <iso>"); run from the
        # target folder too, so that its default ("<iso name>\" in the current folder) lands there.
        # It says nothing while it works, so progress is the size written against the image's size,
        # as "PROGRESS <percent> <text>" lines that the launcher shows as a bar.
        $isoSize = [math]::Max([double]1, [double](Get-Item -LiteralPath $Source).Length)   # doubles: images are over 4 GB
        $out = Join-Path $Base 'extract-xiso.out.txt'
        $null = New-Item -ItemType Directory -Force -Path $Base
        $p = Start-Process $xiso.FullName -ArgumentList @('-x', '-d', "`"$game`"", "`"$Source`"") -WorkingDirectory $game `
            -NoNewWindow -PassThru -RedirectStandardOutput $out -RedirectStandardError "$out.err"
        $null = $p.Handle   # without this, Windows PowerShell may not report the exit code
        while (-not $p.HasExited) {
            $written = [double](Get-ChildItem -LiteralPath $game -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
            Write-Host ("PROGRESS {0} Extracting your ISO" -f [math]::Min(99, [int](100 * $written / $isoSize)))
            Start-Sleep -Seconds 1
        }
        $p.WaitForExit()
        $code = $p.ExitCode
        Write-Host 'PROGRESS 100 Extracted'
        foreach ($f in $out, "$out.err") { if (Test-Path -LiteralPath $f) { Get-Content -LiteralPath $f | Select-Object -Last 5 | ForEach-Object { Say "extract-xiso: $_" } } }
        # extract-xiso can end with a non-zero code when everything came out (e.g. over the disc's
        # $SystemUpdate folder), and may put the files one folder down: go by what is there. The
        # files' fingerprints are checked in the next step anyway.
        $xex = Get-ChildItem -LiteralPath $game -Recurse -Depth 2 -Filter 'default.xex' -ErrorAction SilentlyContinue |
            Sort-Object { $_.FullName.Length } | Select-Object -First 1
        if (-not $xex) {
            throw "Could not extract the ISO (extract-xiso ended with code $code and no default.xex came out). Make sure it is an image of the TTT2 Xbox 360 disc."
        }
        $game = $xex.DirectoryName
        if ($code -ne 0) { Say "extract-xiso ended with code $code, but the game's files are there: going on." }
        Say "Game files: $game"
    }
    & (Join-Path $Rex 'prepare-game.ps1') -GameFolder $game -UpdatePackage $Update
    $null = New-Item -ItemType Directory -Force -Path $Base
    Set-Content -LiteralPath (Join-Path $Base 'files.done') (Get-Date -Format s)
    Say 'Game files: ready.'
}

# A prebuilt package over an older source-layout folder (by the updater, or unzipped over it by hand: an older
# package's updater copies files and knows nothing of this): the old sources go, and the old build (a stale exe and
# objects made by Visual Studio's compiler). Once: only while the old sources are there.
function Convert-ToPrebuiltLayout {
    if (-not (Test-Path -LiteralPath (Join-Path $Rex 'src')) -and -not (Test-Path -LiteralPath (Join-Path $Rex 'patches'))) { return }
    # (Never in a git checkout: a developer's clone keeps its sources, whatever was unzipped over it.)
    if (Test-Path -LiteralPath (Join-Path $Repo '.git')) {
        throw "$Repo is a git checkout (it has a .git folder): its rex\src and rex\patches are not removed. Unzip the package into its own folder."
    }
    foreach ($old in 'rex\src', 'rex\patches', 'recomp\tools\xexpatch.cpp', 'recomp\XENONRECOMP_COMMIT', 'rex\sdk-folder.txt', 'rex\out\build') {
        $path = Join-Path $Repo $old
        if (Test-Path -LiteralPath $path) { Say "The prebuilt layout: removing the old $old"; Remove-Ttt2Folder $path }
    }
}

# (The native shader step's leftovers after a closed window (the main line's lead's review, B2), at every Build and Status.)
function Clear-ShaderLeftovers {
    $f = Join-Path $Rex 'tools\native-shaders\package-shaders.ps1'
    if (Test-Path -LiteralPath $f) { try { . $f; Clear-NativeShaderLeftovers $Rex } catch { } }
}

function Step-Build {
    Clear-ShaderLeftovers
    Remove-OldQtAppNow   # (the old Qt app's files after an update from 4.6.3 or earlier: P5's release step)
    if ($Prebuilt) { Convert-ToPrebuiltLayout }
    Use-Tools
    # (A path with any character outside plain ASCII: the SDK's code generator, rexglue.exe, takes its paths through the code
    # page and reads them as UTF-8, so even a folder named U+00FF failed with "...\?\...\ttt2_manifest.toml is not a manifest"
    # (27 Oct). Said plainly before anything is built.)
    if ($name = Get-Ttt2NonAsciiFolder $Repo) {
        throw "This folder's path has characters the build's tools can't handle ($name): the build would fail. Move the whole folder to C:\ttt2, start BlueSpark from there and press INSTALL again."
    }
    # (The lead's E and F: the build goes in this install folder; a synced folder is said again here, Start Here asks first.)
    if ($problem = Get-Ttt2SpaceProblem 3 $Repo) { throw "$problem The build goes in this folder ($Repo). Free some space on that drive, then click Install again." }
    if ($service = Get-Ttt2SyncedFolder $Repo) { Say "Warning: this folder is inside $service ($Repo): if the build fails, move the folder out of $service (to C:\ttt2 or another drive)." }
    # A package unzipped over an older one: its files carry dates in the past (the packager's,
    # for CMake), often older than the objects already built, so an incremental build would see
    # nothing new and keep the old game. When the package's VERSION.txt differs from the one the
    # last build was made from, our sources are marked as changed (only rex\src: the game's
    # generated code doesn't change between packages and isn't rebuilt; CMake is configured at
    # every build and the SDK's patches are compared by hash). From the training branch, 6833fb1.
    $version = Join-Path $Repo 'VERSION.txt'
    $built = Join-Path $Rex 'out\build\win-amd64-release\package-version.txt'
    $now = if (Test-Path -LiteralPath $version) { (Get-Content -LiteralPath $version -Raw).Trim() } else { '' }
    $was = if (Test-Path -LiteralPath $built) { (Get-Content -LiteralPath $built -Raw).Trim() } else { '' }
    # (A source package: its sources dated now, so that Ninja rebuilds them. The prebuilt package needs nothing here:
    # build-windows.ps1 relinks when the release's manifest changed.)
    if ($now -and $now -ne $was -and (Test-Path -LiteralPath (Split-Path $built)) -and (Test-Path -LiteralPath (Join-Path $Rex 'src'))) {
        Say "A new package ($now): its sources rebuilt."
        Get-ChildItem -LiteralPath (Join-Path $Rex 'src') -Recurse -File | ForEach-Object { $_.LastWriteTime = Get-Date }
    }
    # (Packaging B, 8 Nov: a package with the native renderer (rex\prebuilt\lib\plume.lib) links it in; the game starts on
    # the emulated renderer unless out\renderer.txt says native and the shader cache below is made.)
    if (Test-Path -LiteralPath (Join-Path $Rex 'prebuilt\lib\plume.lib')) { $env:TTT2_NATIVE_GFX = '1' }
    # (Install, with no profile kept yet: the feed's, if it can be reached. Never an error.)
    if (-not (Test-Path -LiteralPath $PgoFile)) {
        try { $feedUrl = if ($UpdateUrl) { $UpdateUrl } else { 'https://raw.githubusercontent.com/avim2/BlueSpark/main/latest.json' }; Get-PgoProfile (Read-Feed $feedUrl) (Feed-Base $feedUrl) }
        catch { Say "PGO profile: not used (the feed was not reached: $($_.Exception.Message))" }
    }
    Set-PgoForBuild
    # (22 Nov, docs/BUILDTIME_PLAN_20261122.md, E: the shader step below is started NOW, beside the configure and the code generation (a second
    # PowerShell, the same step and lines; the build's loops pass its new lines on to the window), and joined after the build, before the warm-up.
    # DEFAULT OFF (the lead, 22 Nov: rows 1 and 1b saved 22 s and a long silent code generation makes the window say "Quiet for ..."): TTT2_BG_SHADERS=1 starts it beside the build, otherwise it runs after the build as before.)
    $shaderTools = Join-Path $Rex 'prebuilt\tools\shaders'
    . (Join-Path $Rex 'tools\renderer-choice.ps1')   # (4.7: $Ttt2NativeOffered false: no shader step, native isn't offered)
    $shaderWanted = (Test-Path -LiteralPath $shaderTools) -and ($Ttt2NativeOffered -or (Test-Ttt2TesterNative $Rex))   # (or a tester's out\renderer-test.txt)
    $shaderBg = $false
    if ($shaderWanted -and $env:TTT2_BG_SHADERS -eq '1' -and (Test-Path -LiteralPath (Join-Path $Rex 'game-folder.txt'))) {
        try {
            . (Join-Path $Rex 'tools\native-shaders\package-shaders.ps1')
            $null = Start-NativeShaderCacheBackground $Rex $shaderTools (Join-Path $Rex 'out\native-shaders.bin')
            $shaderBg = $true
        } catch { Say "Native shaders: not started beside the build ($($_.Exception.Message)); made after it." }
    }
    try { & (Join-Path $Rex 'build-windows.ps1') }
    catch { if ($shaderBg) { Stop-NativeShaderCacheBackground $Rex }; throw }
    if ($now) { Set-Content -LiteralPath $built $now }
    $null = New-Item -ItemType Directory -Force -Path $Base
    Set-Content -LiteralPath (Join-Path $Base 'build.done') (Get-Date -Format s)
    # (The native renderer's shader cache, from the player's own game files with the package's tools (packaging B): made
    # once, again only when the package's translation changes (its stamp). Never fails the Build: without it the game uses
    # the emulated renderer.)
    if ($shaderBg) { Wait-NativeShaderCacheBackground }
    elseif ($shaderWanted) {
        . (Join-Path $Rex 'tools\native-shaders\package-shaders.ps1')
        $null = Invoke-NativeShaderCache -Rex $Rex -Tools $shaderTools -Out (Join-Path $Rex 'out\native-shaders.bin')
    }
    Invoke-PipelineWarmup   # (Install's build part ends with it, 4.5.1; it never fails the part)
    # (20 Nov, the lead's JOB 3c: the install's last step asks for BlueSpark's first-boot page, as Start Here's last step did; bs_first_boot_tab.cpp reads
    # first-boot=pending. The once-per-PC marker (%LOCALAPPDATA%\TTT2Native\first-boot-done.txt) still wins: no page shows while it is there. A key already there, pending or done, is kept.)
    try {
        $fbMarker = Join-Path $env:LOCALAPPDATA 'TTT2Native\first-boot-done.txt'
        $fbFile = Join-Path $Rex 'userdata\launcher-settings.txt'
        $fbLines = if (Test-Path -LiteralPath $fbFile) { @(Get-Content -LiteralPath $fbFile) } else { @() }
        if (-not (Test-Path -LiteralPath $fbMarker) -and -not ($fbLines | Where-Object { $_ -match '^first-boot=' })) {
            New-Item -ItemType Directory -Force (Split-Path $fbFile -Parent) | Out-Null
            Set-Content -LiteralPath $fbFile ($fbLines + 'first-boot=pending')
        }
    } catch { Say "Build: first-boot note not written ($($_.Exception.Message))." }
    Say 'Build: done.'
}

# The pipeline warm-up (the helper's Task 4, A4): the new exe started once, through run-windows.ps1 as Play starts it (the
# game folder, the user data, the pipeline seed), with --ttt2_pipeline_warmup_quit: it quits as soon as the start has made
# the stored pipelines, before the game runs (pipeline_warmup.cpp). A cold GPU driver (after an update that changes how
# shaders are translated) compiles them here, not at the next Play. With no shader file yet (a new player) there is nothing
# to make and it takes a few seconds. Never fails the Build.
function Invoke-PipelineWarmup {
    if (-not (Test-Path -LiteralPath (Join-Path $Rex 'game-folder.txt'))) { return }
    . (Join-Path $Rex 'tools/game-lock.ps1')
    # (A game already running, this install's or another's, or a live lock: skipped, never waited for. run-windows.ps1
    # would wait for the lock, and the game to wait on must be the one started here.)
    $lock = Get-GameLock
    if ((Get-Process ttt2 -ErrorAction SilentlyContinue) -or ($lock -and (Test-GameLockLive $lock) -and [int]$lock.pid -ne $PID)) {
        Say 'Build: a game is running, so the pipeline warm-up is skipped (Play makes them instead).'
        return
    }
    $prompt = $env:TTT2_NO_PROMPT
    $pidFileWas = $env:TTT2_GAME_PID_FILE
    # (The started game's id and start time go into a file of the warm-up's own: the process waited on, and stopped if it
    # must be, is that one and never another.)
    $pidFile = Join-Path $Rex 'out\warmup-pid.txt'
    try {
        Say 'Build: warming up the graphics pipelines (the game''s window shows for a moment)...'
        $env:TTT2_NO_PROMPT = '1'   # (no game folder: run-windows.ps1 throws instead of asking)
        $env:TTT2_GAME_PID_FILE = $pidFile
        Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue
        $started = Get-Date
        # (Its own log file, made again each time: with --log_file the SDK writes no numbered log, so the warm-up's quit
        # (no "Title terminated") is never taken for a crash's leftover log by the next online start, nor packed into a
        # problem report.)
        $warmupLog = Join-Path $Rex 'out\pipeline-warmup.log'
        Remove-Item -LiteralPath $warmupLog -Force -ErrorAction SilentlyContinue   # (the SDK appends to a --log_file)
        & (Join-Path $Rex 'run-windows.ps1') '--ttt2_pipeline_warmup_quit=true' "--log_file=$warmupLog" | Out-Null
        $game = $null
        if (Test-Path -LiteralPath $pidFile) {
            $parts = "$(Get-Content -LiteralPath $pidFile -Raw)".Trim() -split ' '
            $p = Get-Process -Id ([int]$parts[0]) -ErrorAction SilentlyContinue
            if ($p -and $p.ProcessName -eq 'ttt2') { try { if ($p.StartTime.ToFileTimeUtc() -eq [long]$parts[1]) { $game = $p } } catch {} }
        }
        if ($game -and -not $game.WaitForExit(600000)) {
            Stop-Process -Id $game.Id -Force -ErrorAction SilentlyContinue
            Say 'Build: the pipeline warm-up took over 10 minutes and was stopped (Play makes them instead).'
            return
        }
        Say "Build: graphics pipelines warmed up in $([int]((Get-Date) - $started).TotalSeconds) s."
    } catch {
        Say "Build: the pipeline warm-up was skipped ($($_.Exception.Message)); Play makes them instead."
    } finally {
        $env:TTT2_NO_PROMPT = $prompt
        $env:TTT2_GAME_PID_FILE = $pidFileWas
        Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue
    }
}

# The logs every play-test run keeps (rex\out\build\win-amd64-release\logs): only the cheap ones,
# a line a second or a line when something changes, so they cost no frames. Left out: the
# per-resolve and per-input traces (hundreds of lines a second), the sound and XMA dumps
# (gigabytes; "Report a sound problem" makes them and turns the XMA trace on, which at about
# 1,500 lines a second rolled the log over in minutes) and the rollback diagnostics.
$PlayLogSwitches = @(
    '--latency_log=true',        # input-to-present delays and the frame pacing, once a second
    '--ttt2_frame_times=true',   # the update's and the draw's time, every 300 frames
    '--gpu_work_log_ms=8',       # a hitch's first-time GPU work (textures, pipelines, uploads) over 8 ms
    '--ttt2_hang_dump=true',     # where every thread is, if the game stops updating for 2.5 s
    '--ttt2_window_report=true', # a line when the window is minimized, restored or loses the focus, or the steps or the timer drop
    '--audio_stats=true',        # sound frames submitted, played and missed, once a second
    '--ttt2_xmsg_trace=true',    # the game's messages to the console's system services
    '--ttt2_file_trace=true',    # every file the game opens (loads)
    '--ttt2_crash_dump=true'     # a crash nothing else explains: its guest calls logged and a minidump in rex\out\dumps (for Report a problem)
)

function Step-Play {
    Remove-OldQtAppNow   # (the old Qt app's files after an update from 4.6.3 or earlier: P5's release step)
    Use-Tools
    # (A path with a character outside plain ASCII (27 Oct): a CJK or emoji folder ends the game at its start with a C runtime
    # fail-fast (0xC0000409) and no log; a U+00FF folder plays, but the game made its user data (the saves too) in another
    # folder, the name read in the wrong encoding (C:\ptest\U+00C3 U+00BF\...\rex\userdata). Said plainly instead.)
    if ($name = Get-Ttt2NonAsciiFolder $Repo) {
        throw "This folder's path has characters the game can't handle ($name): it would not start, or would put your saves in another folder. Move the whole folder to C:\ttt2, start BlueSpark from there, press INSTALL again, then start the game."
    }
    # Old logs past the newest 20 go, so the folder can't grow without end.
    $logs = Join-Path $Rex 'out\build\win-amd64-release\logs'
    Get-ChildItem -LiteralPath $logs -Filter 'ttt2_*.log' -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -Skip 20 |
        Remove-Item -Force -ErrorAction SilentlyContinue
    $script:LinkMarkAfterPlay = $null
    $switches = Get-PlaySwitches
    Write-PlaySwitches $switches
    if ($null -ne $script:LinkMarkAfterPlay) {   # (replay-links-registered: remembers that there is something to remove; set only for a real Play)
        $settingsFile = Join-Path $Rex 'userdata\launcher-settings.txt'
        Set-Content -LiteralPath $settingsFile (@(Get-Content -LiteralPath $settingsFile | Where-Object { $_ -notmatch '^replay-links-registered=' }) + "replay-links-registered=$($script:LinkMarkAfterPlay)")
    }
    Say (Get-Ttt2GpuWaitChoice).Text
    # (The owner's Play goes first: exclusive, and the shared tests' games are stopped. docs/GAME_LOCK_RULES_20261102.md.)
    $env:TTT2_GAME_LOCK_KIND = 'owner'
    & (Join-Path $Rex 'run-windows.ps1') @switches
}

# The switches Play gives the game. One list for both ways of playing (the lead's I, 26 Oct): Play passes it, and it's
# written to rex\userdata\play-switches.txt (Write-PlaySwitches), which the fast client reads when it starts the game
# (fastclient/app/src/gamestart.cpp, StartHereSwitches), so the two can't drift apart. Start Here's "Play: Fast
# Client" writes it first (the 'switches' step) and then starts the client.
function Get-PlaySwitches {
    # The training mode is always on (the owner, 19 October: training is never off): its opponent,
    # Status Record, and the menu's settings kept between sessions in the user data folder.
    $training = @()
    $logSwitches = $PlayLogSwitches
    if ($true) {
        $settings = Join-Path $Rex 'userdata\training-settings.txt'
        # Easy's slowing in Throw Break Training: on in the play test for the owner to judge
        # (it skips one fight frame in five of the break window, the pause's own way).
        # Rewind and take over (Select + L3): allowed; how far back is the menu's Rewind
        # (Restart Settings, 3 seconds to start with). About 10 MB a second kept and 3 ms once a
        # second (training/STATUS.md, the fourteenth and fifteenth rounds).
        # Replays: every offline Versus match recorded into the user data folder's replays (the
        # newest 50, about 300 KB each), watched from our menu's Replays with the recorded
        # profiles (costumes) installed as the fight is made (the eighteenth round).
        $training = @('--ttt2_training=true', '--ttt2_training_dummy=true', '--ttt2_status_record=true',
                      '--ttt2_training_easy_slow=true', '--ttt2_training_rewind=3',
                      '--ttt2_training_replay=true', '--ttt2_match_setup=true', '--ttt2_match_setup_profiles=true',
                      '--ttt2_physical_unwatch_when_left=true',
                      # (Offline the picture jobs otherwise run on the main thread, Status Record's inline jobs: 2 min of Practice,
                      # 31 Oct: 7 seconds under 59 fps, the lowest 49, against none and 59 with this.)
                      '--ttt2_inline_scheduler=false',
                      "--ttt2_training_settings=$settings")
        # --ttt2_frame_times times the update itself and returns before Status Record's branch
        # (run_ahead.cpp), so with it R3 / L3 did nothing (the owner, 16 October): left out here.
        $logSwitches = @($PlayLogSwitches | Where-Object { $_ -notlike '--ttt2_frame_times*' })
    }
    # Online (the lead's order of 19 October): a build with the online code (rex\src\online, Themail's),
    # Start Here's "Online play (test)" on (on by default since the owner's word of 21 October: only online=false
    # in launcher-settings.txt turns it off), and not "Play offline": the game's Live sign-in, its
    # network layer and the fight splice, with the player's name as the lobby's gamertag (the same name
    # --user_name gives the game, from run-windows.ps1).
    $online = @()
    $settingsFile = Join-Path $Rex 'userdata\launcher-settings.txt'
    $onlineWanted = -not ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'online=false'))
    # (Tournament Setup Mode, the owner 8 Nov: tournament=true in the same file: fully offline, as "Play offline" with the game's own switch on top; rex\src	ournament_mode.cpp.)
    $tournament = (Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'tournament=true')
    if ($HasOnline -and $onlineWanted -and -not $Offline -and -not $tournament) {
        $online = @('--live_signin=true', '--ttt2_live_net=true', '--ttt2_fight_splice=3',
                    '--ttt2_env_sync_pieces_frames=2', '--live_guest_signin=true', '--live_guest_signin_auto=true')   # (auto: Start on the second pad signs the guest in, with no popup: the owner, 1 Nov)
        # The play test's logs (22 October): after each online fight its log lines go to the server's log
        # dropbox by themselves (rex\src\online\log_upload.cpp: signed with the player's key, other players'
        # addresses and the Windows user name taken out, from a thread of their own after the fight). OFF since the
        # public launch (27 Oct): only logupload=true in launcher-settings.txt turns it on (Start Here's "Send each
        # online fight's log"). Crash logs are separate (below) and stay on.
        if ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'logupload=true')) {
            $online += '--ttt2_log_autoupload=true'
        }
        # A crash's log (23 October): the game sends the run before's log at the start when it crashed, on by
        # itself with the online switches; crashlog=false (Start Here's "Send crash logs") turns it off.
        if ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'crashlog=false')) {
            $online += '--ttt2_log_autoupload_crash=false'
        }
        # (The name is the profile folder's since #30, tools\profile-folder.ps1; the game folder's copy is the one before
        # 23 October, read when the profile has none yet. A new install had no gamertag passed: a reader, 24 Oct.)
        . (Join-Path $Rex 'tools\profile-folder.ps1')
        $nameFile = Join-Path (Get-ProfileFolder) 'player-name.txt'
        if (-not (Test-Path -LiteralPath $nameFile)) { $nameFile = Join-Path $Rex 'userdata\player-name.txt' }
        if (Test-Path -LiteralPath $nameFile) {
            $name = "$(Get-Content -LiteralPath $nameFile -Raw)".Trim()
            if ($name) { $online += "--ttt2_live_gamertag=$name" }
        }
        # (4.7, the owner via the main line's lead, 8 Nov: Play TTT2's Practice queue with BlueSpark's route. BEGIN SEARCH on the game's own
        # Ranked / Quick menus goes to Practice and searches there (the menu queue, its rows), and an accepted match asks the select
        # straight from the fight (direct entry; the sign-in ahead and the licence made in Practice while searching, queue_from_practice.cpp).
        # Not --ttt2_queue_from_practice in THIS block (a non-BlueSpark Play: it would skip the ONLINE MODE terms on the player's own press,
        # QueueFromPracticeOnlyByMenu() turns false), not the speculative connect (BlueSpark's only). BlueSpark's list (Get-BlueSparkSwitches)
        # does pass --ttt2_queue_from_practice and --ttt2_parked_practice (20 Nov, the lead's order): there --ttt2_bluespark alone already turned
        # the queue step on (queue_from_practice.cpp QueueFromPracticeOn), so the explicit switch changes nothing for the terms gate. Measured: accept to the intros 31.0 s (35.0 before the route). menuqueue=false in launcher-settings.txt: none.)
        # (4.7-test2, the owner, 9 Nov: "unshippably slow": OFF for 4.7, Ranked and Quick as in 4.6.3. 4.8 makes it fast and turns it back on; until then only
        # menuqueue=true in launcher-settings.txt (a tester's) gives it.)
        if (-not $BlueSpark -and (Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'menuqueue=true')) {
            # (--ttt2_bluespark_fast_walk_load: the walk's fight load under the menu queue's own cover, queue_from_practice.cpp: the route's step 3.)
            $online += @('--ttt2_menu_queue=true', '--ttt2_training_queue_rows=true', '--ttt2_direct_entry=true',
                         '--ttt2_direct_entry_no_online_menu=true', '--ttt2_bluespark_practice_to_select=true', '--ttt2_bluespark_fast_walk_load=true')
        }
        Say "Online: $($online -join ' ')"
    } elseif ($Offline) {
        Say 'Offline: the online switches left out.'
    } elseif ($tournament) {
        Say 'Tournament Setup Mode: the online switches left out.'
    }
    # The keyboard as player one (the lead's orders of 23 Oct, the owner's word): our own layer (src/keyboard_input.cpp,
    # the keys in rex\userdata\keyboard.txt), on unless Start Here's "Keyboard (player 1)" is off (keyboard=false). The
    # SDK's own keyboard (--mnk_mode) always off: given outright, as F4's "Save to config" can have kept mnk_mode = true
    # in ttt2.toml and the command line wins over it.
    $keyboardOn = -not ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'keyboard=false'))
    $keyboard = @('--mnk_mode=false', "--ttt2_keyboard=$(if ($keyboardOn) { 'true' } else { 'false' })",
                  "--ttt2_keyboard_file=$(Join-Path $Rex 'userdata\keyboard.txt')")
    # (Who it plays, the controls update: Start Here's Keyboard plays as; player 1 gives no switch.)
    if ((Test-Path -LiteralPath $settingsFile) -and ($keyboardPlayerLine = @(Get-Content -LiteralPath $settingsFile) -match '^keyboard-player=(2|both|each)$' | Select-Object -First 1)) {
        $keyboard += "--ttt2_keyboard_player=$($keyboardPlayerLine.Substring(16))"
    }
    # (The build's name beside CLOSED ALPHA TEST in online fights, the owner, 24 Oct: package-info's name ("Release 4.1"),
    # or "Release N"; an internal build "internal <commit>".)
    $pkg = Read-PackageInfo
    $releaseName = if ($pkg.name) { $pkg.name } elseif ($pkg.track -eq 'release' -and $pkg.patch) { "Release $($pkg.patch)" }
                   else {
                       $commit = $pkg.commit
                       if (-not $commit -and (Test-Path -LiteralPath (Join-Path $Repo '.git'))) { $commit = "$(& git -C $Repo rev-parse --short HEAD 2>$null)".Trim() }
                       "internal $commit".Trim()
                   }
    $keyboard += "--ttt2_release_name=$releaseName"
    # (24 Nov, 5.1, Task 25: --ttt2_return_relaunch makes run-windows.ps1 start the exit watcher; the tournament menu's LEAVE TOURNAMENT SETUP MODE ends the game on its marker "bluespark" and the watcher starts BlueSpark.exe.)
    if ($tournament) { $keyboard += '--ttt2_tournament_mode=true'; $keyboard += '--ttt2_return_relaunch=true' }
    # (Controller vibration: off unless Start Here's "Controller vibration" box is ticked, vibration=true; 24 Oct.)
    if ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'vibration=true')) { $keyboard += '--ttt2_vibration=true' }
    # (No intro: the splash, then straight to the main menu; on unless Start Here's "No intro" is unticked, nointro=false. 24 Oct.)
    if (-not ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'nointro=false'))) { $keyboard += '--ttt2_no_intro=true' }
    # (Mute in the background: the game's default (on) unless Start Here's box is unticked, mutebg=false; offline and online alike. 4.5.)
    if ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'mutebg=false')) { $keyboard += '--ttt2_mute_in_background=false' }
    # (TEKKEN TUNES with the player's own MP3s: off unless Start Here's box is ticked, tunes=true. 4.6; rex\src\tunes_hooks.cpp.)
    if ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'tunes=true')) {
        $keyboard += '--ttt2_tekken_tunes=true'
        # (The folder the player chose, tunes-folder=. A path's last \ would escape the closing quote on the command line; a drive's top stays a folder as D:\.)
        $tunesFolder = @(Get-Content -LiteralPath $settingsFile | Where-Object { $_ -match '^tunes-folder=.' } | Select-Object -Last 1) -replace '^tunes-folder=', ''
        if ("$tunesFolder") { $tunesFolder = "$tunesFolder".TrimEnd('\'); if ($tunesFolder -match '^[A-Za-z]:$') { $tunesFolder += '\.' }; $keyboard += "--ttt2_tekken_tunes_folder=$tunesFolder" }
    }
    # (Replay links from the website, the owner via the replays lead, 12 Nov; design: replays/design/replay_link_registration.md. The setting replay-links
    # (default false in code) true: the game listens for a handed-over link and registers ttt2:// for this Windows user at every Play (the same value each time,
    # so it follows a moved folder); replay-links-registered=true remembers that there is something to remove. Set false afterwards: the first Play after it
    # adds the one unregister pass, then forgets. rex\src\replay_link.cpp; the game removes only its own command.)
    if ((Test-Path -LiteralPath $settingsFile)) {
        $linkLines = @(Get-Content -LiteralPath $settingsFile)
        # (The mark itself is written by Step-Play, after the switches are made for a real Play: this function also runs for Step-Switches, with no game started.)
        $script:LinkMarkAfterPlay = $null
        if ($linkLines -contains 'replay-links=true') {
            $keyboard += @('--ttt2_replay_link_listen=true', '--ttt2_replay_link_register=true', '--ttt2_replay_link_registry_apply=true')
            if ($linkLines -notcontains 'replay-links-registered=true') { $script:LinkMarkAfterPlay = 'true' }
        } elseif ($linkLines -contains 'replay-links-registered=true') {
            $keyboard += @('--ttt2_replay_link_unregister=true', '--ttt2_replay_link_registry_apply=true')
            $script:LinkMarkAfterPlay = 'false'
        }
    }
    # (Voice chat: off unless Start Here's box is ticked, voip=true; 4.7, rex\src\online\voip.cpp. The microphone the player chose (voip-mic=, empty = the Windows default) goes to the
    # game in a file, userdata\voip-mic.txt, and only that file's path is a switch: a device name can hold a person's name and must not be on a command line, in a log or in a report.)
    if ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'voip=true')) {
        $keyboard += '--ttt2_voip=true'
        $micFile = Join-Path $Rex 'userdata\voip-mic.txt'
        $mic = @(Get-Content -LiteralPath $settingsFile | Where-Object { $_ -match '^voip-mic=.' } | Select-Object -Last 1) -replace '^voip-mic=', ''
        try {
            New-Item -ItemType Directory -Force (Split-Path $micFile -Parent) | Out-Null
            [IO.File]::WriteAllText($micFile, "$mic".Trim(), (New-Object Text.UTF8Encoding($false)))
            $keyboard += "--ttt2_voip_mic_file=$micFile"
        } catch {}
    }
    # (The voice's volume, 4.6.2: voip-volume= from Start Here's slider or the game's Sound Options row, with voice on or off: the row works either way, and the game
    # writes a change back to this same file.)
    $keyboard += "--ttt2_voip_settings_file=$settingsFile"
    if (Test-Path -LiteralPath $settingsFile) {
        $voipVolume = @(Get-Content -LiteralPath $settingsFile | Where-Object { $_ -match '^voip-volume=([0-9]|1[0-3])$' } | Select-Object -Last 1) -replace '^voip-volume=', ''
        if ("$voipVolume") { $keyboard += "--ttt2_voip_volume=$voipVolume" }
    }
    # (Ranked fights' record: wins only unless Start Here's "Show losses and win rate" box is ticked, rankedrecord=full; this PC's
    # screen only, nothing sent. The owner, 30 Oct; rex\src\ranked_hud_record.cpp.)
    if ((Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'rankedrecord=full')) { $keyboard += '--ttt2_ranked_record_wins_only=false' }
    # (Re-cut 10, part A, 23 Nov, the owner: Settings > Controls > "button prompts", padstyle=xbox|playstation; the row applies it live, this keeps it across a restart: --ttt2_pad_style.)
    if (Test-Path -LiteralPath $settingsFile) {
        $padStyle = @(Get-Content -LiteralPath $settingsFile | Where-Object { $_ -match '^padstyle=(xbox|playstation)$' } | Select-Object -Last 1) -replace '^padstyle=', ''
        if ("$padStyle") { $keyboard += "--ttt2_pad_style=$padStyle" }
    }
    # (13 Nov, the owner: Settings > Game > "search from anywhere"; on by default since 14 Nov (b07b6d3b4): a stored search_anywhere=false gives --ttt2_bluespark_search_anywhere=false at the start, search_anywhere=true gives =true; the row also applies it live.)
    if (Test-Path -LiteralPath $settingsFile) {
        $searchAnywhere = @(Get-Content -LiteralPath $settingsFile | Where-Object { $_ -match '^search_anywhere=(true|false)$' } | Select-Object -Last 1) -replace '^search_anywhere=', ''
        if ("$searchAnywhere") { $keyboard += "--ttt2_bluespark_search_anywhere=$searchAnywhere" }
    }
    # (The in-game update popup, 27 Oct: the feed Start Here checks, given only when it isn't the public one, a test
    # URL or folder; the game's own default is the public latest.json. rex\src\update_popup.cpp.)
    if ($UpdateUrl -and $UpdateUrl -ne 'https://raw.githubusercontent.com/avim2/BlueSpark/main/latest.json') { $keyboard += "--ttt2_update_feed=$UpdateUrl" }
    # (4.6's test package, the lead's order of 31 Oct: the fixes that were off, on; any that fails the two-PC pass comes out.)
    $always = @('--ttt2_present_thread=true', '--ttt2_voice_audio_off=true', '--ttt2_sound_lock_loads_only=true')
    # (Only this button's: Play TTT2 never has any of them. docs/BLUESPARK_IN_GAME_PLAN_20261102.md.)
    # (Tournament Setup Mode, the owner, 22 Nov: "Title's own menu". BlueSpark's whole list stays out of a tournament start: it opens BlueSpark's home, parks a Practice under it, walks the title's menus and
    # keeps the queue's route ready, and the mode is offline and opens the title's own main menu. Everything else of Play's list (training, logs, rendering, keyboard, pacing) stays; checkbox off: this line is as it was. rex/src/tournament_mode.cpp has the game's own net for a start without this list.)
    # (PowerShell names are not case sensitive: the next line's $bluespark is the switch $BlueSpark itself, so the word about it is said before it.)
    if ($BlueSpark -and $tournament) { Say "Tournament Setup Mode: BlueSpark's switches left out (the title's own main menu opens)." }
    $bluespark = if ($BlueSpark -and -not $tournament) { Get-BlueSparkSwitches $settingsFile } else { @() }
    @($logSwitches) + $always + $training + $online + $keyboard + $bluespark + @((Get-Ttt2GpuWaitChoice).Switches)
}
# Play BlueSpark's switches (Release 19, P5's release step; the main line's lead, 6 Nov: "the BlueSpark we tested"). Every one is off
# by default in the game. Direct entry isn't gated on --ttt2_bluespark in the game; since 4.7 Play TTT2 gets it too, with its own
# menu queue (Get-PlaySwitches' online block), but never the BlueSpark pages, their fast walk load or the speculative connect.
#   --ttt2_bluespark                      the pages over the main menu
#   --ttt2_bluespark_hidden_practice      START PRACTICE hidden and fast (2b's hop)
#   --ttt2_bluespark_watch                the Replays tab's WATCH (the hop implies it; given for the record)
#   --ttt2_bluespark_fast_walk_load       a walk's first fight loaded unpaced under its cover
#   --ttt2_bluespark_update_banner        the update popup's banner on BlueSpark's pages
#   --ttt2_direct_entry, --ttt2_direct_entry_no_online_menu    an accepted match asked straight from the main menu (P3)
#   --ttt2_bluespark_practice_to_select   ... and straight from Practice's fight (needs the two above)
#   --ttt2_speculative_connect=connected  the match connected silently from the pair, before the accept (needs the two above)
# Left out: the challenger movie (superseded by the challenger anywhere, on by default), menu queueing (Play TTT2's only), the Qt
# app's ttt2_fast_client_* switches. Turned off without a new release by one line in rex\userdata\launcher-settings.txt (they were
# never run across two real networks, only on one PC and one network):
#   bluespark-fastconnect=false   no speculative connect: the match connects after both accept, as P3's direct entry did
#   bluespark-directentry=false   no direct entry at all (and so no speculative connect and no select from Practice): the
#                                 accepted match walks by the game's own Online menu, as BlueSpark did before direct entry
function Get-BlueSparkSwitches([string]$settingsFile) {
    $lines = if ($settingsFile -and (Test-Path -LiteralPath $settingsFile)) { @(Get-Content -LiteralPath $settingsFile) } else { @() }
    $direct = $lines -notcontains 'bluespark-directentry=false'
    $fast = $direct -and $lines -notcontains 'bluespark-fastconnect=false'
    # (20 Nov, the lead's JOB 3c: the first-boot page; it shows once per PC, the marker decides, and only with first-boot=pending or a fresh profile: bs_first_boot_tab.cpp Wanted().)
    $switches = @('--ttt2_bluespark=true', '--ttt2_bluespark_hidden_practice=true', '--ttt2_bluespark_watch=true',
                  '--ttt2_bluespark_fast_walk_load=true', '--ttt2_bluespark_update_banner=true', '--ttt2_bluespark_first_boot=true')
    # (20 Nov, the lead's order via the helper lead: with the stage C bundle ON the parked Practice carries the queue, so the old walk's switches
    # (direct entry, no online menu, select from Practice, speculative connect) are NOT passed; with bluespark-stagec=false the old list is
    # passed exactly as before and no parked switch.)
    $bundle = $lines -notcontains 'bluespark-stagec=false'
    if ($direct -and -not $bundle) { $switches += @('--ttt2_direct_entry=true', '--ttt2_direct_entry_no_online_menu=true', '--ttt2_bluespark_practice_to_select=true') }
    if ($fast -and -not $bundle) { $switches += '--ttt2_speculative_connect=connected' }
    # (13 Nov, the main line's lead, docs/PLAN_BETA.md section 14: three keys, absent = off, none given by default; candidate 1 ships with them absent and the QA lead sets them by hand.)
    #   bluespark-oneplay=true    --ttt2_bluespark_oneplay=true   one Play: Open on, the Classic menu button, the update banner over the title's menu
    #   bluespark-settings=true   --ttt2_bluespark_settings=true  the Settings tab
    #   bluespark-lobbyv2=true    --ttt2_lobby_v2=true            Lobby v2
    # (Candidate 1, the owner, 12 Nov: all three ON by default; a line "<key>=false" turns that one off.)
    if ($lines -notcontains 'bluespark-oneplay=false') { $switches += '--ttt2_bluespark_oneplay=true' }
    if ($lines -notcontains 'bluespark-settings=false') {
        $switches += '--ttt2_bluespark_settings=true'
        # (16 Nov, the helper lead for the lead: the Settings tab's Graphics page, with the Renderer row, comes with the settings switch, but only in a
        # release that offers native, $Ttt2NativeOffered in tools\renderer-choice.ps1; while it is false the page stays off (bs_settings_tab.cpp, default false).)
        $rendererChoice = Join-Path $Rex 'tools\renderer-choice.ps1'
        if (Test-Path -LiteralPath $rendererChoice) {
            . $rendererChoice
            if ($Ttt2NativeOffered) { $switches += '--ttt2_bluespark_graphics_rows=true' }
        }
    }
    if ($lines -notcontains 'bluespark-lobbyv2=false') { $switches += '--ttt2_lobby_v2=true' }
    # (19 Nov, the lead's order via the helper lead, w-b7: Ranked and Quick's first match by the stage C route with its waits cut, ONE switch (stage_c_direct.cpp: the bundle, rows e3-e7); a line
    # bluespark-stagec=false turns it off: the match as before. Not Play TTT2's (no BlueSpark pages, no menu queue in 4.7).)
    # (20 Nov, the lead's order via the helper lead, the owner: the fast queue MUST be on and Play always launches parked: the parked Practice
    # (fastclient_game.cpp, no app) and the queue from it, in Play's list only, with the bundle on; a bare exe changes nothing.)
    # (20 Nov, the lead, after main's PC1 rows on ui-fixes: the boot splash is back with --ttt2_splash_home (from the first present, the home straight after it; parked +64 ms against no splash),
    # so --ttt2_boot_splash=false is gone; --ttt2_parked_play: START PRACTICE hands the parked fight to the player. --ttt2_return_relaunch stays until the in-process return passes its row.)
    # (20 Nov, the lead, after PC1's rows on the fold 7f2ff0dc2: --ttt2_classic_inprocess: the CLASSIC MENU button opens the game's own menu over the parked Practice, no restart (+650 ms early home, +1073 ms parked: the menus' loader runs at boot);
    # --ttt2_register_at_start: the identity is registered with the Worker at the home's first frame, and again once if the Worker answers 'not registered' to a marked install.)
    # (21 Nov, the lead, the owner's ruling of 20 Nov: THE IN-PROCESS RETURN IS THE ROUTE, the restart after a set (--ttt2_return_relaunch) is OUT of Play's list. In: the return's own switches
    # (--ttt2_stage_c_return_close / _reset / _w, --ttt2_stage_c_peer_rearm, --ttt2_parked_home_after_set), the search again after a set with a 10 s same-opponent gate (his words), the abort guards
    # (--ttt2_stage_c_abort_safe, --ttt2_queue_stage_own_pair), and --ttt2_abort_relaunch (his yes, 20 Nov 8:38 pm): only a ROUTE ABORT (rare, nothing posted) ends the game with exit 78 and the
    # watcher starts it again; run-windows.ps1 starts that watcher on this switch. --ttt2_fight_key_per_set: game 2's packet key from the set's key and the game number (the process's rewind count differs between
    # two players once nothing restarts between sets: AR2's frozen game 2). --ttt2_rewound_sync_core: game 2's 30 s synced watchdog also takes a checksum step whose gameplay words agree (a fresh process against one with a set
    # behind it differs in pose words only: MH's game 2 ended at 30 s). PC2 rows: W's notes (cm) L, (ct) AR, (cu) AR2, (cy) AR3, (cz) MH, (da) MH2.
    # --ttt2_match_no_fight_s=90 (21 Nov): the walk's match step with no fight entered for 90 s ends as a route abort (PC1: a host sat there 23 min after a half-open join, the joiner gone).
    # --ttt2_queue_ready_wait_late_ms=13000 and --ttt2_stage_c_walk_end_clears_route (22 Nov, the testers' report: the host accepted 9.4 s after the pair): the joiner waits for a slow host's ready (not 3 s), and a walk that ends at the main menu with no fight clears the route (no second abort). PC2 rows: docs/helper/late_accept_20261122/note.md.
    # --ttt2_classic_leaves_queue (21 Nov): entering the classic menu with a search running leaves the queue (a pair made there could not join: PC1's failed joins, the game at mode 16).)
    # --ttt2_training_parked_as_practice (21 Nov, the owner: "Holding select in practice mode doesnt make the dummy ki charge anymore"): BlueSpark's parked Practice (queue closed) counts as Practice for our dummy shortcuts: ki charge, record, play (PC4 row on 7e457ccc0: ki 5 of 5, FIND from there pairs, DESYNC 0; training/KI_ROWS6_PC4_20261121.md).
    # --ttt2_parked_team_defer (21 Nov, the owner): a Training-tab pick only stores the team; the parked Practice reloads at START PRACTICE or a queue start (PC2 rows ttt2_1133 / ttt2_1134).
    # --ttt2_splash_shaders (21 Nov, the owner: the shader splash in the tester re-cut): the boot splash stays up through the first start's pipeline warm-up with COMPILING SHADERS N% (FIRST START ONLY), then BlueSpark's home (PC2 row ttt2_1137; needs --ttt2_native_gfx_warmup_hold, default true).
    # (21 Nov, the lead's order, PC1 rows on classic-online-20261121: the classic Online menu's own entries land on BlueSpark's tabs, as the classic BEGIN SEARCH does: --ttt2_bluespark_classic_search_lobby (SEARCH SESSION > START SEARCH -> LOBBY), --ttt2_bluespark_classic_replays (SEARCH REPLAYS -> REPLAYS), --ttt2_bluespark_classic_leaderboards (LEADERBOARDS -> LEADERBOARD), --ttt2_bluespark_classic_create_lobby (CREATE SESSION OK -> LOBBY at Create); each acts only from the classic menu out of the parked Practice; docs/CLASSIC_ONLINE_HANDLERS_PC1_20261121.md.)
    # --ttt2_bluespark_menu_music (23 Nov, the owner: "In BlueSpark menu, can we bring back the main menu music?" ... "next tester cut"): BlueSpark's home plays the main menu's song (the player's Tekken Tunes track for the main menu when Tekken Tunes is on and one is saved, else the game's own), at the game's MUSIC VOLUME; silent in the background, under any other mute, in a load, a search or a match (PC1 rows: docs/MENU_MUSIC_RESULTS_20261123.md on classic-online-20261121).
    # --ttt2_parked_named_stage (23 Nov, the owner, the testers' report: the Training tab's stage was not the one played): the stage named at START PRACTICE is kept for the hidden reload it makes; a Random pick and every other re-park draw at random as before.
    # --ttt2_native_gfx_icon_atlas and --ttt2_new_button_cluster (23 Nov, the owner, re-cut 10: "the movelist and input history button icons can be a bit hard for users to see. Use this instead. The buttons used should be in full color, unused greyed out"; and PlayStation buttons in place of the Xbox ones): the game's icon font is drawn from a replacement on the native renderer (his button cluster; the pad style's pictures, from Settings > Controls > button prompts), and our input history uses the same cluster.
    if ($bundle) { $switches += @('--ttt2_stage_c_direct_bundle=true', '--ttt2_parked_practice=true', '--ttt2_queue_from_practice=true', '--ttt2_parked_show=true', '--ttt2_parked_turbo_load=true', '--ttt2_parked_early_home=true', '--ttt2_splash_home=true', '--ttt2_parked_play=true', '--ttt2_classic_inprocess=true', '--ttt2_register_at_start=true',
                                  '--ttt2_stage_c_return_close=true', '--ttt2_stage_c_return_reset=true', '--ttt2_stage_c_return_w=true', '--ttt2_stage_c_peer_rearm=true', '--ttt2_parked_home_after_set=true', '--ttt2_search_again_after_set=true', '--ttt2_same_opponent_gate_s=10',
                                  '--ttt2_stage_c_abort_safe=true', '--ttt2_queue_ready_wait_late_ms=13000', '--ttt2_stage_c_walk_end_clears_route=true', '--ttt2_queue_stage_own_pair=true', '--ttt2_abort_relaunch=true', '--ttt2_fight_key_per_set=true', '--ttt2_rewound_sync_core=true', '--ttt2_match_no_fight_s=90', '--ttt2_classic_leaves_queue=true', '--ttt2_parked_team_defer=true', '--ttt2_splash_shaders=true', '--ttt2_training_parked_as_practice=true', '--ttt2_bluespark_classic_search_lobby=true', '--ttt2_bluespark_classic_replays=true', '--ttt2_bluespark_classic_leaderboards=true', '--ttt2_bluespark_classic_create_lobby=true', '--ttt2_classic_search_select=true', '--ttt2_bluespark_menu_music=true', '--ttt2_parked_named_stage=true', '--ttt2_native_gfx_icon_atlas=true', '--ttt2_new_button_cluster=true') }
    # (17 Nov, the lead's order, fold64: the Benchmark page's Run needs the run itself: --ttt2_benchmark=true beside --ttt2_bluespark_benchmark (the page, default true); a line bluespark-benchmark=false passes the run switch false and the page switch false.)
    # --ttt2_benchmark_capped (21 Nov, the owner: "benchmark needs to change to capped 60 and only care about dips"): the run at the game's own 60, the letter and the Ranked gate by dips (PC2 rows ttt2_1144 native / ttt2_1145 old: AVG 59.96 / 59.94, the gate let both in).
    if ($lines -notcontains 'bluespark-benchmark=false') { $switches += @('--ttt2_benchmark=true', '--ttt2_benchmark_capped=true') } else { $switches += @('--ttt2_benchmark=false', '--ttt2_bluespark_benchmark=false') }
    return $switches
}
# The GPU-fence wait on a PC with fewer than 6 logical processors: blocking (--ttt2_blocking_gpu_wait=true) instead of the spin
# (the main line's lead, 5 Nov, from the helper's 4-core test, helper/STATUS.md item 0: 3 x 130 s a cell; mask F 9/6/5 seconds
# under 59 with the spin against 5/3/3 blocking, mask 55 2/2/2 both ways, blocking 0.6-0.7 fewer cores, read>swap the same).
# 6 and up: the spin as before (main's 12-thread A/B: blocking dropped frames there). TTT2_TEST_CPU_COUNT (tests): that count.
# The fast client's gamestart.cpp does the same for a start without this file's list.
# 4.7.2 (the owner, 10 Nov, "just a revert to a known state"): THE SPIN ON EVERY PC, as in 4.6.3: no switch whatever the count. A 4.7.1 player on a real
# quad-core (i5-7400, 4 threads, GTX 1070) lost frames with the blocking wait on (55-58 presents in 56% of seconds, "gpu done too late by ~0.9 ms" in 15-39 frames
# a second). The blocking wait stays off until it is proven on a real 4-core; the helper's 4-core test above is the only evidence for it. The function stays, so
# the next release can turn it back on here: the game's own switch is untouched (default false). The fast client's gamestart.cpp still has its copy (a release
# ships no Qt app).
function Get-Ttt2GpuWaitChoice {
    $count = if ($env:TTT2_TEST_CPU_COUNT) { [int]$env:TTT2_TEST_CPU_COUNT } else { [Environment]::ProcessorCount }
    return @{ Switches = @(); Text = "The GPU wait: the spin ($count logical processors)" }
}
function Write-PlaySwitches([string[]]$switches) {
    $file = Join-Path $Rex 'userdata\play-switches.txt'
    New-Item -ItemType Directory -Force (Split-Path $file) | Out-Null
    $lines = @("# The switches Start Here's Play gives the game, written at each Play and before the fast client starts; the fast",
               "# client reads them (rex\setup-steps.ps1, Get-PlaySwitches). Written again each time: don't edit.") + $switches
    [IO.File]::WriteAllLines($file, [string[]]$lines, (New-Object Text.UTF8Encoding $false))
}
function Step-Switches {
    $switches = Get-PlaySwitches
    Write-PlaySwitches $switches
    Say "Play's switches written for the fast client ($($switches.Count))."
}

function Step-Status {
    Clear-ShaderLeftovers
    $exe = Join-Path $Rex 'out\build\win-amd64-release\ttt2.exe'
    $toolsDone = Join-Path $Base 'tools.done'
    if ($Prebuilt) {
        # (A marker naming this package's pins: the toolchain changes with the pins. And the tools where the data folder
        # says: a folder changed without moving them, or emptied by hand, is "not done".)
        # (Every pin's marker and its program (Test-Ttt2ToolchainPinsInstalled), not llvm's marker alone: a cmake.exe an
        # antivirus removed left this "done", so Install never ran the toolchain again and the build failed each time, 7 Nov.)
        # (Microsoft's part too (Test-Ttt2MsvcLayout): a pin check alone said "done" for a base whose compiler folder was gone, and Install then stopped at Microsoft's license, 14 Nov. "toolsmark" is tools.done alone: Setup says it will download the tools again.)
        $msvcThere = Test-Ttt2MsvcLayout (Join-Path (Get-Ttt2ToolchainRoot) $script:Ttt2MsvcFolder)
        $there = (Test-Ttt2ToolchainPinsInstalled (Get-Ttt2ToolchainRoot)) -and $msvcThere -and [bool](Get-Ttt2Python)
        "tools=$((Test-Path -LiteralPath $toolsDone) -and (Get-Content -LiteralPath $toolsDone -Raw) -like "prebuilt $(Get-Ttt2ToolchainPinText) *" -and $there)"
        "toolsmark=$(Test-Path -LiteralPath $toolsDone)"
        "msvc=$msvcThere"   # (Setup's own gate: it takes "tools ready" only from a script that says msvc= at all; an older script that does not is "unknown" and the license page comes first)
        "oldsdk=$((Test-Path -LiteralPath $exe) -and @(Get-OldSdkFolders).Count -gt 0)"
    } else {
        "tools=$(Test-Path -LiteralPath $toolsDone)"
    }
    # (The files' rule is Test-GameFilesThere, above Step-Files: Step-Files with no game picked uses the same one.)
    "files=$(Test-GameFilesThere)"
    "build=$(Test-Path -LiteralPath $exe)"
    # (4.5.1's Install: the build is out of date when the package's VERSION.txt isn't the one the last build was made from
    # (Step-Build writes package-version.txt after it); Start Here then shows "Rebuild". A folder without VERSION.txt (git): current.)
    $version = Join-Path $Repo 'VERSION.txt'
    $built = Join-Path $Rex 'out\build\win-amd64-release\package-version.txt'
    $current = Test-Path -LiteralPath $exe
    if ($current -and (Test-Path -LiteralPath $version)) {
        $current = (Test-Path -LiteralPath $built) -and "$(Get-Content -LiteralPath $built -Raw)".Trim() -eq "$(Get-Content -LiteralPath $version -Raw)".Trim()
    }
    "buildcurrent=$current"
    "sac=$(Get-SmartAppControlState)"
}

# BlueSpark.exe's first question (18 Nov, the owner: "if there is no update, the exe should just launch the game, skipping the setup steps"): one line,
#   LAUNCH|play                      installed, the build is this package's, no newer release: start the game now
#   LAUNCH|update|<label>|<notes>    a newer release is in the feed (notes joined with " ; "): ask Update or Play
#   LAUNCH|pages|<why>               not installed, or the build or the game files are not current: the setup pages
# Cheap on purpose (no toolchain check: a build that is current runs without it) and never blocking an offline start: the feed gets 2 seconds, and any answer
# short of a newer release is "play". Only a public package (track=release) looks at the feed, as Step-Update does.
function Step-LaunchCheck {
    $exe = Join-Path $Rex 'out\build\win-amd64-release\ttt2.exe'
    if (-not (Test-Path -LiteralPath $exe)) { Write-Host 'LAUNCH|pages|no build yet'; return }
    $version = Join-Path $Repo 'VERSION.txt'
    $built = Join-Path $Rex 'out\build\win-amd64-release\package-version.txt'
    if (Test-Path -LiteralPath $version) {
        if (-not (Test-Path -LiteralPath $built) -or "$(Get-Content -LiteralPath $built -Raw)".Trim() -ne "$(Get-Content -LiteralPath $version -Raw)".Trim()) { Write-Host 'LAUNCH|pages|the build is not this package''s'; return }
    }
    $gameFile = Join-Path $Rex 'game-folder.txt'
    $gameNamed = if (Test-Path -LiteralPath $gameFile) { "$(Get-Content -LiteralPath $gameFile -TotalCount 1)".Trim() } else { '' }
    if ($gameNamed -and -not (Test-Path -LiteralPath (Join-Path $gameNamed 'default.xex'))) { Write-Host 'LAUNCH|pages|the game folder is gone'; return }
    if (-not ((Test-Path -LiteralPath (Join-Path $Base 'files.done')) -and (Test-Path -LiteralPath (Join-Path $Repo 'gamedata\default_tu.xex')))) { Write-Host 'LAUNCH|pages|the game files are not extracted'; return }
    $info = Read-PackageInfo
    if ($info.track -eq 'release') {
        $url = if ($UpdateUrl) { $UpdateUrl } else { 'https://raw.githubusercontent.com/avim2/BlueSpark/main/latest.json' }
        try {
            $feed = Read-Feed $url 2
            if ($feed.release -and [int]$feed.release -gt $info.patch) {
                $label = if ($feed.name) { "$($feed.name)" } else { "Release $($feed.release)" }
                $notes = (@($feed.notes) | Where-Object { $_ } | ForEach-Object { "$_" -replace '[\r\n|]+', ' ' }) -join ' ; '
                Write-Host ('LAUNCH|update|{0}|{1}' -f $label, $notes)
                return
            }
        } catch { }
    }
    Write-Host 'LAUNCH|play'
}

# The update (the lead's order of 17 Oct, the owner's word): the newest package of this track from the feed
# (latest.json; -UpdateUrl a URL or a local folder holding latest.json and the zip), downloaded, checked
# (the size and the SHA-256), unzipped, and its top folder's contents copied over this install folder,
# whatever the player named it. Never a file deleted; rex\userdata, gamedata\, rex\out\ and
# rex\game-folder.txt never touched. The launcher restarts itself afterwards and runs Build.
$NeverTouched = @('rex\userdata', 'gamedata', 'rex\out', 'rex\game-folder.txt')

function Read-PackageInfo {
    $info = @{ track = 'main'; patch = 0; commit = '' }
    $file = Join-Path $Rex 'package-info.txt'
    if (Test-Path -LiteralPath $file) {
        foreach ($line in Get-Content -LiteralPath $file) {
            if ($line -match '^(\w+)=(.*)$') { $info[$Matches[1]] = $Matches[2].Trim() }
        }
        $info.patch = [int]$info.patch
    }
    return $info
}
# (A release by its package-info name, "Release 4.1", as players know it; else "Release <patch>". The lead's 77cdf86.)
function Release-Label($p) { if ($p.name) { "$($p.name)" } else { "Release $($p.patch)" } }

# The feed: a local folder's latest.json, or the URL's (5 s).
function Read-Feed($updateUrl, [int]$timeout = 5) {
    if (Test-Path -LiteralPath $updateUrl -PathType Container) {
        return (Get-Content -LiteralPath (Join-Path $updateUrl 'latest.json') -Raw | ConvertFrom-Json)
    }
    return Invoke-RestMethod $updateUrl -TimeoutSec $timeout -Headers @{ 'User-Agent' = 'ttt2-launcher' }
}

function Feed-Base($updateUrl) {
    if (Test-Path -LiteralPath $updateUrl -PathType Container) { return $updateUrl }
    return $updateUrl.Substring(0, $updateUrl.LastIndexOf('/') + 1)
}

# The PGO profile (the owner, 18 Nov: "Ship build as normal and include profile as download"): a second file of the release, never
# in git and not in the zip. WHAT CHECKS IT (the lead's ruling 18 Nov: under the owner's signature, no new signing step): the expected
# SHA-256 is NOT the feed's. Packaging writes it into the package info (rex\package-info.txt: pgo_sha256=<hex>, recomp\tools\
# make_playtest_package.py from TTT2_PGO_PROFILE_FILE), the owner's package signature covers that file, and Test-ReleaseZip
# verified it before this runs. The feed gives only where the file is: profile = { file, size }, file a plain name beside the
# feed (a folder feed too) or an https URL, size checked when the feed gives it. Update fetches the file after the zip
# (Get-PgoProfile) to <TTT2Native>\profile\ttt2-pgo.profdata, renamed only when its SHA-256 is the package's. The build
# (Set-PgoForBuild) sets TTT2_PGO_AUTO=1 and TTT2_PGO_PROFILE=<the file> only when the kept file is the package's hash: a
# profile of other code has another hash, so there is no separate stale test. Anything else (no hash in the package, no
# file, bad name, http, wrong size, wrong hash, download fails) = today's build, no error, one line
# "PGO profile: not used (<reason>)". Neither function ever throws.
$PgoDir = Join-Path $Base 'profile'
$PgoFile = Join-Path $PgoDir 'ttt2-pgo.profdata'
function Get-PgoProfile($entry, [string]$feedBase) {
    $tmp = Join-Path $PgoDir 'ttt2-pgo.profdata.part'
    try {
        $want = "$((Read-PackageInfo).pgo_sha256)".Trim().ToLower()
        if ($want -notmatch '^[0-9a-f]{64}$') { Say 'PGO profile: not used (this release names no profile)'; return }
        $pr = $entry.profile
        $name = if ($pr) { "$($pr.file)" } else { '' }
        if (-not $name) { Say 'PGO profile: not used (the feed has no profile file for this release)'; return }
        # (A kept copy that is the package's is used again.)
        if ((Test-Path -LiteralPath $PgoFile) -and (Get-FileHash -LiteralPath $PgoFile -Algorithm SHA256).Hash.ToLower() -eq $want) { Say 'PGO profile: the kept copy is this release''s'; return }
        $isUrl = $name -match '^[a-z][a-z0-9+.-]*://'
        if ($isUrl) { if ($name -notmatch '^https://') { Say 'PGO profile: not used (its address is not https)'; return } }
        elseif ($name -match '[\\/]' -or $name -match '\.\.' -or $name -match '[:*?"<>|]') { Say 'PGO profile: not used (the feed''s file name is not a plain file name)'; return }
        $url = if ($isUrl) { $name } elseif (Test-Path -LiteralPath $feedBase -PathType Container) { '' } else { $feedBase + $name }
        if ($url -and $url -notmatch '^https://') { Say 'PGO profile: not used (its address is not https)'; return }
        New-Item -ItemType Directory -Force $PgoDir | Out-Null
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
        if ($url) { Download $url $tmp $want } else { Copy-Item -LiteralPath (Join-Path $feedBase $name) $tmp -ErrorAction Stop }
        $size = (Get-Item -LiteralPath $tmp).Length
        if ($pr.size -and [long]$pr.size -ne $size) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue; Say "PGO profile: not used (it is $size bytes, the feed says $($pr.size))"; return }
        if ((Get-FileHash -LiteralPath $tmp -Algorithm SHA256).Hash.ToLower() -ne $want) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue; Say 'PGO profile: not used (its SHA-256 is not the one this release''s package names)'; return }
        Move-Item -LiteralPath $tmp $PgoFile -Force
        Say "PGO profile: downloaded and checked against the package ($size bytes)"
    } catch {
        Say "PGO profile: not used (download failed: $($_.Exception.Message))"
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    }
}
function Set-PgoForBuild {
    try {
        $want = "$((Read-PackageInfo).pgo_sha256)".Trim().ToLower()
        if ($want -notmatch '^[0-9a-f]{64}$') { Say 'PGO profile: not used (this release names no profile)'; return }
        if (-not (Test-Path -LiteralPath $PgoFile)) { Say 'PGO profile: not used (none downloaded)'; return }
        if ((Get-FileHash -LiteralPath $PgoFile -Algorithm SHA256).Hash.ToLower() -ne $want) { Say 'PGO profile: not used (the kept file is not the one this release names)'; return }
        $env:TTT2_PGO_AUTO = '1'
        $env:TTT2_PGO_PROFILE = $PgoFile
        Say "PGO profile: used ($([int]((Get-Item -LiteralPath $PgoFile).Length / 1KB)) KB)"
    } catch { Say "PGO profile: not used ($($_.Exception.Message))" }
}

function Copy-Over($from, $to, $relative) {
    # Every file of the unzipped package copied over the install folder, the untouched paths skipped,
    # nothing deleted.
    foreach ($item in Get-ChildItem -LiteralPath $from -Force) {
        $rel = if ($relative) { "$relative\$($item.Name)" } else { $item.Name }
        if ($NeverTouched -contains $rel) { continue }
        $target = Join-Path $to $item.Name
        if ($item.PSIsContainer) {
            New-Item -ItemType Directory -Force $target | Out-Null
            Copy-Over $item.FullName $target $rel
        } else {
            try { Copy-Item -LiteralPath $item.FullName $target -Force }
            catch {
                # (BlueSpark.exe is the program running this update: Windows will not overwrite a running exe but lets it be renamed. The old one is
                # set aside as <name>.old-<n> and removed by a later start (Remove-OldSetupExes in setup_main.cpp).)
                if ((Test-Path -LiteralPath $target) -and $item.Name -like '*.exe') {
                    Move-Item -LiteralPath $target "$target.old-$([guid]::NewGuid().ToString('N').Substring(0, 6))" -Force
                    Copy-Item -LiteralPath $item.FullName $target -Force
                } else { throw }
            }
        }
    }
}

# An antivirus that took the downloaded zip: the file operation throws "the file contains a virus or potentially unwanted
# software" (a player's 4.5 update, 29 Oct: a false alarm on the feed's zip), or the file is gone under it. Said plainly, not as a raw error.
function Stop-IfAntivirusBlocked($failure) {
    $text = "$($failure.Exception.Message)"
    $hresult = $failure.Exception.HResult
    $zipGone = $text -match 'update-download' -and $text -match 'Cannot find path|Could not find'
    if ($text -match 'virus|potentially unwanted' -or $hresult -eq -2147024671 -or $hresult -eq -2147024670 -or $zipGone) {
        throw ("Windows Security (or another antivirus) blocked the update's download, so nothing was changed and your build still works. " +
               "This is a false alarm on a new file. To update: open Windows Security > Virus & threat protection > Protection history, " +
               "find the blocked item, choose Actions > Allow, then press Check for updates again.")
    }
}

# Windows Smart App Control (S-16): on, it may block programs built on this PC, and setup builds the game here, so the game may not start. It only WARNS (4.7.3: one PC's
# evidence, the "on" path never seen, and a wrong block would stop a player whose game works). 0 off, 1 on, 2 evaluation (a missing key or value, or any read error,
# is 0: this check never fails a step by itself). TTT2_TEST_SAC_STATE (0, 1 or 2) replaces the read, for tests. The state is in `status` ("sac=") and the problem report.
function Get-SmartAppControlState {
    if ($env:TTT2_TEST_SAC_STATE -match '^[012]$') { return [int]$env:TTT2_TEST_SAC_STATE }
    try {
        $value = (Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy' -Name VerifiedAndReputablePolicyState -ErrorAction Stop).VerifiedAndReputablePolicyState
        if ($value -in 0, 1, 2) { return [int]$value }
    } catch { }
    return 0
}
function Get-SmartAppControlText {
    return ("Smart App Control is on. It blocks programs that are built on this PC, and this game is built on your PC during setup, so Windows may not let it start. " +
            "If it does not start, this is why. To play, Smart App Control has to be turned off: Windows Security > App & browser control > Smart App Control settings. " +
            "Windows does not let it be turned back on without resetting Windows, so that choice is yours.")
}
function Warn-IfSmartAppControlOn {
    $state = Get-SmartAppControlState
    if ($state -eq 1) { Say ('Warning: ' + (Get-SmartAppControlText) + ' Setup carries on.') }
    if ($state -eq 2) { Say 'Smart App Control is in evaluation mode: carrying on.' }
}
# (A step that failed on a PC with Smart App Control on says so too, as the antivirus's explanation above does.)
function Add-SmartAppControlToFailure($failure) {
    if ((Get-SmartAppControlState) -ne 1) { return }
    throw ("$($failure.Exception.Message)" + [Environment]::NewLine + [Environment]::NewLine + (Get-SmartAppControlText))
}

# The updater's clone guard (11 Nov, the main line's lead; launcher.ps1 has the same): a folder with a .git is a developer's clone, not an install: nothing is downloaded or copied, one plain
# line, a non-zero exit. No override.
function Stop-IfDeveloperClone {
    if (Test-Path -LiteralPath (Join-Path $Repo '.git')) {
        Say "this folder is a developer's clone, not an install: the update is not applied"
        exit 3
    }
}
function Step-Update {
    Stop-IfDeveloperClone
    $info = Read-PackageInfo
    # (24 Nov, report 50: BlueSpark.exe runs this step without -UpdateUrl (no --feed): the empty string went to Read-Feed and the update failed with
    # "Cannot bind argument to parameter 'LiteralPath' because it is an empty string". Empty = the public feed, as the other steps already read it.)
    if (-not $UpdateUrl) { $UpdateUrl = 'https://raw.githubusercontent.com/avim2/BlueSpark/main/latest.json' }
    $feed = Read-Feed $UpdateUrl
    # (The public feed is flat: one build line, "release" N; only a public package, track=release, takes it.)
    if ($info.track -ne 'release') { throw "This is an internal $($info.track) package: it does not update from the public feed." }
    $entry = $feed
    if (-not $entry.release) { throw 'The feed has no release number.' }
    $entry | Add-Member -NotePropertyName patch -NotePropertyValue ([int]$entry.release) -Force
    if ([int]$entry.patch -le $info.patch) { Say "Release $($entry.patch) is out; this is Release $($info.patch): nothing to do."; return }
    if ($Patch -and [int]$entry.patch -ne $Patch) { Say "The feed says Patch $($entry.patch) now, not $Patch; taking it." }
    Say "Updating to Release $($entry.patch) (built from $($entry.commit), $($entry.date))."
    foreach ($note in @($entry.notes)) { Say "  - $note" }
    # (Its own folder: TTT2Native\update is where an ISO install keeps its title update, and this one is deleted.)
    $work = Join-Path $Base 'update-download'
    Remove-Ttt2Folder $work
    New-Item -ItemType Directory -Force $work | Out-Null
    $zip = Join-Path $work (Split-Path $entry.zip -Leaf)
    $base = Feed-Base $UpdateUrl
    if ("$($entry.zip)" -match '^https?://') {
        Download $entry.zip $zip   # (an absolute URL: a GitHub Release asset)
    } elseif (Test-Path -LiteralPath $base -PathType Container) {
        Copy-Item -LiteralPath (Join-Path $base $entry.zip) $zip
    } else {
        Download ($base + $entry.zip) $zip
    }
    $size = (Get-Item -LiteralPath $zip).Length
    if ([long]$entry.size -ne $size) { throw "The download is $size bytes, the feed says $($entry.size): the current build is kept. (It will be tried again at the next start.)" }
    $sha = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower()
    if ($sha -ne "$($entry.sha256)".ToLower()) { throw "The download's SHA-256 does not match the feed's: the current build is kept. (It will be tried again at the next start.)" }
    # (The feed's own SHA-256 says only that the zip is the one the feed names. As a dropped zip is (Step-UpdateFile),
    # the zip is checked too: the owner's signature over its file list, every file as listed, no entry outside its
    # folder, and a release of this track. The lead's 77cdf86: a must before the builds repo goes public.)
    . (Join-Path $Rex 'tools\package-check.ps1')
    $check = Test-ReleaseZip $zip
    if (-not $check.ok) { throw "$($check.why) The current build is kept." }
    if ($check.info.track -ne $info.track) { throw "The feed's zip is a $($check.info.track) package, and this folder is a $($info.track) one: the current build is kept." }
    Say "Downloaded and checked ($size bytes, signed)."
    Install-Zip $zip $work
    Get-PgoProfile $entry $base
    $now = Read-PackageInfo
    Say "Updated to $(Release-Label $now). BlueSpark restarts and builds."
}

# A checked package zip unzipped in $work and its top folder copied over this install (the update's and the
# downloaded zip's way alike): no file deleted but the old Qt app's listed ones (Remove-OldQtApp); rex\userdata, gamedata\,
# rex\out\, rex\game-folder.txt kept.
# BlueSpark.exe is the entry now (18 Nov, the owner via the helper lead): an install updated in place (by an older launcher, or by Setup) keeps no way into the old menu. A shortcut (Desktop, Start menu, the taskbar's pins) that pointed
# at Start Here.cmd points at BlueSpark.exe; 24 Nov (5.1, the owner): "Start Here.cmd" goes, but at BlueSpark.exe's next start (setup_main.cpp), not here. Nothing is deleted here; nothing outside those shortcut folders is looked through.
function Hand-OverToBlueSpark($folder) {
    $exe = Join-Path $folder 'BlueSpark.exe'
    if (-not (Test-Path -LiteralPath $exe)) { return }
    $dirs = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('CommonDesktopDirectory'), [Environment]::GetFolderPath('Programs'), [Environment]::GetFolderPath('CommonPrograms'),
              (Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar')) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
    $names = @((Join-Path $folder 'Start Here.cmd'), (Join-Path $folder 'StartHere.cmd'))
    try {
        $shell = New-Object -ComObject WScript.Shell
        foreach ($d in $dirs) {
            foreach ($l in @(Get-ChildItem -LiteralPath $d -Filter *.lnk -Recurse -File -ErrorAction SilentlyContinue)) {
                try {
                    $sc = $shell.CreateShortcut($l.FullName)
                    if ($names -contains $sc.TargetPath) {
                        $sc.TargetPath = $exe; $sc.Arguments = ''; $sc.WorkingDirectory = $folder; $sc.IconLocation = "$exe,0"; $sc.Save()
                        Say "The shortcut $($l.Name) starts BlueSpark.exe."
                    }
                } catch { }
            }
        }
    } catch { }
    # (24 Nov, 5.1: Start Here.cmd is NOT deleted here (the lead: a batch file still being read by the cmd that started this update would break): BlueSpark.exe deletes it at its next ordinary start, when nothing runs from it.)
}
function Install-Zip($zip, $work) {
    $unzipped = Join-Path $work 'unzipped'
    Expand-Archive -LiteralPath $zip -DestinationPath $unzipped -Force
    $top = Get-ChildItem -LiteralPath $unzipped -Directory | Select-Object -First 1
    if (-not $top) { throw 'The package has no top folder.' }
    $newInfo = Join-Path $top.FullName 'rex\package-info.txt'
    if ((Test-Path -LiteralPath (Join-Path $Repo '.git')) -and (Test-Path -LiteralPath $newInfo) -and (@(Get-Content -LiteralPath $newInfo) -contains 'layout=prebuilt')) {
        throw "$Repo is a git checkout (it has a .git folder): a prebuilt package is not copied over it. Unzip it into its own folder."
    }
    Test-PrebuiltHashes $top.FullName
    # (The old package's own list, read before the copy writes the new one over it: Remove-OldQtApp below.)
    $oldList = Join-Path $Rex 'package-files.txt'
    $oldFiles = if (Test-Path -LiteralPath $oldList) { @(Get-Content -LiteralPath $oldList | Where-Object { "$_".Trim() }) } else { @() }
    Say "Copying $($top.Name) over $Repo (your saves, game files and builds are not touched)."
    Copy-Over $top.FullName $Repo ''
    # (The copy is checked before the step says it updated (4.5): this folder's package-info must now be the zip's. A copy
    # that silently left the old one (a file in use, a folder the player can't write) said "Updated" and Start Here then
    # showed "... was installed, but this folder says ..." with nothing the player could do.)
    if (Test-Path -LiteralPath $newInfo) {
        $installed = Join-Path $Rex 'package-info.txt'
        $want = (Get-Content -LiteralPath $newInfo -Raw).Trim()
        $have = if (Test-Path -LiteralPath $installed) { (Get-Content -LiteralPath $installed -Raw).Trim() } else { '' }
        if ($have -ne $want) {
            throw "The update was copied, but this folder's rex\package-info.txt is still the old one, so the copy did not go through. Close the game and every BlueSpark window, then drag the zip onto BlueSpark again. If it fails again, unzip the zip into a new folder and run BlueSpark there."
        }
    }
    Remove-OldQtApp ($oldFiles + (Get-OldQtAppList)) (Join-Path $top.FullName 'rex\package-files.txt')
    # A prebuilt package over an older source-layout folder: the old sources and the old build go (a stale exe and
    # objects); the old SDK folder is offered for deletion after the first build, never deleted here.
    if ((Test-Path -LiteralPath $newInfo) -and (@(Get-Content -LiteralPath $newInfo) -contains 'layout=prebuilt')) { Convert-ToPrebuiltLayout }
    Hand-OverToBlueSpark $Repo
    $null = Remove-Ttt2Folder $work -Quiet
}

# The Qt app's files an older package left (P5's release step, Release 19: BlueSpark is the game's own pages, so a package
# ships no fastclient\ now, and an update deletes nothing by itself: Copy-Over). Only the files the previous package's
# package-files.txt listed under fastclient\ go, and only those the new package's list doesn't have; anything else in that
# folder (a player's own file) stays, and so does the folder when anything is left in it. Not while the Qt app runs (an
# exe in use can't go): the files are left and said so, for the next update or the player.
# (Release 18's list, shipped as rex\old-qt-app-files.txt: the update from 4.6.3 runs 4.6.3's own Install-Zip, which deletes nothing and
# writes the new package-files.txt over the old, so the new build and play steps remove those files themselves.)
function Get-OldQtAppList {
    $file = Join-Path $Rex 'old-qt-app-files.txt'
    if (-not (Test-Path -LiteralPath $file)) { return @() }
    @(Get-Content -LiteralPath $file | Where-Object { "$_".Trim() -and -not "$_".StartsWith('#') })
}
function Remove-OldQtAppNow {
    # (A package install only: a git checkout has fastclient\ as source, and no package-files.txt to say what is the package's.)
    if (-not (Test-Path -LiteralPath (Join-Path $Repo 'fastclient')) -or (Test-Path -LiteralPath (Join-Path $Repo '.git')) -or
        -not (Test-Path -LiteralPath (Join-Path $Rex 'package-files.txt'))) { return }
    try { Remove-OldQtApp (Get-OldQtAppList) (Join-Path $Rex 'package-files.txt') } catch { Say "The old BlueSpark app's files weren't removed: $($_.Exception.Message)" }
}
function Remove-OldQtApp([string[]]$oldFiles, [string]$newList) {
    if (Test-Path -LiteralPath (Join-Path $Repo '.git')) { return }   # (never in a git checkout: its fastclient\ is source)
    $old = @($oldFiles | ForEach-Object { "$_".Trim() } | Where-Object { $_ -like 'fastclient/*' -and $_ -notmatch '(^|/)\.\.(/|$)' })
    if (-not $old.Count) { return }
    $new = if (Test-Path -LiteralPath $newList) { @(Get-Content -LiteralPath $newList | ForEach-Object { "$_".Trim() }) } else { @() }
    $gone = @($old | Where-Object { $new -notcontains $_ -and (Test-Path -LiteralPath (Join-Path $Repo ($_ -replace '/', '\')) -PathType Leaf) })
    if (-not $gone.Count) { return }   # (none left: quiet, as at every Play once they've gone)
    $root = Join-Path $Repo 'fastclient'
    $running = @(Get-Process ttt2-fastclient -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path.StartsWith("$root\", [StringComparison]::OrdinalIgnoreCase) })
    if ($running.Count) { Say "The old BlueSpark app is running, so its files in $root are left; close it, and the next update removes them."; return }
    $removed = 0; $folders = @{}
    foreach ($rel in $gone) {
        $path = Join-Path $Repo ($rel -replace '/', '\')
        if (Test-Path -LiteralPath $path -PathType Leaf) {
            try { Remove-Item -LiteralPath $path -Force -ErrorAction Stop; $removed++ } catch { Say "Couldn't remove $path ($($_.Exception.Message)): left." }
        }
        for ($d = Split-Path $path -Parent; $d.Length -ge $root.Length; $d = Split-Path $d -Parent) { $folders[$d] = $true }
    }
    # (Emptied folders only, the deepest first: a folder still holding anything stays.)
    foreach ($d in @($folders.Keys | Sort-Object Length -Descending)) {
        if ((Test-Path -LiteralPath $d -PathType Container) -and -not @(Get-ChildItem -LiteralPath $d -Force).Count) { Remove-Item -LiteralPath $d -Force }
    }
    Say "The old BlueSpark app's files: $removed of $($gone.Count) removed (BlueSpark is in the game now)."
}

# The package's own check (a zip from Discord has no feed to say its size and hash): each binary rex\prebuilt\manifest.txt
# names, unzipped, against its SHA-256 there. A damaged or partial download stops here, before anything is copied.
function Test-PrebuiltHashes($top) {
    $manifest = Join-Path $top 'rex\prebuilt\manifest.txt'
    if (-not (Test-Path -LiteralPath $manifest)) { return }
    $bad = 0; $checked = 0
    foreach ($line in Get-Content -LiteralPath $manifest) {
        if ($line -notmatch '^file\.(.+?)=([0-9a-fA-F]{64})$') { continue }
        $rel = $Matches[1]; $want = $Matches[2].ToLower()
        $path = Join-Path (Join-Path $top 'rex\prebuilt') $rel
        if (-not (Test-Path -LiteralPath $path)) { $found = @(Get-ChildItem -LiteralPath (Join-Path $top 'rex\prebuilt') -Recurse -File -Filter (Split-Path $rel -Leaf)); $path = if ($found.Count) { $found[0].FullName } else { '' } }
        if (-not $path -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower() -ne $want) { $bad++ } else { $checked++ }
    }
    if ($bad) { throw "$bad of the package's files don't match its own list: the download is damaged. Download the zip again. Your current build is kept." }
    Say "The package's $checked files match its own list."
}

# A release zip the player downloaded (the lead's order of 24 Oct: releases are posted on the owner's Discord, whose
# links expire, so Start Here can't fetch them): checked as ours, the same track, newer (or the player said yes), its
# SHA-256 if given (-Sha256, or a <zip>.sha256 beside it), then installed as an update.
function Step-UpdateFile {
    Stop-IfDeveloperClone
    if (-not $ZipFile -or -not (Test-Path -LiteralPath $ZipFile -PathType Leaf)) { throw "There's no file at $ZipFile." }
    $info = Read-PackageInfo
    # (Start Here checked it before asking; checked again here, before it's unzipped: the owner's signature over its
    # file list, every file as listed, no entry outside its folder. rex\tools\package-check.ps1.)
    . (Join-Path $Rex 'tools\package-check.ps1')
    $check = Test-ReleaseZip $ZipFile
    if (-not $check.ok) { throw $check.why }
    $zipInfo = $check.info
    if ($zipInfo.track -ne $info.track) { throw "$(Split-Path $ZipFile -Leaf) is a $($zipInfo.track) package, and this folder is a $($info.track) one: it isn't installed here." }
    if ($zipInfo.patch -le $info.patch -and -not $AllowOlder) { throw "$(Split-Path $ZipFile -Leaf) is $(Release-Label $zipInfo), and this folder is $(Release-Label $info) already." }
    $want = $Sha256
    $side = "$ZipFile.sha256"
    if (-not $want -and (Test-Path -LiteralPath $side)) { $want = ((Get-Content -LiteralPath $side -Raw) -split '\s+')[0] }
    if ($want) {
        $sha = (Get-FileHash -LiteralPath $ZipFile -Algorithm SHA256).Hash
        if ($sha -ne $want.Trim()) { throw "The zip's fingerprint (SHA-256) isn't the one in the post: the download is damaged. Download it again." }
        Say 'The fingerprint matches the post.'
    }
    Say "Updating to $(Release-Label $zipInfo) from $(Split-Path $ZipFile -Leaf)."
    $work = Join-Path $Base 'update-download'
    Remove-Ttt2Folder $work
    New-Item -ItemType Directory -Force $work | Out-Null
    Install-Zip $ZipFile $work
    $now = Read-PackageInfo
    Say "Updated to $(Release-Label $now). BlueSpark restarts and builds."
}

# Start Here's rescue (the lead's order of 24 Oct, B): a new folder with no build, and an earlier install with one. This
# package is copied over that install, as an update is (its saves, game files and build kept), so it only relinks: the
# game's build folder knows its own folder's path, and copied into a new folder it would be built again from nothing.
# (Setup's quick start, a folder with no build: is there an earlier install, in a place Start Here's own installs.txt names? One line, ADOPT|<folder>|<its release label>, or nothing.
# Only an install that has a build and a steps script, is no git checkout, and is not newer than this package: nothing else on the PC is looked through.)
function Step-AdoptFind {
    $exe = 'rex\out\build\win-amd64-release\ttt2.exe'
    $mine = (Resolve-Path -LiteralPath $Repo).Path
    $thisInfo = Read-PackageInfo
    $file = Join-Path $Base 'installs.txt'
    $found = @()
    $lines = @(if (Test-Path -LiteralPath $file) { Get-Content -LiteralPath $file })
    foreach ($c in ($lines | Select-Object -Unique)) {
        $c = "$c".Trim()
        if (-not $c -or -not (Test-Path -LiteralPath (Join-Path $c $exe)) -or -not (Test-Path -LiteralPath (Join-Path $c 'rex\setup-steps.ps1')) -or (Test-Path -LiteralPath (Join-Path $c '.git'))) { continue }
        if ((Resolve-Path -LiteralPath $c).Path -eq $mine) { continue }
        $patch = 0; $name = ''
        $pi = Join-Path $c 'rex\package-info.txt'
        if (Test-Path -LiteralPath $pi) { foreach ($line in Get-Content -LiteralPath $pi) { if ($line -match '^patch=(\d+)') { $patch = [int]$Matches[1] }; if ($line -match '^name=(.+)$') { $name = $Matches[1].Trim() } } }
        if ($thisInfo.patch -gt 0 -and $patch -gt $thisInfo.patch) { continue }   # (an install newer than this package is not copied over)
        $found += [pscustomobject]@{ Folder = $c; Label = $(if ($name) { $name } elseif ($patch) { "Release $patch" } else { 'an earlier build' }); When = (Get-Item -LiteralPath (Join-Path $c $exe)).LastWriteTime }
    }
    if ($found.Count) { $best = $found | Sort-Object When | Select-Object -Last 1; Write-Host ('ADOPT|{0}|{1}' -f $best.Folder, $best.Label) }
}
function Step-Adopt {
    if (-not $Into -or -not (Test-Path -LiteralPath (Join-Path $Into 'rex\setup-steps.ps1'))) { throw "$Into isn't a TTT2 Native install." }
    if ((Resolve-Path -LiteralPath $Into).Path -eq (Resolve-Path -LiteralPath $Repo).Path) { throw 'That is this folder.' }
    if (Test-Path -LiteralPath (Join-Path $Into '.git')) { throw "$Into is a git checkout: nothing is copied over it." }
    Say "Copying this package over your previous install, $Into (its saves, game files and build are kept)."
    foreach ($item in Get-ChildItem -LiteralPath $Repo -Force) {
        if ($NeverTouched -contains $item.Name -or $item.Name -eq '.git') { continue }
        $target = Join-Path $Into $item.Name
        if ($item.PSIsContainer) { New-Item -ItemType Directory -Force $target | Out-Null; Copy-Over $item.FullName $target $item.Name }
        else { Copy-Item -LiteralPath $item.FullName $target -Force }
    }
    Hand-OverToBlueSpark $Into
    Say "Your previous install has this package now. Its BlueSpark opens and builds."
}

# The SDK folders a Visual Studio-era package built (several GB), which the prebuilt package doesn't use.
function Get-OldSdkFolders {
    @(Get-ChildItem -LiteralPath $env:USERPROFILE -Directory -Filter 'rexsdk-playtest*' -ErrorAction SilentlyContinue)
}

# (Setup's old-SDK box: what the Delete would remove, one line: OLDSDK|<GB>|<folder;folder>)
function Step-OldSdk {
    $folders = @(Get-OldSdkFolders)
    $bytes = 0
    foreach ($f in $folders) { $bytes += [long](@(Get-ChildItem -LiteralPath $f.FullName -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum)[0].Sum) }
    Write-Host ('OLDSDK|{0}|{1}' -f ([math]::Round($bytes / 1GB, 1)).ToString('F1', [Globalization.CultureInfo]::InvariantCulture), (($folders | ForEach-Object { $_.FullName }) -join ';'))
}

function Step-Cleanup {
    if (-not $Prebuilt) { throw 'Only the prebuilt package removes the old SDK folders.' }
    foreach ($d in Get-OldSdkFolders) {
        Say "Removing the old SDK folder $($d.FullName)"
        Remove-Ttt2Folder $d.FullName
    }
    Say 'Old SDK folders: removed.'
}

# The tools and game files to another data folder (Start Here's "Where to put the tools and game files", the lead's E):
# each of toolchain\, tools\, game\ and update\ moved (the same drive: renamed; another: robocopy /MOVE, with the bar),
# then the folder recorded and every install's rex\game-folder.txt that pointed into the old game folder pointed at the
# new one. Run again after a stop, it carries on (robocopy merges into what is there).
function Step-Move {
    if (-not $From -or -not $To) { throw 'move needs -From and -To.' }
    $from = [IO.Path]::GetFullPath($From).TrimEnd('\'); $to = [IO.Path]::GetFullPath($To).TrimEnd('\')
    if ($from -eq $to) { Set-Ttt2DataFolder $to; Say "The tools and game files: $to"; return }
    if ($to.StartsWith("$from\", [StringComparison]::OrdinalIgnoreCase)) { throw "The new folder can't be inside the old one ($from)." }
    New-Item -ItemType Directory -Force $to | Out-Null
    $parts = @($script:Ttt2DataParts | Where-Object { Test-Path -LiteralPath (Join-Path $from $_) })
    $sameDrive = (Get-Ttt2DriveName $from) -eq (Get-Ttt2DriveName $to)
    if (-not $sameDrive) {
        $gb = ($parts | ForEach-Object { Get-Ttt2FolderGB (Join-Path $from $_) } | Measure-Object -Sum).Sum
        $free = Get-Ttt2FreeGB $to
        if ($free -ge 0 -and $free -lt $gb + 0.5) { throw ("Moving the tools and game files needs about {0:N1} GB on {1}, which has {2:N1} GB free." -f ($gb + 0.5), (Get-Ttt2DriveName $to), $free) }
    }
    foreach ($part in $parts) {
        $src = Join-Path $from $part; $dst = Join-Path $to $part
        if ($sameDrive -and -not (Test-Path -LiteralPath $dst)) { Say "Moving $part"; Move-Item -LiteralPath $src $dst; continue }
        $total = [math]::Max([double]1, (Get-Ttt2FolderGB $src) * 1GB)
        Say ("Moving {0} ({1:N1} GB) to {2}" -f $part, ($total / 1GB), $to)
        $out = Join-Path $Base 'move.out.txt'
        $null = New-Item -ItemType Directory -Force -Path $Base
        $p = Start-Process robocopy.exe -ArgumentList @("`"$src`"", "`"$dst`"", '/E', '/MOVE', '/R:5', '/W:3', '/NFL', '/NDL', '/NP', '/NJH') `
            -NoNewWindow -PassThru -RedirectStandardOutput $out
        $null = $p.Handle
        while (-not $p.HasExited) {
            $left = [double](Get-ChildItem -LiteralPath $src -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
            Write-Host ("PROGRESS {0} Moving {1}" -f [math]::Min(99, [int](100 * (1 - $left / $total))), $part)
            Start-Sleep -Seconds 2
        }
        $p.WaitForExit()
        if ($p.ExitCode -ge 8) {
            Get-Content -LiteralPath $out -ErrorAction SilentlyContinue | Where-Object { $_.Trim() } | Select-Object -Last 6 | ForEach-Object { Say "robocopy: $_" }
            throw "Moving $part to $to failed (robocopy $($p.ExitCode)). What was moved is in $dst; click Change again to carry on."
        }
        $null = Remove-Ttt2Folder $src -Quiet   # (robocopy leaves the emptied folders)
        Write-Host "PROGRESS 100 Moved $part"
    }
    Set-Ttt2DataFolder $to
    # (Every install Start Here knows, and this one: its game folder, when it was inside the old data folder.)
    $installs = @($Repo) + @(if (Test-Path -LiteralPath (Join-Path $Base 'installs.txt')) { Get-Content -LiteralPath (Join-Path $Base 'installs.txt') })
    foreach ($install in ($installs | Where-Object { $_ } | Select-Object -Unique)) {
        $gf = Join-Path $install 'rex\game-folder.txt'
        if (-not (Test-Path -LiteralPath $gf)) { continue }
        $was = Read-Ttt2GameFolderFile $gf
        # a file that could not be read must not be skipped silently: the game was moved, that install still names the old place.
        if (-not $was -and $script:Ttt2GameFolderReadError) { throw "Could not read $gf ($script:Ttt2GameFolderReadError), so it was not checked after the data folder moved to $to. If that install cannot find the game, open its BlueSpark Setup (BlueSpark.exe --setup), click INSTALL and pick your game again on the Choose your game page." }
        if (-not $was) { Say "$install's game folder file is empty or damaged: left as it is. If that install cannot find the game, open its BlueSpark Setup (BlueSpark.exe --setup), click INSTALL and pick your game again on the Choose your game page."; continue }
        foreach ($part in 'game', 'update') {
            $old = Join-Path $from $part
            if ($was -eq $old -or $was.StartsWith("$old\", [StringComparison]::OrdinalIgnoreCase)) {
                $now = (Join-Path $to $part) + $was.Substring($old.Length)
                # as loud as the old Set-Content: the game was moved, so a file still naming the old place must not look saved.
                if (-not (Save-Ttt2GameFolder $gf $now)) { throw "Could not write $gf. The game files were moved to $to, but that install still names the old folder: open that install's BlueSpark Setup (BlueSpark.exe --setup), click INSTALL and pick your game again on the Choose your game page." }
                Say "$install's game folder: $now"
            }
        }
    }
    Say "The tools and game files: $to"
}

# Setup's picker page (rex\setup\setup_main.cpp) asks this script to check what the player picked, with Start Here's own rules
# (launcher.ps1's Choose: an ISO, or a folder with default.xex; Get-UpdateFileProblem; "Tools and game files: Change...": a TTT2Native
# folder in the picked one, not in a synced folder, with room). One line each, "PICK|what|ok" or "PICK|what|<the problem, plainly>";
# the data folder's line is "PICK|data|<folder>|<GB free or -1>|<drive>|<problem or empty>". -Commit keeps the picks the way Choose and
# Change do (game-source= and game-update= in launcher-settings.txt, data-folder.txt), once they all pass.
function Step-Pick {
    $oneLine = { param($t) ("$t" -replace '\s*[\r\n]+\s*', ' ').Trim() }
    $dataNew = $Data
    if ($To) {
        $picked = $To.TrimEnd('\')
        $dataNew = if ((Split-Path $picked -Leaf) -eq 'TTT2Native') { $picked } else { Join-Path $picked 'TTT2Native' }
        $dataNew = [IO.Path]::GetFullPath($dataNew)
    }
    $bad = $false
    $isIso = $false
    if ($Source) {
        $isIso = Test-Path -LiteralPath $Source -PathType Leaf
        $p = if ($isIso) { $null }
             elseif (Test-Path -LiteralPath $Source -PathType Container) {
                 if (Test-Path -LiteralPath (Join-Path $Source 'default.xex')) { $null }
                 else { "That folder has no default.xex. Pick the folder with default.xex and the data*.bin files (your game's disc, copied as it is)." }
             } else { 'That file or folder is not there.' }
        if ($p) { $bad = $true; Write-Host "PICK|game|$p" } else { Write-Host 'PICK|game|ok' }
    }
    if ($Update) {
        if ($p = Get-UpdateFileProblem $Update $Source) { $bad = $true; Write-Host "PICK|update|$(& $oneLine $p)" } else { Write-Host 'PICK|update|ok' }
    }
    $free = Get-Ttt2FreeGB $dataNew
    $note = ''
    if ($n = Get-Ttt2SyncedFolderNote $dataNew 'That folder') { $note = (& $oneLine $n) -replace 'Move the whole folder out of.*$', 'Choose a folder that is not synced.' }
    elseif ($n = Get-Ttt2NonAsciiPathNote $dataNew) { $note = (& $oneLine $n) -replace 'Move the whole folder to C:\ttt2.*$', 'Choose a folder whose path is plain letters and numbers.' }
    elseif ($free -lt 0) { $note = "That drive isn't there." }
    else {
        $haveTools = Test-Path -LiteralPath (Join-Path $dataNew 'toolchain')
        $problem = if ($haveTools) { $null } else { Get-Ttt2SpaceProblem 1 $dataNew 0 }
        if (-not $problem -and $isIso) { $problem = Get-Ttt2SpaceProblem 2 $dataNew (Get-Ttt2FolderGB (Join-Path $dataNew 'game')) }
        if ($problem) { $note = & $oneLine $problem }
    }
    if ($note) { $bad = $true }
    Write-Host ("PICK|data|{0}|{1}|{2}|{3}" -f $dataNew, $free.ToString('F1', [Globalization.CultureInfo]::InvariantCulture), (Get-Ttt2DriveName $dataNew), $note)
    if ($Commit) {
        if ($bad -or -not $Source -or -not $Update) { Write-Host 'PICK|commit|a pick is not right yet'; return }
        $file = Join-Path $Rex 'userdata\launcher-settings.txt'
        $lines = @(); if (Test-Path -LiteralPath $file) { $lines = @(Get-Content -LiteralPath $file | Where-Object { $_ -notmatch '^(game-source|game-update)=' }) }
        New-Item -ItemType Directory -Force (Split-Path $file -Parent) | Out-Null
        Set-Content -LiteralPath $file ($lines + "game-source=$Source" + "game-update=$Update")
        if ($To) { Set-Ttt2DataFolder $dataNew }
        Write-Host 'PICK|commit|ok'
    }
}

switch ($Step) {
    'move' { Step-Move }
    'pick' { Step-Pick }
    'cleanup' { Step-Cleanup }
    'oldsdk' { Step-OldSdk }
    'tools'  { Warn-IfSmartAppControlOn; Step-Tools }
    'files'  { Step-Files }
    'build'  { Warn-IfSmartAppControlOn; try { Step-Build } catch { Add-SmartAppControlToFailure $_; throw } }
    'play'   { Warn-IfSmartAppControlOn; try { Step-Play } catch { Add-SmartAppControlToFailure $_; throw } }
    'switches' { Step-Switches }
    'status' { Step-Status }
    'launchcheck' { Step-LaunchCheck }
    'adoptfind' { Step-AdoptFind }
    'handover' { Hand-OverToBlueSpark $(if ($Into) { $Into } else { $Repo }) }   # (the same thing an update and an adopt do at their end; the scripted checks run it alone)
    'update' { try { Step-Update } catch { Stop-IfAntivirusBlocked $_; throw } }
    'update-file' { try { Step-UpdateFile } catch { Stop-IfAntivirusBlocked $_; throw } }
    'adopt' { Step-Adopt }
}
