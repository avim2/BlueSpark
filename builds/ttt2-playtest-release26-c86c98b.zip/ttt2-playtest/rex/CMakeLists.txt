# ttt2 - ReXGlue Recompiled Project
#
# SDK boilerplate lives in generated/rexglue.cmake.

cmake_minimum_required(VERSION 3.25)
project(ttt2 LANGUAGES C CXX)
if(WIN32)
    enable_language(RC)   # (18 Nov: assets/app-icon/ttt2.rc gives ttt2.exe its own icon, the one Explorer and a pinned shortcut show)
endif()

set(CMAKE_CXX_STANDARD 23)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

include(generated/rexglue.cmake)

# Sources
set(TTT2_SOURCES
    src/determinism.cpp
    src/gpu_wait.cpp
    src/texture_prewarm.cpp
    src/pipeline_warmup.cpp
    src/first_start.cpp
    src/app_icon.cpp
    src/input_socd.cpp
    src/input_stick_dpad.cpp
    src/input_stick_modes.cpp
    src/test_pad_frames.cpp
    src/test_pad_frames_game.cpp
    src/training_match_counter_native.cpp
    src/match_counter.cpp
    src/match_counter_game.cpp
    src/match_counter_probe.cpp
    src/input_rstick_tag.cpp
    src/input_swallow.cpp
    src/switch_check.cpp
    src/customize_readback.cpp
    src/watch_lost.cpp
    src/xmem_between_test.cpp
    src/xmem_trace.cpp
    src/xapi_heap.cpp
    src/voice_audio.cpp
    src/update_popup.cpp
    src/replay_link.cpp
    src/speed_warning.cpp
    src/input_keys.cpp
    src/keyboard_input.cpp
    src/window_watch.cpp
    src/controller_setup.cpp
    src/ewgf_voice.cpp
    src/main_menu_entries.cpp
    src/voice_volume_row.cpp
    src/motion_blur_option.cpp
    src/vs_rematch.cpp
    src/mode_states.cpp
    src/quick_boot.cpp
    src/test_speed.cpp
    src/test_menu_script.cpp
    src/dev_overlays.cpp
    src/data_root.cpp
    src/unpaced.cpp
    src/mute.cpp
    src/session_marker.cpp
    src/timer_resolution.cpp
    src/stack_guard.cpp
    src/event_log.cpp
    src/bind_check.cpp
    src/vibration.cpp
    src/save_pairs.cpp
    src/music_loop.cpp
    src/music_copy.cpp
    src/menu_music.cpp
    src/mixer_host.cpp
    src/tunes_hooks.cpp
    src/tunes_library.cpp
    src/tunes_loudness.cpp
    src/tunes_mix.cpp
    src/tunes_player.cpp
    src/shader_tables.cpp
    src/ko_replay.cpp
    src/update_notice.cpp
    src/ranked_hud_record.cpp
    src/gamer_picture.cpp
    src/online_pass.cpp
    src/boot_splash.cpp
    src/fastclient_game.cpp
    src/fastclient_gin.cpp
    src/fastclient_pipe.cpp
    src/fastclient_roster.cpp
    src/fastclient_load.cpp
    src/fastclient_online.cpp
    src/fastclient_conn.cpp
    src/fastclient_boxes.cpp
    src/costume_choice.cpp
    src/costume_audit.cpp
    src/costume_preview.cpp
    src/select_undo.cpp
    src/pad_slots.cpp
    src/test_virtual_pads.cpp
    src/tournament_mode.cpp
    src/fastclient_select.cpp
    src/fastclient_guest.cpp
    src/fastclient_speed.cpp
    src/fastclient_states.cpp
    src/fastclient_ranked.cpp
    src/preferred_side.cpp
    src/direct_entry.cpp
    src/queue_from_practice.cpp
    src/menu_queue.cpp
    src/unlock_all.cpp
    src/unlock_layer.cpp
    src/unlock_layer_sets.cpp
    src/unlock_off.cpp
    src/unlock_row.cpp
    src/job_inline.cpp
    src/cpu_threads.cpp
    src/thread_policy.cpp
    src/mix_voices.cpp
    src/ttt2_mutex.cpp
    src/netplay.cpp
    src/bluespark/bs_input.cpp
    src/bluespark/bs_pages_ranked.cpp
    src/bluespark/bs_qwerty_keys.cpp
    src/bluespark/bs_afk.cpp
    src/bluespark/bs_hold_quit.cpp
    src/bluespark/bs_queue.cpp
    src/bluespark/bs_select.cpp
    src/bluespark/bs_hop.cpp
    src/bluespark/bs_padmap.cpp
    src/bluespark/bs_padstyle_game.cpp
    src/bluespark/bs_update.cpp
    src/bluespark/bs_walk_load.cpp
    src/bluespark/bs_challenger.cpp
    src/bluespark/bs_anywhere.cpp
    src/bluespark/bs_parked_play.cpp
    src/bluespark/bs_gfx.cpp
    src/bluespark/bs_gfx_d3d12.cpp
    src/bluespark/bs_gallery.cpp
    src/bluespark/bs_text.cpp
    src/bluespark/bs_anim.cpp
    src/bluespark/bs_art.cpp
    src/bluespark/bs_look.cpp
    src/bluespark/bs_kit.cpp
    src/bluespark/bs_kit_hints.cpp
    src/bluespark/bs_kit_input.cpp
    src/bluespark/bs_kit_draw.cpp
    src/bluespark/bs_kit_cvars.cpp
    src/bluespark/bs_kit_demo.cpp
    src/bluespark/bs_kit_fightpanel.cpp
    src/ttt2_settings.cpp
    src/bluespark/bs_icon_picker.cpp
    src/bluespark/bs_icon_picker_draw.cpp
    src/bluespark/bs_settings_screen.cpp
    src/bluespark/bs_settings_tab.cpp
    src/bluespark/bs_first_boot.cpp
    src/bluespark/bs_first_boot_draw.cpp
    src/bluespark/bs_first_boot_tab.cpp
    src/bluespark/bs_mic_test.cpp
    src/bluespark/bs_report.cpp
    src/bluespark/bs_benchmark.cpp
    src/benchmark_grade.cpp
    src/perf_overlay.cpp
    src/present_gap_stats.cpp
    src/bluespark/bs_settings_apply.cpp
    src/bluespark/bs_oneplay.cpp
    src/bluespark/bs_classic_create.cpp
    src/bluespark/bs_classic_online.cpp
    src/bluespark/bs_endcard.cpp
    src/bluespark/bs_cues.cpp
    src/bluespark/bs_pages_found.cpp
    src/bluespark/bs_shell.cpp
    src/bluespark/bs_widgets.cpp
    src/bluespark/bs_board.cpp
    src/bluespark/bs_replays.cpp
    src/bluespark/bs_watch.cpp
    src/bluespark/bs_lobby.cpp
    src/bluespark/bs_lobby2.cpp
    src/bluespark/bs_lobby_wait.cpp
    src/bluespark/bs_tourney.cpp
    src/bluespark/bs_tourney_desk.cpp
    src/bluespark/bs_tourney_chat.cpp
    src/bluespark/bs_tourney_prize.cpp
    src/bluespark/bs_tourney_fight.cpp
    src/bluespark/bs_links.cpp
    src/bluespark/bs_ranked_panels.cpp
    src/bluespark/bs_panels_test.cpp
    src/bluespark/bs_betapopup.cpp
    src/online/ttt2_online.cpp
    src/online/live_trace.cpp
    src/online/xnet_tunnel.cpp
    src/online/pair_play.cpp
    src/online/pair_save.cpp
    src/online/test_live_guard.cpp
    src/online/upnp.cpp
    src/online/turn_client.cpp
    src/online/turn_path.cpp
    src/online/peer_lost_trace.cpp
    src/online/fightsplice.cpp
    src/online/match_prefs.cpp
    src/online/rematch.cpp
    src/online/void_popup.cpp
    src/online/rematch_hooks.cpp
    src/online/stage_b_skip.cpp
    src/online/stage_c_fast.cpp
    src/online/stage_c_phases.cpp
    src/online/win_pose_skip.cpp
    src/online/lucky_box_skip.cpp
    src/online/online_full_stages.cpp
    src/online/ranked_range.cpp
    src/online/stage_c_trace.cpp
    src/online/stage_c_spike.cpp
    src/online/stage_c_direct.cpp
    src/online/prefight_void.cpp
    src/online/stage_c_states.cpp
    src/online/stage_c_fast_join.cpp
    src/online/queue_ready.cpp
    src/online/queue_stage.cpp
    src/online/result_trace.cpp
    src/online/queue_load_unpaced.cpp
    src/online/direct_xuid.cpp
    src/online/slotid_trace.cpp
    src/online/found_to_fight.cpp
    src/online/queue_options.cpp
    src/online/queue_modes.cpp
    src/online/queue_counts.cpp
    src/online/lobby_v2_client.cpp
    src/online/lobby_v2_feed.cpp
    src/online/tourney_client.cpp
    src/online/ranked_rank.cpp
    src/online/glicko_predict.cpp
    src/online/glicko_pc.cpp
    src/online/net_bars.cpp
    src/online/identity.cpp
    src/online/identity_transfer.cpp
    src/online/machine_id.cpp
    src/online/ban.cpp
    src/online/profile_backup.cpp
    src/online/profile_guard.cpp
    src/online/env_sync_pace.cpp
    src/test_save_plain.cpp
    src/online/link_kind.cpp
    src/online/online_api.cpp
    src/online/log_upload.cpp
    src/online/profile_icons.cpp
    src/online/voip.cpp
    src/online/voip_codec.cpp
    src/online/voip_audio.cpp
    src/online/voip_spatial.cpp
    src/profile.cpp
    src/safe_walk.cpp
    src/frame_timing.cpp
    src/main_probe.cpp
    src/mem_census.cpp
    src/fight_split.cpp
    src/gpu_lines.cpp
    src/warmup_hold.cpp
    src/splash_home.cpp
    src/machine_lines.cpp
    src/rand_isolate.cpp
    src/main.cpp
    src/render_same_frame.cpp
    src/present_watch.cpp
    src/mem_census.cpp
    src/draw_job_check.cpp
    src/vbuf_check.cpp
    src/crash_nets.cpp
    src/rollback.cpp
    src/run_ahead.cpp
    src/save_census.cpp
    src/savestate.cpp
    src/signal_wait.cpp
    src/sound_entries.cpp
    src/sound_isolate.cpp
    src/state_map.cpp
    src/task_trace.cpp
    src/ttt2_threads.cpp
    src/work_units.cpp
    src/swap_kick.cpp
    src/test_pad.cpp
    src/quick_fights.cpp
    src/training_log.cpp
    src/training_reader.cpp
    src/training_guest_read.cpp
    src/training_frames.cpp
    src/training_stance_act.cpp
    src/training_pad.cpp
    src/training_shortcuts.cpp
    src/training_input.cpp
    src/training_settings.cpp
    src/training_dummy.cpp
    src/training_dummy_hook.cpp
    src/training_recording.cpp
    src/training_key_replay.cpp
    src/training_recordings_file.cpp
    src/training_restart.cpp
    src/training_restart_hook.cpp
    src/training_hud.cpp
    src/training_menu.cpp
    src/training_hints.cpp
    src/training_drills.cpp
    src/training_punish_notice.cpp
    src/training_button_map.cpp
    src/training_button_table.cpp
    src/training_quick_select.cpp
    src/training_hold_request.cpp
    src/training_hold_request_game.cpp
    src/test_fight_steps.cpp
    src/test_offline_mode.cpp
    src/test_setup_sync.cpp
    src/save_busy.cpp
    src/training_quick_select_game.cpp
    src/training_quick_costumes.cpp
    src/training_costume_file.cpp
    src/training_costume_trace.cpp
    src/training_pacing_log.cpp
    src/training_pacing_spread.cpp
    src/training_pause_guard.cpp
    src/training_pause_values.cpp
    src/training_ui_timing.cpp
    src/training_ui_timing_log.cpp
    src/training_stage_pictures.cpp
    src/training_punish_list.cpp
    src/training_punish_build.cpp
    src/training_move_set.cpp
    src/training_frame_table.cpp
    src/training_frame_table_cache.cpp
    src/training_frame_table_disk.cpp
    src/training_move_list.cpp
    src/training_move_list_hook.cpp
    src/training_command_list.cpp
    src/training_command_list_read.cpp
    src/training_command_walk.cpp
    src/training_command_pin.cpp
    src/training_command_list_hook.cpp
    src/training_walls.cpp
    src/training_walls_hook.cpp
    src/training_wall_restart.cpp
    src/training_list_accuracy.cpp
    src/training_playback_escapes.cpp
    src/training_eye_trace.cpp
    src/training_drill_hook.cpp
    src/training_punish_choice.cpp
    src/training_overlay.cpp
    src/training_overlay_menu.cpp
    src/training_overlay_online.cpp
    src/training_overlay_hud.cpp
    src/training_overlay_panels.cpp
    src/training_overlay_kit.cpp
    src/training_overlay_kit_quick.cpp
    src/training_overlay_kit_replays.cpp
    src/training_overlay_kit_rest.cpp
    src/training_snappy.cpp
    src/training_footer_fit.cpp
    src/training_overlay_kit_parts.cpp
    src/training_overlay_kit_controller.cpp
    src/training_return_ticket.cpp
    src/training_return_ticket_game.cpp
    src/training_stage_log.cpp
    src/training_hud_feed.cpp
    src/training_break_timing.cpp
    src/training_menu_hook.cpp
    src/training_song_diag.cpp
    src/training_readouts.cpp
    src/training_search_practice.cpp
    src/training_seat.cpp
    src/training_reset_options.cpp
    src/training_function_button.cpp
    src/training_function_button_game.cpp
    src/training_online_letgo.cpp
    src/training_queue_rows.cpp
    src/training_queue_game.cpp
    src/training_replay_sparks.cpp
    src/hud_label_trace.cpp
    src/training_rage.cpp
    src/training_sweep_test.cpp
    src/training_health.cpp
    src/training_fonts.cpp
    src/icon_atlas.cpp
    src/icon_atlas_cfg.cpp
    src/training_portraits.cpp
    src/training_rewind.cpp
    src/training_rewind_strip.cpp
    src/training_replay.cpp
    src/rewind_set_test.cpp
    src/pending_mode_trace.cpp
    src/set_rewind.cpp
    src/set_rewind_clock.cpp
    src/set_rewind_xma.cpp
    src/m_dump.cpp
    src/stage_fx_probe.cpp
    src/set_rewind_free_guard.cpp
    src/training_sim_settings.cpp
    src/training_online_gate.cpp
    src/training_combo_test.cpp
    src/training_game_replay_log.cpp
    src/training_online_replay.cpp
    src/training_online_replay_play.cpp
    src/render_replay.cpp
    src/render_capture.cpp
    src/training_test_practice_ask.cpp
    src/ui_movie_guard.cpp
    src/pool_free_net.cpp
    src/training_online_test.cpp
    src/training_replay_cards.cpp
    src/training_replay_skips.cpp
    src/training_replay_snapshots.cpp
    src/replay_state_probe.cpp
    src/replay_back_chain.cpp
    src/replay_ahead_probe.cpp
    src/pause_probe.cpp
    src/pause_keep.cpp
    src/replay_pause_menu.cpp
    src/replay_pause_pad.cpp
    src/replay_pause_glue.cpp
    src/replay_pause_draw.cpp
    src/replay_scroll.cpp
    src/replay_scroll_glue.cpp
    src/benchmark.cpp
    src/benchmark_grade.cpp
    src/perf_overlay.cpp
    src/present_gap_stats.cpp
    src/replay_takeover_map.cpp
    src/replay_file_map.cpp
    src/replay_kit.cpp
    src/replay_kit_input.cpp
    src/training_process_memory.cpp
    src/training_tag_crash_delay.cpp
    src/training_tag_crash_delay_hook.cpp
    src/training_throw_choice.cpp
    src/training_replay_load.cpp
    src/training_own_profile.cpp
    src/training_queue_profile.cpp
    src/training_move_dump.cpp
    src/training_frame_table_dump.cpp
    src/training_replay_usage.cpp
    src/match_record.cpp
    src/match_setup_record.cpp
    src/match_setup_apply.cpp
    src/rerun_parts.cpp
    src/ripple_guard.cpp
    src/motion_reset.cpp
    src/moku_trace.cpp
    src/heap_check.cpp
    src/heap_neighbour.cpp
    src/font_guard.cpp
    src/ui_table_guard.cpp
    src/net_settle.cpp
)

# Voice chat's codec: libopus 1.5.2, vendored (third_party/opus), compiled into ttt2_ours.lib / the exe with the rest. The list and
# config.h are hand-written (no neural features, no SIMD run-time detection); a missing file stops the build here, not at the link.
# (The player's prebuilt package has the library inside ttt2_ours.lib and no sources: nothing to check there.)
if(NOT TTT2_PREBUILT)
include(third_party/opus/opus_sources.cmake)
foreach(_opus_src IN LISTS TTT2_OPUS_SOURCES)
    if(NOT EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/${_opus_src}")
        message(FATAL_ERROR "Voice chat needs libopus: ${_opus_src} is missing (rex/third_party/opus; the package list must carry it).")
    endif()
endforeach()
if(NOT EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/third_party/opus/include/opus.h" OR NOT EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/third_party/opus/config.h")
    message(FATAL_ERROR "Voice chat needs libopus: rex/third_party/opus/include/opus.h or config.h is missing.")
endif()
set_source_files_properties(${TTT2_OPUS_SOURCES} PROPERTIES
    COMPILE_DEFINITIONS "HAVE_CONFIG_H"
    COMPILE_OPTIONS "-w"
    INCLUDE_DIRECTORIES "${CMAKE_CURRENT_SOURCE_DIR}/third_party/opus;${CMAKE_CURRENT_SOURCE_DIR}/third_party/opus/celt;${CMAKE_CURRENT_SOURCE_DIR}/third_party/opus/silk;${CMAKE_CURRENT_SOURCE_DIR}/third_party/opus/silk/float;${CMAKE_CURRENT_SOURCE_DIR}/third_party/opus/include;${CMAKE_CURRENT_SOURCE_DIR}/third_party/opus/src")
list(APPEND TTT2_SOURCES ${TTT2_OPUS_SOURCES})
set_source_files_properties(src/online/voip_codec.cpp PROPERTIES INCLUDE_DIRECTORIES "${CMAKE_CURRENT_SOURCE_DIR}/third_party/opus/include")
endif()

# (native-gfx: the native renderer's units and the Linux port's, kept out of the main line's list so that a
# Windows build without TTT2_NATIVE_GFX_PLUME compiles exactly the main line's sources (the merge's rule, 5
# November: the Windows build unchanged). On Linux: the port's own units, rex/src/linux_stubs.cpp for the
# symbols of the main line's Windows-only units, which are left out here (one list, kept by native-gfx at
# each merge of the main line; rex/NATIVE_MERGE_REVIEW.md).)
# (native-gfx's test-only SDK observers (rex/patches/90, 91: the dual render's tee and the reference capture's draw
# observer): only in a test build (TTT2_NATIVE_TEST_OBSERVERS, set by rex/tools/native-test's -Dual and resolve dumps;
# always on Linux, the cloud's tools), never in a player's or a package's, native on or off.)
option(TTT2_NATIVE_TEST_OBSERVERS "native-gfx's test-only SDK observers (patches 90, 91)" OFF)
if(TTT2_NATIVE_TEST_OBSERVERS OR NOT WIN32)
    add_compile_definitions(TTT2_NATIVE_TEST_OBSERVERS=1)
endif()
if(TTT2_NATIVE_GFX_PLUME OR NOT WIN32)
    # (Our hooks inside the main line's files are under #if TTT2_NATIVE_UNITS.)
    add_compile_definitions(TTT2_NATIVE_UNITS=1)
    list(APPEND TTT2_SOURCES
        src/reference_capture.cpp
        src/native_gfx/native_graphics_system.cpp
        src/native_gfx/native_packets.cpp
        src/native_gfx/native_shader_dump.cpp
        src/native_gfx/native_shaders.cpp
        src/native_gfx/native_draw.cpp
        src/native_gfx/gpu_thread_cost.cpp
        src/native_gfx/ring_sampler.cpp
        src/native_gfx/native_host_vblank.cpp
        src/native_gfx/native_icon_atlas.cpp)
endif()
if(NOT WIN32)
    list(APPEND TTT2_SOURCES
        src/profile_posix.cpp
        src/ttt2_win32_posix.cpp
        src/linux_tree_diag.cpp
        src/linux_stubs.cpp)
    list(REMOVE_ITEM TTT2_SOURCES
        src/online/ban.cpp
        src/online/glicko_predict.cpp
        src/online/glicko_pc.cpp
        src/online/online_api.cpp
        src/online/pair_play.cpp
        src/online/profile_icons.cpp
        src/online/queue_counts.cpp
        src/online/ranked_rank.cpp
        src/safe_walk.cpp
        src/session_marker.cpp
        src/timer_resolution.cpp
        src/event_log.cpp
        src/stack_guard.cpp
        src/bluespark/bs_gfx_d3d12.cpp
        src/bluespark/bs_links.cpp
        src/bluespark/bs_lobby.cpp
        src/bluespark/bs_settings_tab.cpp
        src/bluespark/bs_lobby2.cpp
        src/online/lobby_v2_client.cpp
        src/online/lobby_v2_feed.cpp
        src/online/tourney_client.cpp
        src/bluespark/bs_tourney.cpp
        src/bluespark/bs_tourney_desk.cpp
        src/bluespark/bs_tourney_chat.cpp
        src/bluespark/bs_tourney_prize.cpp
        src/bluespark/bs_tourney_fight.cpp
        src/bluespark/bs_board.cpp
        src/bluespark/bs_shell.cpp
        src/bluespark/bs_input.cpp
        src/bluespark/bs_hold_quit.cpp
        src/render_capture.cpp
        src/crash_nets.cpp
        src/boot_splash.cpp
        src/fastclient_game.cpp
        src/fastclient_pipe.cpp
        src/gamer_picture.cpp
        src/online/link_kind.cpp
        src/online/machine_id.cpp
        src/online/xnet_tunnel.cpp
        src/pipeline_warmup.cpp
        src/present_watch.cpp
        src/ripple_guard.cpp
        src/training_process_memory.cpp
        src/tunes_loudness.cpp
        src/tunes_player.cpp
        src/update_popup.cpp
        src/replay_link.cpp
    )
endif()

# Release 3's prebuilt package (docs/PREBUILT_PACKAGE_PLAN). Both off: the sources compiled into the exe, as always.
#  - TTT2_OURS_LIB (the owner's rex\build-prebuilt.ps1): all of TTT2_SOURCES as the static library ttt2_ours, the exe
#    linking it whole.
#  - TTT2_PREBUILT (the player's package): no sources; rex/prebuilt/lib/ttt2_ours.lib linked whole.
# Whole, because the generated code names every hooked sub_X as a weak alias, and a weak reference never pulls a
# library member: a plain link would silently drop hooks and cvars (build-windows.ps1 checks ttt2.map for them).
option(TTT2_OURS_LIB "Build rex/src as the static library ttt2_ours, linked whole" OFF)
option(TTT2_FMA "The game's code compiled with the hardware fused multiply-add (-mfma) and no other fusing (-ffp-contract=off): the guest's single fmadds become one instruction instead of a std::fma library call, the same bits (15 Nov, Themail's CPU week; the owner said yes to the build). OFF = the plain exe." OFF)
option(TTT2_V3 "With TTT2_FMA: -march=x86-64-v3 (AVX2, FMA, BMI1/2, LZCNT, MOVBE) instead of only -mfma, still -ffp-contract=off (15 Nov, the owner: yes to the fast exe as x86-64-v3; the start must check the CPU for both). OFF = -mfma only." OFF)
set(TTT2_OPT "" CACHE STRING "A build variant for low-end CPUs (brief 37, 18 Nov; off: today's build): thinlto = ThinLTO; pgogen = the instrumented exe that writes a profile at the benchmark's end; pgo = ThinLTO + the profile TTT2_PGO_PROFILE. The recompiled code and our sources only (the SDK's libraries are prebuilt). No fight arithmetic changes: no -ffast-math, no contraction change.")
set(TTT2_PGO_PROFILE "" CACHE FILEPATH "With TTT2_OPT=pgo: the merged .profdata (llvm-profdata merge of the pgogen run's .profraw)")
option(TTT2_PREBUILT "Link the prebuilt rex/prebuilt/lib/ttt2_ours.lib (the player's package): no sources" OFF)
if(TTT2_PREBUILT)
    add_library(ttt2_ours STATIC IMPORTED)
    set_target_properties(ttt2_ours PROPERTIES IMPORTED_LOCATION "${CMAKE_CURRENT_SOURCE_DIR}/prebuilt/lib/ttt2_ours.lib")
    add_executable(ttt2 WIN32)
elseif(TTT2_OURS_LIB)
    add_library(ttt2_ours STATIC ${TTT2_SOURCES})
    target_include_directories(ttt2_ours PRIVATE ${CMAKE_CURRENT_SOURCE_DIR} src)
    target_link_libraries(ttt2_ours PRIVATE rex::runtime)
    rexglue_apply_target_settings(ttt2_ours)
    add_dependencies(ttt2_ours ttt2_codegen)
    add_executable(ttt2 WIN32)
elseif(WIN32)
    add_executable(ttt2 WIN32 ${TTT2_SOURCES})
else()
    add_executable(ttt2 ${TTT2_SOURCES})
endif()

if(WIN32)
    target_sources(ttt2 PRIVATE assets/app-icon/ttt2.rc)   # (19 Nov: beside the icon, not in src/: an installed older updater removes all of rex/src when it converts to the prebuilt layout)
endif()

rexglue_setup_target(ttt2 GPU_PLUGINS xenos)
if(TTT2_FMA AND NOT MSVC)
    # -ffp-contract=off is the point: with the FMA instruction available clang would fuse other a*b+c expressions (host code and generated code alike), and the fight's hashes would change.
    if(TTT2_V3)
        set(TTT2_FAST_FLAGS -march=x86-64-v3 -ffp-contract=off)
    else()
        set(TTT2_FAST_FLAGS -mfma -ffp-contract=off)
    endif()
    target_compile_options(ttt2 PRIVATE ${TTT2_FAST_FLAGS})
    if(TARGET ttt2_recomp AND NOT TTT2_RECOMP_OBJECTS_DIR)   # (22 Nov: not for the cached objects of build cache D, imported: they carry their flags) (the generated code is its own OBJECT library: that is where the 6,934 std::fma sites are; 15 Nov: build 1 had the flag on ttt2 only and the objects came out the same)
        target_compile_options(ttt2_recomp PRIVATE ${TTT2_FAST_FLAGS})
    endif()
    if(TTT2_OURS_LIB)
        target_compile_options(ttt2_ours PRIVATE ${TTT2_FAST_FLAGS})
    endif()
endif()
if(TTT2_OPT AND NOT MSVC)
    if(TTT2_OPT STREQUAL "thinlto")
        set(TTT2_OPT_FLAGS -flto=thin)
    elseif(TTT2_OPT STREQUAL "pgogen")
        set(TTT2_OPT_FLAGS -fprofile-instr-generate)
    elseif(TTT2_OPT STREQUAL "pgo")
        if(NOT EXISTS "${TTT2_PGO_PROFILE}")
            message(FATAL_ERROR "TTT2_OPT=pgo needs TTT2_PGO_PROFILE (the merged .profdata)")
        endif()
        set(TTT2_OPT_FLAGS -flto=thin -fprofile-instr-use=${TTT2_PGO_PROFILE} -Wno-profile-instr-unprofiled -Wno-profile-instr-out-of-date)
    else()
        message(FATAL_ERROR "TTT2_OPT is thinlto, pgogen or pgo")
    endif()
    target_compile_options(ttt2 PRIVATE ${TTT2_OPT_FLAGS})
    if(TARGET ttt2_recomp)
        target_compile_options(ttt2_recomp PRIVATE ${TTT2_OPT_FLAGS})
    endif()
    if(TTT2_OURS_LIB)
        target_compile_options(ttt2_ours PRIVATE ${TTT2_OPT_FLAGS})
    endif()
    if(TTT2_OPT STREQUAL "pgogen")
        # (the profile runtime: in the compiler's own resource folder; benchmark.cpp writes the profile at the run's end, as the game is stopped, not exited)
        execute_process(COMMAND ${CMAKE_CXX_COMPILER} --print-resource-dir OUTPUT_VARIABLE TTT2_CLANG_RES OUTPUT_STRIP_TRAILING_WHITESPACE)
        target_link_libraries(ttt2 PRIVATE "${TTT2_CLANG_RES}/lib/windows/clang_rt.profile-x86_64.lib")
        target_compile_definitions(ttt2 PRIVATE TTT2_PGO_GEN=1)
    endif()
endif()
if(TTT2_PREBUILT OR TTT2_OURS_LIB)
    target_link_libraries(ttt2 PRIVATE "$<LINK_LIBRARY:WHOLE_ARCHIVE,ttt2_ours>")
endif()

# Off Windows, every rex/src file sees ttt2_platform.h (the MSVC intrinsics' names the code uses),
# so that a file added on the main line with _byteswap_ulong builds on Linux unchanged.
if(NOT WIN32)
    target_compile_options(ttt2 PRIVATE "SHELL:$<$<COMPILE_LANGUAGE:CXX>:-include ${CMAKE_CURRENT_SOURCE_DIR}/src/ttt2_platform.h>"
                                        "SHELL:$<$<COMPILE_LANGUAGE:CXX>:-include ${CMAKE_CURRENT_SOURCE_DIR}/src/linux_stubs.h>")
    # (The Windows headers the main line's shared files include, over ttt2_win32_posix.h: native-gfx's.)
    target_include_directories(ttt2 BEFORE PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/src/linux_include)
endif()

# A map of ttt2.exe next to it, for tools/profile.pl to name the functions in a profile
# (src/profile.cpp), and the timer the profile sleeps by.
if(WIN32)
    target_link_options(ttt2 PRIVATE "LINKER:/MAP:ttt2.map")
    target_link_libraries(ttt2 PRIVATE winmm dbghelp ws2_32 winhttp ole32 windowscodecs iphlpapi mfuuid)
    target_include_directories(ttt2 PRIVATE src)
endif()

# The native renderer's graphics API layer (rex/NATIVE_PLAN.md): Plume (MIT, renderbag and
# contributors), fetched at a fixed commit with its own submodules (volk, VMA, Vulkan-Headers).
# Off by default, so that builds without the native renderer are unchanged (no network fetch, no
# SDL3 CMake package needed): rex/build-linux.sh and rex/build-windows.ps1 turn it on with
# TTT2_NATIVE_GFX=1. Vulkan on both (through SDL3 on Linux, the window's HWND on Windows); Plume's D3D12 back end is
# left out (below).
option(TTT2_NATIVE_GFX_PLUME "Build the native renderer's Plume (Vulkan) presenter" OFF)
if(TTT2_NATIVE_GFX_PLUME)
    # (SDL3's config: the SDK's install has it (rexglue's own config finds it too), so prebuilt\sdk does.)
    find_package(SDL3 REQUIRED CONFIG)
    if(NOT WIN32)
        set(PLUME_SDL3_VULKAN_ENABLED ON CACHE BOOL "" FORCE)
    endif()
    # (Plume vendored, nothing fetched (NATIVE_PLAN N5 step 4): rex/third_party/plume, made by
    # rex/third_party/plume-vendor.sh from the pinned commit with src/native_gfx/plume-ttt2.patch applied
    # (each swap chain image's first transition waits on the acquire; texture-to-buffer copies; a pipeline
    # cache kept on disk); its VENDORED.md records the pins and the licences. Missing: the build stops.)
    # (Where the renderer's code goes (packaging B, 8 Nov): the exe's own sources in a source build; inside
    # ttt2_ours.lib for the release build (TTT2_OURS_LIB), with plume.lib beside it in rex/prebuilt/lib; and in the
    # player's prebuilt build (TTT2_PREBUILT: no sources, no Plume sources) both libraries imported.)
    if(TTT2_PREBUILT)
        # (The player's package ships plume.lib, not Plume's sources (the main line's lead's review, 8 Nov: the
        # source check below failed every prebuilt install).)
        add_library(plume STATIC IMPORTED)
        set_target_properties(plume PROPERTIES IMPORTED_LOCATION "${CMAKE_CURRENT_SOURCE_DIR}/prebuilt/lib/plume.lib")
        target_link_libraries(ttt2 PRIVATE plume)
    else()
        set(TTT2_PLUME_DIR "${CMAKE_CURRENT_SOURCE_DIR}/third_party/plume")
        if(NOT EXISTS "${TTT2_PLUME_DIR}/CMakeLists.txt" OR NOT EXISTS "${TTT2_PLUME_DIR}/VENDORED.md")
            message(FATAL_ERROR "rex/third_party/plume is missing: the native renderer needs the vendored Plume "
                                "(bash rex/third_party/plume-vendor.sh makes it); nothing is downloaded.")
        endif()
        # (Plume's D3D12 back end left out (plume-ttt2.patch's option): the native renderer uses Vulkan only, so the
        # package needs no D3D12MA, no Agility SDK and no D3D12Core.dll (the lead, 8 Nov).)
        set(PLUME_D3D12_ENABLED OFF CACHE BOOL "" FORCE)
        add_subdirectory("${TTT2_PLUME_DIR}" "${CMAKE_CURRENT_BINARY_DIR}/plume" EXCLUDE_FROM_ALL)
        if(TTT2_OURS_LIB)
            target_sources(ttt2_ours PRIVATE src/native_gfx/native_renderer.cpp)
            target_link_libraries(ttt2_ours PRIVATE plume)
            target_compile_definitions(ttt2_ours PRIVATE TTT2_NATIVE_GFX_PLUME=1)
            if(WIN32)
                target_link_libraries(ttt2_ours PRIVATE SDL3::Headers)
            endif()
            # (The exe links plume.lib too: ttt2_ours.lib is linked whole, plume's objects come from its own library.)
            target_link_libraries(ttt2 PRIVATE plume)
        else()
            target_sources(ttt2 PRIVATE src/native_gfx/native_renderer.cpp)
            target_link_libraries(ttt2 PRIVATE plume)
        endif()
        # (TTT2_NATIVE_LINEINFO=ON, Linux, for the ring sampler's lines (rex/tools/ring-sample-report.py --lines): line tables for the native
        # renderer's own sources only. Off by default; the build is otherwise the same.)
        option(TTT2_NATIVE_LINEINFO "Line tables (-g1) for the native renderer's sources, for the ring sampler" OFF)
        if(TTT2_NATIVE_LINEINFO AND NOT WIN32)
            set_source_files_properties(
                src/native_gfx/native_renderer.cpp src/native_gfx/native_packets.cpp src/native_gfx/native_shaders.cpp
                src/native_gfx/native_graphics_system.cpp PROPERTIES COMPILE_OPTIONS "-g1")
        endif()
    endif()
    if(WIN32)
        # (Plume's SDL3 integration is Linux-only: the renderer finds the game's window through
        # SDL3 itself. No d3d12/dxgi/dxguid: Plume's D3D12 back end is out, and the Vulkan one uses none of them.)
        target_link_libraries(ttt2 PRIVATE SDL3::Headers)
    endif()
    target_compile_definitions(ttt2 PRIVATE TTT2_NATIVE_GFX_PLUME=1)
endif()
