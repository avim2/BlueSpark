# The portable toolchain (docs/PREBUILT_PACKAGE_PLAN.md, decision 3): the compiler, CMake, Ninja, and Microsoft's C++
# runtime headers/libraries and Windows SDK, pinned and the same on the owner's PC (building the SDK, our libraries and
# xexpatch.exe) and on a player's (compiling the game code). No Visual Studio, no Git.
#
#   . rex\tools\toolchain.ps1
#   Install-Ttt2Toolchain -AcceptMicrosoftLicense   # downloads what's missing (each by URL and SHA-256), unpacks
#   Use-Ttt2Toolchain                               # PATH, INCLUDE and LIB for this PowerShell, VS's own settings off
#
# Everything goes in <the data folder>\toolchain\<pin> (rex\tools\data-folder.ps1: %LOCALAPPDATA%\TTT2Native unless Start
# Here's "Where to put the tools and game files" says another; or $env:TTT2_TOOLCHAIN_ROOT). Microsoft's parts are
# fetched by xwin (MIT/Apache-2.0) from Microsoft's own servers, only after the player accepted Microsoft's license.
# xwin's layout is used as is (crt\, sdk\); its one version-folder symbolic link needs a privilege Windows doesn't give
# by default and nothing here uses it, so its failure is ignored once the files are checked.

$script:Ttt2ToolchainPins = [ordered]@{
    llvm  = @{ version = '20.1.8'; folder = 'llvm-20.1.8'; kind = 'tar.xz'; strip = 1
               url = 'https://github.com/llvm/llvm-project/releases/download/llvmorg-20.1.8/clang+llvm-20.1.8-x86_64-pc-windows-msvc.tar.xz'
               sha256 = 'f229769f11d6a6edc8ada599c0cda964b7dee6ab1a08c6cf9dd7f513e85b107f'; size = '940 MB'; needGB = 5.2
               unpackedGB = 3.902; what = 'the compiler'; key = 'bin\clang++.exe' }   # (needGB: the archive and its 3.9 GB unpacked, at once; unpackedGB: the unpack's progress, measured 28 Oct)
    cmake = @{ version = '3.31.8'; folder = 'cmake-3.31.8'; kind = 'zip'; inner = 'cmake-3.31.8-windows-x86_64'
               url = 'https://github.com/Kitware/CMake/releases/download/v3.31.8/cmake-3.31.8-windows-x86_64.zip'
               sha256 = '81aa9964dbabd71fe02e7ec50472fd3ad56138c49944515ece9001efbff8d719'; size = '47 MB'; key = 'bin\cmake.exe' }
    ninja = @{ version = '1.12.1'; folder = 'ninja-1.12.1'; kind = 'zip'
               url = 'https://github.com/ninja-build/ninja/releases/download/v1.12.1/ninja-win.zip'
               sha256 = 'f550fec705b6d6ff58f2db3c374c2277a37691678d6aba463adcbb129108467a'; size = '0.3 MB'; key = 'ninja.exe' }   # (no published hash: ours, 21 Oct)
    xwin  = @{ version = '0.10.0'; folder = 'xwin-0.10.0'; kind = 'tar.gz'; strip = 1
               url = 'https://github.com/Jake-Shadle/xwin/releases/download/0.10.0/xwin-0.10.0-x86_64-pc-windows-msvc.tar.gz'
               sha256 = '96e83665ef5c1406aabd0be603a8d08e67e604f36fda630b6807ee948a614e26'; size = '3 MB'
               unpackedGB = 0.007; what = 'xwin'; key = 'xwin.exe' }
}
# (key: the program a pin is unpacked for. A pin counts as installed only with its marker AND its key file: an antivirus
# can remove the program after the unpack, and then Install skipped the pin forever while the build said it was missing:
# a player's Install looped on a quarantined cmake.exe, 7 Nov, the main line's lead.)
# Microsoft's C++ runtime (the MSVC CRT/STL) and the Windows SDK, through xwin (the VS 17 release channel's manifest).
$script:Ttt2MsvcCrt = '14.44.17.14'   # (its packages: the VC tools build 14.44.35208, VS 17.14's)
$script:Ttt2WinSdk = '10.0.26100'
# xwin takes the SDK by its short version only; the package build it lays out (Win11SDK_10.0.26100's version in the
# manifest) is checked after the download. A different build is a warning, not a stop (Microsoft services the SDK).
$script:Ttt2WinSdkBuild = '10.0.26100.15'
$script:Ttt2MsvcFolder = "msvc-$($script:Ttt2MsvcCrt)-sdk-$($script:Ttt2WinSdk)"
# The VC++ runtime a game built with this CRT needs at least (HKLM\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64).
$script:Ttt2VcRuntimeMin = [version]'14.44.0.0'
. (Join-Path $PSScriptRoot 'data-folder.ps1')
. (Join-Path $PSScriptRoot 'remove-folder.ps1')

function Get-Ttt2ToolchainRoot {
    if ($env:TTT2_TOOLCHAIN_ROOT) { return $env:TTT2_TOOLCHAIN_ROOT }
    Join-Path (Get-Ttt2DataFolder) 'toolchain'
}

# A pin's folder: <folder> once it is unpacked, else a complete <folder>.new-<time> (an unpack that went into a fresh
# folder because the old one was locked: the lead's G2), else <folder> (to be unpacked).
function Get-Ttt2PinFolder([string]$root, $p) {
    $main = Join-Path $root $p.folder
    if (Test-Path -LiteralPath (Join-Path $main 'ttt2-unpacked.txt')) { return $main }
    $fresh = Get-ChildItem -LiteralPath $root -Directory -Filter "$($p.folder).new-*" -ErrorAction SilentlyContinue |
        Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'ttt2-unpacked.txt') } | Sort-Object Name | Select-Object -Last 1
    if ($fresh) { return $fresh.FullName }
    return $main
}

# A pin unpacked and still whole: its folder's marker and its key program (Start Here's "tools done" and Install's skip).
function Test-Ttt2PinInstalled([string]$root, $p) {
    $dest = Get-Ttt2PinFolder $root $p
    (Test-Path -LiteralPath (Join-Path $dest 'ttt2-unpacked.txt')) -and (Test-Path -LiteralPath (Join-Path $dest $p.key))
}
function Test-Ttt2ToolchainPinsInstalled([string]$root) {
    foreach ($k in $script:Ttt2ToolchainPins.Keys) { if (-not (Test-Ttt2PinInstalled $root $script:Ttt2ToolchainPins[$k])) { return $false } }
    $true
}

# G1 (the lead, 27 Oct): a tar.exe or our Python still unpacking under the toolchain folder (an earlier Install tools
# still running, or left running by a closed Start Here): its processes, by the record each unpack leaves beside its
# folder while it runs (<folder>.unpacking: the process's id and start time). 4.5.1: no listing of the PC's processes
# and their command lines, a pattern antivirus models weigh.
# (4.5.1, B: our temp files in a folder of our own, never %TEMP%: for a Windows user name with a space %TEMP% is an 8.3
# short path (C:\Users\<user>~1\...), and on one Windows PowerShell 5.1's Remove-Item -LiteralPath throws a terminating
# error that -ErrorAction SilentlyContinue doesn't stop ("An object at the specified path ... does not exist"). Removed
# through .NET in a try, so a cleanup never fails a step.)
function Get-Ttt2TempFolder {
    $d = Join-Path $env:LOCALAPPDATA 'TTT2Native\tmp'
    [void][IO.Directory]::CreateDirectory($d)
    return $d
}
function Remove-Ttt2TempFile([string[]]$paths) {
    foreach ($p in $paths) { try { if ($p -and [IO.File]::Exists($p)) { [IO.File]::Delete($p) } } catch { } }
}
function Get-Ttt2UnpackersRunning([string]$root) {
    if (-not (Test-Path -LiteralPath $root)) { return @() }
    @(foreach ($f in @(Get-ChildItem -LiteralPath $root -Filter '*.unpacking' -File -Force -ErrorAction SilentlyContinue)) {
        $w = "$(Get-Content -LiteralPath $f.FullName -TotalCount 1 -ErrorAction SilentlyContinue)" -split ' '
        $p = if ($w.Count -ge 2) { Get-Process -Id ([int]$w[0]) -ErrorAction SilentlyContinue } else { $null }
        $start = if ($p) { try { "$($p.StartTime.ToFileTimeUtc())" } catch { '' } } else { '' }
        if ($p -and $p.Id -ne $PID -and $start -eq $w[1]) { [pscustomobject]@{ Name = $p.ProcessName; ProcessId = $p.Id } }
        else { Remove-Ttt2TempFile $f.FullName }   # (its unpacker is gone)
    })
}

# G2 (the lead, 27 Oct; a player's step 1: "The process cannot access the file 'llvm-extract.exe' because it is being
# used by another process", Remove-Item of a half-unpacked folder): the removal is tried for up to $seconds (Windows
# Defender scans the new .exe files and lets go), each retry said; still locked, the folder is renamed aside
# (<folder>.old-<time>, removed at a later start). True when $path is gone; false when it is still there (the caller
# unpacks into a fresh folder instead).
function Remove-Ttt2LockedFolder([string]$path, [int]$seconds = 60, [switch]$Quiet) {
    if (-not (Test-Path -LiteralPath $path)) { return $true }
    $until = (Get-Date).AddSeconds($seconds)
    $try = 0
    while ($true) {
        try { Remove-Ttt2Folder $path; return $true }
        catch {
            $try++
            if ((Get-Date) -ge $until -or $Quiet) { break }
            Write-Host "Removing the unfinished $(Split-Path $path -Leaf): a file in it is in use ($($_.Exception.Message)); trying again in 3 s (try $try, up to $seconds s: an antivirus scan lets go)"
            Start-Sleep -Seconds 3
        }
    }
    $aside = "$path.old-$(Get-Date -Format yyyyMMdd-HHmmss)"
    try {
        Rename-Item -LiteralPath $path (Split-Path $aside -Leaf) -ErrorAction Stop
        if (-not $Quiet) { Write-Host "The unfinished $(Split-Path $path -Leaf) is still in use after $seconds s: moved aside to $(Split-Path $aside -Leaf) (removed at a later start)" }
        return $true
    } catch {
        if (-not $Quiet) { Write-Host "The unfinished $(Split-Path $path -Leaf) is still in use after $seconds s and can't be moved aside either: unpacking into a fresh folder beside it" }
        return $false
    }
}

# A later start's clean-up (G2): folders moved aside go; an unpack that went into a fresh folder takes the pin's own
# name once the old one can go. Never waits: what is still locked is left for the next time.
function Clear-Ttt2ToolchainLeftovers([string]$root) {
    foreach ($k in $script:Ttt2ToolchainPins.Keys) {
        $p = $script:Ttt2ToolchainPins[$k]
        foreach ($old in @(Get-ChildItem -LiteralPath $root -Directory -Filter "$($p.folder).old-*" -ErrorAction SilentlyContinue)) {
            try { Remove-Ttt2Folder $old.FullName; Write-Host "Removed the leftover $($old.Name)" } catch { }
        }
        $main = Join-Path $root $p.folder
        $fresh = Get-Ttt2PinFolder $root $p
        if ($fresh -ne $main) {
            if (Remove-Ttt2LockedFolder $main 0 -Quiet) {
                try { Rename-Item -LiteralPath $fresh $p.folder -ErrorAction Stop; Write-Host "$($p.folder): the fresh unpack now has the folder's own name" } catch { }
            }
        }
        foreach ($new in @(Get-ChildItem -LiteralPath $root -Directory -Filter "$($p.folder).new-*" -ErrorAction SilentlyContinue)) {
            if ($new.FullName -ne (Get-Ttt2PinFolder $root $p)) { try { Remove-Ttt2Folder $new.FullName } catch { } }
        }
    }
}

# One line naming every pin (for tools.done and the prebuilt manifest).
function Get-Ttt2ToolchainPinText {
    $parts = foreach ($k in $script:Ttt2ToolchainPins.Keys) { "$k=$($script:Ttt2ToolchainPins[$k].version)" }
    (@($parts) + @("msvc-crt=$($script:Ttt2MsvcCrt)", "winsdk=$($script:Ttt2WinSdk)")) -join ' '
}

# Stops with a plain message when the drive holding $path has less than $gb free (a full disk made tar fail with only
# "failed (1)" on a player's PC, 21 October).
function Assert-Ttt2FreeSpace([string]$path, [double]$gb, [string]$what) {
    if ($gb -le 0) { return }
    try {
        $drive = [IO.Path]::GetPathRoot([IO.Path]::GetFullPath($path))
        $free = (New-Object IO.DriveInfo $drive).AvailableFreeSpace / 1GB
    } catch { return }
    if ($free -lt $gb) {
        throw ("Install (the tools) needs about {3:N1} GB on {2}, which has {1:N1} GB free ({0}). Free some space on that drive, or choose another folder for the tools and game files (MOVE DATA FOLDER in BlueSpark), then press INSTALL again." -f $what, $free, $drive.TrimEnd('\'), $gb)
    }
}

# The portable Python setup-steps.ps1 installs before the compiler (<the data folder>\tools\python; or where it was
# before the folder could be chosen), or $null.
function Get-Ttt2Python {
    foreach ($p in @($env:TTT2_PYTHON, (Join-Path (Get-Ttt2DataFolder) 'tools\python\python.exe'), (Join-Path $env:LOCALAPPDATA 'TTT2Native\tools\python\python.exe'))) {
        if ($p -and (Test-Path -LiteralPath $p)) { return $p }
    }
    return $null
}

# A .tar.xz / .tar.gz unpacked by Python's tarfile (its own lzma: no xz program needed), the first $strip path parts
# dropped as tar's --strip-components does, with tarfile's 'data' filter (nothing outside $dest). Its output is returned;
# $LASTEXITCODE says how it went.
function Expand-Ttt2TarWithPython([string]$python, [string]$file, [string]$dest, [int]$strip, [double]$expectedBytes, [string]$text, [ref]$said) {
    $code = @'
import sys, tarfile
src, dest, strip = sys.argv[1], sys.argv[2], int(sys.argv[3])
def cut(name):
    return '/'.join(name.replace('\\', '/').split('/')[strip:])
with tarfile.open(src) as t:
    for m in t:
        m.name = cut(m.name)
        if not m.name:
            continue
        if m.islnk():
            m.linkname = cut(m.linkname)
        t.extract(m, dest, filter='data')
print('unpacked')
'@
    $script = Join-Path (Get-Ttt2TempFolder) 'ttt2-untar.py'
    [IO.File]::WriteAllText($script, $code)
    if ($env:TTT2_TOOLCHAIN_TEST_UNPACK -eq 'stall-both') { return (Invoke-Ttt2TestSleeper $dest $text $said) }   # (test only)
    Invoke-Ttt2Unpacker $python @('-I', "`"$script`"", "`"$file`"", "`"$dest`"", "$strip") $dest $expectedBytes $text $said
}

# What Install says when a program it needs isn't there (an antivirus's quarantine, most often): the file and where to allow.
function Get-Ttt2MissingProgramText([string]$exe) {
    $folder = try { Get-Ttt2DataFolder } catch { Join-Path $env:LOCALAPPDATA 'TTT2Native' }
    "Install can't find $exe, a program it needs to unpack the compiler. An antivirus may have quarantined it: allow the TTT2 folder ($folder) " +
        "in your antivirus (and restore the file from its quarantine if it's there), then click Install again."
}

# A .tar.xz / .tar.gz unpacked into $dest (a [ref]: it can move to a fresh folder beside $baseFolder): Windows' own tar.exe first,
# then the portable Python when tar fails, stalls or isn't on the PC. Returns 0, 'stalled' or tar's / Python's code; their words in $said.
# Python needed and missing: a clear stop naming it (Get-Ttt2MissingProgramText). TTT2_TOOLCHAIN_TEST_TAR_EXE (tests): another tar.exe path.
function Expand-Ttt2TarFile([string]$file, [ref]$dest, [string]$flag, [int]$strip, [double]$expected, [string]$what, [string]$baseFolder, [ref]$said) {
    $tar = if ($env:TTT2_TOOLCHAIN_TEST_TAR_EXE) { $env:TTT2_TOOLCHAIN_TEST_TAR_EXE } else { "$env:SystemRoot\System32\tar.exe" }
    $words = @()
    if ($env:TTT2_TOOLCHAIN_TEST_NO_TAR) { $words = @('tar skipped for a test (TTT2_TOOLCHAIN_TEST_NO_TAR)'); $code = 1 }   # (Windows 10's tar, on a Windows 11 PC)
    elseif ($env:TTT2_TOOLCHAIN_TEST_UNPACK -like 'stall*') { $code = Invoke-Ttt2TestSleeper $dest.Value $what ([ref]$words) }   # (test only)
    else {
        if ($env:TTT2_TOOLCHAIN_TEST_UNPACK -eq 'slow') { $null = Invoke-Ttt2TestSlowWriter $dest.Value $what ([ref]$words) }   # (test only)
        $code = Invoke-Ttt2Unpacker $tar @($flag, "`"$file`"", '-C', "`"$($dest.Value)`"", "--strip-components=$strip") $dest.Value $expected $what ([ref]$words)
    }
    if ("$code" -ne '0') {
        $python = Get-Ttt2Python
        if (-not $python) {   # (the setup installs it before the compiler: gone means removed, most likely quarantined)
            $said.Value = $words
            throw (Get-Ttt2MissingProgramText (Join-Path (Get-Ttt2DataFolder) 'tools\python\python.exe'))
        }
        if ("$code" -eq 'stalled') {
            Write-Host "The unpack made no progress for 3 minutes (Windows' tar): stopped. Unpacking with Python instead (a few minutes)"
        } elseif ("$code" -eq 'no-tar') {
            Write-Host "Windows' own tar.exe isn't on this PC (some cut-down Windows builds remove it): unpacking with Python instead (a few minutes)"
        } else {
            Write-Host "Windows' tar couldn't unpack it ($((($words | Where-Object { $_ } | Select-Object -First 1)))): unpacking with Python instead (a few minutes)"
        }
        if (-not (Remove-Ttt2LockedFolder $dest.Value)) { $dest.Value = "$baseFolder.new-$(Get-Date -Format yyyyMMdd-HHmmss)" }
        New-Item -ItemType Directory -Force $dest.Value | Out-Null
        $code = Expand-Ttt2TarWithPython $python $file $dest.Value $strip $expected $what ([ref]$words)
    }
    $said.Value = $words
    return $code
}

# Step 1's unpack watched (the owner, for 4.4.2: a player's step 1 sat on "Unpacking llvm 20.1.8" for hours with no other line; tar.exe
# says nothing while it works, so a slow unpack and a hung one looked the same). The unpacker runs as a process of its own (as step 2's
# extract-xiso) and every 2 s the bytes under $dest are said as "PROGRESS <percent> <text>" against the pin's unpackedGB, the launcher's
# bar. Nothing more written for 3 minutes (the files' count and sizes, and the newest file's size asked of the file itself: a folder's
# listing can lag while a big file is written): the unpacker is stopped and 'stalled' is returned. Else its exit code; its words in $said.
function Invoke-Ttt2Unpacker([string]$exe, [string[]]$arguments, [string]$dest, [double]$expectedBytes, [string]$text, [ref]$said) {
    # (The program checked first (the main line's lead, 5 Nov): Start-Process's own error for a missing file told a player nothing.
    # Windows' tar.exe missing (cut-down Windows builds remove it): 'no-tar', and the caller unpacks with Python. Any other program
    # missing (the portable python.exe, most likely quarantined by an antivirus): a clear stop that names it.)
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) {
        if ([IO.Path]::GetFileName($exe) -ieq 'tar.exe') { $said.Value = @("Windows' own tar.exe isn't on this PC ($exe)"); return 'no-tar' }
        throw (Get-Ttt2MissingProgramText $exe)
    }
    $out = Join-Path (Get-Ttt2TempFolder) "ttt2-unpack-$PID.txt"
    $p = Start-Process $exe -ArgumentList $arguments -NoNewWindow -PassThru -RedirectStandardOutput $out -RedirectStandardError "$out.err"
    $null = $p.Handle   # (without it Windows PowerShell may not give the exit code)
    $record = "$($dest.TrimEnd('\')).unpacking"   # (G1's record of this unpack, while it runs)
    try { [IO.File]::WriteAllText($record, "$($p.Id) $($p.StartTime.ToFileTimeUtc())") } catch { }
    $stallSeconds = if ($env:TTT2_TOOLCHAIN_TEST_STALL_S) { [int]$env:TTT2_TOOLCHAIN_TEST_STALL_S } else { 180 }   # (test only: shorter)
    $mark = ''
    $since = Get-Date
    $stalled = $false
    while (-not $p.WaitForExit(2000)) {
        $files = @(Get-ChildItem -LiteralPath $dest -Recurse -File -Force -ErrorAction SilentlyContinue)
        $sum = [double]($files | Measure-Object Length -Sum).Sum
        $newest = $files | Sort-Object CreationTimeUtc | Select-Object -Last 1
        $newestLength = if ($newest) { try { ([IO.FileInfo]::new($newest.FullName)).Length } catch { 0 } } else { 0 }
        $now = "$($files.Count) $sum $newestLength"
        if ($now -ne $mark) { $mark = $now; $since = Get-Date }
        Write-Host ("PROGRESS {0} Unpacking {1}" -f [math]::Min(99, [int](100 * $sum / [math]::Max([double]1, $expectedBytes))), $text)
        if (((Get-Date) - $since).TotalSeconds -ge $stallSeconds) {
            try { $p.Kill() } catch { }   # (4.5.1: the process itself, no taskkill.exe; the unpackers start no others)
            $null = $p.WaitForExit(10000)
            $stalled = $true
            break
        }
    }
    Remove-Ttt2TempFile $record
    $words = @(foreach ($f in $out, "$out.err") { if (Test-Path -LiteralPath $f) { Get-Content -LiteralPath $f -ErrorAction SilentlyContinue } })
    Remove-Ttt2TempFile $out, "$out.err"
    $said.Value = $words
    if ($stalled) { return 'stalled' }
    Write-Host "PROGRESS 100 Unpacked $text"
    return $p.ExitCode
}

# (Test only, TTT2_TOOLCHAIN_TEST_UNPACK: 'stall' puts a process that sleeps and writes nothing in tar's place, 'stall-both' in Python's too;
# 'slow' writes 64 KB under $dest every 30 s for 4 minutes before the real tar, so a slow unpack must not be taken for a stalled one.)
function Invoke-Ttt2TestSleeper([string]$dest, [string]$text, [ref]$said) {
    Invoke-Ttt2Unpacker "$PSHOME\powershell.exe" @('-NoProfile', '-Command', 'Start-Sleep -Seconds 3600') $dest 1GB $text $said
}
function Invoke-Ttt2TestSlowWriter([string]$dest, [string]$text, [ref]$said) {
    $slow = Join-Path $dest 'ttt2-slow-writer-test.bin'
    $command = "1..8 | ForEach-Object { [IO.File]::AppendAllText('$slow', ('x' * 65536)); Start-Sleep -Seconds 30 }"
    $code = Invoke-Ttt2Unpacker "$PSHOME\powershell.exe" @('-NoProfile', '-Command', "`"$command`"") $dest 1GB $text $said
    Remove-Item -LiteralPath $slow -Force -ErrorAction SilentlyContinue
    return $code
}

function Get-Ttt2ToolchainFile([string]$url, [string]$file, [string]$sha256) {
    # (TTT2_TEST_DOWNLOAD_FAIL=<part of a URL>: test only, that download fails as a dropped connection would, even when the file is there:
    # Start Here's Install stops at the tools part and goes on from it at the next click. 4.5.1.)
    if ($env:TTT2_TEST_DOWNLOAD_FAIL -and $url -like "*$($env:TTT2_TEST_DOWNLOAD_FAIL)*") { throw "Test: the download of $url is taken as failed (TTT2_TEST_DOWNLOAD_FAIL). Check your internet connection, then click Install again." }
    if (Test-Path -LiteralPath $file) {
        if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -eq $sha256.ToUpper()) { return }
        Remove-Item -LiteralPath $file -Force
    }
    Write-Host "Downloading $url"
    $tmp = "$file.part"
    $saved = $ProgressPreference
    $ProgressPreference = 'SilentlyContinue'
    try { Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing } catch { throw (Get-Ttt2NetProblem $url $_.Exception) } finally { $ProgressPreference = $saved }
    $got = (Get-FileHash -LiteralPath $tmp -Algorithm SHA256).Hash
    if ($got -ne $sha256.ToUpper()) {
        Remove-Item -LiteralPath $tmp -Force
        throw "The download of $url doesn't match its pinned SHA-256 (got $got): not used."
    }
    Move-Item -LiteralPath $tmp $file -Force
}

function Test-Ttt2MsvcLayout([string]$dir) {
    foreach ($f in 'crt\include\vector', 'crt\lib\x64\msvcprt.lib', 'crt\lib\x64\vcruntime.lib', 'sdk\include\um\windows.h',
                   'sdk\include\ucrt\stdio.h', 'sdk\include\shared\winerror.h', 'sdk\lib\um\x64\kernel32.lib', 'sdk\lib\ucrt\x64\ucrt.lib') {
        if (-not (Test-Path -LiteralPath (Join-Path $dir $f))) { return $false }
    }
    $true
}

# Downloads and unpacks what's missing. Microsoft's parts only with -AcceptMicrosoftLicense (the player accepted
# Microsoft's license in the installer's screen).
function Install-Ttt2Toolchain([switch]$AcceptMicrosoftLicense) {
    $root = Get-Ttt2ToolchainRoot
    New-Item -ItemType Directory -Force $root | Out-Null
    # (G1: never two installs at once. installing.lock is held open, unshared, for the whole install: a second one can't
    # open it, whatever stage the first is at (its download, its wait on a locked folder, its unpack); Windows lets go
    # of it when the install ends, however it ends.)
    $lockPath = Join-Path $root 'installing.lock'
    try { $lock = [IO.File]::Open($lockPath, 'OpenOrCreate', 'ReadWrite', 'None') }
    catch { throw 'An earlier install is still running (Install in another BlueSpark window): wait for it to finish (a few minutes), or restart the PC, then press INSTALL again.' }
    try { Install-Ttt2ToolchainLocked $root -AcceptMicrosoftLicense:$AcceptMicrosoftLicense }
    finally { $lock.Close(); Remove-Item -LiteralPath $lockPath -Force -ErrorAction SilentlyContinue }
}

function Install-Ttt2ToolchainLocked([string]$root, [switch]$AcceptMicrosoftLicense) {
    $downloads = Join-Path $root 'downloads'
    New-Item -ItemType Directory -Force $downloads | Out-Null
    # (G1: an unpack an older or closed Start Here left running: its tar.exe or Python still writing here.)
    $running = @(Get-Ttt2UnpackersRunning $root)
    if ($running.Count) {
        throw "An earlier install is still unpacking ($(($running | ForEach-Object { "$($_.Name) $($_.ProcessId)" }) -join ', ')): wait for it to finish (a few minutes), or restart the PC, then click Install again."
    }
    Clear-Ttt2ToolchainLeftovers $root
    foreach ($k in $script:Ttt2ToolchainPins.Keys) {
        $p = $script:Ttt2ToolchainPins[$k]
        $dest = Get-Ttt2PinFolder $root $p
        $marker = Join-Path $dest 'ttt2-unpacked.txt'
        if (Test-Path -LiteralPath $marker) {
            if (Test-Path -LiteralPath (Join-Path $dest $p.key)) { continue }
            # (Unpacked once, but its program is gone (an antivirus, most likely): the marker and the folder go, and the pin is
            # unpacked again; its archive was deleted after the first unpack, so it is downloaded again. 7 Nov.)
            Write-Host "$k $($p.version): $($p.key) is missing (an antivirus may have removed it): unpacking it again."
            Remove-Item -LiteralPath $marker -Force -ErrorAction Stop
            $main = Join-Path $root $p.folder
            if ($dest -ne $main) { $null = Remove-Ttt2LockedFolder $dest 15 -Quiet }   # (a .new- folder: gone, or left for the leftovers' clean-up)
            $dest = $main   # (removed just below, as before an unpack)
        }
        $file = Join-Path $downloads ($p.url -replace '^.*/', '')
        if ($p.needGB) {
            # (The archive already here counts as space already taken.)
            $have = if (Test-Path -LiteralPath $file) { (Get-Item -LiteralPath $file).Length / 1GB } else { 0 }
            Assert-Ttt2FreeSpace $root ($p.needGB - $have) "the compiler ($k $($p.version))"
        }
        Get-Ttt2ToolchainFile $p.url $file $p.sha256
        Write-Host "Unpacking $k $($p.version)"
        if (-not (Remove-Ttt2LockedFolder $dest)) { $dest = "$dest.new-$(Get-Date -Format yyyyMMdd-HHmmss)" }   # (G2: still locked)
        New-Item -ItemType Directory -Force $dest | Out-Null
        if ($p.kind -eq 'zip') {
            Expand-Archive -LiteralPath $file $dest -Force
            if ($p.inner) {   # (the archive's own top folder, moved up)
                Get-ChildItem -LiteralPath (Join-Path $dest $p.inner) -Force | Move-Item -Destination $dest
                Remove-Ttt2Folder (Join-Path $dest $p.inner)
            }
        } else {
            # Windows' own tar.exe (bsdtar) reads .tar.gz everywhere and .tar.xz on Windows 11; Windows 10's has no xz
            # ("Can't initialize filter; unable to run program "xz -d -qq"", a player's PC, 21 October): then the
            # portable Python the setup installs first unpacks it (Expand-Ttt2TarWithPython).
            $flag = if ($p.kind -eq 'tar.xz') { '-xJf' } else { '-xzf' }
            # (tar's own words kept for the error: "failed (1)" alone told a player nothing, 21 October.) Run and watched by
            # Invoke-Ttt2Unpacker: its progress as the launcher's bar, and a stop after 3 minutes with nothing written.
            $expected = [double]$p.unpackedGB * 1GB
            $said = @()
            $code = Expand-Ttt2TarFile $file ([ref]$dest) $flag $p.strip $expected $p.what (Join-Path $root $p.folder) ([ref]$said)
            if ("$code" -eq 'stalled') {
                $null = Remove-Ttt2LockedFolder $dest 15   # (half unpacked: gone, or aside; the checked archive stays for the next try)
                throw "The unpack stopped making progress. An antivirus may be holding the new files: allow $root, then click Install again."
            }
            if ("$code" -ne '0') {
                $null = Remove-Ttt2LockedFolder $dest 15   # (half unpacked: gone, or aside; the checked archive stays for the next try)
                $tail = ($said | Where-Object { $_ } | Select-Object -Last 4) -join "`n  "
                throw "Unpacking $file failed ($code). It said:`n  $tail`nThe usual causes: the disk filled up, or an antivirus blocked the new .exe files (allow the folder $root, then click Install again)."
            }
        }
        # (Its program there before the marker: an antivirus that removes it during the unpack is named now, and with no
        # marker the next Install unpacks it again from the archive, which stays.)
        $keyFile = Join-Path $dest $p.key
        if (-not (Test-Path -LiteralPath $keyFile)) { throw "An antivirus may have removed $($keyFile): allow $root, then click Install again." }
        Set-Content -LiteralPath (Join-Path $dest 'ttt2-unpacked.txt') "$($p.version) $($p.sha256)"
        Remove-Item -LiteralPath $file -Force   # (unpacked and recorded: the archive's 1 GB isn't kept)
        if ($dest -ne (Join-Path $root $p.folder)) { Clear-Ttt2ToolchainLeftovers $root }   # (a fresh folder: its own name if the old one can go now)
    }
    $msvc = Join-Path $root $script:Ttt2MsvcFolder
    if (-not (Test-Ttt2MsvcLayout $msvc)) {
        if (-not $AcceptMicrosoftLicense) { throw "Microsoft's C++ runtime and Windows SDK need Microsoft's license accepted first." }
        $xwin = Join-Path (Get-Ttt2PinFolder $root $script:Ttt2ToolchainPins.xwin) 'xwin.exe'
        Write-Host "Downloading Microsoft's C++ runtime $($script:Ttt2MsvcCrt) and Windows SDK $($script:Ttt2WinSdk) (from Microsoft, about 85 MB)"
        $saved = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        $said = @()
        try {
            $said = @(& $xwin --accept-license --log-level warn --cache-dir (Join-Path $root 'xwin-cache') --arch x86_64 `
                --crt-version $script:Ttt2MsvcCrt --sdk-version $script:Ttt2WinSdk `
                splat --disable-symlinks --preserve-ms-arch-notation --output $msvc 2>&1 | ForEach-Object { "$_" })
        } finally { $ErrorActionPreference = $saved }
        # (xwin's one version-folder symbolic link fails without Developer Mode, "A required privilege is not held (os error
        # 1314)", as an error a player took for a failed install, 21 October: those lines become one plain line; the
        # layout is checked below either way.)
        $symlink = ($said -join "`n") -match 'unable to symlink' -and ($said -join "`n") -match 'os error 1314'
        $said | Where-Object { -not ($symlink -and $_ -match 'failed to splat|RemoteException|^Caused by|^\s*\d+: |unable to symlink|required privilege|^\s*$') } |
            ForEach-Object { Write-Host $_ }
        if ($symlink) { Write-Host "(One shortcut link in the SDK folder needs Windows' Developer Mode; nothing uses it, so it is skipped.)" }
        # (Never another version in its place: the game's libraries were built against exactly these.)
        if (($said -join "`n") -match 'does not exist in the manifest|unable to locate SDK') {
            throw "The compiler's Microsoft part isn't available any more (C++ runtime $($script:Ttt2MsvcCrt), Windows SDK $($script:Ttt2WinSdk)): tell the BlueSpark team."
        }
        if (-not (Test-Ttt2MsvcLayout $msvc)) { throw "xwin didn't lay out Microsoft's C++ runtime and Windows SDK in $msvc." }
        $vsman = Get-ChildItem -LiteralPath (Join-Path $root 'xwin-cache\dl') -Filter 'pkg_manifest_*.vsman' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime | Select-Object -Last 1
        if ($vsman -and ([IO.File]::ReadAllText($vsman.FullName) -match "`"id`":`"Win11SDK_$([regex]::Escape($script:Ttt2WinSdk))`",`"version`":`"([^`"]+)`"")) {
            if ($Matches[1] -ne $script:Ttt2WinSdkBuild) { Write-Warning "Windows SDK build $($Matches[1]) laid out (the release was built with $($script:Ttt2WinSdkBuild))." }
            Set-Content -LiteralPath (Join-Path $msvc 'ttt2-sdk-build.txt') $Matches[1]
        }
        $null = Remove-Ttt2Folder (Join-Path $root 'xwin-cache') -Quiet   # (laid out: the packages aren't kept)
    }
    Write-Host "Toolchain: $(Get-Ttt2ToolchainPinText)"
}

# The VC++ runtime the game runs on (the build is /MD): the installed one's version, or $null.
function Get-Ttt2VcRuntimeVersion {
    $r = Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64' -ErrorAction SilentlyContinue
    if (-not $r -or -not $r.Installed) { return $null }
    try { [version]("$($r.Version)".TrimStart('v')) } catch { $null }
}
# Microsoft's vc_redist.x64.exe when the installed runtime is older than the pinned toolset's (one UAC prompt).
# Never shipped app-local.
function Install-Ttt2VcRuntime([string]$Downloads) {
    $have = Get-Ttt2VcRuntimeVersion
    if ($have -and $have -ge $script:Ttt2VcRuntimeMin) { Write-Host "VC++ runtime: $have"; return }
    $exe = Join-Path $Downloads 'vc_redist.x64.exe'
    $saved = $ProgressPreference
    $ProgressPreference = 'SilentlyContinue'
    try { Invoke-WebRequest -Uri 'https://aka.ms/vs/17/release/vc_redist.x64.exe' -OutFile $exe -UseBasicParsing } catch { throw (Get-Ttt2NetProblem 'https://aka.ms/vs/17/release/vc_redist.x64.exe' $_.Exception) } finally { $ProgressPreference = $saved }
    $sig = Get-AuthenticodeSignature $exe
    if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'O=Microsoft Corporation') { throw "vc_redist.x64.exe isn't signed by Microsoft: not run." }
    Write-Host 'Installing the Microsoft Visual C++ runtime (Windows asks for permission once)'
    $p = Start-Process $exe -ArgumentList '/install', '/quiet', '/norestart' -Verb RunAs -Wait -PassThru
    if ($p.ExitCode -notin 0, 1638, 3010) { throw "The Visual C++ runtime didn't install (exit $($p.ExitCode))." }
    Write-Host "VC++ runtime: $(Get-Ttt2VcRuntimeVersion)"
}

# The toolchain for this PowerShell: PATH (LLVM, CMake, Ninja, then Windows' own folders and whatever else was on it
# minus Visual Studio's), INCLUDE and LIB as a VS developer shell sets them, and VS's own settings cleared, so that
# nothing of an installed Visual Studio is picked up.
function Use-Ttt2Toolchain {
    $root = Get-Ttt2ToolchainRoot
    $p = $script:Ttt2ToolchainPins
    $llvm = Join-Path (Get-Ttt2PinFolder $root $p.llvm) 'bin'
    $cmake = Join-Path (Get-Ttt2PinFolder $root $p.cmake) 'bin'
    $ninja = Get-Ttt2PinFolder $root $p.ninja
    $msvc = Join-Path $root $script:Ttt2MsvcFolder
    foreach ($need in (Join-Path $llvm 'clang++.exe'), (Join-Path $cmake 'cmake.exe'), (Join-Path $ninja 'ninja.exe')) {
        if (-not (Test-Path -LiteralPath $need)) { throw "The toolchain is not installed ($need is missing: an antivirus may have removed it, and Install now puts it back): run Install-Ttt2Toolchain." }
    }
    if (-not (Test-Ttt2MsvcLayout $msvc)) { throw "Microsoft's C++ runtime and Windows SDK are not installed ($msvc)." }
    foreach ($v in 'VCINSTALLDIR', 'VCToolsInstallDir', 'VCToolsVersion', 'VSINSTALLDIR', 'VCIDEInstallDir', 'DevEnvDir', 'VisualStudioVersion',
                   'WindowsSdkDir', 'WindowsSDKVersion', 'WindowsSdkBinPath', 'WindowsSdkVerBinPath', 'UCRTVersion', 'UniversalCRTSdkDir',
                   'ExtensionSdkDir', 'LIBPATH', 'TTT2_LLVM', 'VSCMD_ARG_TGT_ARCH', 'VSCMD_VER', 'Platform') {
        Remove-Item -LiteralPath "Env:\$v" -ErrorAction SilentlyContinue
    }
    $kept = @($env:PATH -split ';' | Where-Object { $_ -and $_ -notmatch 'Microsoft Visual Studio|Windows Kits|\\LLVM\\|\\CMake\\' })
    $env:PATH = (@($llvm, $cmake, $ninja) + $kept) -join ';'
    $env:INCLUDE = (@('crt\include', 'sdk\include\ucrt', 'sdk\include\um', 'sdk\include\shared', 'sdk\include\winrt', 'sdk\include\cppwinrt') |
        ForEach-Object { Join-Path $msvc $_ }) -join ';'
    $env:LIB = (@('crt\lib\x64', 'sdk\lib\ucrt\x64', 'sdk\lib\um\x64') | ForEach-Object { Join-Path $msvc $_ }) -join ';'
    $env:TTT2_TOOLCHAIN_IN_USE = Get-Ttt2ToolchainPinText
    # (CMake's resource compiler and manifest tool: LLVM's, not the Windows Kits' rc.exe / mt.exe.)
    $env:RC = Join-Path $llvm 'llvm-rc.exe'
    # The MSVC version clang compiles as, pinned to the CRT's (14.44 -> 19.44; a player, czapla, 27 Oct). With VS's settings
    # cleared, clang looked for an installed Visual Studio by itself (the registry included), found an old one (VS2012) and
    # compiled as its _MSC_VER 1700 against our 14.44 STL: the C++ compile failed. VCToolsInstallDir names the CRT folder
    # (his fix: clang finds no cl.exe there, so it stops looking), and CCC_OVERRIDE_OPTIONS (clang's own driver variable;
    # "#": silent) adds -fms-compatibility-version to every clang, clang++ and clang-cl call of the builds (step 2's
    # xexpatch, step 3's CMake, the SDK, build-prebuilt), so it wins over whatever clang found. On this PC (VS 2026) clang
    # took 19.51 before; with VCToolsInstallDir alone, its default 19.33.
    # ('^': first, not '+': last (8 Nov, native's packaging slot). CMake's Ninja rules call clang-cl with "--" before the
    # source, so a flag added last landed after it and clang-cl took it for a file: "no such file or directory:
    # '-fms-compatibility-version=19.44'". Nothing else passes the flag, so first pins it the same; ttt2_ours.lib built both
    # ways was identical with the stamps zeroed, 407 objects.)
    $env:VCToolsInstallDir = (Join-Path $msvc 'crt') + '\'
    $env:CCC_OVERRIDE_OPTIONS = "# ^-fms-compatibility-version=$(Get-Ttt2MsvcCompatVersion)"
    Write-Host "Portable toolchain: $env:TTT2_TOOLCHAIN_IN_USE; clang compiles as MSVC $(Get-Ttt2ClangMsvcVersion)"
}

# The compiler version (cl.exe's 19.xx) of the pinned CRT: 14.44.17.14 -> 19.44.
function Get-Ttt2MsvcCompatVersion {
    $parts = $script:Ttt2MsvcCrt -split '\.'
    "19.$($parts[1])"
}

# The MSVC version clang-cl takes now (its -fms-compatibility-version in `clang-cl -### -c`), for the steps' logs.
function Get-Ttt2ClangMsvcVersion {
    $t = Join-Path (Get-Ttt2TempFolder) 'ttt2-msvc-version.cpp'
    $saved = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'   # (-### writes to stderr: under the steps' Stop it threw)
    try {
        Set-Content -LiteralPath $t 'int main() { return 0; }'
        $said = (& clang-cl -### -c $t 2>&1 | ForEach-Object { "$_" }) -join ' '
        if ($said -match '-fms-compatibility-version=([0-9.]+)') { return $Matches[1] }
        return '(not said)'
    } catch { return '(not known)' }
    finally { $ErrorActionPreference = $saved; Remove-Ttt2TempFile $t }
}

# A build folder made at another MSVC version is started fresh (27 Oct): clang's precompiled headers record the version
# ("Microsoft Visual C/C++ Version differs in AST file ... compiled for x86_64-pc-windows-msvc19.44.0 but ... msvc19.51"),
# and the pin goes through CCC_OVERRIDE_OPTIONS, which Ninja doesn't see, so nothing would be rebuilt by itself. The
# version is kept in <build folder>\ttt2-msvc-version.txt; a folder without it was built before the pin. True: made fresh.
function Reset-Ttt2BuildForMsvc([string]$BuildDir, [string]$What) {
    $file = Join-Path $BuildDir 'ttt2-msvc-version.txt'
    $want = Get-Ttt2MsvcCompatVersion
    if (-not (Test-Path -LiteralPath $BuildDir)) { return $false }
    if ((Test-Path -LiteralPath $file) -and "$(Get-Content -LiteralPath $file -TotalCount 1)".Trim() -eq $want) { return $false }
    if (-not (Test-Path -LiteralPath (Join-Path $BuildDir 'CMakeCache.txt'))) { return $false }
    Write-Host "$What was built for another MSVC version: it is built again from the start (once, for MSVC $want; a few minutes)"
    # (CMake's and Ninja's part only: the objects and precompiled headers are under CMakeFiles; the logs, the dumps and the
    # exe beside them stay.)
    foreach ($f in 'CMakeFiles', 'CMakeCache.txt', 'build.ninja', '.ninja_log', '.ninja_deps', 'cmake_install.cmake') { Remove-Ttt2Folder (Join-Path $BuildDir $f) }
    return $true
}
function Write-Ttt2BuildMsvc([string]$BuildDir) {
    New-Item -ItemType Directory -Force $BuildDir | Out-Null
    Set-Content -LiteralPath (Join-Path $BuildDir 'ttt2-msvc-version.txt') (Get-Ttt2MsvcCompatVersion)
}
