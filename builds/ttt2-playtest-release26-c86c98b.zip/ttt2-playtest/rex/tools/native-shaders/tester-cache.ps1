# A tester's one command for the native renderer's shader cache (12 Nov; the beta-integration package, docs/native/TESTER_NATIVE.md):
#
#   powershell -ExecutionPolicy Bypass -File rex\tools\native-shaders\tester-cache.ps1
#
# Makes rex\out\native-shaders.bin (with its stamp) from the player's own game files and the package's tools, on all cores,
# in the foreground, and says how long it took. What Install and Play do in the background, but in one go. Safe to run again: a
# cache that is current is kept. Never changes a setting; to turn native on, put the word "native" in rex\out\renderer-test.txt.
param([int]$Cores = [Environment]::ProcessorCount)
$ErrorActionPreference = 'Stop'
$Rex = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
. (Join-Path $PSScriptRoot 'package-shaders.ps1')
$tools = Join-Path $Rex 'prebuilt\tools\shaders'
if (-not (Test-Path -LiteralPath $tools)) { Write-Host "This package has no native shader tools ($tools): nothing to make."; exit 1 }
$clock = [Diagnostics.Stopwatch]::StartNew()
$ok = Invoke-NativeShaderCache -Rex $Rex -Tools $tools -Out (Join-Path $Rex 'out\native-shaders.bin') -Cores $Cores
Write-Host ("Native shader cache: {0} in {1} s" -f $(if ($ok) { 'ready' } else { 'NOT made (see the lines above)' }), [int]$clock.Elapsed.TotalSeconds)
exit $(if ($ok) { 0 } else { 1 })
