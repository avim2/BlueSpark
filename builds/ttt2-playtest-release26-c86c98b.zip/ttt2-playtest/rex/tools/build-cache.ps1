# The install's per-PC build caches (docs/BUILDTIME_PLAN_20261122.md, 22 Nov: the owner's "shrink the build time"; the main lead's order).
# What a step makes from inputs that do not change from one install folder to the next is kept in the data folder
# (rex\tools\data-folder.ps1: where the toolchain already is), in <data folder>\cache\<kind>\<key>\, and a later install on the same PC
# copies it back where the step writes it today. One cache for the whole PC, not one per install folder.
#
#   . rex\tools\build-cache.ps1
#
# The rules, for every kind (A: the shader file; B: the generated code; C: xexpatch.exe; D: the generated code's objects):
#   - the key is a SHA-256 over EVERY input the result depends on, as "name=value" lines; an input that cannot be read or hashed makes the key
#     '' = a miss, and the step runs as it does without a cache (a wrong hit must be impossible);
#   - an entry is added only after the step succeeded, built in <key>.tmp-<pid> and renamed;
#   - a hit is COPIED to where the step writes today and then checked there (size and SHA-256 recorded in entry.txt beside the files); a bad
#     copy is removed, the entry deleted, and the step runs;
#   - the newest 2 entries of a kind are kept (by last use), older ones removed;
#   - TTT2_NO_BUILD_CACHE=1: no lookup, no add, every step as before;
#   - every hit and miss says so in one line with the key's first 12 digits ("Build: <what> cache hit <key>").
# Nothing here ever throws to its caller: a cache that cannot be used is a miss.

. (Join-Path $PSScriptRoot 'data-folder.ps1')
. (Join-Path $PSScriptRoot 'remove-folder.ps1')

function Test-Ttt2BuildCacheOff { "$env:TTT2_NO_BUILD_CACHE".Trim() -eq '1' }

function Get-Ttt2BuildCacheRoot { Join-Path (Get-Ttt2DataFolder) 'cache' }

function ConvertTo-Ttt2Hex([byte[]]$bytes) { [BitConverter]::ToString($bytes).Replace('-', '').ToLowerInvariant() }

# The file's SHA-256 (lower case hex), '' when it cannot be read.
function Get-Ttt2Sha256([string]$path) {
    try {
        if (-not [IO.File]::Exists($path)) { return '' }
        $sha = [Security.Cryptography.SHA256]::Create()
        $fs = New-Object IO.FileStream($path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite, 1048576)
        try { return (ConvertTo-Ttt2Hex $sha.ComputeHash($fs)) } finally { $fs.Dispose(); $sha.Dispose() }
    } catch { return '' }
}

function Get-Ttt2TextSha256([string]$text) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { ConvertTo-Ttt2Hex $sha.ComputeHash((New-Object Text.UTF8Encoding($false)).GetBytes($text)) } finally { $sha.Dispose() }
}

# The key from "name=value" lines: '' when any line has no value (an input that could not be read).
function New-Ttt2CacheKey([string[]]$parts) {
    foreach ($p in $parts) { if ("$p" -notmatch '^[^=]+=.+$') { return '' } }
    Get-Ttt2TextSha256 ($parts -join "`n")
}

function Get-Ttt2CacheKindDir([string]$kind) { Join-Path (Get-Ttt2BuildCacheRoot) $kind }

# A file name and the order of a folder's files, so that the same tree always gives the same lines.
function Get-Ttt2TreeLines([string]$root, [string]$label) {
    $full = (Resolve-Path -LiteralPath $root).Path.TrimEnd('\') + '\'
    $files = @(Get-ChildItem -LiteralPath $full -Recurse -File -Force | Sort-Object { $_.FullName.Substring($full.Length).ToLowerInvariant() })
    foreach ($f in $files) {
        $rel = $f.FullName.Substring($full.Length).Replace('\', '/')
        "$label/$rel=$(Get-Ttt2Sha256 $f.FullName)"
    }
}

# The entry's folder when there is one for the key (not checked yet), else ''.
function Find-Ttt2CacheEntry([string]$kind, [string]$key) {
    if (-not $key) { return '' }
    $dir = Join-Path (Get-Ttt2CacheKindDir $kind) $key
    if (Test-Path -LiteralPath (Join-Path $dir 'entry.txt')) { return $dir }
    ''
}

# Copies the entry's files under $dest (each at its relative path) and checks every copy against the recorded size and SHA-256. $true when all
# match. A bad entry is deleted; a failed copy leaves nothing it made: the caller removes what it must.
function Restore-Ttt2CacheEntry([string]$dir, [string]$dest) {
    try {
        $lines = @([IO.File]::ReadAllLines((Join-Path $dir 'entry.txt')) | Where-Object { $_ })
        if (-not $lines.Count) { throw 'the entry lists no files' }
        foreach ($l in $lines) {
            $f = $l -split "`t", 3
            if ($f.Count -ne 3) { throw 'a bad line in entry.txt' }
            $from = Join-Path (Join-Path $dir 'files') $f[2]
            $to = Join-Path $dest $f[2]
            if (-not [IO.File]::Exists($from)) { throw "$($f[2]) is missing" }
            $null = New-Item -ItemType Directory -Force -Path (Split-Path $to -Parent)
            [IO.File]::Copy($from, $to, $true)
            if (([IO.FileInfo]$to).Length -ne [long]$f[1] -or (Get-Ttt2Sha256 $to) -ne $f[0]) { throw "$($f[2]) does not match its record" }
        }
        # (Used: the newest two are kept.)
        try { (Get-Item -LiteralPath (Join-Path $dir 'entry.txt')).LastWriteTime = Get-Date } catch { }
        return $true
    } catch {
        Write-Host "Build: a cache entry could not be used ($($_.Exception.Message)); it is removed and the step runs."
        try { Remove-Ttt2Folder $dir } catch { }
        return $false
    }
}

# Adds an entry: $files maps a relative path to the full path of the file to keep. Built beside, renamed when whole. Never throws; returns $true
# when the entry is there. $needMB: the space it takes (the drive of the cache must have that and 2 GB more).
function Add-Ttt2CacheEntry([string]$kind, [string]$key, [System.Collections.IDictionary]$files, [double]$needMB, [string]$what) {
    if (-not $key -or (Test-Ttt2BuildCacheOff)) { return $false }
    $tmp = ''
    try {
        $kindDir = Get-Ttt2CacheKindDir $kind
        $final = Join-Path $kindDir $key
        if (Test-Path -LiteralPath (Join-Path $final 'entry.txt')) { return $true }
        $free = Get-Ttt2FreeGB $kindDir
        if ($free -ge 0 -and $free * 1024 -lt $needMB + 2048) { Write-Host "Build: $what cache not kept: $([math]::Round($free, 1)) GB free on that drive."; return $false }
        $null = New-Item -ItemType Directory -Force -Path $kindDir
        $tmp = Join-Path $kindDir "$key.tmp-$PID"
        if (Test-Path -LiteralPath $tmp) { Remove-Ttt2Folder $tmp }
        $null = New-Item -ItemType Directory -Force -Path (Join-Path $tmp 'files')
        $records = New-Object Collections.Generic.List[string]
        foreach ($rel in ($files.Keys | Sort-Object)) {
            $to = Join-Path (Join-Path $tmp 'files') $rel
            $null = New-Item -ItemType Directory -Force -Path (Split-Path $to -Parent)
            [IO.File]::Copy($files[$rel], $to, $true)
            # (The record is of the COPY kept: what a later hit is checked against.)
            $sha = Get-Ttt2Sha256 $to
            if (-not $sha) { throw "$rel could not be read back" }
            $records.Add("$sha`t$(([IO.FileInfo]$to).Length)`t$rel")
        }
        [IO.File]::WriteAllLines((Join-Path $tmp 'entry.txt'), $records)
        if (Test-Path -LiteralPath $final) { Remove-Ttt2Folder $final }
        Move-Item -LiteralPath $tmp $final
        $tmp = ''
        Write-Host "Build: $what cache added $($key.Substring(0, 12))."
        Remove-Ttt2CacheOld $kind
        return $true
    } catch {
        Write-Host "Build: $what cache not kept ($($_.Exception.Message))."
        if ($tmp) { try { Remove-Ttt2Folder $tmp } catch { } }
        return $false
    }
}

# The newest 2 entries of a kind (by last use) stay; older ones and the leftovers of a run that died (a .tmp- folder over an hour old) go.
function Remove-Ttt2CacheOld([string]$kind, [int]$keep = 2) {
    try {
        $kindDir = Get-Ttt2CacheKindDir $kind
        $all = @(Get-ChildItem -LiteralPath $kindDir -Directory -ErrorAction SilentlyContinue)
        foreach ($d in ($all | Where-Object { $_.Name -like '*.tmp-*' -and $_.LastWriteTime -lt (Get-Date).AddHours(-1) })) { Remove-Ttt2Folder $d.FullName }
        $entries = @($all | Where-Object { $_.Name -notlike '*.tmp-*' } | Sort-Object {
                $e = Join-Path $_.FullName 'entry.txt'
                if (Test-Path -LiteralPath $e) { (Get-Item -LiteralPath $e).LastWriteTime } else { [datetime]::MinValue }
            } -Descending)
        foreach ($d in ($entries | Select-Object -Skip $keep)) { Remove-Ttt2Folder $d.FullName }
    } catch { }
}

# ---- D: the objects of the generated code (the compiler's output for ttt2_recomp) ------------------------------------------------------------
# The folder of this install is not part of the key: its path is written <rex> in the command lines, in the headers' list and in the two files
# CMake makes for the precompiled header. The objects' debug line tables name the folder that made them; the exe does not (checked: two clean builds
# in two folders differ in 5 bytes).

function ConvertTo-Ttt2RexRelative([string]$text, [string]$rex) {
    $a = $rex.TrimEnd('\')
    $b = $a.Replace('\', '/')
    $t = [regex]::Replace($text, [regex]::Escape($a), '<rex>', 'IgnoreCase')
    [regex]::Replace($t, [regex]::Escape($b), '<rex>', 'IgnoreCase')
}

# The headers (and other files) the compiler read for the generated code's objects and its precompiled header, from ninja's own record of the build
# that made them, one "sha<TAB>path" line each (the folder as <rex>), except what the key holds already (the generated folder, the build folder's
# own files). $false when a file could not be read.
function New-Ttt2ObjectDeps([string]$buildDir, [string]$rex, [string]$outFile) {
    try {
        $rexF = $rex.TrimEnd('\').Replace('\', '/')
        $buildF = $buildDir.TrimEnd('\').Replace('\', '/')
        $set = New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
        $take = $false
        foreach ($l in (& ninja -C $buildDir -t deps 2>$null)) {
            $s = "$l"
            if ($s -match '^\S') { $take = $s.StartsWith('CMakeFiles/ttt2_recomp.dir/'); continue }
            if (-not $take -or -not $s.StartsWith('    ')) { continue }
            $f = $s.Substring(4).Trim()
            if ($f.StartsWith($buildF + '/', [StringComparison]::OrdinalIgnoreCase)) { continue }
            if ($f.StartsWith($rexF + '/generated/default/', [StringComparison]::OrdinalIgnoreCase)) { continue }
            [void]$set.Add($f)
        }
        if ($set.Count -lt 50) { return $false }
        $lines = New-Object Collections.Generic.List[string]
        foreach ($f in ($set | Sort-Object)) {
            $sha = Get-Ttt2Sha256 $f
            if (-not $sha) { return $false }
            $lines.Add("$sha`t$(ConvertTo-Ttt2RexRelative $f $rex)")
        }
        [IO.File]::WriteAllLines($outFile, $lines)
        return $true
    } catch { return $false }
}

# '' when every file of the list still has its recorded SHA-256 (this install's folder put in for <rex>), else the first path that does not
# (or that cannot be read): a miss.
function Test-Ttt2ObjectDeps([string]$listFile, [string]$rex) {
    $rexF = $rex.TrimEnd('\').Replace('\', '/')
    try {
        $n = 0
        foreach ($l in [IO.File]::ReadAllLines($listFile)) {
            if (-not $l) { continue }
            $f = $l -split "`t", 2
            if ($f.Count -ne 2) { return 'a bad line in the list' }
            $path = $f[1].Replace('<rex>', $rexF)
            if ((Get-Ttt2Sha256 $path) -ne $f[0]) { return $f[1] }
            $n++
        }
        if ($n -lt 50) { return 'the list is too short' }
        return ''
    } catch { return "the list could not be read ($($_.Exception.Message))" }
}
