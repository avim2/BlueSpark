# eff-measure.ps1: the efficiency round's numbers from OUTSIDE a running game (12 Nov, the native lead's recipe for the laptop; W).
# Standalone: one file, no repo or package needed beside it, nothing downloaded, no administrator, Windows PowerShell 5.1.
#
#   powershell -NoProfile -ExecutionPolicy Bypass -File eff-measure.ps1 [-Seconds 60] [-DelaySeconds 0] [-Label emulated]
#                                                                         [-ProcessName ttt2] [-WaitSeconds 120] [-OutDir .] [-PathLike *]
#
# Start it AFTER the fight is on (or give -DelaySeconds to wait that long once the game exists). It attaches to the running
# ttt2.exe by process, samples once a second for -Seconds, and prints (and writes to eff-<label>-<time>.txt in -OutDir):
#   - per second: the CPU of all threads (ms per frame), the GPU 3D engine's busy time (ms per frame), GPU memory (dedicated), RAM;
#   - the summary: the means and medians of those, the GPU engines by type;
#   - every thread's CPU (ms per frame over the whole run) with the name the game gave it (SetThreadDescription): the
#     render thread (native: "Native GPU ring"; emulated: the GPU thread), the main thread, thread 13 and the rest can be read.
# "Per frame" = per 1/60 s of wall time (the game runs at 60 frames a second; the Latency lines say how many it really made).
# GPU busy ms per frame = the engine counter's percent x 16.667 / 100. The counters are Windows' own (\GPU Engine, \GPU Process
# Memory), read for this process only; on a PC with two GPUs (a laptop) every engine of the process is listed with its adapter.
param(
    [int]$Seconds = 60,
    [int]$DelaySeconds = 0,
    [string]$Label = 'run',
    [string]$ProcessName = 'ttt2',
    [int]$WaitSeconds = 120,
    [string]$OutDir = '.',
    [string]$PathLike = '*'   # only a game whose exe path matches (when more than one install is running)
)
$ErrorActionPreference = 'Stop'

# --- thread names (GetThreadDescription, Windows 10 1607 and later) -----------------------------------------------------------
if (-not ('EffThreads.Names' -as [type])) {
    Add-Type -Namespace EffThreads -Name Names -MemberDefinition @'
[DllImport("kernel32.dll")] static extern System.IntPtr OpenThread(uint access, bool inherit, uint id);
[DllImport("kernel32.dll")] static extern bool CloseHandle(System.IntPtr h);
[DllImport("kernel32.dll")] static extern int GetThreadDescription(System.IntPtr h, out System.IntPtr name);
[DllImport("kernel32.dll")] static extern System.IntPtr LocalFree(System.IntPtr p);
public static string Of(uint id) {
    System.IntPtr h = OpenThread(0x0800, false, id);   // THREAD_QUERY_LIMITED_INFORMATION
    if (h == System.IntPtr.Zero) return "";
    string s = "";
    try {
        System.IntPtr p;
        if (GetThreadDescription(h, out p) >= 0 && p != System.IntPtr.Zero) {
            s = System.Runtime.InteropServices.Marshal.PtrToStringUni(p);
            LocalFree(p);
        }
    } catch { }
    CloseHandle(h);
    return s;
}
'@
}

# --- attach to the game ------------------------------------------------------------------------------------------------------
Write-Host "eff-measure: waiting for $ProcessName.exe (up to $WaitSeconds s)"
$game = $null
$deadline = (Get-Date).AddSeconds($WaitSeconds)
while (-not $game -and (Get-Date) -lt $deadline) {
    $game = Get-Process -Name $ProcessName -ErrorAction SilentlyContinue | Where-Object { $_.Path -like $PathLike } | Sort-Object StartTime | Select-Object -Last 1
    if (-not $game) { Start-Sleep -Milliseconds 500 }
}
if (-not $game) { throw "eff-measure: no $ProcessName.exe running after $WaitSeconds s." }
$id = $game.Id
Write-Host "eff-measure: attached to $ProcessName.exe (process $id); $DelaySeconds s delay, then $Seconds s"
if ($DelaySeconds -gt 0) { Start-Sleep -Seconds $DelaySeconds }
$game.Refresh()
if ($game.HasExited) { throw 'eff-measure: the game ended during the delay.' }

# --- sampling ---------------------------------------------------------------------------------------------------------------
$frameMs = 1000.0 / 60.0
$threadFirst = @{}      # id -> cpu ms at first sight
$threadLast = @{}       # id -> cpu ms at last sight
$threadName = @{}
$threadUserFirst = @{}  # id -> user-mode cpu ms at first sight (kernel = total - user)
$threadUserLast = @{}
$rows = New-Object System.Collections.ArrayList
$engineSum = @{}        # 'adapter engtype' -> sum of percent over samples
$haveGpu = $true
$counters = @("\GPU Engine(pid_${id}_*)\Utilization Percentage", "\GPU Process Memory(pid_${id}_*)\Dedicated Usage")
$prevCpu = $null
$prevAt = $null
$start = Get-Date
$gpuProbeOk = $true
try { $null = Get-Counter $counters -MaxSamples 1 -ErrorAction Stop } catch { $gpuProbeOk = $false; $gpuProbeError = $_.Exception.Message }

for ($n = 0; $n -lt $Seconds; $n++) {
    $tickStart = Get-Date
    if ($game.HasExited) { Write-Host "eff-measure: the game ended after $n s."; break }
    $gpu3d = 0.0; $gpuAll = 0.0; $gpuMemMb = 0.0
    if ($gpuProbeOk) {
        try {
            # (A one-second sample interval: the call itself takes the second, and the CPU reads below are taken right after it.)
            $samples = (Get-Counter $counters -SampleInterval 1 -MaxSamples 1 -ErrorAction Stop).CounterSamples
            foreach ($c in $samples) {
                if ($c.Path -like '*gpu engine*') {
                    $gpuAll += $c.CookedValue
                    $type = if ($c.InstanceName -match 'engtype_(\w+)') { $Matches[1] } else { 'other' }
                    $luid = if ($c.InstanceName -match 'luid_(0x[0-9A-Fa-f]+_0x[0-9A-Fa-f]+)') { $Matches[1] } else { '?' }
                    $key = "adapter $luid  $type"
                    if (-not $engineSum.ContainsKey($key)) { $engineSum[$key] = 0.0 }
                    $engineSum[$key] += $c.CookedValue
                    if ($type -eq '3D') { $gpu3d += $c.CookedValue }
                } elseif ($c.Path -like '*gpu process memory*') {
                    $gpuMemMb += $c.CookedValue / 1MB
                }
            }
        } catch { $gpuProbeOk = $false; $gpuProbeError = $_.Exception.Message }
    } else {
        Start-Sleep -Seconds 1
    }
    $now = Get-Date
    try {
        $game.Refresh()
        $cpuTotal = $game.TotalProcessorTime.TotalMilliseconds
        $ram = $game.WorkingSet64 / 1MB
        foreach ($t in $game.Threads) {
            try {
                $ms = $t.TotalProcessorTime.TotalMilliseconds
                if (-not $threadFirst.ContainsKey($t.Id)) {
                    # (A thread born during the run counts from zero; one that was there counts from its first sight.)
                    $threadFirst[$t.Id] = if ($n -eq 0) { $ms } else { 0.0 }
                    $threadName[$t.Id] = ''
                }
                $threadLast[$t.Id] = $ms
                $um = $t.UserProcessorTime.TotalMilliseconds
                if (-not $threadUserFirst.ContainsKey($t.Id)) { $threadUserFirst[$t.Id] = if ($n -eq 0) { $um } else { 0.0 } }
                $threadUserLast[$t.Id] = $um
                if (-not $threadName[$t.Id]) { $threadName[$t.Id] = [EffThreads.Names]::Of([uint32]$t.Id) }
            } catch {}
        }
    } catch { break }
    if ($prevCpu -ne $null) {
        $dt = ($now - $prevAt).TotalSeconds
        $cpuPerFrame = ($cpuTotal - $prevCpu) / ($dt * 60.0)
        [void]$rows.Add([pscustomobject]@{
            T = $n; CpuMsPerFrame = [math]::Round($cpuPerFrame, 3); Gpu3dPct = [math]::Round($gpu3d, 2)
            Gpu3dMsPerFrame = [math]::Round($gpu3d * $frameMs / 100.0, 3); GpuAllPct = [math]::Round($gpuAll, 2)
            GpuMemMB = [math]::Round($gpuMemMb); RamMB = [math]::Round($ram)
        })
    }
    $prevCpu = $cpuTotal; $prevAt = $now
}
$elapsed = ((Get-Date) - $start).TotalSeconds

# --- threads over the whole run -----------------------------------------------------------------------------------------------
$spanSeconds = [math]::Max(1.0, $rows.Count)
$threadRows = foreach ($tid in $threadLast.Keys) {
    $ms = $threadLast[$tid] - $threadFirst[$tid]
    $um = $threadUserLast[$tid] - $threadUserFirst[$tid]
    [pscustomobject]@{ Id = $tid; Name = $threadName[$tid]; MsPerFrame = [math]::Round($ms / ($spanSeconds * 60.0), 3); KernelMsPerFrame = [math]::Round(($ms - $um) / ($spanSeconds * 60.0), 3) }
}
$threadRows = @($threadRows | Sort-Object MsPerFrame -Descending)
$threadTotal = ($threadRows | Measure-Object MsPerFrame -Sum).Sum

function Median($values) {
    $v = @($values | Sort-Object)
    if ($v.Count -eq 0) { return 0 }
    if ($v.Count % 2) { return $v[($v.Count - 1) / 2] }
    return ($v[$v.Count / 2 - 1] + $v[$v.Count / 2]) / 2
}
function Stats($name, $values, $unit) {
    $v = @($values)
    if ($v.Count -eq 0) { return ('{0,-34} no samples' -f $name) }
    $m = ($v | Measure-Object -Average -Maximum -Minimum)
    '{0,-34} mean {1,9:N3}   median {2,9:N3}   min {3,9:N3}   max {4,9:N3}  {5}' -f $name, $m.Average, (Median $v), $m.Minimum, $m.Maximum, $unit
}

$out = New-Object System.Collections.ArrayList
[void]$out.Add("eff-measure: label '$Label', $ProcessName.exe process $id, $($rows.Count) one-second samples over $([math]::Round($elapsed)) s, window $($start.ToString('HH:mm:ss')) to $(($start.AddSeconds($elapsed)).ToString('HH:mm:ss')) on $(Get-Date -Format 'yyyy-MM-dd') (the game log's Latency lines in that window are the run's)")
[void]$out.Add("per frame = per 1/60 s of wall time; GPU busy ms per frame = percent x 16.667 / 100")
if (-not $gpuProbeOk) { [void]$out.Add("GPU counters NOT read: $gpuProbeError") }
[void]$out.Add('')
[void]$out.Add('SUMMARY')
[void]$out.Add((Stats 'CPU, all threads (ms per frame)' ($rows | ForEach-Object { $_.CpuMsPerFrame }) 'ms'))
[void]$out.Add((Stats 'GPU 3D engine busy (ms per frame)' ($rows | ForEach-Object { $_.Gpu3dMsPerFrame }) 'ms'))
[void]$out.Add((Stats 'GPU 3D engine (percent)' ($rows | ForEach-Object { $_.Gpu3dPct }) '%'))
[void]$out.Add((Stats 'GPU, all engines summed (percent)' ($rows | ForEach-Object { $_.GpuAllPct }) '%'))
[void]$out.Add((Stats 'GPU memory, dedicated (MB)' ($rows | ForEach-Object { $_.GpuMemMB }) 'MB'))
[void]$out.Add((Stats 'RAM, working set (MB)' ($rows | ForEach-Object { $_.RamMB }) 'MB'))
[void]$out.Add('')
[void]$out.Add('GPU ENGINES (mean percent over the run, this process only)')
if ($engineSum.Count -eq 0) { [void]$out.Add('  none read') }
foreach ($k in ($engineSum.Keys | Sort-Object)) {
    [void]$out.Add(('  {0,-48} {1,8:N2} %' -f $k, ($engineSum[$k] / [math]::Max(1, $rows.Count))))
}
[void]$out.Add('')
[void]$out.Add("THREADS (CPU ms per frame over the run; all threads sum $([math]::Round($threadTotal, 3)))")
[void]$out.Add(('  {0,8}  {1,10}  {2,10}  {3}' -f 'thread', 'ms/frame', 'kernel', 'name (set by the game; empty = unnamed; kernel = the part of ms/frame spent in kernel mode)'))
foreach ($t in ($threadRows | Select-Object -First 24)) {
    [void]$out.Add(('  {0,8}  {1,10:N3}  {2,10:N3}  {3}' -f $t.Id, $t.MsPerFrame, $t.KernelMsPerFrame, $t.Name))
}
if ($threadRows.Count -gt 24) {
    $rest = ($threadRows | Select-Object -Skip 24 | Measure-Object MsPerFrame -Sum).Sum
    [void]$out.Add(('  {0,8}  {1,10:N3}  the other {2} threads together' -f '', $rest, ($threadRows.Count - 24)))
}
[void]$out.Add('')
[void]$out.Add('PER SECOND')
[void]$out.Add(('  {0,4} {1,10} {2,9} {3,12} {4,9} {5,9} {6,8}' -f 't', 'cpu ms/fr', 'gpu3D %', 'gpu3D ms/fr', 'gpuAll %', 'gpuMemMB', 'ramMB'))
foreach ($r in $rows) {
    [void]$out.Add(('  {0,4} {1,10:N3} {2,9:N2} {3,12:N3} {4,9:N2} {5,9} {6,8}' -f $r.T, $r.CpuMsPerFrame, $r.Gpu3dPct, $r.Gpu3dMsPerFrame, $r.GpuAllPct, $r.GpuMemMB, $r.RamMB))
}

$out | ForEach-Object { Write-Host $_ }
try {
    New-Item -ItemType Directory -Force $OutDir | Out-Null
    $file = Join-Path $OutDir ("eff-{0}-{1}.txt" -f $Label, (Get-Date -Format 'yyyyMMdd-HHmmss'))
    $out | Set-Content -Encoding UTF8 $file
    Write-Host "eff-measure: written to $file"
} catch { Write-Host "eff-measure: could not write the file: $_" }
