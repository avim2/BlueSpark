# The renderer choice (native-gfx, 8 Nov: 4.7's option B, then called 5.0; the renderer toggle): which renderer Play asks for, and why.
# Dot-sourced by run-windows.ps1 (it passes the switches) and launcher.ps1 (Settings' RENDERER row).
#
# In order, the first that says one:
#   1. rex\out\renderer.txt, "native" or "emulated": a tester's override (the packaging PC slot's checks use it);
#   2. the player's choice, renderer= in launcher-settings.txt (Settings' RENDERER box writes it);
#   3. $Ttt2DefaultRenderer below: the package's default. **Turning native on for everyone is this one line**, when the
#      owner says so; a player who chose emulated keeps it, and the box always offers the way back.
# Whatever is chosen, native also needs the package's shader cache (run-windows.ps1 checks its stamp); without it, or if
# the game finds native unusable (NativeGfxChooseAtSetup: a lost GPU device in an earlier game, a cache it can't read),
# the game plays emulated and says so.

$Ttt2DefaultRenderer = 'native'   # (5.0, the owner, 15 Nov: "5.0 doesnt go out without native renderer default"; a saved renderer= (Settings, PlayCompat) is answered first, out\renderer.txt before that. Was 'emulated': 4.7-test2, the owner, 9 Nov: back to emulated after his hand tests. 5.0's flip to native waits for the gate and the owner's blind test.)
# (4.7, the owner, 9 Nov: native is not offered at all: no Settings row, no Install shader step, and renderer.txt or an old renderer=native give emulated.
# Its code and the shader tools stay in the package, unused. 4.8 turns this back on with the default above.)
$Ttt2NativeOffered = $true   # (5.0, 15 Nov: native is offered again: the Settings row, Install's shader step; was $false in 4.7)

# A tester's way in while native is not offered to players (12 Nov, the QA lead's ask for the beta-integration package): a file
# rex\out\renderer-test.txt whose first line is "native" turns the native renderer on for that install, and only if the package can
# draw natively (its game is linked with Plume: prebuilt\lib\plume.lib, or the shader tools are there, or a source build's cache
# stamp). Players never have the file: no Settings row, renderer.txt and renderer=native are still ignored while $Ttt2NativeOffered
# is false. The shader cache is made by Install (setup-steps.ps1), by Play in the background (run-windows.ps1), or by
# rex\tools\native-shaders\tester-cache.ps1 in one go.
function Test-Ttt2TesterNative([string]$Rex) {
    $file = Join-Path $Rex 'out\renderer-test.txt'
    if (-not (Test-Path -LiteralPath $file)) { return $false }
    if ("$(Get-Content -LiteralPath $file -TotalCount 1)".Trim().ToLower() -ne 'native') { return $false }
    return (Test-Path -LiteralPath (Join-Path $Rex 'prebuilt\lib\plume.lib')) -or
           (Test-Path -LiteralPath (Join-Path $Rex 'prebuilt\tools\shaders\VERSION.txt')) -or
           (Test-Path -LiteralPath (Join-Path $Rex 'out\native-shaders.bin.stamp'))
}

# The way back to emulated (12 Nov, the native lead's contract): a failure marker, rex\out\native-shaders.bin.native-failed (line 1 = the reason
# in plain words, then kind=, ...), written by the game (no device, device lost), by Play (a start that never finished) or by
# "Play (old renderer).cmd" (kind=player-chose), keeps every start emulated until the player picks native again (Settings' choice
# deletes it: Clear-Ttt2NativeFailed).
function Get-Ttt2NativeFailed([string]$Rex) {
    $marker = Join-Path $Rex 'out\native-shaders.bin.native-failed'
    if (-not (Test-Path -LiteralPath $marker)) { return $null }
    $reason = "$(Get-Content -LiteralPath $marker -TotalCount 1)".Trim()
    return @{ Path = $marker; Reason = $reason }
}
# (B's Play side, the native lead's 12 Nov contract item 3: picking native again deletes .native-failed, .device-lost and a stale
# .starting; a .starting whose process is still running is another game starting on this PC and is left alone.)
function Clear-Ttt2NativeFailed([string]$Rex) {
    Remove-Item -LiteralPath (Join-Path $Rex 'out\native-shaders.bin.native-failed') -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath (Join-Path $Rex 'out\native-shaders.bin.device-lost') -Force -ErrorAction SilentlyContinue
    if (Test-Ttt2NativeStartStale $Rex) {
        Remove-Item -LiteralPath (Join-Path $Rex 'out\native-shaders.bin.starting') -Force -ErrorAction SilentlyContinue
    }
}

# The lost-device retry (19 Nov, the owner's yes via the main line's lead; the native lead's three conditions): a device loss leaves TWO files,
# <cache>.device-lost and <cache>.native-failed (kind=device-lost), and either one sends the game to the old renderer. A Play start that finds that kind
# removes BOTH and lets the game try native, ONCE: the count is lost_retry= in launcher-settings.txt (Play's own settings, no new file). Another kind
# (no-device, start-crash, player-chose, ...) stays sticky, as does a loss after the retry (count 1: the old renderer and the card stay). A clean
# run resets the count: a later Play start finding no marker, no running game and no "THE GPU DEVICE WAS LOST" line in the newest log. Not on the
# immediate restart after a loss's exit 77 (TTT2_PLAY_RESTARTED): that start is the old renderer with the card; the NEXT Play start is the retry.
# Returns 'retry' (markers removed, count set to 1), 'sticky' (a marker stays), 'reset' (the count went back to 0) or 'none'.
function Get-Ttt2SettingValue([string]$SettingsFile, [string]$Name) {
    if (-not $SettingsFile -or -not (Test-Path -LiteralPath $SettingsFile)) { return $null }
    $line = Get-Content -LiteralPath $SettingsFile | Where-Object { $_ -match "^$Name=" } | Select-Object -Last 1
    if ($line -match "^$Name=(.*)$") { return $Matches[1].Trim() }
    return $null
}
function Set-Ttt2SettingValue([string]$SettingsFile, [string]$Name, [string]$Value) {
    $lines = @()
    if (Test-Path -LiteralPath $SettingsFile) { $lines = @(Get-Content -LiteralPath $SettingsFile | Where-Object { $_ -notmatch "^$Name=" }) }
    New-Item -ItemType Directory -Force (Split-Path $SettingsFile -Parent) | Out-Null
    Set-Content -LiteralPath $SettingsFile ($lines + "$Name=$Value")
}
function Use-Ttt2LostRetry([string]$Rex, [string]$SettingsFile, [string]$LogsDir) {
    if (-not $SettingsFile) { return 'none' }
    $cache = Join-Path $Rex 'out\native-shaders.bin'
    $failedFile = "$cache.native-failed"; $lostFile = "$cache.device-lost"
    $hasFailed = Test-Path -LiteralPath $failedFile; $hasLost = Test-Path -LiteralPath $lostFile
    $count = 0
    $stored = Get-Ttt2SettingValue $SettingsFile 'lost_retry'
    if ($stored -match '^\d+$') { $count = [int]$stored }
    if (-not $hasFailed -and -not $hasLost) {
        if ($count -le 0) { return 'none' }
        if (Get-Process -Name ttt2 -ErrorAction SilentlyContinue) { return 'none' }   # (a game is running: its run is not over)
        $newest = if ($LogsDir -and (Test-Path -LiteralPath $LogsDir)) { Get-ChildItem -LiteralPath $LogsDir -Filter 'ttt2_*.log' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime | Select-Object -Last 1 } else { $null }
        if ($newest -and (Select-String -LiteralPath $newest.FullName -Pattern 'THE GPU DEVICE WAS LOST' -SimpleMatch -Quiet)) { return 'none' }
        Set-Ttt2SettingValue $SettingsFile 'lost_retry' '0'
        return 'reset'
    }
    $kind = ''
    if ($hasFailed) {
        $kl = Get-Content -LiteralPath $failedFile -ErrorAction SilentlyContinue | Where-Object { $_ -match '^kind=' } | Select-Object -First 1
        if ($kl) { $kind = "$kl".Substring(5).Trim() }
    } elseif ($hasLost) { $kind = 'device-lost' }   # (the loss file alone: the game's write of the other one did not happen)
    if ($kind -ne 'device-lost' -or $count -ge 1) { return 'sticky' }
    Remove-Item -LiteralPath $failedFile, $lostFile -Force -ErrorAction SilentlyContinue
    Set-Ttt2SettingValue $SettingsFile 'lost_retry' '1'
    return 'retry'
}

# The start marker, rex\out\native-shaders.bin.starting (the game writes it before it makes the device, with --ttt2_native_gfx_fallback_marker):
# one "pid=N" line per game starting. Stale (the game's own rule, FallbackStartIsStale) = a pid line whose process is gone, or no pid line.
function Get-Ttt2NativeStartPids([string]$Rex) {
    $file = Join-Path $Rex 'out\native-shaders.bin.starting'
    if (-not (Test-Path -LiteralPath $file)) { return $null }
    # (The comma keeps an empty list a list: returned bare, PowerShell would hand back $null, which reads as "no marker".)
    return , @(Get-Content -LiteralPath $file -ErrorAction SilentlyContinue | Where-Object { $_ -match '^pid=(\d+)\s*$' } |
        ForEach-Object { [int64]$Matches[1] })
}
function Test-Ttt2NativeStartStale([string]$Rex) {
    $pids = Get-Ttt2NativeStartPids $Rex
    if ($null -eq $pids) { return $false }
    if ($pids.Count -eq 0) { return $true }
    foreach ($p in $pids) { if (-not (Get-Process -Id $p -ErrorAction SilentlyContinue)) { return $true } }
    return $false
}

# The game's switch for the marker contract (--ttt2_native_gfx_fallback_marker, off in the game). Play waits on a native start's first
# seconds (for the no-device exit code) only when it is on: in the caller's switches, or here, turned on with the game's default.
$Ttt2FallbackMarkerOn = $false
$Ttt2NativeExitNoDevice = 77   # (kNativeGfxExitNoDevice, rex/src/native_gfx/native_graphics_system.h)

# The prompt for a start without BlueSpark (the helper lead's 12 Nov item 6(c)): a failure marker not yet shown (no "shown=1" line)
# gets ONE plain Windows message box before the game starts, and the marker is marked shown. With BlueSpark the game's popup does it.
function Show-Ttt2NativeFailedBox([string]$Rex) {
    $marker = Join-Path $Rex 'out\native-shaders.bin.native-failed'
    if (-not (Test-Path -LiteralPath $marker)) { return $false }
    $lines = @(Get-Content -LiteralPath $marker -ErrorAction SilentlyContinue)
    if ($lines -contains 'shown=1') { return $false }
    $reason = "$($lines | Select-Object -First 1)".Trim()
    $text = "$reason`r`n`r`nIf this keeps happening, run ""Report a problem.cmd"" in the game's folder and send the zip it makes to the developers."
    try {
        Add-Type -AssemblyName System.Windows.Forms
        [void][System.Windows.Forms.MessageBox]::Show($text, 'TTT2: the old renderer', 'OK', 'Information')
    } catch { Write-Host "The message box did not show: $($_.Exception.Message)" }
    try { Add-Content -LiteralPath $marker -Value 'shown=1' -Encoding ascii } catch { }
    return $true
}

function Get-Ttt2RendererChoice([string]$Rex, [string]$SettingsFile) {
    if ($failed = Get-Ttt2NativeFailed $Rex) { return @{ Renderer = 'emulated'; From = "rex\out\native-shaders.bin.native-failed: $($failed.Reason)" } }
    if (-not $Ttt2NativeOffered) {
        if (Test-Ttt2TesterNative $Rex) { return @{ Renderer = 'native'; From = 'out\renderer-test.txt (a tester)' } }
        return @{ Renderer = 'emulated'; From = 'this release (native not offered)' }
    }
    $override = Join-Path $Rex 'out\renderer.txt'
    if (Test-Path -LiteralPath $override) {
        $v = "$(Get-Content -LiteralPath $override -TotalCount 1)".Trim().ToLower()
        if ($v -in @('native', 'emulated')) { return @{ Renderer = $v; From = 'out\renderer.txt' } }
    }
    if ($SettingsFile -and (Test-Path -LiteralPath $SettingsFile)) {
        foreach ($line in Get-Content -LiteralPath $SettingsFile) {
            if ($line -match '^renderer=(native|emulated)\s*$') { return @{ Renderer = $Matches[1]; From = 'Settings' } }
        }
    }
    return @{ Renderer = $Ttt2DefaultRenderer; From = 'default' }
}

# Can this install draw natively at all? A package with the shader tools, or a source checkout's native build.
function Test-Ttt2NativeAvailable([string]$Rex) {
    if (-not $Ttt2NativeOffered) { return $false }   # (4.7: Settings' RENDERER row is hidden)
    return (Test-Path -LiteralPath (Join-Path $Rex 'prebuilt\tools\shaders\VERSION.txt')) -or
           (Test-Path -LiteralPath (Join-Path $Rex 'out\native-shaders.bin.stamp'))
}

# The native shader cache's state, for Settings' note: ready, being made, not yet made, failed to translate, or set aside after a lost device.
function Get-Ttt2NativeCacheState([string]$Rex) {
    $cache = Join-Path $Rex 'out\native-shaders.bin'
    if (Test-Path -LiteralPath "$cache.device-lost") { return 'device-lost' }
    if (Test-Path -LiteralPath "$cache.building") {   # (the lock holds its builder's process id: a closed window's stale lock doesn't count)
        $holder = "$(Get-Content -LiteralPath "$cache.building" -TotalCount 1)".Trim()
        if ($holder -match '^\d+$' -and (Get-Process -Id ([int]$holder) -ErrorAction SilentlyContinue)) { return 'building' }
    }
    if (-not (Test-Path -LiteralPath $cache) -or -not (Test-Path -LiteralPath "$cache.stamp")) {
        if (Test-Path -LiteralPath "$cache.failed") {   # (C3: failed with these tools: Install tries again; new tools, the next Play)
            $versionFile = Join-Path $Rex 'prebuilt\tools\shaders\VERSION.txt'
            $want = if (Test-Path -LiteralPath $versionFile) {
                ("$(Get-Content -LiteralPath $versionFile | Where-Object { $_ -like 'stamp=*' } | Select-Object -First 1)" -replace '^stamp=', '').Trim()
            } else { '' }
            if ("$(Get-Content -LiteralPath "$cache.failed" -TotalCount 1)".Trim() -eq $want) { return 'failed' }
        }
        return 'none'
    }
    $versionFile = Join-Path $Rex 'prebuilt\tools\shaders\VERSION.txt'
    if (Test-Path -LiteralPath $versionFile) {
        $want = ("$(Get-Content -LiteralPath $versionFile | Where-Object { $_ -like 'stamp=*' } | Select-Object -First 1)" -replace '^stamp=', '').Trim()
        $have = "$(Get-Content -LiteralPath "$cache.stamp" -TotalCount 1)".Trim()
        if ($want -and $have -ne $want) { return 'old' }
    }
    return 'ready'
}
