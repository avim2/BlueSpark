﻿# Builds TTT2 on Windows: the ReXGlue SDK (once), then the game.
#
# Run from the repo folder:
#   powershell -ExecutionPolicy Bypass -File rex\build-windows.ps1
#
# Needs Visual Studio with "Desktop development with C++" plus the "C++ Clang Compiler for
# Windows" (Clang 20 or newer) and "MSBuild support for LLVM (clang-cl) toolset" components,
# and Git. The SDK goes in %USERPROFILE%\rexsdk (a short path: its build has deep folders), with
# the changes in rex\patches applied to it. When those change, the SDK is rebuilt.
#
# Three ways (docs/PREBUILT_PACKAGE_PLAN.md):
#  - the source build (the default, dev work): rex\src compiled into the exe;
#  - -OursLib (rex\build-prebuilt.ps1, the owner's release build): rex\src as the static library ttt2_ours, linked whole;
#  - the player's package (rex\prebuilt\manifest.txt exists): no SDK build and no sources: rex\prebuilt\sdk and
#    rex\prebuilt\lib\ttt2_ours.lib, the pinned portable toolchain; the translation is checked against the release and
#    the link against the hook list.

# -Toolchain portable (or TTT2_TOOLCHAIN=portable): the pinned portable toolchain (rex\tools\toolchain.ps1) instead of
# Visual Studio, with its own SDK folder (%USERPROFILE%\rexsdk-portable unless rex\sdk-folder.txt names one).
param([ValidateSet('vs', 'portable')][string]$Toolchain = $(if ($env:TTT2_TOOLCHAIN -eq 'portable') { 'portable' } else { 'vs' }),
      [switch]$OursLib)

$ErrorActionPreference = 'Stop'
# (Builds run freely, each in its own folder, but not during a quiet measurement: docs/GAME_LOCK_RULES_20261102.md.)
. (Join-Path $PSScriptRoot 'tools\game-lock.ps1')
Enter-GameLockBuild $PSScriptRoot
# (4.5: an install folder with [ or ] in its path, "...[RF]": CMake reads them as a wildcard in its own file(GLOB ...), so the SDK's
# exported targets and helpers find nothing there ("IMPORTED_LOCATION not set for imported target rex::rexglue"). The build runs through
# a junction to the same folder with a plain name instead, the same one each time (%LOCALAPPDATA%\TTT2Native\path-alias\<hash>; a
# junction needs no administrator), so CMake never sees the brackets. The files are this folder's: the build lands in it as usual.)
if ($PSScriptRoot -match '[\[\]]') {
    $realRepo = Split-Path -Parent $PSScriptRoot
    $sha = [Security.Cryptography.SHA256]::Create()
    $hash = -join ($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($realRepo.ToLowerInvariant())) | Select-Object -First 6 | ForEach-Object { $_.ToString('x2') })
    $aliasRoot = Join-Path $env:LOCALAPPDATA 'TTT2Native\path-alias'
    $alias = Join-Path $aliasRoot $hash
    if ($alias -match '[\[\]]') { throw "This folder's path has [ or ] in it ($realRepo), and so does ${aliasRoot}: the build can't run from it. Move the whole folder to C:\ttt2 and run BlueSpark there." }
    New-Item -ItemType Directory -Force $aliasRoot | Out-Null
    if (Test-Path -LiteralPath $alias) {
        $target = @((Get-Item -LiteralPath $alias -Force).Target) | Select-Object -First 1
        if ($target -ne $realRepo) { [IO.Directory]::Delete($alias) }   # (a junction: only the link goes)
    }
    if (-not (Test-Path -LiteralPath $alias)) {
        # (4.5.1: PowerShell's own junction, not cmd's mklink. Its -Target reads [ and ] as wildcards, so escaped.)
        $made = try { New-Item -ItemType Junction -Path $alias -Target ([Management.Automation.WildcardPattern]::Escape($realRepo)) -ErrorAction Stop | Out-Null; 'made' } catch { $_.Exception.Message }
        if ($made -ne 'made' -or -not (Test-Path -LiteralPath (Join-Path $alias 'rex\build-windows.ps1'))) {
            throw "This folder's path has [ or ] in it ($realRepo), which the build's CMake can't take, and the plain-named link to it couldn't be made ($made). Move the whole folder to C:\ttt2 and run BlueSpark there."
        }
    }
    Write-Host "This folder's path has [ or ] in it: the build runs through $alias (the same folder, a plain name for CMake)."
    & (Join-Path $alias 'rex\build-windows.ps1') @PSBoundParameters
    exit 0
}
$SdkTag = 'v0.10.0'
$Repo = Split-Path -Parent $PSScriptRoot
$Rex = $PSScriptRoot
. (Join-Path $Rex 'tools\remove-folder.ps1')   # (Remove-Ttt2Folder: deletes through .NET, safe in a non-ASCII install folder)
. (Join-Path $Rex 'tools\build-cache.ps1')   # (the install's per-PC build caches, 22 Nov: docs/BUILDTIME_PLAN_20261122.md)
$PrebuiltManifest = Join-Path $Rex 'prebuilt\manifest.txt'
$Prebuilt = Test-Path -LiteralPath $PrebuiltManifest
if ($Prebuilt) { $Toolchain = 'portable'; $OursLib = $false }
# The host-write lint (rex\tools\host-write-lint.ps1 runs rex\tools\check_host_writes.py): FATAL in the marked build (rex\ttt2_manifest.toml has
# template_dir = "templates_dirty"), one WARNING otherwise; skipped when there is no usable Python; a package has no sources.
$HostWriteLintStep = Join-Path $Rex 'tools\host-write-lint.ps1'
if (-not $Prebuilt -and (Test-Path -LiteralPath $HostWriteLintStep)) { & $HostWriteLintStep -Rex $Rex }
# The SDK's folder: %USERPROFILE%\rexsdk, or what rex\sdk-folder.txt says (one line: a folder name
# under %USERPROFILE%, or a full path; this PC's, not part of the repo), so that two clones on
# branches with different rex\patches each keep their own SDK and don't rebuild each other's.
$SdkFolder = Join-Path $env:USERPROFILE $(if ($Toolchain -eq 'portable') { 'rexsdk-portable' } else { 'rexsdk' })
$sdkFolderFile = Join-Path $Rex 'sdk-folder.txt'
if (-not $Prebuilt -and (Test-Path -LiteralPath $sdkFolderFile)) {
    $named = "$(Get-Content -LiteralPath $sdkFolderFile -Raw)".Trim().Trim('"')
    if ($named) {
        $SdkFolder = if ([IO.Path]::IsPathRooted($named)) { $named } else { Join-Path $env:USERPROFILE $named }
    }
}
# (native-gfx: a build with the test-only observers 90+ (TTT2_NATIVE_TEST_OBSERVERS=1) gets an SDK folder of its own,
# '<folder>-native-test', so no other build ever picks up an SDK built with them; the main line's lead, 5 Nov.)
if ($env:TTT2_NATIVE_TEST_OBSERVERS -eq '1' -and -not $Prebuilt -and $SdkFolder -notlike '*-native-test') { $SdkFolder = "$SdkFolder-native-test" }
$SdkSource = Join-Path $SdkFolder 'src'
$SdkInstall = if ($Prebuilt) { Join-Path $Rex 'prebuilt\sdk' } else { Join-Path $SdkFolder 'install' }
Write-Host "ReXGlue SDK folder: $(if ($Prebuilt) { $SdkInstall } else { $SdkFolder })"

# (E, 22 Nov: an install's shader step runs beside this build (setup-steps.ps1 starts it); the new whole lines it has made are passed on to the window
# from the loops below, at most every 1.5 s. No relay set (a developer's build, and the default: TTT2_BG_SHADERS=1 is the opt-in): nothing.)
function Send-Ttt2BgShaders { if ($global:Ttt2BgShadersRelay) { & $global:Ttt2BgShadersRelay } }
function Step($text) { Send-Ttt2BgShaders; Write-Host ''; Write-Host "== $text" -ForegroundColor Cyan }
function Run {
    # Native tools write progress to stderr. Windows PowerShell turns that into errors when its own
    # output is redirected (as in the launcher's steps), which $ErrorActionPreference = 'Stop' makes
    # fatal; so stderr is passed through as plain text, and only the exit code decides.
    $saved = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { & $args[0] $args[1..($args.Count - 1)] 2>&1 | ForEach-Object { Send-Ttt2BgShaders; "$_" } }
    finally { $ErrorActionPreference = $saved }
    if ($LASTEXITCODE -ne 0) { throw "Failed ($LASTEXITCODE): $($args -join ' ')" }
}
# A configure (cmake --preset ...) with one retry when the compiler's own feature test failed (a player's Install, 3 Nov: "Detecting
# CXX compile features - failed", then the generate step's "No known features for CXX compiler"): the build folder cleared, the configure
# run once more; failed again, said plainly (often an antivirus blocking the compiler's test programs). TTT2_TEST_CONFIGURE_FEATURES=1:
# the first configure is made to fail so (the retry's path), =2: both (the message's).
function Invoke-Ttt2Configure([string]$dir, [string[]]$cmakeArgs) {
    $script:configureTry = 0
    $once = {
        $script:configureTry++
        $lines = New-Object System.Collections.Generic.List[string]
        $failed = $null
        try { Run cmake @cmakeArgs | ForEach-Object { $lines.Add($_); Write-Host $_ } } catch { $failed = $_ }   # (shown as it comes, not this block's output)
        $test = $env:TTT2_TEST_CONFIGURE_FEATURES
        if (-not $failed -and (($test -eq '1' -and $script:configureTry -eq 1) -or $test -eq '2')) {
            $lines.Add('-- Detecting CXX compile features - failed (TTT2_TEST_CONFIGURE_FEATURES)'); $failed = 'the test hook'
            Write-Host '-- Detecting CXX compile features - failed (TTT2_TEST_CONFIGURE_FEATURES)'
        }
        [pscustomobject]@{ Failed = $failed; Features = ($lines -match 'compile features - failed|No known features for CXX compiler').Count -gt 0 }
    }
    $r = & $once
    if (-not $r.Failed) { return }
    if (-not $r.Features) { throw $r.Failed }
    Write-Host "The compiler's own feature test failed: $dir cleared, the configure run once more."
    if (Test-Path -LiteralPath $dir) { Remove-Ttt2Folder $dir }
    $r = & $once
    if (-not $r.Failed) { return }
    throw ("The compiler's own test failed on this PC, twice: often an antivirus blocking it. Add $Repo and $env:LOCALAPPDATA\TTT2Native " +
           "to its exclusions, then click Install again. (The details are in $dir\CMakeFiles\CMakeConfigureLog.yaml: Report a problem sends it.)")
}
# key=value lines (the prebuilt manifest).
function Read-KeyValues([string]$file) {
    $map = [ordered]@{}
    if (Test-Path -LiteralPath $file) {
        foreach ($line in Get-Content -LiteralPath $file) {
            $i = $line.IndexOf('=')
            if ($i -gt 0) { $map[$line.Substring(0, $i)] = $line.Substring($i + 1) }
        }
    }
    $map
}
# A text file's SHA-256 with its line endings made \n (a checkout or an unzip may give either).
function Get-TextHash([string]$file) {
    $text = [IO.File]::ReadAllText($file) -replace "`r`n", "`n"
    $sha = [Security.Cryptography.SHA256]::Create()
    ($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($text)) | ForEach-Object { $_.ToString('x2') }) -join ''
}

# One run of the translation (the ttt2_codegen target): its exit code, its analysis errors (the "0x... from 0x..." lines of
# its ANALYSIS ERRORS report, sorted) and the partition's hash ('' when it made none). Its output is shown as Run shows it.
function Invoke-Ttt2Codegen([string]$Build, [string]$Partition) {
    $saved = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { $out = @(& cmake --build $Build --target ttt2_codegen 2>&1 | ForEach-Object { "$_" }) } finally { $ErrorActionPreference = $saved }
    $code = $LASTEXITCODE
    $out | ForEach-Object { Write-Host $_ }
    Send-Ttt2BgShaders
    $errors = @($out | ForEach-Object { if ($_ -match '(0x[0-9A-Fa-f]{8}( from 0x[0-9A-Fa-f]{8})?: .*)$') { $Matches[1].Trim() } } | Sort-Object -Unique)
    $hash = if (Test-Path -LiteralPath $Partition) { Get-TextHash (Resolve-Path -LiteralPath $Partition) } else { '' }
    [pscustomobject]@{ Code = $code; Errors = $errors; Hash = $hash }
}
function Describe-Ttt2Codegen($r) {
    if ($r.Errors.Count) { return "$($r.Errors.Count) analysis error(s), the first: $($r.Errors[0])" }
    if ($r.Code -ne 0) { return "it failed ($($r.Code))" }
    "the translation $($r.Hash.Substring(0, [Math]::Min(12, $r.Hash.Length)))"
}
# The words when the same work gave two different answers (I, the lead's order of 27 Oct): the processor or the memory. The
# Intel lines only for a 13th or 14th generation Core i5/i7/i9 (their instability); others: the memory overclock and the BIOS.
function Get-Ttt2Cpu { try { (Get-CimInstance Win32_Processor | Select-Object -First 1).Name } catch { '' } }
function Get-Ttt2StabilityAdvice([string]$cpu = (Get-Ttt2Cpu)) {
    $intel1314 = "$cpu" -match 'Core\(TM\) i[579]-1[34]\d{2,3}|Core i[579]-1[34]\d{2,3}'
    if ($intel1314) {
        "Update your motherboard's BIOS, use Intel's default settings and turn XMP/EXPO off, then try again. Intel's Processor Diagnostic Tool can check the processor."
    } else {
        "Turn off any memory overclock (XMP/EXPO) and other overclocking, update your motherboard's BIOS, then try again."
    }
}
function Get-Ttt2UnstablePcNote {
    $cpu = Get-Ttt2Cpu
    "Your PC gave two different answers to the same work. Your game files are fine; this is the processor or the memory ($cpu). $(Get-Ttt2StabilityAdvice $cpu)"
}
# How many compiler jobs the game's build runs at once (4.5.1, the lead's order of 30 Oct: the marked build, ~20 min, ran out of memory
# at 12 jobs on a 32 GB PC). One job of the marked build peaks at $Ttt2JobPeakGB (its biggest generated file, measured); the count is the
# PC's threads, or what its free memory holds at that peak, whichever is fewer. TTT2_BUILD_JOBS: a count of your own.
# TTT2_TEST_BUILD_FREE_GB: test only, the free memory taken as this (a 16 GB PC's).
$Ttt2JobPeakGB = 1.0   # (measured 30 Oct: 0.93 GB private at most, the clean marked build at 6 jobs, llvm 20.1.8)
function Get-Ttt2BuildJobs {
    if ($env:TTT2_BUILD_JOBS -match '^\d+$' -and [int]$env:TTT2_BUILD_JOBS -gt 0) { return @{ Jobs = [int]$env:TTT2_BUILD_JOBS; Why = 'TTT2_BUILD_JOBS' } }
    $threads = [Math]::Max(1, [Environment]::ProcessorCount)
    $freeGB = try {
        Add-Type -AssemblyName Microsoft.VisualBasic
        (New-Object Microsoft.VisualBasic.Devices.ComputerInfo).AvailablePhysicalMemory / 1GB
    } catch { $null }
    if ($env:TTT2_TEST_BUILD_FREE_GB -match '^\d+(\.\d+)?$') { $freeGB = [double]$env:TTT2_TEST_BUILD_FREE_GB; Write-Host "Test: the free memory taken as $freeGB GB (TTT2_TEST_BUILD_FREE_GB)" }
    if ($null -eq $freeGB) { return @{ Jobs = [Math]::Min($threads, 4); Why = "$threads threads, the free memory unknown" } }
    $byMemory = [Math]::Max(1, [int][Math]::Floor($freeGB / $Ttt2JobPeakGB))
    # (4.6.2.1, the owner's "a more stable build": at most $Ttt2MaxJobs. Players' clang crashed at 16 jobs and again at 8 with memory to
    # spare (4 Nov); fewer at once is less load on a PC that computes wrong under it. A clean build here: 3 min at 8 or 16 jobs.)
    $jobs = [Math]::Min([Math]::Min($threads, $byMemory), $Ttt2MaxJobs)
    @{ Jobs = $jobs; Why = ('{0} threads, {1:N1} GB of memory free at ~{2} GB a job, at most {3}' -f $threads, $freeGB, $Ttt2JobPeakGB, $Ttt2MaxJobs) }
}
$Ttt2MaxJobs = 8
# A compiler that crashed or ran out of memory, in the build's output (clang's own words, Windows' for a full page file).
function Test-Ttt2CompilerCrash([string[]]$lines) {
    [bool]($lines | Where-Object { $_ -match '(?i)clang\S* frontend command failed|PLEASE submit a bug report|LLVM ERROR|out of memory|bad_alloc|unable to allocate|not enough (memory|space)|paging file is too small|0xC0000005|0xC0000409|0xC000001D|Stack dump:' } | Select-Object -First 1)
}
# The files Ninja says failed ("FAILED: <object>" lines: the .cpp's name from the object's) and clang's first error line, for the log and
# the box (4.6.2.1: so players' reports tell one file that always fails from random ones).
function Get-Ttt2BuildFailure([string[]]$lines) {
    $files = @($lines | Where-Object { $_ -match '^FAILED: ' } | ForEach-Object { if ($_ -match '([\w\.\-]+\.(cpp|c|cc))\.obj') { $Matches[1] } else { ($_ -replace '^FAILED: ', '').Trim() } } | Select-Object -Unique)
    # (clang's own error line first: "clang++: error: clang frontend command failed due to signal", not its "PLEASE submit" banner)
    $first = $lines | Where-Object { $_ -match '(?i)\berror:|LLVM ERROR|Exception Code:|0xC0000005|out of memory|paging file' } | Select-Object -First 1
    if (-not $first) { $first = $lines | Where-Object { $_ -match '(?i)PLEASE submit a bug report|Stack dump:' } | Select-Object -First 1 }
    @{ Files = $files; First = if ($first) { "$first".Trim() } else { '' } }
}
# Precompiled headers (11 Nov, a 4.7.3 player: 4.7.2 built, then updated in place, every build after failed with "file '...\func.h' has
# been modified since the precompiled header '...\cmake_pch.hxx.pch' was built" in all 196 units): the update replaced the SDK's headers
# with the package's file times, older than the player's last build, so Ninja kept the old .pch and clang refused it. The .pch files are
# only a cache (seconds to make again): they are deleted when the package is not the one that made them (pch-owner.txt in the build
# folder, written after a good build; none: deleted too), and once more if a build still fails with that error.
function Remove-Ttt2Pch([string]$Build) {
    $n = 0
    if (Test-Path -LiteralPath $Build) {
        foreach ($f in @(Get-ChildItem -LiteralPath $Build -Recurse -File -Force -Filter 'cmake_pch.*' -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '\.pch$' })) {
            try { Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop; $n++ } catch { }
        }
    }
    return $n
}
# What identifies the package the headers came from: the prebuilt manifest's text hash (a release), else VERSION.txt's (a checkout).
function Get-Ttt2PchOwner {
    if ($Prebuilt -and (Test-Path -LiteralPath $PrebuiltManifest)) { return "prebuilt $(Get-TextHash $PrebuiltManifest)" }
    $v = Join-Path $Repo 'VERSION.txt'
    if (Test-Path -LiteralPath $v) { return "version $(Get-TextHash $v)" }
    return ''
}
function Clear-Ttt2StalePch([string]$Build) {
    $owner = Get-Ttt2PchOwner
    if (-not $owner) { return }
    $record = Join-Path $Build 'pch-owner.txt'
    $recorded = if (Test-Path -LiteralPath $record) { "$(Get-Content -LiteralPath $record -TotalCount 1)".Trim() } else { '' }
    if ($recorded -eq $owner) { return }
    $n = Remove-Ttt2Pch $Build
    if ($n) { Write-Host "Build: the precompiled headers ($n) were made by another release: they are made again (a few seconds)." }
}
function Save-Ttt2PchOwner([string]$Build) {
    $owner = Get-Ttt2PchOwner
    if ($owner) { try { Set-Content -LiteralPath (Join-Path $Build 'pch-owner.txt') -Value $owner -Encoding ascii } catch { } }
}
# The game's build. 4.6.2.1 (the owner, 4 Nov: "a more stable build"): Ninja keeps going past a failed file (-k 0), so a try makes
# every file it can; after a compiler crash or out of memory the build goes on at fewer jobs, down a ladder: the job count, half of
# it, 2, then 1 (Ninja redoes only the files not yet made: a crash under load often passes alone). Only then the message. A build
# that passed after a crash says on which try, and which files had crashed.
# TTT2_TEST_BUILD_CRASH_FILE=<ttt2_recomp.N.cpp>: test only, that generated file really crashes clang on the first try (a
# "#pragma clang __debug crash" line in it), and is put back as it was before the second.
function Invoke-Ttt2GameBuild([string]$Build) {
    $plan = Get-Ttt2BuildJobs
    $ladder = @(@($plan.Jobs, [int][Math]::Floor($plan.Jobs / 2), 2, 1) | Where-Object { $_ -ge 1 -and $_ -le $plan.Jobs } | Select-Object -Unique)
    $crashedFiles = [Collections.Generic.List[string]]::new()
    $testFile = $null; $testBytes = $null
    if ($env:TTT2_TEST_BUILD_CRASH_FILE) {
        $testFile = Join-Path $Rex "generated\default\$($env:TTT2_TEST_BUILD_CRASH_FILE)"
        if (Test-Path -LiteralPath $testFile) {
            $testBytes = [IO.File]::ReadAllBytes($testFile)
            [IO.File]::AppendAllText($testFile, "`n#pragma clang __debug crash`n")
            Write-Host "Test: $($env:TTT2_TEST_BUILD_CRASH_FILE) crashes clang on the first try (TTT2_TEST_BUILD_CRASH_FILE)"
        } else { Write-Host "Test: TTT2_TEST_BUILD_CRASH_FILE: no $testFile"; $testFile = $null }
    }
    $pchRetried = $false; $deniedRetried = $false; $attempt = 0
    try {
    for ($try = 1; ; $try++) {
        $attempt++
        $jobs = $ladder[[Math]::Min($try, $ladder.Count) - 1]
        Write-Host "Compiling with $jobs jobs at once ($($plan.Why))."
        $lines = [Collections.Generic.List[string]]::new()
        $saved = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        try { & cmake --build $Build --parallel $jobs -- -k 0 2>&1 | ForEach-Object { Send-Ttt2BgShaders; $l = "$_"; $lines.Add($l); $l } }
        finally { $ErrorActionPreference = $saved }
        $code = $LASTEXITCODE
        if ($testFile -and $testBytes) { [IO.File]::WriteAllBytes($testFile, $testBytes); $testBytes = $null; Write-Host "Test: $($env:TTT2_TEST_BUILD_CRASH_FILE) put back as it was" }
        # (TTT2_TEST_BUILD_CRASH=1 or 1,2: test only, that try is taken as a compiler crash: the retry, then the message.)
        if (@("$env:TTT2_TEST_BUILD_CRASH" -split ',') -contains "$try") { Write-Host "Test: the compiler is taken as crashed (TTT2_TEST_BUILD_CRASH, try $try)"; $code = 1; $lines.Add('clang++: error: clang frontend command failed due to signal (test)') }
        # (TTT2_TEST_BUILD_PCH=1 / TTT2_TEST_BUILD_DENIED=1,2: test only, that attempt fails with the precompiled-header error / a header
        # that cannot be opened: the paths below.)
        if ($env:TTT2_TEST_BUILD_PCH -eq '1' -and $attempt -eq 1) { $code = 1; $lines.Add("fatal error: file 'C:\sdk\include\rex\ppc\func.h' has been modified since the precompiled header 'C:\build\cmake_pch.hxx.pch' was built (test)"); Write-Host "Test: the precompiled-header error on the first attempt (TTT2_TEST_BUILD_PCH)" }
        if (@("$env:TTT2_TEST_BUILD_DENIED" -split ',') -contains "$attempt") { $code = 1; $lines.Add("fatal error: cannot open file 'C:\sdk\include\spdlog\details\registry.h': permission denied (test)"); Write-Host "Test: a header cannot be opened (TTT2_TEST_BUILD_DENIED, attempt $attempt)" }
        if ($code -eq 0) {
            if ($try -gt 1) { Write-Host "Build: passed on try $try of $($ladder.Count) (jobs $(($ladder[0..($try - 1)]) -join ', ')), after a compiler crash in $(if ($crashedFiles.Count) { $crashedFiles -join ', ' } else { 'a file not named' })." }
            return
        }
        if ($code -ne 0) {
            $text = $lines -join "`n"
            if (-not $pchRetried -and $text -match 'has been modified since the precompiled header') {
                $pchRetried = $true
                $n = Remove-Ttt2Pch $Build
                Write-Host "Build: a precompiled header was older than the SDK's files: $n deleted, the build goes on once more."
                $try--; continue
            }
            if ($text -match "(?i)(?<!LNK\d{4}: )fatal error: cannot open (source )?file '[^']*'|:\s*permission denied") {
                if (-not $deniedRetried) {
                    $deniedRetried = $true
                    Write-Host 'Build: a source or header file could not be opened (a program may be scanning the new files): waiting 20 seconds, then once more.'
                    Start-Sleep -Seconds 20
                    $try--; continue
                }
                throw ("A source or header file could not be opened, twice: a security program (often an antivirus) is holding the files. Add $Repo and $env:LOCALAPPDATA\TTT2Native " +
                       "to its exclusions, then click Install again.")
            }
        }
        $crashed = Test-Ttt2CompilerCrash $lines
        $failure = Get-Ttt2BuildFailure $lines
        foreach ($f in $failure.Files) { if (-not $crashedFiles.Contains($f)) { $crashedFiles.Add($f) } }
        if ($failure.Files.Count -or $failure.First) { Write-Host "Build: try $try failed in $(if ($failure.Files.Count) { $failure.Files -join ', ' } else { 'a file not named' }): $($failure.First)" }
        if ($crashed -and $try -lt $ladder.Count) {
            $plan.Why = "try $($try + 1) of $($ladder.Count) after a compiler crash"
            Write-Host "The compiler crashed or ran out of memory: the build goes on with $($ladder[$try]) job$(if ($ladder[$try] -ne 1) { "s" }) at once (the files already made are kept)."
            continue
        }
        if ($crashed) {
            $where = if ($failure.Files.Count) { " (in $($failure.Files -join ', '): $($failure.First))" } else { '' }
            # (30 Oct, main's PC: clang's crashes were access violations in random passes with 14 GB free and no job over 1 GB: not memory.
            # With few jobs, or memory to spare, the advice is the PC's stability.)
            $freeNow = try { Add-Type -AssemblyName Microsoft.VisualBasic; (New-Object Microsoft.VisualBasic.Devices.ComputerInfo).AvailablePhysicalMemory / 1GB } catch { 0 }
            if ($env:TTT2_TEST_BUILD_FREE_GB -match '^\d+(\.\d+)?$') { $freeNow = [double]$env:TTT2_TEST_BUILD_FREE_GB }
            $notMemory = $jobs -le 4 -or $freeNow -ge 2 * $jobs * $Ttt2JobPeakGB
            $what = if ($notMemory) { "The compiler crashed $($ladder.Count) times, the last with $jobs job$(if ($jobs -ne 1) { 's' }) at once$(if ($freeNow) { ' and {0:N0} GB of memory free' -f $freeNow })$($where): that is not a lack of memory." } else { "The compiler crashed or ran out of memory $($ladder.Count) times, the last with $jobs job$(if ($jobs -ne 1) { 's' }) at once$($where)." }
            $advice = "Close other programs (browsers, games) and click Install again: it goes on from where it stopped."
            if ($notMemory) { $advice += " If it keeps crashing, this PC may be computing wrong under load: $(Get-Ttt2StabilityAdvice) If that doesn't help: Report a problem.cmd, and send the report." }
            throw "$what $advice"
        }
        $where = if ($failure.Files.Count) { " in $($failure.Files -join ', '): $($failure.First)" } else { '' }
        throw "Failed ($code)$($where): cmake --build $Build --parallel $jobs"
    }
    } finally {
        if ($testFile -and $testBytes) { [IO.File]::WriteAllBytes($testFile, $testBytes) }   # (the test's file always put back)
    }
}
# Every hooked sub_X must come from our code (ttt2_ours): read from ttt2.map, the linker's own record of where each
# symbol came from. A hook missing from it, or coming from the generated code, was dropped.
function Test-HookLink([string]$map, [string[]]$hooks) {
    if (-not (Test-Path -LiteralPath $map)) { throw "No link map ($map): the hook check can't run." }
    $map = (Resolve-Path -LiteralPath $map).ProviderPath   # (.NET reads relative paths from the process's folder, not this one)
    $from = @{}
    foreach ($line in [IO.File]::ReadLines($map)) {
        $f = $line.Trim() -split '\s+'
        if ($f.Count -ge 4 -and $f[1] -like 'sub_*') { $from[$f[1]] = $f[$f.Count - 1] }
    }
    $bad = @($hooks | Where-Object { -not $from.ContainsKey($_) -or $from[$_] -notmatch 'ttt2_ours' })
    if ($bad.Count) {
        throw "The link dropped $($bad.Count) of our $($hooks.Count) hooks ($(($bad | Select-Object -First 5) -join ', ')...): ttt2_ours.lib wasn't linked whole. The game would run without them; not used."
    }
    Write-Host "Hook check: all $($hooks.Count) hooks come from ttt2_ours."
}

if ($Toolchain -eq 'portable') {
Step 'The portable toolchain'
. (Join-Path $Rex 'tools\toolchain.ps1')
Use-Ttt2Toolchain
$llvm = Split-Path (Get-Command clang++).Source
} else {
Step 'Finding Visual Studio'
$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
if (-not (Test-Path -LiteralPath $vswhere)) { throw 'Visual Studio Installer not found.' }
# The newest Visual Studio with the C++ tools and CMake (with Ninja); else the newest with the
# C++ tools (a PC can have several, e.g. a Community without CMake and our Build Tools).
$vs = & $vswhere -latest -prerelease -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 Microsoft.VisualStudio.Component.VC.CMake.Project -property installationPath
if (-not $vs) { $vs = & $vswhere -latest -prerelease -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath }
if (-not $vs) { throw 'No Visual Studio with the C++ tools. Add "Desktop development with C++" in the Visual Studio Installer.' }
Write-Host "Visual Studio: $vs"
Import-Module (Join-Path $vs 'Common7\Tools\Microsoft.VisualStudio.DevShell.dll')
Enter-VsDevShell -VsInstallPath $vs -SkipAutomaticLocation -DevCmdArguments '-arch=x64 -host_arch=x64' | Out-Null

# Visual Studio's own Clang, ahead of any other on PATH; or, when TTT2_LLVM names a standalone
# LLVM's bin folder (the launcher sets it when Visual Studio's Clang is older than 20), that one.
$llvm = Join-Path $vs 'VC\Tools\Llvm\x64\bin'
if ($env:TTT2_LLVM -and (Test-Path -LiteralPath (Join-Path $env:TTT2_LLVM 'clang.exe'))) { $llvm = $env:TTT2_LLVM }
if (-not (Test-Path -LiteralPath (Join-Path $llvm 'clang.exe'))) {
    throw 'Clang is missing. In the Visual Studio Installer, Modify, Individual components: tick "C++ Clang Compiler for Windows" and "MSBuild support for LLVM (clang-cl) toolset".'
}
$env:PATH = "$llvm;$env:PATH"
}
$clangVersion = (& clang --version | Select-Object -First 1)
Write-Host $clangVersion
if ($clangVersion -match 'version (\d+)\.' -and [int]$Matches[1] -lt 20) {
    throw "ReXGlue needs Clang 20 or newer; Visual Studio has $($Matches[1]). Update Visual Studio."
}
foreach ($tool in @(if (-not $Prebuilt) { 'git' }) + @('cmake', 'ninja')) {
    if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) { throw "$tool not found." }
}

$manifest = Read-KeyValues $PrebuiltManifest
if ($Prebuilt) {
    # The package's SDK, built by the owner with the patches the manifest names: checked, never rebuilt here.
    Step 'The prebuilt ReXGlue SDK'
    $patchRecord = Join-Path $SdkInstall 'ttt2-patches.txt'
    $built = if (Test-Path -LiteralPath $patchRecord) { (Get-Content -LiteralPath $patchRecord -Raw).Trim() } else { '' }
    # (24 Nov, 5.1, the lead: two players met one message for two causes: split, and the log says which.)
    if (-not (Test-Path -LiteralPath (Join-Path $SdkInstall 'bin\rexglue.exe'))) {
        Write-Host "Prebuilt SDK check: rex\prebuilt\sdk\bin\rexglue.exe is MISSING (patch record: $(if ($built) { 'present' } else { 'missing' }))"
        throw "The package's SDK has no rex\prebuilt\sdk\bin\rexglue.exe. A security program may have quarantined it: allow the folder in it (or restore the file), then run this again."
    }
    if ($built -ne $manifest['patches']) {
        Write-Host "Prebuilt SDK check: the patch record DIFFERS from this release's (record: '$built', release: '$($manifest['patches'])')"
        throw "The package's SDK (rex\prebuilt\sdk) is not the one this release was made with. Unzip the package into an EMPTY folder (not over an older one)."
    }
    if ((Get-FileHash -LiteralPath (Join-Path $SdkInstall 'bin\rexglue.exe') -Algorithm SHA256).Hash -ne $manifest['codegen.rexglue']) {
        throw "rex\prebuilt\sdk\bin\rexglue.exe is not this release's. Unzip the package again."
    }
    Write-Host "Release $($manifest['release']), built with $($manifest['toolchain'])"
} else {
# The SDK is built with our patches. A file in the install folder records which ones, so that a
# new or changed patch rebuilds it.
$patches = @(Get-ChildItem -LiteralPath (Join-Path $Rex 'patches') -Filter *.patch | Sort-Object Name)
# (native-gfx: the Linux pair's linux-NN patches never on Windows, and the native renderer's test-only observers
# (90 and up) only with TTT2_NATIVE_TEST_OBSERVERS=1 (rex\tools\native-test's -Dual and resolve dumps; player and package
# builds never set it, native on or off): every other build applies the main line's patches alone (the helper's
# comparison and the main line's lead, 5 November).)
$patches = @($patches | Where-Object { $_.Name -notlike 'linux-*' -and ($env:TTT2_NATIVE_TEST_OBSERVERS -eq '1' -or $_.Name -notmatch '^9\d-') })
# The SDK's build options of ours (no source change), recorded with the patches so that a new one rebuilds the SDK too.
# SPDLOG_PREVENT_CHILD_FD (the lead's word, 24 Oct): spdlog's own option, a PUBLIC define on its target, so it reaches every
# target that compiles or links spdlog, ours included: the log's handle is not inherited, and a child process (curl.exe)
# can't hold the log open through a rotation; a failed rename made spdlog truncate the log and lose its start (1879).
$sdkOptions = @('-DSPDLOG_PREVENT_CHILD_FD=ON')
$patchList = (@($patches | ForEach-Object { "$($_.Name) $((Get-FileHash -LiteralPath $_.FullName).Hash)" }) + @($sdkOptions)) -join ';'
$patchRecord = Join-Path $SdkInstall 'ttt2-patches.txt'
$patchesBuilt = if (Test-Path -LiteralPath $patchRecord) { (Get-Content -LiteralPath $patchRecord -Raw).Trim() } else { '' }
# The CMake the SDK was configured with, in a record of its own (ttt2-patches.txt's text is what the package's manifest and the
# player's Install compare). With the portable toolchain a different CMake rebuilds the SDK: 4.6.3's first candidate had the SDK
# of a default-toolchain build (Visual Studio's CMake 4.1) under a manifest naming cmake=3.31.8, and the helper's cross-check
# found its libraries different (5 Nov). The default toolchain doesn't compare it, so switching back and forth isn't a rebuild.
$cmakeRecord = Join-Path $SdkInstall 'ttt2-sdk-cmake.txt'
$cmakeNow = "$((Get-Command cmake).Source) $((& cmake --version | Select-Object -First 1))".Trim()
$cmakeBuilt = if (Test-Path -LiteralPath $cmakeRecord) { (Get-Content -LiteralPath $cmakeRecord -Raw).Trim() } else { '' }
$cmakeChanged = $Toolchain -eq 'portable' -and $cmakeBuilt -ne $cmakeNow
if ($cmakeChanged -and (Test-Path -LiteralPath (Join-Path $SdkInstall 'bin\rexglue.exe'))) {
    Write-Host "The SDK was configured with another CMake ($(if ($cmakeBuilt) { $cmakeBuilt } else { 'not recorded' })): rebuilt with $cmakeNow."
    Remove-Ttt2Folder (Join-Path $SdkSource 'out\build\win-amd64')
}

if (-not (Test-Path -LiteralPath (Join-Path $SdkInstall 'bin\rexglue.exe')) -or $patchesBuilt -ne $patchList -or $cmakeChanged) {
    if (-not (Test-Path -LiteralPath (Join-Path $SdkSource '.git'))) {
        Step "Downloading the ReXGlue SDK $SdkTag (with its libraries, about 400 MB)"
        Run git -c core.longpaths=true clone --branch $SdkTag --recursive --depth 1 --shallow-submodules https://github.com/rexglue/rexglue-sdk.git $SdkSource
    }
    # libmspack's cabextract/mspack holds symbolic links to its libmspack/mspack sources. Git
    # on Windows checks those out as small text files holding the link's target unless
    # symbolic links are enabled, and the build then fails on lzxd.c. Copy the real files over.
    # Real links (symbolic links enabled: Developer Mode, or an administrator) are left alone:
    # copying through one is copying a file onto itself, which Windows refuses.
    $links = Join-Path $SdkSource 'thirdparty\libmspack\cabextract\mspack'
    $sources = Join-Path $SdkSource 'thirdparty\libmspack\libmspack\mspack'
    $reparse = [IO.FileAttributes]::ReparsePoint
    if (-not ((Get-Item -LiteralPath $links).Attributes -band $reparse)) {
        Get-ChildItem -LiteralPath $links -File | Where-Object { $_.Length -lt 200 -and -not ($_.Attributes -band $reparse) } | ForEach-Object {
            $real = Join-Path $sources $_.Name
            if (Test-Path -LiteralPath $real) { Copy-Item -LiteralPath $real $_.FullName -Force }
        }
    }

    Push-Location -LiteralPath $SdkSource
    try {
        Step 'Applying rex\patches to the ReXGlue SDK'
        # Back to the SDK as released first, so that a changed patch applies cleanly. This drops
        # any other change under the SDK's include and src folders, files a patch added included.
        Run git checkout HEAD -- include src
        Run git clean -fdq -- include src
        # (A patch of patches\ may name a file of the SDL submodule (thirdparty\sdl3, 60-sdl-audio-stream-lifetime): back to its commit too,
        # or that patch would not apply a second time.)
        if (Test-Path -LiteralPath 'thirdparty\sdl3\.git') { Run git -C thirdparty/sdl3 checkout -- . }
        foreach ($patch in $patches) {
            Write-Host $patch.Name
            Run git apply --ignore-whitespace $patch.FullName
        }

        Step 'Building the ReXGlue SDK (the first time takes a while)'
        # (The portable toolchain has no debug C++ runtime: CMake's own test programs are built as Release.)
        $sdkExtra = @(if ($Toolchain -eq 'portable') { '-DCMAKE_TRY_COMPILE_CONFIGURATION=Release' })
        if ($Toolchain -eq 'portable') { $null = Reset-Ttt2BuildForMsvc (Join-Path $SdkSource 'out\build\win-amd64') 'The SDK' }   # (the MSVC version pin)
        Invoke-Ttt2Configure (Join-Path $SdkSource 'out\build\win-amd64') (@('--preset', 'win-amd64', "-DCMAKE_INSTALL_PREFIX=$SdkInstall") + @($sdkExtra) + @($sdkOptions))
        Run cmake --build out/build/win-amd64 --config Release --target install
        if ($Toolchain -eq 'portable') { Write-Ttt2BuildMsvc (Join-Path $SdkSource 'out\build\win-amd64') }
        Set-Content -LiteralPath $patchRecord -Value $patchList
        Set-Content -LiteralPath $cmakeRecord -Value $cmakeNow
    } finally { Pop-Location }
} else {
    Write-Host "ReXGlue SDK already built: $SdkInstall"
}

# The build id for netplay (rex\src\netplay.cpp: two instances must be the same build): the commit, and
# hashes of rex\src's and rex\patches' sources, in rex\src\build_id.h (not in git).
# (In the player's package it is baked into ttt2_ours.lib: "this release's libraries".)
# The same at the same commit on any PC (the main line's lead, 5 Nov): in a clone only the files git tracks (no build_id.h, no
# stray or generated file, no unapplied patch left in the folder; the generated code's partition is left out too), each by its
# path under rex\ in ordinal order, its text with line endings made LF (Get-TextHash; 4 Nov: a clone edited with LF lines in CRLF
# files, or a CRLF checkout against an LF one, gave another id); the commit at a fixed 12 characters (--short grows with a
# clone's object count). Without git (a package's folder): the same walk over the folder, build_id.h left out.
Step 'The build id'
$idParts = @()
$commit = $null
try { $commit = git -C $Repo rev-parse --short=12 HEAD 2>$null } catch { }
$idParts += if ($commit) { "$commit".Trim() } else { 'nogit' }
$tracked = $null
if ($commit) { try { $tracked = @(git -C $Rex ls-files -- src patches 2>$null) } catch { $tracked = $null } }
foreach ($set in @(@('src', '.cpp', '.h', '.inc', '.hlsl', '.c'), @('patches', '.patch'))) {
    $folder = Join-Path $Rex $set[0]
    $exts = $set[1..($set.Count - 1)]
    $rel = if ($tracked) {
        @($tracked | ForEach-Object { "$_" -replace '\\', '/' } | Where-Object { $_.StartsWith("$($set[0])/") -and (Test-Path -LiteralPath (Join-Path $Rex $_) -PathType Leaf) })
    } else {
        @(Get-ChildItem -LiteralPath $folder -File -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'build_id.h' } |
            ForEach-Object { $_.FullName.Substring($Rex.TrimEnd('\').Length + 1) -replace '\\', '/' })
    }
    $rel = @($rel | Where-Object { $exts -contains [IO.Path]::GetExtension($_).ToLowerInvariant() })
    [Array]::Sort($rel, [StringComparer]::Ordinal)
    $lines = $rel | ForEach-Object { "$_ $(Get-TextHash (Join-Path $Rex $_))" }
    $sha = [Security.Cryptography.SHA1]::Create()
    $hash = ($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes(($lines -join "`n"))) | ForEach-Object { $_.ToString('x2') }) -join ''
    $idParts += $hash.Substring(0, 12)
}
$idText = $idParts -join ' '
$idHeader = Join-Path $Rex 'src\build_id.h'
$idContent = "// Written by build-windows.ps1 before every build; not in git.`n#pragma once`n#define TTT2_BUILD_ID_TEXT `"$idText`"`n"
if (-not (Test-Path -LiteralPath $idHeader) -or (Get-Content -LiteralPath $idHeader -Raw) -ne $idContent) { [IO.File]::WriteAllText($idHeader, $idContent) }
Write-Host "Build id: $idText"
}

# Files dated in the future by this PC's clock make Ninja re-run CMake for ever ("manifest
# 'build.ninja' still dirty after 100 tries"). A zip's dates have no time zone and unpack as
# local time, so a package made east of here has them. Date such files now.
$now = Get-Date
$future = @(Get-ChildItem -LiteralPath $Rex -Force | Where-Object { $_.Name -ne 'out' } | ForEach-Object {
        if ($_.PSIsContainer) { Get-ChildItem -LiteralPath $_.FullName -Recurse -File -Force } else { $_ }
    } | Where-Object { $_.LastWriteTime -gt $now.AddMinutes(1) })
if ($future.Count) {
    Write-Host "$($future.Count) files were dated in the future by this PC's clock; dating them now."
    foreach ($f in $future) { $f.LastWriteTime = $now }
}

Push-Location -LiteralPath $Rex
try {
    # (TTT2_FMA=1: the FMA3 exe, a second build folder of its own beside the plain one (15 Nov): same sources, -mfma -ffp-contract=off. The plain exe is not touched.)
    # (24 Nov, 5.1, Task 9: Setup's PGO profile. Set-PgoForBuild (setup-steps.ps1) sets TTT2_PGO_AUTO=1 and TTT2_PGO_PROFILE=<the checked ttt2-pgo.profdata> only when the kept file is the package's hash.
    # With both, a non-empty file and no TTT2_OPT of the caller's own, the player's build is compiled with the profile INTO THE PLAIN BUILD FOLDER (the exe the player runs is rex\out\build\win-amd64-release\ttt2.exe:
    # a folder of its own would never be launched). Anything less = today's build, exactly: -DTTT2_OPT= is empty and nothing else here changes.)
    $pgoAuto = $false
    if ($env:TTT2_PGO_AUTO -eq '1' -and -not $env:TTT2_OPT) {
        if ($env:TTT2_PGO_PROFILE -and (Test-Path -LiteralPath $env:TTT2_PGO_PROFILE -PathType Leaf) -and (Get-Item -LiteralPath $env:TTT2_PGO_PROFILE).Length -gt 0) {
            $pgoAuto = $true
            Write-Host "PGO build: the profile $($env:TTT2_PGO_PROFILE) is used (-DTTT2_OPT=pgo, the plain build folder)"
        } else { Write-Host 'PGO build: not used (no profile file): the plain build' }
    }
    $optDir = if ($env:TTT2_OPT -in @('thinlto', 'pgogen', 'pgo')) { "out/build/win-amd64-release-$($env:TTT2_OPT)" } else { '' }   # (brief 37, 18 Nov: TTT2_OPT=thinlto|pgogen|pgo, a build folder of its own beside the plain one; TTT2_PGO_PROFILE names the merged profile for pgo)
    $build = if ($optDir) { $optDir } elseif ($env:TTT2_FMA -eq 'v3') { 'out/build/win-amd64-release-v3' } elseif ($env:TTT2_FMA -eq '1') { 'out/build/win-amd64-release-fma' } else { 'out/build/win-amd64-release' }   # (TTT2_FMA=v3: -march=x86-64-v3, its own folder)
    # CMake remembers where it found the SDK's packages. If that is another SDK folder than the
    # one in use (rex\sdk-folder.txt was added or changed), forget it: the game would otherwise
    # be compiled and linked against that one and run with this one's DLLs.
    $cache = Join-Path $build 'CMakeCache.txt'
    if (Test-Path -LiteralPath $cache) {
        $found = Select-String -LiteralPath $cache -Pattern '^rexglue_DIR:PATH=(.*)$' | Select-Object -First 1
        $wanted = ($SdkInstall -replace '\\', '/').TrimEnd('/')
        if ($found -and -not $found.Matches[0].Groups[1].Value.StartsWith("$wanted/", [StringComparison]::OrdinalIgnoreCase)) {
            Write-Host "The game was configured for another SDK folder ($($found.Matches[0].Groups[1].Value)): configuring it anew."
            Remove-Item -LiteralPath $cache -Force
        }
    }
    # Likewise for another compiler (Visual Studio's against the portable one): its linker's folder names it.
    if (Test-Path -LiteralPath $cache) {
        $linker = Select-String -LiteralPath $cache -Pattern '^CMAKE_LINKER:FILEPATH=(.*)$' | Select-Object -First 1
        $wantedLlvm = ($llvm -replace '\\', '/').TrimEnd('/')
        if ($linker -and -not $linker.Matches[0].Groups[1].Value.StartsWith("$wantedLlvm/", [StringComparison]::OrdinalIgnoreCase)) {
            Write-Host "The game was configured with another compiler ($($linker.Matches[0].Groups[1].Value)): configuring it anew."
            Remove-Item -LiteralPath $cache -Force
        }
    }
    # Likewise for another path to this folder (4.5: a folder with [ or ] in its path is built through its plain-named link, above;
    # a cache made from the bracketed path before, a failed step 3, can't be used from the link: CMake refuses another source folder).
    if (Test-Path -LiteralPath $cache) {
        $cacheHome = Select-String -LiteralPath $cache -Pattern '^CMAKE_HOME_DIRECTORY:INTERNAL=(.*)$' | Select-Object -First 1
        $wantedHome = ($Rex -replace '\\', '/').TrimEnd('/')
        if ($cacheHome -and $cacheHome.Matches[0].Groups[1].Value.TrimEnd('/') -ne $wantedHome) {
            Write-Host "The game was configured from another path to this folder ($($cacheHome.Matches[0].Groups[1].Value)): configuring it anew."
            Remove-Item -LiteralPath $cache -Force
        }
    }
    # The player's package: the zip's dates are the commit's minus two days, so Ninja doesn't see a new library or
    # new address files. When the shipped manifest differs from the one the last build used, the exe is relinked, and
    # if the translation's inputs differ the translation is made again.
    $usedManifest = Join-Path $build 'prebuilt-manifest.txt'
    if ($Prebuilt) {
        $used = Read-KeyValues $usedManifest
        if ((Test-Path -LiteralPath $usedManifest) -and (Get-Content -LiteralPath $usedManifest -Raw) -ne (Get-Content -LiteralPath $PrebuiltManifest -Raw)) {
            Write-Host 'A new release: the game is linked anew.'
            Remove-Item -LiteralPath (Join-Path $build 'ttt2.exe') -Force -ErrorAction SilentlyContinue
            $codegenNow = ($manifest.Keys | Where-Object { $_ -like 'codegen.*' } | ForEach-Object { "$_=$($manifest[$_])" }) -join ';'
            $codegenUsed = ($used.Keys | Where-Object { $_ -like 'codegen.*' } | ForEach-Object { "$_=$($used[$_])" }) -join ';'
            if ($codegenNow -ne $codegenUsed -and (Test-Path -LiteralPath 'generated\default')) {
                Write-Host 'Its translation differs too: the game code is translated anew.'
                Remove-Ttt2Folder 'generated\default'
            }
        }
    }
    # (The manifest's template_dir, 28 Oct: 4.4.2's package left rex\templates_dirty out, the SDK only WARNED "Override directory
    # does not exist", and the player's translation had plain stores with no dirty-page marks, while #90's dirty saves ran on
    # them: fights crashed. A named folder that is missing, or has no marks template, now stops the build here. And a translation
    # made without the marks (generated\default from such a build) is made again, as it would otherwise stay.
    # TTT2_SKIP_TEMPLATE_CHECK=1: test only, builds the exe the field had.)
    $manifestToml = Join-Path $Rex 'ttt2_manifest.toml'
    $templateLine = if (Test-Path -LiteralPath $manifestToml) { Select-String -LiteralPath $manifestToml -Pattern '^\s*template_dir\s*=\s*"([^"]+)"' | Select-Object -First 1 } else { $null }
    if ($templateLine -and $env:TTT2_SKIP_TEMPLATE_CHECK -eq '1') {
        Write-Host 'Test: the template check is skipped (TTT2_SKIP_TEMPLATE_CHECK)'
    } elseif ($templateLine) {
        $templateName = $templateLine.Matches[0].Groups[1].Value
        $templatePch = Join-Path $Rex (Join-Path $templateName 'codegen\pch_h.inja')
        if (-not (Test-Path -LiteralPath $templatePch)) {
            throw "rex\ttt2_manifest.toml names template_dir = ""$templateName"", but rex\$templateName\codegen\pch_h.inja is missing. Without it the translation has no dirty-page marks (the ReXGlue SDK only warns, 'Override directory does not exist'). Unzip the package again (or restore the folder from git) and build again."
        }
        if ((Get-Content -LiteralPath $templatePch -Raw) -notmatch 'ttt2_dirty_marks_built') {
            throw "rex\$templateName\codegen\pch_h.inja is not this release's (it does not set ttt2_dirty_marks_built). Unzip the package again and build again."
        }
        $madePch = Join-Path $Rex 'generated\default\ttt2_pch.h'
        if ((Test-Path -LiteralPath $madePch) -and ((Get-Content -LiteralPath $madePch -Raw) -notmatch 'ttt2_dirty_marks_built')) {
            Write-Host 'The translation in rex\generated\default was made without the dirty-page marks: it is made again (a couple of minutes).'
            Remove-Ttt2Folder (Join-Path $Rex 'generated\default')
        }
    }
    # (The portable toolchain pins clang's MSVC version (toolchain.ps1, 27 Oct): a build folder made at another version is
    # built again from the start, once, as its precompiled headers would otherwise refuse the new one.)
    if ($Toolchain -eq 'portable') { $null = Reset-Ttt2BuildForMsvc (Join-Path $Rex $build) 'The game' }
    # (The install's build cache B (docs/BUILDTIME_PLAN_20261122.md): the translation of the game's code (79 s, one thread) is made from the manifest's codegen
    # lines, the code generator's own file, its config files (the manifest, the three toml lists, the dirty-page templates) and default_tu.xex, and nothing else: the
    # same inputs on this PC gave the same files before, in another install folder, and they are copied in and checked against their recorded SHA-256. A hit still has
    # to pass the release's own check (the partition's hash) below. A key that cannot be made, or TTT2_NO_BUILD_CACHE=1, is the step as before. TTT2_CODEGEN_CACHED
    # (rexglue.cmake) is set at EVERY configure: ON only when generated\default is the cache's translation for the key made now.)
    $cgKey = ''
    $cgCached = $false
    $cgRestored = $false
    $cgDir = Join-Path $Rex 'generated\default'
    $cgMarker = Join-Path $cgDir 'ttt2-codegen-key.txt'
    if ($Prebuilt -and -not (Test-Ttt2BuildCacheOff)) {
        try {
            $cgStarted = Get-Date
            $cgXex = Join-Path $Repo 'gamedata\default_tu.xex'
            $cgParts = @('kind=codegen v1')
            $cgParts += @($manifest.Keys | Where-Object { $_ -like 'codegen.*' } | Sort-Object | ForEach-Object { "manifest $_=$($manifest[$_])" })
            $cgParts += "rexglue.exe=$(Get-Ttt2Sha256 (Join-Path $SdkInstall 'bin\rexglue.exe'))"
            $cgParts += "default_tu.xex=$(Get-Ttt2Sha256 $cgXex)"
            foreach ($n in 'ttt2_manifest.toml', 'ttt2_jumps.toml', 'ttt2_functions.toml', 'ttt2_function_pointers.toml') { $cgParts += "$n=$(Get-Ttt2Sha256 (Join-Path $Rex $n))" }
            if ($templateLine) { $cgParts += @(Get-Ttt2TreeLines (Join-Path $Rex $templateLine.Matches[0].Groups[1].Value) 'template') }
            $cgKey = New-Ttt2CacheKey $cgParts
            $cgKeyText = '{0:N1}' -f (((Get-Date) - $cgStarted).TotalSeconds)
            if (-not $cgKey) { Write-Host "Build: generated-code cache miss (an input could not be read; $cgKeyText s)" }
            else {
                $cgShort = $cgKey.Substring(0, 12)
                $cgHave = Test-Path -LiteralPath (Join-Path $cgDir 'sources.cmake')
                if ($cgHave -and (Test-Path -LiteralPath $cgMarker) -and "$(Get-Content -LiteralPath $cgMarker -TotalCount 1)".Trim() -eq $cgKey) {
                    $cgCached = $true
                    Write-Host "Build: generated-code cache: the translation in this folder is the one for key $cgShort (the code generation is only stamped)"
                } elseif (-not $cgHave) {
                    $cgEntry = Find-Ttt2CacheEntry 'codegen' $cgKey
                    if (-not $cgEntry) { Write-Host "Build: generated-code cache miss $cgShort (key $cgKeyText s)" }
                    else {
                        Remove-Ttt2Folder $cgDir
                        $cgCopyStarted = Get-Date
                        if (Restore-Ttt2CacheEntry $cgEntry $cgDir) {
                            # (ninja's depfile for the code generation: the inputs it names, as this folder's paths; the cache holds none of its own.)
                            $cgRoot = ($Rex -replace '\\', '/').TrimEnd('/')
                            $cgInputs = @("$(($Repo -replace '\\', '/').TrimEnd('/'))/gamedata/default_tu.xex")
                            if ($templateLine) {
                                $cgTemplates = Join-Path $Rex $templateLine.Matches[0].Groups[1].Value
                                $cgInputs += @(Get-ChildItem -LiteralPath $cgTemplates -Recurse -File | Sort-Object FullName | ForEach-Object { $_.FullName -replace '\\', '/' })
                            }
                            $cgInputs += @('ttt2_function_pointers.toml', 'ttt2_functions.toml', 'ttt2_jumps.toml', 'ttt2_manifest.toml' | ForEach-Object { "$cgRoot/$_" })
                            $cgDep = @("$cgRoot/generated/default/codegen.build.stamp: \") + @($cgInputs | ForEach-Object { '  ' + ($_ -replace ' ', '\ ') + ' \' })
                            $cgDep[-1] = $cgDep[-1].TrimEnd('\').TrimEnd()
                            [IO.File]::WriteAllLines((Join-Path $cgDir 'codegen.d'), $cgDep)
                            [IO.File]::WriteAllText($cgMarker, "$cgKey`n")
                            $cgCached = $true
                            $cgRestored = $true
                            Write-Host ("Build: generated-code cache hit {0} (key {1} s, copied and checked in {2:N1} s)" -f $cgShort, $cgKeyText, ((Get-Date) - $cgCopyStarted).TotalSeconds)
                        } else { Remove-Ttt2Folder $cgDir }
                    }
                }
            }
        } catch { $cgKey = ''; $cgCached = $false; Write-Host "Build: generated-code cache miss (the key could not be made: $($_.Exception.Message))" }
    }
    Step 'Configuring TTT2'
    # (native-gfx: TTT2_NATIVE_GFX=1 builds the native renderer in (rex/NATIVE_PLAN.md; Plume vendored in
    # rex/third_party/plume, nothing fetched). Without it the option is OFF: no Plume, the main line's sources.)
    $gameExtra = @(if ($Toolchain -eq 'portable') { '-DCMAKE_TRY_COMPILE_CONFIGURATION=Release' })   # (no debug C++ runtime)
    $gameExtra += "-DTTT2_PREBUILT=$(if ($Prebuilt) { 'ON' } else { 'OFF' })"
    $gameExtra += "-DTTT2_OURS_LIB=$(if ($OursLib) { 'ON' } else { 'OFF' })"
    # (Always said, ON or OFF: CMake keeps an option in the build folder's cache, so a build after a native
    # one in the same folder would otherwise stay native.)
    $gameExtra += "-DTTT2_NATIVE_GFX_PLUME=$(if ($env:TTT2_NATIVE_GFX -eq '1') { 'ON' } else { 'OFF' })"
    $gameExtra += "-DTTT2_FMA=$(if ($env:TTT2_FMA -eq '1' -or $env:TTT2_FMA -eq 'v3') { 'ON' } else { 'OFF' })"
    $gameExtra += "-DTTT2_V3=$(if ($env:TTT2_FMA -eq 'v3') { 'ON' } else { 'OFF' })"
    if ($env:TTT2_FMA -eq '1' -or $env:TTT2_FMA -eq 'v3' -or $optDir) { $gameExtra += @('-B', (Join-Path $Rex $build)) }
    $gameExtra += "-DTTT2_OPT=$(if ($optDir) { $env:TTT2_OPT } elseif ($pgoAuto) { 'pgo' } else { '' })"
    if (($optDir -and $env:TTT2_OPT -eq 'pgo') -or $pgoAuto) { $gameExtra += "-DTTT2_PGO_PROFILE=$($env:TTT2_PGO_PROFILE)" }   # (the preset's folder is the plain exe's)
    $gameExtra += "-DTTT2_NATIVE_TEST_OBSERVERS=$(if ($env:TTT2_NATIVE_TEST_OBSERVERS -eq '1') { 'ON' } else { 'OFF' })"
    $gameExtra += "-DTTT2_CODEGEN_CACHED=$(if ($cgCached) { 'ON' } else { 'OFF' })"   # (always said: CMake keeps it in the build folder's cache)
    $gameExtra += '-DTTT2_RECOMP_OBJECTS_DIR='   # (build cache D: empty at every configure = the generated code is compiled; set below only for a hit)
    Invoke-Ttt2Configure (Join-Path $Rex $build) (@('--preset', 'win-amd64-release', "-DCMAKE_PREFIX_PATH=$SdkInstall") + @($gameExtra))

    $partition = 'generated\default\codegen.partition.json'
    # (Every throw here takes the translation away first (report 20261031-154108): a bad one left behind was never made again, as
    # sources.cmake was there, so the release's check failed at every later Install, whatever the PC did next.)
    $translate = {
        Step 'Recompiling the game code from gamedata\default_tu.xex (a couple of minutes)'
        # (The code generation is made here: a configure that stamped only (build cache B) is set back, so the real command runs.)
        if ($cgCached) { Run cmake '-DTTT2_CODEGEN_CACHED=OFF' $build }
        $script:cgRan = $true
        $first = Invoke-Ttt2Codegen $build $partition
        # (Test only, TTT2_TEST_CODEGEN_FLAKY=1: the first run's translation changed after it, as a PC that computes wrong would.)
        if ($env:TTT2_TEST_CODEGEN_FLAKY -eq '1' -and (Test-Path -LiteralPath $partition)) {
            Add-Content -LiteralPath $partition ' '
            $first.Hash = Get-TextHash (Resolve-Path -LiteralPath $partition)
            Write-Host 'Test: the first translation changed (TTT2_TEST_CODEGEN_FLAKY)'
        }
        # (I, the lead's order of 27 Oct: a translation that fails, by its analysis errors or, in a release, by its hash, is
        # made once more (~30 s). The same files gave a player 8 unresolved calls, then 3 different ones, then other output,
        # with call targets no PowerPC branch can have: the PC computing wrong, not the files.)
        $bad = { param($r) $r.Code -ne 0 -or ($Prebuilt -and $r.Hash -ne $manifest['codegen.partition']) }
        if (& $bad $first) {
            Write-Host "The translation didn't come out right ($(Describe-Ttt2Codegen $first)): it is made once more, to see whether this PC gives the same answer (about 30 s)."
            Remove-Ttt2Folder 'generated\default'
            $second = Invoke-Ttt2Codegen $build $partition
            if ($second.Hash -ne $first.Hash -or (($second.Errors -join "`n") -ne ($first.Errors -join "`n")) -or $second.Code -ne $first.Code) {
                Write-Host "The two translations differ: first $(Describe-Ttt2Codegen $first), then $(Describe-Ttt2Codegen $second)."
                Remove-Ttt2Folder 'generated\default'
                throw (Get-Ttt2UnstablePcNote)
            }
            Write-Host "The second translation came out the same ($(Describe-Ttt2Codegen $second)): this PC is consistent; the files or the package aren't the expected ones."
        }
        if ($first.Code -ne 0 -and -not $Prebuilt) {
            Remove-Ttt2Folder 'generated\default'
            throw "The translation failed ($(Describe-Ttt2Codegen $first))."
        }
        # The generated file list only exists now, so CMake has to read it again.
        if (Test-Path -LiteralPath 'generated\default\sources.cmake') { Run cmake $build }
    }
    $translated = $false
    if (-not (Test-Path -LiteralPath 'generated\default\sources.cmake')) {
        & $translate
        $translated = $true
    }
    if ($Prebuilt) {
        # The library was made for one translation of the game: this PC's must be the same.
        $translationMatches = { (Test-Path -LiteralPath $partition) -and (Get-TextHash (Resolve-Path -LiteralPath $partition)) -eq $manifest['codegen.partition'] }
        if (-not (& $translationMatches) -and -not $translated) {
            Write-Host "The translation that's here doesn't match this release: it is made again."
            Remove-Ttt2Folder 'generated\default'
            & $translate
        }
        if (-not (& $translationMatches)) {
            Remove-Ttt2Folder 'generated\default'
            throw "The translation didn't match this release (your game files or the package are not the expected ones)."
        }
        Write-Host 'The translation matches this release.'
        # (Build cache B: a translation made in this run, which matched the release, is kept for the next install folder on this PC, and this folder's marker says which inputs it is for.)
        if ($cgKey -and $script:cgRan -and -not $cgRestored) {
            try {
                $cgFiles = [ordered]@{}
                foreach ($f in (Get-ChildItem -LiteralPath $cgDir -Recurse -File)) {
                    if ($f.Name -in 'codegen.d', 'codegen.build.stamp', 'ttt2-codegen-key.txt') { continue }
                    $cgFiles[$f.FullName.Substring($cgDir.Length + 1)] = $f.FullName
                }
                $null = Add-Ttt2CacheEntry 'codegen' $cgKey $cgFiles 260 'generated-code'
                [IO.File]::WriteAllText($cgMarker, "$cgKey`n")
            } catch { Write-Host "Build: generated-code cache not kept ($($_.Exception.Message))." }
        }
    }

    # (The install's build cache D (docs/BUILDTIME_PLAN_20261122.md): the 209 objects of the generated code (181 s of the build). The key is the compiler's file, the
    # exact command line of every one of them (this folder's path written <rex>), the SHA-256 of every file of the generated folder, and the two files CMake makes
    # for the precompiled header; and the entry holds the list of every other file the compiler read (ninja's own record, the SDK's and the toolchain's headers), each
    # with its SHA-256, which is checked again now. Any difference, or anything unreadable, is a miss and they are compiled. On a hit they are copied in, checked, and
    # the game is configured once more to link them (TTT2_RECOMP_OBJECTS_DIR, rexglue.cmake): only the link runs. PGO (-fprofile) is never cached.)
    # (TTT2_TEST_TOUCH_GENERATED=<file name in generated\default>: test only, a comment line is appended to that generated file here, so one input of the object cache's key is different.)
    if ($env:TTT2_TEST_TOUCH_GENERATED) {
        $touchFile = Join-Path $cgDir $env:TTT2_TEST_TOUCH_GENERATED
        if (Test-Path -LiteralPath $touchFile) { [IO.File]::AppendAllText($touchFile, "`n// test touch (TTT2_TEST_TOUCH_GENERATED)`n"); Write-Host "Test: a comment line appended to generated\default\$($env:TTT2_TEST_TOUCH_GENERATED)" }
        else { Write-Host "Test: TTT2_TEST_TOUCH_GENERATED: no $touchFile" }
    }
    $obKey = ''
    $obRestored = $false
    $obCmds = @()
    $obBuildFull = Join-Path $Rex ($build -replace '/', '\')
    $obDir = Join-Path $obBuildFull 'cached-objects'
    if ($Prebuilt -and $Toolchain -eq 'portable' -and -not (Test-Ttt2BuildCacheOff)) {
        try {
            $obStarted = Get-Date
            $obCompiler = Join-Path $llvm 'clang++.exe'
            $obCmds = @(& ninja -C $build -t commands ttt2_recomp 2>$null | ForEach-Object { "$_" } | Where-Object { $_ -match ' -c ' -and $_ -match 'ttt2_recomp\.dir' })
            if ($obCmds.Count -lt 100) { throw "only $($obCmds.Count) compile commands" }
            if (@($obCmds | Where-Object { -not $_.StartsWith($obCompiler, [StringComparison]::OrdinalIgnoreCase) -or $_ -match '-fprofile' }).Count) { throw 'a compile command is not the pinned compiler or uses a profile' }
            # (A folder whose objects are all newer than every generated file has nothing to compile (an update that did not change the translation, in the folder
            # that was built before): the cache is not asked, Ninja relinks as it always did.)
            $obCurrent = $false
            $obNatural = Join-Path $obBuildFull 'CMakeFiles\ttt2_recomp.dir\generated\default'
            if (Test-Path -LiteralPath $obNatural) {
                $obHave = @(Get-ChildItem -LiteralPath $obNatural -Filter *.obj -File)
                if ($obHave.Count -eq ($obCmds.Count - 1)) {
                    $oldestObj = ($obHave | Sort-Object LastWriteTimeUtc | Select-Object -First 1).LastWriteTimeUtc
                    $newestGen = (Get-ChildItem -LiteralPath $cgDir -File | Where-Object { $_.Extension -in '.cpp', '.h' } | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1).LastWriteTimeUtc
                    if ($newestGen -and $oldestObj -ge $newestGen) { $obCurrent = $true }
                }
            }
            if ($obCurrent) { Write-Host 'Build: object cache not needed: the objects in this folder are newer than every generated file (nothing to compile)' }
            else {
            $obParts = @('kind=objects v1', "clang++.exe=$(Get-Ttt2Sha256 $obCompiler)")
            $obParts += @($obCmds | ForEach-Object { 'cmd=' + (ConvertTo-Ttt2RexRelative $_ $Rex) })
            $obParts += @(Get-Ttt2TreeLines $cgDir 'gen' | Where-Object { $_ -notmatch '^gen/(codegen\.d|codegen\.build\.stamp|ttt2-codegen-key\.txt)=' })
            foreach ($n in 'cmake_pch.hxx', 'cmake_pch.hxx.cxx') {
                $obParts += "$n=$(Get-Ttt2TextSha256 (ConvertTo-Ttt2RexRelative ([IO.File]::ReadAllText((Join-Path $obBuildFull "CMakeFiles\ttt2_recomp.dir\$n"))) $Rex))"
            }
            $obKey = New-Ttt2CacheKey $obParts
            $obKeyText = '{0:N1}' -f (((Get-Date) - $obStarted).TotalSeconds)
            if (-not $obKey) { Write-Host "Build: object cache miss (an input could not be read; $obKeyText s)" }
            else {
                $obShort = $obKey.Substring(0, 12)
                $obEntry = Find-Ttt2CacheEntry 'objects' $obKey
                if (-not $obEntry) { Write-Host "Build: object cache miss $obShort (key $obKeyText s)" }
                else {
                    $obDepsStarted = Get-Date
                    $obBad = Test-Ttt2ObjectDeps (Join-Path $obEntry 'files\deps.txt') $Rex
                    $obDepsText = '{0:N1}' -f (((Get-Date) - $obDepsStarted).TotalSeconds)
                    if ($obBad) {
                        Write-Host "Build: object cache miss $obShort (a file the compiler read is not the one it was made with: $obBad; headers checked $obDepsText s); the entry is removed"
                        try { Remove-Ttt2Folder $obEntry } catch { }
                    } else {
                        $obCopyStarted = Get-Date
                        if (Test-Path -LiteralPath $obDir) { Remove-Ttt2Folder $obDir }
                        if (Restore-Ttt2CacheEntry $obEntry $obDir) {
                            Remove-Item -LiteralPath (Join-Path $obDir 'deps.txt') -Force -ErrorAction SilentlyContinue
                            $obFound = @(Get-ChildItem -LiteralPath $obDir -Filter *.obj -File)
                            if ($obFound.Count -ne ($obCmds.Count - 1)) { throw "the entry has $($obFound.Count) objects, not $($obCmds.Count - 1)" }
                            Run cmake "-DTTT2_RECOMP_OBJECTS_DIR=$($obDir -replace '\\', '/')" $build | Out-Null
                            $obRestored = $true
                            Write-Host ("Build: object cache hit {0} (key {1} s, headers checked {2} s, copied and checked in {3:N1} s, {4} objects, {5:N0} MB; only the link runs)" -f $obShort, $obKeyText, $obDepsText, ((Get-Date) - $obCopyStarted).TotalSeconds, $obFound.Count, (($obFound | Measure-Object Length -Sum).Sum / 1MB))
                        } elseif (Test-Path -LiteralPath $obDir) { Remove-Ttt2Folder $obDir }
                    }
                }
            }
            }
        } catch {
            $obRestored = $false
            Write-Host "Build: object cache miss (the key could not be made or the entry not used: $($_.Exception.Message))"
            try { Run cmake '-DTTT2_RECOMP_OBJECTS_DIR=' $build | Out-Null } catch { }
            try { if (Test-Path -LiteralPath $obDir) { Remove-Ttt2Folder $obDir } } catch { }
        }
    }
    Step 'Building TTT2 (the first build after an update takes about 3 to 5 minutes, more on an older PC)'
    Clear-Ttt2StalePch $build
    Invoke-Ttt2GameBuild $build
    Save-Ttt2PchOwner $build
    if ($Toolchain -eq 'portable') { Write-Ttt2BuildMsvc (Join-Path $Rex $build) }
    # The build copies the SDK's DLLs next to ttt2.exe only when it links ttt2.exe, which a
    # rebuilt SDK does not always cause.
    Get-ChildItem -LiteralPath (Join-Path $SdkInstall 'bin') -Filter *.dll | Copy-Item -Destination $build -Force
    if ($Prebuilt -or $OursLib) {
        # (Every sub_X the library defines: REX_HOOK_RAW and the macros made of it. The package names them in its
        # manifest; the owner's build reads them from the library just made.)
        $hooks = if ($Prebuilt) { @($manifest['hooks'] -split ' ' | Where-Object { $_ }) } else {
            @(& llvm-nm --defined-only (Join-Path $build 'ttt2_ours.lib') 2>$null | ForEach-Object { if ($_ -match '\sT\s(sub_[0-9A-Fa-f]+)$') { $Matches[1] } } | Sort-Object -Unique) }
        if ($hooks.Count -lt 100) { throw "Only $($hooks.Count) hooks to check: the hook list is wrong." }
        try { Test-HookLink (Join-Path $build 'ttt2.map') $hooks }
        catch { Remove-Item -LiteralPath (Join-Path $build 'ttt2.exe') -Force -ErrorAction SilentlyContinue; throw }
    }
    # (Build cache D: the objects made in this run, now linked and checked, are kept for the next install folder on this PC with the list of every file the compiler read.)
    if ($obKey -and -not $obRestored) {
        try {
            $obNatural = Join-Path $obBuildFull 'CMakeFiles\ttt2_recomp.dir\generated\default'
            $obMade = @(Get-ChildItem -LiteralPath $obNatural -Filter *.obj -File)
            $obDeps = Join-Path $obBuildFull 'cached-objects-deps.txt'
            if ($obMade.Count -ne ($obCmds.Count - 1)) { Write-Host "Build: object cache not kept ($($obMade.Count) objects, expected $($obCmds.Count - 1))." }
            elseif (-not (New-Ttt2ObjectDeps $obBuildFull $Rex $obDeps)) { Write-Host 'Build: object cache not kept (a file the compiler read could not be hashed).' }
            else {
                $obFiles = [ordered]@{ 'deps.txt' = $obDeps }
                foreach ($o in $obMade) { $obFiles[$o.Name] = $o.FullName }
                $null = Add-Ttt2CacheEntry 'objects' $obKey $obFiles 400 'object'
            }
            Remove-Item -LiteralPath $obDeps -Force -ErrorAction SilentlyContinue
        } catch { Write-Host "Build: object cache not kept ($($_.Exception.Message))." }
    }
    if ($Prebuilt) { Copy-Item -LiteralPath $PrebuiltManifest $usedManifest -Force }
} finally { Pop-Location }

Step 'Done'
Write-Host "Game: $Rex\$($build -replace '/', '\')\ttt2.exe"
Write-Host 'Start it with:  powershell -ExecutionPolicy Bypass -File rex\run-windows.ps1'
