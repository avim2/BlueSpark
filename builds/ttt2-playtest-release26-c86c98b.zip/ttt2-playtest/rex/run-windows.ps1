# Starts TTT2 on Windows. The first time, it asks for your game folder: the one with
# default.xex and the data*.bin files from your disc. It remembers the answer in
# rex\game-folder.txt (not part of the repo).
#
#   powershell -ExecutionPolicy Bypass -File rex\run-windows.ps1
#
# Anything after the script name goes to the game, e.g. --log_level=debug.

$ErrorActionPreference = 'Stop'
$Rex = $PSScriptRoot
# (Test only, 15 Nov: TTT2_EXE_DIR=win-amd64-release-fma or win-amd64-release-v3 runs the FMA / x86-64-v3 exe made by TTT2_FMA=1 / v3 rex\build-windows.ps1; its logs are in that folder.)
$exeDir = if ($env:TTT2_EXE_DIR -match '^win-amd64-release(-fma|-v3|-msr|-thinlto|-pgogen|-pgo)?$') { $env:TTT2_EXE_DIR } else { 'win-amd64-release' }
$exe = Join-Path $Rex "out\build\$exeDir\ttt2.exe"
if (-not (Test-Path -LiteralPath $exe)) { throw 'ttt2.exe is not built yet. Run rex\build-windows.ps1 first.' }

# (rex\game-folder.txt: read tolerantly, written only when it changed, whole: tools/data-folder.ps1; a damaged file = "none chosen", 18 Nov)
. (Join-Path $Rex 'tools\data-folder.ps1')
# an update that copied this script but not tools\data-folder.ps1 (it stopped half way): say so, not "is not recognized".
if (-not (Get-Command Read-Ttt2GameFolderFile -ErrorAction SilentlyContinue)) { throw 'The game files are only partly updated (rex\tools\data-folder.ps1 is old). Open BlueSpark Setup (BlueSpark.exe --setup) and click REPAIR.' }
$saved = Join-Path $Rex 'game-folder.txt'
$game = Read-Ttt2GameFolderFile $saved
while (-not $game -or -not (Test-Path -LiteralPath (Join-Path $game 'default.xex'))) {
    if ($game) { Write-Host "No default.xex in $game" -ForegroundColor Yellow }
    if ($env:TTT2_NO_PROMPT) { throw "No default.xex in the game folder ($(if ($game) { $game } else { 'none chosen' })). In BlueSpark, press INSTALL, pick your game (CHOOSE ISO or CHOOSE FOLDER) and your title update (CHOOSE FILE), then CONTINUE." }
    $game = ConvertTo-Ttt2GameFolder (Read-Host 'Path to your TTT2 game folder (the one with default.xex)')
}
[void](Save-Ttt2GameFolder $saved $game)

# The game is built from the disc's executable with the title update applied (version 0.0.3.2),
# and the runtime loads the game's image from that file in the game folder: put there once,
# beside the disc's default.xex, from the repo's gamedata\default_tu.xex.
$patched = Join-Path $game 'default_tu.xex'
if (-not (Test-Path -LiteralPath $patched)) {
    $source = Join-Path (Split-Path $Rex -Parent) 'gamedata\default_tu.xex'
    if (-not (Test-Path -LiteralPath $source)) { throw "gamedata\default_tu.xex is missing: run rex\prepare-game.ps1 first (it makes it from your own game files)." }
    Write-Host "Copying default_tu.xex (the game with its title update applied) into $game"
    Copy-Item -LiteralPath $source $patched
}

# The title update's files (Default.xexp, data100.bin, data100.ofs), which the game opens as
# update:\ : a folder "update" beside the game folder if there is one, or the repo's
# gamedata\update.
$update = Join-Path (Split-Path $game -Parent) 'update'
if (-not (Test-Path -LiteralPath (Join-Path $update 'data100.bin'))) {
    $update = Join-Path (Split-Path $Rex -Parent) 'gamedata\update'
}
if (-not (Test-Path -LiteralPath (Join-Path $update 'data100.bin'))) { throw "The title update's files are not in $update." }

$userData = Join-Path $Rex 'userdata'
# (Another folder for a test, as of a first start on a PC: given twice on the command line,
# the switch makes the game fail at its start.)
if ($env:TTT2_USER_DATA) { $userData = $env:TTT2_USER_DATA }
# The player's profile (the XUID and its key, the save data, the name) in %LOCALAPPDATA%\TTT2Native\profile, outside the game folder
# (tools/profile-folder.ps1, SDK patch 51): a new build or a deleted folder no longer loses it. Copied there from this game folder
# the first time. A test's own user data folder (TTT2_USER_DATA) keeps its profile inside it, as before.
$profileDir = $null
$profileArgs = @()
if (-not $env:TTT2_USER_DATA -and -not ($args | Where-Object { "$_" -like '--profile_data_root*' })) {
    . (Join-Path $Rex 'tools/profile-folder.ps1')
    $profileDir = Get-ProfileFolder
    Copy-ProfileOnce $userData $profileDir
    $profileArgs = @("--profile_data_root=$profileDir")
}
# A first start: the render targets seen on other PCs (their keys: numbers of the runtime's, no
# game data), so that the runtime makes them at the start and not in the middle of the first
# match (STATUS.md, "The first tag of a match"). The runtime adds to the file as it meets more.
# Held to the card's video memory at every Play (tools/gpu-memory.ps1, the main line's lead, 5 Nov): at most
# floor((V - 2350) / 12.6) keys, the list cut to that; no room at all, the key cache off.
$renderTargetArgs = @()
if (Test-Path -LiteralPath (Join-Path $Rex 'tools/gpu-memory.ps1')) {
    try {
        . (Join-Path $Rex 'tools/gpu-memory.ps1')
        $rt = Update-Ttt2RenderTargetList $userData (Join-Path $Rex 'render-targets-seed.txt')
        $rt.Lines | ForEach-Object { Write-Host $_ }
        if (-not ($args | Where-Object { "$_" -like '--render_target_key_cache*' })) { $renderTargetArgs = @($rt.Args) }
    } catch { Write-Host "The render targets' list: not checked ($($_.Exception.Message))" }
}
# Likewise the pipelines seen on other PCs (helper Task 4's A2, rex/PIPELINE_SEED.md): the runtime's stored pipeline
# descriptions (shader hashes and render state, no shader code or driver data), RTV and ROV. Copied when the player has
# none; otherwise the seed's records the player's file lacks are appended (a file of another translator version is left
# alone). The prewarm (--d3d12_pipeline_prewarm_stored) then queues them as their shaders load. Never stops Play.
if (Test-Path (Join-Path $Rex 'tools/pipeline-seed.ps1')) {
    try {
        . (Join-Path $Rex 'tools/pipeline-seed.ps1')
        foreach ($kind in 'rtv', 'rov') {
            Add-PipelineSeed (Join-Path $Rex "pipelines-seed.$kind.xpso") (Join-Path $userData "cache/shaders/shareable/4E4D0859.$kind.d3d12.xpso")
        }
    } catch { "Pipeline seed: not added ($($_.Exception.Message))" }
}

# Controller mappings for SDL: the community SDL_GameControllerDB (rex\gamecontrollerdb.txt, zlib
# licence in rex\gamecontrollerdb-LICENSE.txt). DirectInput pads, fight sticks and adapters work as
# controllers only if SDL knows their mapping, and L2/R2 only if it maps them as the triggers. A
# player's own mapping lines go in userdata\my-controllers.txt (kept across package updates):
# they're added after the database's, so they win for the same controller.
$mappingArgs = @()
$mappings = Join-Path $Rex 'gamecontrollerdb.txt'
if ((Test-Path -LiteralPath $mappings) -and -not ($args | Where-Object { "$_" -like '--hid_mappings_file*' })) {
    $ownMappings = Join-Path $userData 'my-controllers.txt'
    if (Test-Path -LiteralPath $ownMappings) {
        $merged = Join-Path $userData 'cache/gamecontrollerdb.txt'
        New-Item -ItemType Directory -Force (Split-Path $merged -Parent) | Out-Null
        Get-Content -LiteralPath $mappings, $ownMappings | Set-Content -LiteralPath $merged
        $mappings = $merged
    }
    $mappingArgs = @("--hid_mappings_file=$mappings")
}

# The player's name (the gamertag the game shows), from rex\userdata\player-name.txt (Start Here asks for it the
# first time Play is pressed), unless the caller passed --user_name itself.
$nameArgs = @()
$nameFile = Join-Path $(if ($profileDir) { $profileDir } else { $userData }) 'player-name.txt'   # (the profile folder's, 23 October)
if ((Test-Path -LiteralPath $nameFile) -and -not ($args | Where-Object { "$_" -like '--user_name*' })) {
    $playerName = "$(Get-Content -LiteralPath $nameFile -Raw)".Trim()
    if ($playerName) { $nameArgs = @("--user_name=$playerName") }
}

# The display: Start Here's "Display" choice and "VSync" box (rex\userdata\launcher-settings.txt:
# display=borderless|fullscreen|windowed-<W>x<H>, borderless when unset, an old plain "windowed" taken as the
# 1920x1080 window (1280x720 on a smaller monitor); tearing=true|false, true (VSync Off) when unset: the one default on both renderers), passed as the
# runtime's switches unless the caller passed --fullscreen or --present_tearing itself. A window never
# tears on the old renderer: tearing asked with a window size is turned off, and said so; the native renderer keeps it (VSync off in a window).
$displayArgs = @()
# (The file Start Here's Settings writes, rex\userdata's, launcher.ps1: also when a test's TTT2_USER_DATA points the game's data elsewhere.
# Before (the native lead, 8 Nov) it was read from TTT2_USER_DATA's folder, so a tester's Settings choices were ignored. A test that means its
# own settings file names it in TTT2_LAUNCHER_SETTINGS.)
$settingsFile = if ($env:TTT2_LAUNCHER_SETTINGS) { $env:TTT2_LAUNCHER_SETTINGS } else { Join-Path $Rex 'userdata\launcher-settings.txt' }
$display = 'borderless'
$tearing = 'true'   # (unset: VSync Off, the one default; the switch is passed below)
$tearingStored = $false
if (Test-Path -LiteralPath $settingsFile) {
    foreach ($line in Get-Content -LiteralPath $settingsFile) {
        if ($line -match '^display=(.*)$') { $display = $Matches[1].Trim().ToLower() }
        if ($line -match '^tearing=(.*)$') { $tearing = $Matches[1].Trim().ToLower(); $tearingStored = $true }
    }
}
$windowSize = $null
if ($display -match '^windowed-(\d+)x(\d+)$') {
    $windowSize = @([int]$Matches[1], [int]$Matches[2])
} elseif ($display -eq 'windowed') {
    Add-Type -Namespace TTT2Run -Name Screen -MemberDefinition @'
[DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr h);
[DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr h, IntPtr dc);
[DllImport("gdi32.dll")] public static extern int GetDeviceCaps(IntPtr dc, int index);
'@
    $dc = [TTT2Run.Screen]::GetDC([IntPtr]::Zero)
    $big = [TTT2Run.Screen]::GetDeviceCaps($dc, 118) -ge 1920 -and [TTT2Run.Screen]::GetDeviceCaps($dc, 117) -ge 1080
    [void][TTT2Run.Screen]::ReleaseDC([IntPtr]::Zero, $dc)
    $windowSize = if ($big) { @(1920, 1080) } else { @(1280, 720) }
}
if (-not ($args | Where-Object { "$_" -like '--fullscreen*' })) {
    if ($windowSize) {
        $displayArgs += @('--fullscreen=false', '--fullscreen_exclusive=false',
                          "--window_pixel_width=$($windowSize[0])", "--window_pixel_height=$($windowSize[1])")
    } else {
        $displayArgs += '--fullscreen=true'
        # (18 Nov sweep item 1: the launcher never passes --fullscreen_exclusive=true: fullscreen runs as borderless fullscreen unless the game itself, with --ttt2_exclusive_fullscreen, switches exclusive on)
        $displayArgs += '--fullscreen_exclusive=false'
    }
}
# (The tearing switch is passed below, after the renderer is known.)
# The renderer (packaging B, 8 Nov; the toggle, 8 Nov): tools\renderer-choice.ps1 decides: out\renderer.txt (a tester's
# override), else Settings' choice (renderer= in launcher-settings.txt), else the package's default. Native needs the shader
# cache setup made (out\native-shaders.bin with its stamp); without it, or if the game finds it unusable, the game says so
# and uses the emulated renderer (NativeGfxChooseAtSetup). A caller's own --ttt2_native_gfx switch wins.
. (Join-Path $Rex 'tools\renderer-choice.ps1')
# (19 Nov: a device loss is retried once by the next Play start, not by the restart right after the loss's exit 77: renderer-choice.ps1, Use-Ttt2LostRetry.)
if (-not $env:TTT2_PLAY_RESTARTED) {
    $lostRetry = Use-Ttt2LostRetry $Rex $settingsFile (Join-Path (Split-Path $exe -Parent) 'logs')
    if ($lostRetry -eq 'retry') { Write-Host 'The graphics device was lost in the last game: this start tries the new renderer once more.' }
    elseif ($lostRetry -eq 'reset') { Write-Host 'The last game on the new renderer ended cleanly: a later device loss is retried once again.' }
}
$rendererChoice = Get-Ttt2RendererChoice $Rex $settingsFile
$renderer = $rendererChoice.Renderer
$shaderCache = Join-Path $Rex 'out\native-shaders.bin'
# (The cache counts only with the stamp the package's tools make (prebuilt\tools\shaders\VERSION.txt's stamp=): an older
# translation is not used (the main line's lead's review, 8 Nov). A source checkout has no VERSION.txt: the stamp beside
# the cache is taken as it is.)
$versionFile = Join-Path $Rex 'prebuilt\tools\shaders\VERSION.txt'
$wantStamp = if (Test-Path -LiteralPath $versionFile) {
    ("$(Get-Content -LiteralPath $versionFile | Where-Object { $_ -like 'stamp=*' } | Select-Object -First 1)" -replace '^stamp=', '').Trim()
} else { '' }
$haveStamp = if (Test-Path -LiteralPath "$shaderCache.stamp") { "$(Get-Content -LiteralPath "$shaderCache.stamp" -TotalCount 1)".Trim() } else { '' }
$callerChose = [bool]($args | Where-Object { "$_" -match '^--(no)?ttt2_native_gfx(=|$)' })
# (14 Nov, the owner: "Vsync off HAS to work on the native renderer." Whether this start draws natively, known before the display
# switches below: native chosen with its shader cache ready, or the caller passing --ttt2_native_gfx itself.)
$nativeCacheReady = (Test-Path -LiteralPath $shaderCache) -and $haveStamp -and (-not $wantStamp -or $haveStamp -eq $wantStamp)
$callerNative = [bool]($args | Where-Object { "$_" -match '^--ttt2_native_gfx(=(true|1))?$' })
$nativeRuns = $callerNative -or ($renderer -eq 'native' -and -not $callerChose -and $nativeCacheReady)
if (-not ($args | Where-Object { "$_" -like '--present_tearing*' })) {
    # (Unset: VSync Off, true, on both renderers (the lead, 14 Nov: one default); a stored tearing= line is never overridden. The in-game Settings store (ttt2_settings.cpp) and Start Here's box make the same choice.)
    if ($windowSize -and $tearing -eq 'true') {
        if ($nativeRuns) {
            # (The native renderer presents a window immediate when the player's VSync is off (present mode 4), so the choice stands.)
            Write-Host "Tearing stays on: the game is in a $($windowSize[0])x$($windowSize[1]) window on the native renderer, which shows frames at once with VSync off."
        } else {
            if ($tearingStored) { Write-Host "Tearing is off: the game is in a $($windowSize[0])x$($windowSize[1]) window, and a window never tears on the old renderer (VSync is on in a window)." }
            $tearing = 'false'
        }
    }
    $displayArgs += "--present_tearing=$(if ($tearing -eq 'true') { 'true' } else { 'false' })"
}
Write-Host "Display: $display$(if ($windowSize) { " ($($windowSize[0])x$($windowSize[1]) window)" }), tearing $tearing$(if (-not $tearingStored) { ' (the default)' })"

if ($renderer -eq 'native' -and -not $callerChose) {
    if ((Test-Path -LiteralPath $shaderCache) -and $haveStamp -and (-not $wantStamp -or $haveStamp -eq $wantStamp)) {
        $displayArgs += @('--ttt2_native_gfx=true', "--ttt2_native_gfx_shader_cache=$shaderCache")
        # (21 Nov, the lead; PC1's five pacing arms, logs ttt2_435..439: the native vblank thread at priority 2 ended the ticks over 3 ms late and halved the seconds with a swap over 24 ms; free of CPU cost.)
        $displayArgs += '--ttt2_native_vblank_priority=2'
        Write-Host "Renderer: native ($($rendererChoice.From))"
        # The Graphics rows (13 Nov, the helper lead's final list): the picture keys from launcher-settings.txt, each as its switch unless the caller gave one.
        # Only the keys the file holds (no row changed: the game's own default), only a number in the row's range; the live ones also follow a change inside the game.
        $gfxKeys = @(
            @{ Key = 'gfx_brightness'; Switch = 'ttt2_native_gfx_brightness';     Min = 50; Max = 150 },
            @{ Key = 'gfx_sharpen';    Switch = 'ttt2_native_gfx_sharpen';        Min = 0;  Max = 100 },
            @{ Key = 'gfx_filter';     Switch = 'ttt2_native_gfx_upscale_filter'; Min = 0;  Max = 2 },
            @{ Key = 'gfx_aniso';      Switch = 'ttt2_native_gfx_aniso';          Min = 0;  Max = 16 },
            @{ Key = 'gfx_resolution'; Switch = 'ttt2_native_gfx_resolution_percent'; Min = 0; Max = 300 })   # (13 Nov: aniso 0 is Off, 1 the game's own 4x; resolution 50/75/100, 0 is Display, read at the start; 17 Nov: 150/200/300 are 1080p/1440p/2160p)
        if ($settingsFile -and (Test-Path -LiteralPath $settingsFile)) {
            $settingsLines = Get-Content -LiteralPath $settingsFile
            foreach ($g in $gfxKeys) {
                if ($args | Where-Object { "$_" -match "^--$($g.Switch)(=|$)" }) { continue }
                $line = $settingsLines | Where-Object { $_ -match "^$($g.Key)=(\d+)\s*$" } | Select-Object -Last 1
                if ($line -match '=(\d+)\s*$') {
                    $n = [int]$Matches[1]
                    if ($n -ge $g.Min -and $n -le $g.Max) { $displayArgs += "--$($g.Switch)=$n"; Write-Host "Graphics: $($g.Key)=$n" }
                }
            }
            # (Edge smoothing (FXAA): off/on, a true|false value. Aniso 0 and a resolution other than 100 are right only with the native build that has them; a build without them takes the switch as an unknown one.)
            # (Bloom, 13 Nov: landed on native-gfx 3620f742, live, native only: a true|false value, passed when the row holds one)
            if (-not ($args | Where-Object { "$_" -match '^--ttt2_native_gfx_bloom(=|$)' })) {
                $bl = $settingsLines | Where-Object { $_ -match '^gfx_bloom=(true|false)\s*$' } | Select-Object -Last 1
                if ($bl -match '=(true|false)\s*$') { $displayArgs += "--ttt2_native_gfx_bloom=$($Matches[1])"; Write-Host "Graphics: gfx_bloom=$($Matches[1])" }
            }
            # (Shadows, 13 Nov: landed on native-gfx 942f77bb, live, native only: a true|false value, passed when the row holds one)
            if (-not ($args | Where-Object { "$_" -match '^--ttt2_native_gfx_shadows(=|$)' })) {
                $sh = $settingsLines | Where-Object { $_ -match '^gfx_shadows=(true|false)\s*$' } | Select-Object -Last 1
                if ($sh -match '=(true|false)\s*$') { $displayArgs += "--ttt2_native_gfx_shadows=$($Matches[1])"; Write-Host "Graphics: gfx_shadows=$($Matches[1])" }
            }
            if (-not ($args | Where-Object { "$_" -match '^--ttt2_native_gfx_fxaa(=|$)' })) {
                $fx = $settingsLines | Where-Object { $_ -match '^gfx_fxaa=(true|false)\s*$' } | Select-Object -Last 1
                if ($fx -match '=(true|false)\s*$') { $displayArgs += "--ttt2_native_gfx_fxaa=$($Matches[1])"; Write-Host "Graphics: gfx_fxaa=$($Matches[1])" }
            }
            # (Fixed exposure, 18 Nov: native only, from the next fight; the switch is the native lead's item 3b, passed when the row holds a value)
            if (-not ($args | Where-Object { "$_" -match '^--ttt2_native_gfx_fixed_exposure(=|$)' })) {
                $fe = $settingsLines | Where-Object { $_ -match '^gfx_fixed_exposure=(true|false)\s*$' } | Select-Object -Last 1
                if ($fe -match '=(true|false)\s*$') { $displayArgs += "--ttt2_native_gfx_fixed_exposure=$($Matches[1])"; Write-Host "Graphics: gfx_fixed_exposure=$($Matches[1])" }
            }
            # (Stage shadows, 18 Nov: native only; the switch is INVERTED (native-gfx 5003cb329): the row Off passes ..._stage_shadows_off=true)
            if (-not ($args | Where-Object { "$_" -match '^--ttt2_native_gfx_stage_shadows_off(=|$)' })) {
                $ss = $settingsLines | Where-Object { $_ -match '^gfx_stage_shadows=(true|false)\s*$' } | Select-Object -Last 1
                if ($ss -match '=(true|false)\s*$') { $off = if ($Matches[1] -eq 'true') { 'false' } else { 'true' }; $displayArgs += "--ttt2_native_gfx_stage_shadows_off=$off"; Write-Host "Graphics: gfx_stage_shadows=$($Matches[1]) (switch _off=$off)" }
            }
        }
    } else {
        # (The background fallback (the lead's design, 7 Nov): this game plays emulated; the cache is made now, hidden, below
        # normal priority (XenosRecomp inherits it), and the next start uses native. Also what a Start Here closed during
        # its shader step leaves to do.)
        $shaderTools = Join-Path $Rex 'prebuilt\tools\shaders'
        # (Only with every tool there: a quarantined or missing one makes nothing, and the line says so instead of
        # promising a build (the packaging slot's check 8, 8 Nov).)
        $missingTool = @('XenosRecomp.exe', 'dxcompiler.dll', 'shader_common.hlsli', 'ttt2unpack.exe', 'VERSION.txt') |
            Where-Object { -not (Test-Path -LiteralPath (Join-Path $shaderTools $_)) } | Select-Object -First 1
        $failedBefore = (Test-Path -LiteralPath "$shaderCache.failed") -and $wantStamp -and
            "$(Get-Content -LiteralPath "$shaderCache.failed" -TotalCount 1)".Trim() -eq $wantStamp
        if ($failedBefore) {
            # (C3: a translation that failed with these tools isn't tried again at every Play; Install tries again.)
            Write-Host 'Renderer: old renderer; the native renderer''s shaders failed to translate last time (rex\out\native-shaders-build.log); Install tries again'
        } elseif ((Test-Path -LiteralPath $shaderTools) -and $missingTool) {
            Write-Host "Renderer: old renderer; the native renderer's shader tools are incomplete ($missingTool missing: an antivirus may have removed it; Install again restores it)"
        } elseif (Test-Path -LiteralPath $shaderTools) {
            # (The paths go through the environment, never into the command's text: an apostrophe in the install folder
            # can't break it. Half the cores at idle priority, so a game played meanwhile (an online match) keeps the rest
            # (the main line's lead's review, B6).)
            $env:TTT2_SHADERS_REX = $Rex; $env:TTT2_SHADERS_TOOLS = $shaderTools; $env:TTT2_SHADERS_OUT = $shaderCache
            $env:TTT2_SHADERS_LOG = Join-Path $Rex 'out\native-shaders-build.log'
            $env:TTT2_SHADERS_CORES = "$([Math]::Max(1, [int]([Environment]::ProcessorCount / 2)))"
            $script = '. (Join-Path $env:TTT2_SHADERS_REX ''tools\native-shaders\package-shaders.ps1''); ' +
                '$null = Invoke-NativeShaderCache -Rex $env:TTT2_SHADERS_REX -Tools $env:TTT2_SHADERS_TOOLS -Out $env:TTT2_SHADERS_OUT ' +
                '-Cores ([int]$env:TTT2_SHADERS_CORES) -Idle -FromPlay *> $env:TTT2_SHADERS_LOG'
            $builder = Start-Process powershell -WindowStyle Hidden -PassThru -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', $script)
            try { $builder.PriorityClass = 'Idle' } catch { }
            foreach ($v in 'REX', 'TOOLS', 'OUT', 'LOG', 'CORES') { Remove-Item -LiteralPath "Env:TTT2_SHADERS_$v" -ErrorAction SilentlyContinue }
            Write-Host 'Renderer: old renderer this time; the native renderer''s shaders are being made in the background (native from the next start)'
        } else {
            Write-Host 'Renderer: old renderer (no native shader cache)'
        }
    }
} else {
    # (15 Nov, the native lead's order 829939c57: a caller that chose native itself (--ttt2_native_gfx=true) and named no cache
    # switch gets the shader cache too; without it a package fell back to the emulated renderer.)
    if ($callerNative -and -not ($args | Where-Object { "$_" -like '--ttt2_native_gfx_shader_cache*' }) -and (Test-Path -LiteralPath $shaderCache)) {
        $displayArgs += "--ttt2_native_gfx_shader_cache=$shaderCache"
    }
    Write-Host "Renderer: $(if ($callerChose) { 'as the command line says' } else { "old renderer ($($rendererChoice.From))" })"
}
# (5.0, 15 Nov: --ttt2_native_gfx is on in the game by default, so a start that is emulated here (the player chose the old renderer, a failure marker,
# the shader cache not ready) says so; a caller's own switch is left as it is.)
if (-not $callerChose -and -not ($displayArgs | Where-Object { "$_" -eq '--ttt2_native_gfx=true' })) { $displayArgs += '--ttt2_native_gfx=false' }
# The way back to emulated, B's Play side (the native lead's 12 Nov contract item 3; C's game side behind --ttt2_native_gfx_fallback_marker):
# (1) one plain line when a marker decides this start; (2) the shader cache's switch also on an emulated start while a failure marker is
# there, so the game's notice (NativeGfxFallbackNotice, keyed on that switch) finds it for BlueSpark's popup; (3) a start without BlueSpark
# shows the marker's reason once in a plain message box before the game starts (not for test scripts); (4) below: a native start that
# ends at once with the no-device exit code is started again (the marker then makes it emulated).
$nativeThisStart = $callerNative -or [bool]($displayArgs | Where-Object { "$_" -eq '--ttt2_native_gfx=true' })
$failedNow = Get-Ttt2NativeFailed $Rex
# (18 Nov, the main line's lead's ruling on the fold trial: a native start with the clone's own cache has the shipped pipeline key list beside it
# (<cache>.shipped-keys, rex\native\pipekeys.bin): Install and the background build make it, a cache from before the list had none and Play never added it,
# so a first fight made its pipelines by draws. Copy-NativeShippedKeys is the one copy (package-shaders.ps1): only when the file differs, never fails or
# slows the start more than a hash of the list.)
if ($nativeThisStart -and ($displayArgs -contains "--ttt2_native_gfx_shader_cache=$shaderCache")) {
    try { . (Join-Path $Rex 'tools\native-shaders\package-shaders.ps1'); Copy-NativeShippedKeys -Rex $Rex -Out $shaderCache } catch { }
}
if ($failedNow) {
    Write-Host "This start uses the old renderer: $($failedNow.Reason)"
    if (-not $nativeThisStart -and -not ($args | Where-Object { "$_" -like '--ttt2_native_gfx_shader_cache*' }) -and
        -not ($displayArgs | Where-Object { "$_" -like '--ttt2_native_gfx_shader_cache*' })) {
        $displayArgs += "--ttt2_native_gfx_shader_cache=$shaderCache"
    }
    $testStart = $env:TTT2_GAME_PID_FILE -or [bool]($args | Where-Object { "$_" -match '^--ttt2_test_' })
    $blueSpark = [bool]($args | Where-Object { "$_" -eq '--ttt2_bluespark=true' })
    if (-not $blueSpark -and -not $testStart) { $null = Show-Ttt2NativeFailedBox $Rex }
} elseif ($nativeThisStart -and (Test-Ttt2NativeStartStale $Rex)) {
    Write-Host 'The native renderer did not finish starting last time: with the fall-back switch on, the game uses the old renderer this start.'
}
$markerOn = $Ttt2FallbackMarkerOn -or [bool]($args | Where-Object { "$_" -match '^--ttt2_native_gfx_fallback_marker(=(true|1))?$' })
$watchNoDevice = $nativeThisStart -and $markerOn -and -not $env:TTT2_PLAY_RESTARTED
$restartEmulated = $false
# (Plan B, 20 Nov, the helper lead: --ttt2_return_relaunch=true, off by default. The game ends with exit code 78 on the end card's RETURN TO MENU in a walk's set; this script,
# started with the same switch, leaves a hidden watcher (tools\return-relaunch-watch.ps1) that starts the game again on that code after every set, 50 rounds at most (TTT2_PLAY_RELAUNCH_COUNT).)
$Ttt2ReturnRelaunchExit = 78
$watchReturn = [bool]($args | Where-Object { "$_" -match '^--ttt2_(return_relaunch|abort_relaunch|classic_session)(=(true|1))?$' }) -and ([int]"0$env:TTT2_PLAY_RELAUNCH_COUNT" -lt 50)
$relaunchReturn = $false

# The Old renderer's anisotropy (13 Nov, the helper lead): the stored value is read at the start and handed to the SDK's own switch, 0 Off / 2 = 2x / 4 = 8x / 5 = 16x
# (the row's 1, the game's own 4x, passes no switch at all: Medium's launch line stays today's). Only where the game runs emulated and no switch of the caller's names it; the native renderer reads its own aniso key.
if (-not ($displayArgs | Where-Object { "$_" -match '^--ttt2_native_gfx=true$' }) -and -not ($args | Where-Object { "$_" -match '^--anisotropic_override(=|$)' }) -and $settingsFile -and (Test-Path -LiteralPath $settingsFile)) {
    $an = Get-Content -LiteralPath $settingsFile | Where-Object { $_ -match '^gfx_aniso=' } | Select-Object -Last 1   # (the last line of the key; then only 0 / 2 / 8 / 16 pass a switch: 1, the game's own, passes nothing, so Medium's launch line is today's)
    if ($an -match '^gfx_aniso=(0|2|8|16)\s*$') {
        $sdkAniso = @{ '0' = 0; '2' = 2; '8' = 4; '16' = 5 }[$Matches[1]]
        $displayArgs += "--anisotropic_override=$sdkAniso"
        Write-Host "Graphics: anisotropic filtering $($Matches[1]) (the Old renderer's $sdkAniso)"
    }
}
# Motion blur (13 Nov, native-gfx 51b9abc3): --ttt2_motion_blur -1 = the player's own setting (the default: nothing passed), 0 off, 1 on; both renderers. Passed only when the file holds
# a gfx_motionblur line (the player has set it); a switch of the caller's wins. The one table of the polarity (1 = on waits for PC2's toggle): $motionBlurSwitch.
$motionBlurSwitch = @{ 'false' = 0; 'true' = 1 }
if (-not ($args | Where-Object { "$_" -match '^--ttt2_motion_blur(=|$)' }) -and $settingsFile -and (Test-Path -LiteralPath $settingsFile)) {
    $mb = Get-Content -LiteralPath $settingsFile | Where-Object { $_ -match '^gfx_motionblur=' } | Select-Object -Last 1
    if ($mb -match '^gfx_motionblur=(true|false)\s*$') {
        $displayArgs += "--ttt2_motion_blur=$($motionBlurSwitch[$Matches[1]])"
        Write-Host "Graphics: gfx_motionblur=$($Matches[1])"
    }
}
# The online combo counter (13 Nov, training 0415d800): --ttt2_match_counter_online is off by default and Ttt2MatchCounterOnlineSet() does not save, so the row's value is passed at each start,
# only when the file holds an online_combo_counter line (the player has set it); a switch of the caller's wins.
if (-not ($args | Where-Object { "$_" -match '^--ttt2_match_counter_online(=|$)' }) -and $settingsFile -and (Test-Path -LiteralPath $settingsFile)) {
    $oc = Get-Content -LiteralPath $settingsFile | Where-Object { $_ -match '^online_combo_counter=' } | Select-Object -Last 1
    if ($oc -match '^online_combo_counter=(true|false)\s*$') {
        $displayArgs += "--ttt2_match_counter_online=$($Matches[1])"
        Write-Host "Gameplay: online_combo_counter=$($Matches[1])"
    }
}
# The game lock (tools/game-lock.ps1, docs/GAME_LOCK_RULES_20261102.md): taken here unless the script that started this one has
# it, and then handed to the game itself, so that it is held for as long as the game runs. Exclusive unless the caller says
# (TTT2_GAME_LOCK_KIND: shared, exclusive, quiet, or owner for Start Here's Play; TTT2_GAME_LOCK_PURPOSE). Which process the game
# is goes into out/game-pid.txt, for the test scripts to stop the game they started and no other.
. (Join-Path $Rex "tools/game-lock.ps1")
$lockPurpose = "$env:TTT2_GAME_LOCK_PURPOSE"
$mine = switch ("$env:TTT2_GAME_LOCK_KIND") {
    'shared' { Take-GameLock $Rex -Shared -Purpose $lockPurpose }
    'quiet'  { Take-GameLock $Rex -Exclusive -Quiet -Purpose $lockPurpose }
    'owner'  { Take-GameLock $Rex -Exclusive -Owner -Purpose 'the owner''s Play' }
    default  { Take-GameLock $Rex -Exclusive -Purpose $lockPurpose }
}
$handed = $false
# (Games started together from one build: one at a time from the start until the game and its log are known, or the search
# below could take the other's. Named by the exe, so another clone doesn't wait.)
$startMutex = New-Object Threading.Mutex($false, "Local\ttt2-game-start-$(($exe -replace '[\\:]', '_').ToLower())")
$startHeld = $false
try { $startHeld = $startMutex.WaitOne(60000) } catch [Threading.AbandonedMutexException] { $startHeld = $true }
try {
    $before = Get-Date
    # (The exact command line the game is started with, for a tester to send: userdata\last-launch.txt,
    # written at every launch.)
    $launchArgs = @("--game_data_root=$game", "--update_data_root=$update", "--user_data_root=$userData") + $profileArgs + $mappingArgs + $nameArgs + $displayArgs + $renderTargetArgs + @($args)
    try {
        $quoted = $launchArgs | ForEach-Object { if ("$_" -match '\s') { '"' + "$_" + '"' } else { "$_" } }
        Set-Content -LiteralPath (Join-Path $userData 'last-launch.txt') ('"' + $exe + '" ' + ($quoted -join ' ')) -Encoding utf8
    } catch { Write-Host "last-launch.txt not written: $($_.Exception.Message)" }
    # (Each switch as a plain string: with this script started by -File, Windows PowerShell 5.1 passed a "--name=value"
    # with a space unquoted, so the game got "--ttt2_release_name=Release" and a stray "4.1"; 24 Oct.)
    $passArgs = @($args | ForEach-Object { "$_" })
    & $exe "--game_data_root=$game" "--update_data_root=$update" "--user_data_root=$userData" @profileArgs @mappingArgs @nameArgs @displayArgs @renderTargetArgs @passArgs
    $started = $null
    $deadline = (Get-Date).AddSeconds(20)
    while (-not $started -and (Get-Date) -lt $deadline) {
        $started = Get-Process ttt2 -ErrorAction SilentlyContinue |
            Where-Object { $_.Path -eq $exe -and $_.StartTime -ge $before.AddSeconds(-2) } |
            Sort-Object StartTime | Select-Object -Last 1
        if (-not $started) { Start-Sleep -Milliseconds 100 }
    }
    New-Item -ItemType Directory -Force (Join-Path $Rex 'out') | Out-Null
    # (Its start time read now, while it runs: Install's pipeline warm-up game makes its pipelines and quits in ~3 s, before the wait for
    # its log below ends (with --log_file there is no numbered log to wait for), and an exited process's StartTime is null: the
    # "null-valued expression" that skipped the warm-up's own lines in 4.6.2, 4 Nov.)
    $startedAt = if ($started) { try { $started.StartTime.ToFileTimeUtc() } catch { 0 } } else { 0 }
    # (The process's handle taken now, while it runs, so its exit code can be read after it ends: the no-device wait below.)
    if ($started -and ($watchNoDevice -or $watchReturn)) { try { $null = $started.Handle } catch { } }
    if ($started) {
        # (The pair mode names a file an instance: TTT2_GAME_PID_FILE; else this clone's one file.)
        $pidFile = if ($env:TTT2_GAME_PID_FILE) { $env:TTT2_GAME_PID_FILE } else { Join-Path $Rex "out/game-pid.txt" }
        # (Its log's name third, for runs that share the logs folder with another game: the newest log may be the other's.)
        $ownLog = $null
        $logDeadline = (Get-Date).AddSeconds(5)
        while (-not $ownLog -and (Get-Date) -lt $logDeadline) {
            $ownLog = Get-ChildItem -LiteralPath (Join-Path (Split-Path $exe -Parent) 'logs') -Filter 'ttt2_*.log' -ErrorAction SilentlyContinue |
                Where-Object { $_.CreationTime -ge $before.AddSeconds(-2) -and $_.Name -notmatch '\.\d+\.log$' } | Sort-Object CreationTime | Select-Object -Last 1
            if (-not $ownLog) { Start-Sleep -Milliseconds 100 }
        }
        Set-Content -LiteralPath $pidFile -Value "$($started.Id) $startedAt $(if ($ownLog) { $ownLog.FullName })".Trim()
        # (A game already gone (the warm-up's, above): no lock to hand it; this run's own lock is let go below as for a game that never started.)
        try { if ($mine) { Move-GameLock $started.Id; $handed = $true } else { Add-GameLockProcess $started.Id } }
        catch { if (Get-Process -Id $started.Id -ErrorAction SilentlyContinue) { throw } }
        # Online replays to the server (21 October): the game saves each finished online match as replays\<date>-online.ttt2replay;
        # tools\replay-uploader.ps1, hidden beside the game, sends each file unchanged and ends when the game does. Only for an online
        # start with a server; "replay_upload=false" in launcher-settings.txt turns it off.
        $online = @($args | Where-Object { "$_" -eq '--ttt2_live_net=true' }).Count -gt 0
        $workerArg = @($args | Where-Object { "$_" -like '--ttt2_live_worker=*' } | Select-Object -Last 1)
        $worker = if ($workerArg.Count) { ("$($workerArg[0])" -replace '^--ttt2_live_worker=', '').Trim('"') } else { 'https://elo.bluespark.site' }
        $uploadOff = (Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'replay_upload=false')
        $uploader = Join-Path $Rex 'tools\replay-uploader.ps1'
        # (13 Nov: started whenever the start is online, even with replay_upload=false: the uploader reads the file each pass and sends nothing while it says false, so the game's Settings tab can turn it on in the running game.)
        if ($online -and $worker -and (Test-Path -LiteralPath $uploader)) {
            try {
                $uploaderArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$uploader`"",
                    '-UserData', "`"$userData`"", '-Worker', $worker, '-GamePid', $started.Id)
                $uploaderArgs += @('-SettingsFile', "`"$settingsFile`"")
                if ($profileDir) { $uploaderArgs += @('-ProfileDir', "`"$profileDir`"") }   # (the identity is in the profile folder since 23 October)
                Start-Process powershell -WindowStyle Hidden -ArgumentList $uploaderArgs | Out-Null
            } catch { Write-Host "The replay uploader did not start: $($_.Exception.Message)" }
        }
        # (4) The no-device exit (C's kNativeGfxExitNoDevice): the game writes .native-failed kind=no-device and ends with that code
        # right after its start marker, so Play watches only the first seconds: until its "pid=" line leaves .starting (300 frames, a
        # failure, or the player's close), 20 s if the line never comes, 120 s at most. Then it starts the game again, once, at once.
        if ($watchNoDevice) {
            $seen = $false; $watchFrom = Get-Date
            while (-not $started.HasExited) {
                $pids = Get-Ttt2NativeStartPids $Rex
                if ($pids -and ($pids -contains [int64]$started.Id)) { $seen = $true } elseif ($seen) { break }
                $age = ((Get-Date) - $watchFrom).TotalSeconds
                if ((-not $seen -and $age -gt 20) -or $age -gt 120) { break }
                Start-Sleep -Milliseconds 250
            }
            if ($seen -and -not $started.HasExited) { $null = $started.WaitForExit(3000) }
            if ($started.HasExited) {
                $code = try { $started.ExitCode } catch { $null }
                if ($code -eq $Ttt2NativeExitNoDevice) {
                    $restartEmulated = $true
                    Write-Host "The native renderer could not start on this PC (exit code $code): the game starts again with the old renderer."
                }
            }
        }
    }
} finally {
    if ($startHeld) { try { $startMutex.ReleaseMutex() } catch {} }
    $startMutex.Dispose()
    if ($mine -and -not $handed) { Release-GameLock }
}
if ($watchReturn -and $started) {
    # (Plan B: this script returns as always (Play's step waits for it); a hidden watcher outlives it and starts the game again on exit 78, 50 rounds at most: tools\return-relaunch-watch.ps1.)
    try {
        $argsFile = Join-Path $env:TEMP "ttt2-relaunch-args-$($started.Id).txt"
        Set-Content -LiteralPath $argsFile -Value @($args | ForEach-Object { "$_" }) -Encoding UTF8
        $watcher = Join-Path $Rex 'tools\return-relaunch-watch.ps1'
        Start-Process powershell -WindowStyle Hidden -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$watcher`"", '-GamePid', $started.Id,
            '-RunWindows', "`"$PSCommandPath`"", '-ArgsFile', "`"$argsFile`"", '-Round', [int]"0$env:TTT2_PLAY_RELAUNCH_COUNT") | Out-Null
    } catch { Write-Host "The return-relaunch watcher did not start: $($_.Exception.Message)" }
}
if ($restartEmulated) {
    # (Once: the restarted Play sees .native-failed and starts emulated; TTT2_PLAY_RESTARTED stops a second round.)
    $env:TTT2_PLAY_RESTARTED = '1'
    & $PSCommandPath @args
    exit $LASTEXITCODE
}
