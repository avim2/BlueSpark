@echo off
rem "Play (old renderer)": starts the game with the old renderer (the way TTT2 has always been drawn), for a PC where the
rem native renderer gives trouble. It writes the choice (see rex\tools\compat-renderer.ps1) and starts Play; the next plain Play stays
rem on the old renderer until the native renderer is picked again in Start Here's Settings.
if exist "%~dp0rex\tools\compat-renderer.ps1" goto found
echo.
echo   Play (old renderer) can't find rex\tools\compat-renderer.ps1 beside it.
echo   Unzip the WHOLE zip into a folder first (right-click the zip, Extract All),
echo   then run it from that folder, not from inside the zip.
echo.
pause
exit /b 1
:found
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0rex\tools\compat-renderer.ps1"
if errorlevel 1 pause
