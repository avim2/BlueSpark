# Report a problem: packs what is needed to look into a crash, a hang, a failed build or anything else
# into one zip on the Desktop, for whoever gave out the build. Nothing is played or changed.
#
#   powershell -ExecutionPolicy Bypass -File rex\problem-report.ps1 [-OutDir <folder>] [-NoPause]
#
# What goes in:
#   - the newest run's game log and its newest parts, 4 at most (rex\out\build\win-amd64-release\logs) and the newest 3 crash dumps of the
#     last 14 days (rex\out\dumps, --ttt2_crash_dump's), and the hang dump of the last 14 days (profile\hang.txt,
#     --ttt2_hang_dump's: where every thread was when the game stopped updating; the alt-tab freeze, 24 Oct);
#   - Start Here's own logs (%LOCALAPPDATA%\TTT2Native\logs: the newest 8 step logs (Play's too) with their .err, and
#     update-check.log);
#   - VERSION.txt, rex\package-info.txt, prebuilt\manifest.txt's release line, the display and tearing
#     settings (those two lines of rex\userdata\launcher-settings.txt, nothing else of it);
#   - the PC: Windows, the processor, memory, the graphics card and its driver, each monitor's size.
# What NEVER goes in: the identity and its key, the saves, the profile backup, the replays, or anything
# else of rex\userdata (the player's name, the settings file itself): only the paths above are read.
param([string]$OutDir = '', [switch]$NoPause)
$ErrorActionPreference = 'Stop'
$Rex = $PSScriptRoot
$Root = Split-Path $Rex -Parent
if (-not $OutDir) { $OutDir = [Environment]::GetFolderPath('Desktop') }

function Say($text, $color = 'White') { Write-Host $text -ForegroundColor $color }

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$work = Join-Path $env:TEMP "ttt2-problem-report-$stamp"
New-Item -ItemType Directory -Force $work | Out-Null
$summary = @("TTT2 problem report, $stamp", "folder: $Root", '')

# The newest files of a folder matching a filter, copied under a subfolder of the report.
function Take([string]$from, [string]$filter, [int]$count, [string]$to, [int]$days = 0) {
    if (-not (Test-Path $from)) { $script:summary += "${to}: none ($from is not there)"; return }
    $files = @(Get-ChildItem $from -Filter $filter -File -ErrorAction SilentlyContinue |
               Where-Object { $days -le 0 -or $_.LastWriteTime -ge (Get-Date).AddDays(-$days) } |
               Sort-Object LastWriteTime -Descending | Select-Object -First $count)
    if (-not $files.Count) { $script:summary += "${to}: none"; return }
    $dir = Join-Path $work $to
    New-Item -ItemType Directory -Force $dir | Out-Null
    foreach ($f in $files) {
        Copy-Item $f.FullName $dir
        $script:summary += "${to}\$($f.Name)  ($([Math]::Round($f.Length / 1KB)) KB, $($f.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')))"
    }
}

# The game's logs: the newest run's live log (ttt2_NNN.log, the highest NNN), then that run's newest cut parts
# (ttt2_NNN.1.log ...), 4 files at most. (Not by file time: a log the game still has open can keep an old time, and two
# reports in a row, 26 Oct, took the run's cut parts and left out the live log, which held the freeze.) Read shared, as
# the game may be writing it.
function TakeGameLogs([string]$from, [string]$to, [int]$count = 4) {
    if (-not (Test-Path $from)) { $script:summary += "${to}: none ($from is not there)"; return }
    $runs = @(Get-ChildItem $from -Filter 'ttt2_*.log' -File -ErrorAction SilentlyContinue |
              Where-Object { $_.Name -match '^ttt2_(\d+)\.log$' } | Sort-Object { [int]($_.Name -replace '^ttt2_(\d+)\.log$', '$1') } -Descending)
    if (-not $runs.Count) { $script:summary += "${to}: none"; return }
    $run = $runs[0].Name -replace '\.log$', ''
    $parts = @(Get-ChildItem $from -Filter "$run.*.log" -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    $files = @($runs[0]) + $parts | Select-Object -First $count
    $dir = Join-Path $work $to
    New-Item -ItemType Directory -Force $dir | Out-Null
    foreach ($f in $files) {
        try {
            $in = [IO.File]::Open($f.FullName, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
            try { $out = [IO.File]::Create((Join-Path $dir $f.Name)); try { $in.CopyTo($out) } finally { $out.Dispose() } } finally { $in.Dispose() }
            $script:summary += "${to}\$($f.Name)  ($([Math]::Round($f.Length / 1KB)) KB, $($f.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')))"
        } catch {
            $script:summary += "${to}\$($f.Name): not read ($($_.Exception.Message))"
        }
    }
}

Say ''
Say '  TTT2: report a problem' Cyan
Say '  ----------------------'
Say '  Putting the report together...'

TakeGameLogs (Join-Path $Rex 'out\build\win-amd64-release\logs') 'game-logs'
Take (Join-Path $Rex 'out\dumps') 'ttt2_*.dmp' 3 'crash-dumps' 14
Take (Join-Path $Rex 'out\build\win-amd64-release\profile') 'hang.txt' 1 'hang-dump' 14
$setupLogs = Join-Path $env:LOCALAPPDATA 'TTT2Native\logs'
Take $setupLogs '*.log' 8 'start-here-logs'
# (each step log's .err beside it)
foreach ($f in @(Get-ChildItem (Join-Path $work 'start-here-logs') -Filter '*.log' -ErrorAction SilentlyContinue)) {
    $err = Join-Path $setupLogs "$($f.Name).err"
    if (Test-Path $err) { Copy-Item $err (Join-Path $work 'start-here-logs') }
}
$updateCheck = Join-Path $setupLogs 'update-check.log'
if ((Test-Path $updateCheck) -and -not (Test-Path (Join-Path $work 'start-here-logs\update-check.log'))) {
    New-Item -ItemType Directory -Force (Join-Path $work 'start-here-logs') | Out-Null
    Copy-Item $updateCheck (Join-Path $work 'start-here-logs')
}

# ---- The build and the settings ---------------------------------------------------------------
$build = @('== The build')
foreach ($file in @((Join-Path $Root 'VERSION.txt'), (Join-Path $Rex 'package-info.txt'))) {
    if (Test-Path $file) { $build += "-- $(Split-Path $file -Leaf):"; $build += Get-Content $file } else { $build += "-- $(Split-Path $file -Leaf): not there" }
}
$manifest = Join-Path $Rex 'prebuilt\manifest.txt'
if (Test-Path $manifest) { $build += '-- prebuilt\manifest.txt:'; $build += Get-Content $manifest | Where-Object { $_ -match '^(release|toolchain)=' } }
else { $build += 'prebuilt\manifest.txt: not there (a build from source)' }
$exe = Join-Path $Rex 'out\build\win-amd64-release\ttt2.exe'
if (Test-Path $exe) { $build += "ttt2.exe: $((Get-Item $exe).LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')), $((Get-Item $exe).Length) bytes" }
else { $build += 'ttt2.exe: not built' }
$build += '', '== Display settings (Start Here)'
$settings = Join-Path $Rex 'userdata\launcher-settings.txt'
$shown = @()
if (Test-Path $settings) { $shown = @(Get-Content $settings | Where-Object { $_ -match '^(display|tearing)=' }) }
$build += $(if ($shown.Count) { $shown } else { 'the defaults (no display or tearing setting saved)' })

# ---- The PC -----------------------------------------------------------------------------------
$pc = @()
function Try-Add($title, [scriptblock]$what) {
    $script:pc += '', "== $title"
    try { $script:pc += (& $what | Out-String).Trim() } catch { $script:pc += "not available: $_" }
}
Try-Add 'Windows' { Get-CimInstance Win32_OperatingSystem | Format-List Caption, Version, BuildNumber, OSArchitecture }
Try-Add 'Processor and memory' {
    Get-CimInstance Win32_Processor | Format-List Name, NumberOfCores, NumberOfLogicalProcessors, MaxClockSpeed
    "memory: $([Math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)) GB"
}
Try-Add 'Graphics' { Get-CimInstance Win32_VideoController | Format-List Name, DriverVersion, DriverDate, CurrentHorizontalResolution, CurrentVerticalResolution, CurrentRefreshRate }
Try-Add 'Monitors' {
    # (DPI-aware first: otherwise Windows' scaling shrinks the sizes, 3840 x 2160 at 200% read as 1920 x 1080.)
    Add-Type -Name Dpi -Namespace Ttt2Report -MemberDefinition '[DllImport("user32.dll")] public static extern bool SetProcessDPIAware();'
    [void][Ttt2Report.Dpi]::SetProcessDPIAware()
    Add-Type -AssemblyName System.Windows.Forms
    foreach ($s in [System.Windows.Forms.Screen]::AllScreens) {
        "{0}: {1} x {2}{3}" -f $s.DeviceName, $s.Bounds.Width, $s.Bounds.Height, $(if ($s.Primary) { ' (main)' } else { '' })
    }
    Get-CimInstance -Namespace root\wmi -ClassName WmiMonitorBasicDisplayParams -ErrorAction SilentlyContinue |
        ForEach-Object { "panel: {0} x {1} cm" -f $_.MaxHorizontalImageSize, $_.MaxVerticalImageSize }
}
Try-Add 'Power plan' { powercfg /getactivescheme }

Set-Content (Join-Path $work 'build.txt') $build -Encoding utf8
Set-Content (Join-Path $work 'pc.txt') $pc -Encoding utf8
$summary += '', 'Not included: the identity and its key, the saves, the profile backup, the replays, the rest of rex\userdata.'
Set-Content (Join-Path $work 'summary.txt') $summary -Encoding utf8

$zip = Join-Path $OutDir "ttt2-problem-report-$stamp.zip"
Compress-Archive -Path (Join-Path $work '*') -DestinationPath $zip -Force
Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue

Say ''
Say '  Done. Please send this file (it is on your Desktop), with a few words on what went wrong:' Green
Say "    $(Split-Path $zip -Leaf)   ($([Math]::Round((Get-Item $zip).Length / 1MB, 1)) MB)"
Say '  It holds the game''s and Start Here''s logs, any crash dumps, the build''s version and your PC''s'
Say '  parts. Not your identity, saves, replays or settings.'
if (-not $NoPause) {
    Start-Process explorer.exe "/select,`"$zip`""
    [void](Read-Host '  Press Enter to close')
}
