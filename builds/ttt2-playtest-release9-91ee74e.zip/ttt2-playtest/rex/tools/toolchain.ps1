# The portable toolchain (docs/PREBUILT_PACKAGE_PLAN.md, decision 3): the compiler, CMake, Ninja, and Microsoft's C++
# runtime headers/libraries and Windows SDK, pinned and the same on the owner's PC (building the SDK, our libraries and
# xexpatch.exe) and on a player's (compiling the game code). No Visual Studio, no Git.
#
#   . rex\tools\toolchain.ps1
#   Install-Ttt2Toolchain -AcceptMicrosoftLicense   # downloads what's missing (each by URL and SHA-256), unpacks
#   Use-Ttt2Toolchain                               # PATH, INCLUDE and LIB for this PowerShell, VS's own settings off
#
# Everything goes in %LOCALAPPDATA%\TTT2Native\toolchain\<pin> (or $env:TTT2_TOOLCHAIN_ROOT). Microsoft's parts are
# fetched by xwin (MIT/Apache-2.0) from Microsoft's own servers, only after the player accepted Microsoft's license.
# xwin's layout is used as is (crt\, sdk\); its one version-folder symbolic link needs a privilege Windows doesn't give
# by default and nothing here uses it, so its failure is ignored once the files are checked.

$script:Ttt2ToolchainPins = [ordered]@{
    llvm  = @{ version = '20.1.8'; folder = 'llvm-20.1.8'; kind = 'tar.xz'; strip = 1
               url = 'https://github.com/llvm/llvm-project/releases/download/llvmorg-20.1.8/clang+llvm-20.1.8-x86_64-pc-windows-msvc.tar.xz'
               sha256 = 'f229769f11d6a6edc8ada599c0cda964b7dee6ab1a08c6cf9dd7f513e85b107f'; size = '940 MB'; needGB = 5.2 }   # (needGB: the archive and its 3.9 GB unpacked, at once)
    cmake = @{ version = '3.31.8'; folder = 'cmake-3.31.8'; kind = 'zip'; inner = 'cmake-3.31.8-windows-x86_64'
               url = 'https://github.com/Kitware/CMake/releases/download/v3.31.8/cmake-3.31.8-windows-x86_64.zip'
               sha256 = '81aa9964dbabd71fe02e7ec50472fd3ad56138c49944515ece9001efbff8d719'; size = '47 MB' }
    ninja = @{ version = '1.12.1'; folder = 'ninja-1.12.1'; kind = 'zip'
               url = 'https://github.com/ninja-build/ninja/releases/download/v1.12.1/ninja-win.zip'
               sha256 = 'f550fec705b6d6ff58f2db3c374c2277a37691678d6aba463adcbb129108467a'; size = '0.3 MB' }   # (no published hash: ours, 21 Oct)
    xwin  = @{ version = '0.10.0'; folder = 'xwin-0.10.0'; kind = 'tar.gz'; strip = 1
               url = 'https://github.com/Jake-Shadle/xwin/releases/download/0.10.0/xwin-0.10.0-x86_64-pc-windows-msvc.tar.gz'
               sha256 = '96e83665ef5c1406aabd0be603a8d08e67e604f36fda630b6807ee948a614e26'; size = '3 MB' }
}
# Microsoft's C++ runtime (the MSVC CRT/STL) and the Windows SDK, through xwin (the VS 17 release channel's manifest).
$script:Ttt2MsvcCrt = '14.44.17.14'   # (its packages: the VC tools build 14.44.35208, VS 17.14's)
$script:Ttt2WinSdk = '10.0.26100'
# xwin takes the SDK by its short version only; the package build it lays out (Win11SDK_10.0.26100's version in the
# manifest) is checked after the download. A different build is a warning, not a stop (Microsoft services the SDK).
$script:Ttt2WinSdkBuild = '10.0.26100.15'
$script:Ttt2MsvcFolder = "msvc-$($script:Ttt2MsvcCrt)-sdk-$($script:Ttt2WinSdk)"
# The VC++ runtime a game built with this CRT needs at least (HKLM\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64).
$script:Ttt2VcRuntimeMin = [version]'14.44.0.0'

function Get-Ttt2ToolchainRoot {
    if ($env:TTT2_TOOLCHAIN_ROOT) { return $env:TTT2_TOOLCHAIN_ROOT }
    Join-Path $env:LOCALAPPDATA 'TTT2Native\toolchain'
}

# One line naming every pin (for tools.done and the prebuilt manifest).
function Get-Ttt2ToolchainPinText {
    $parts = foreach ($k in $script:Ttt2ToolchainPins.Keys) { "$k=$($script:Ttt2ToolchainPins[$k].version)" }
    (@($parts) + @("msvc-crt=$($script:Ttt2MsvcCrt)", "winsdk=$($script:Ttt2WinSdk)")) -join ' '
}

# Stops with a plain message when the drive holding $path has less than $gb free (a full disk made tar fail with only
# "failed (1)" on a player's PC, 21 October).
function Assert-Ttt2FreeSpace([string]$path, [double]$gb, [string]$what) {
    if ($gb -le 0) { return }
    try {
        $drive = [IO.Path]::GetPathRoot([IO.Path]::GetFullPath($path))
        $free = (New-Object IO.DriveInfo $drive).AvailableFreeSpace / 1GB
    } catch { return }
    if ($free -lt $gb) {
        throw ("Not enough disk space for {0}: {1:N1} GB free on {2}, about {3:N1} GB needed. Free some space on that drive and click Install tools again." -f $what, $free, $drive, $gb)
    }
}

# The portable Python setup-steps.ps1 installs before the compiler (%LOCALAPPDATA%\TTT2Native\tools\python), or $null.
function Get-Ttt2Python {
    foreach ($p in @($env:TTT2_PYTHON, (Join-Path $env:LOCALAPPDATA 'TTT2Native\tools\python\python.exe'))) {
        if ($p -and (Test-Path $p)) { return $p }
    }
    return $null
}

# A .tar.xz / .tar.gz unpacked by Python's tarfile (its own lzma: no xz program needed), the first $strip path parts
# dropped as tar's --strip-components does, with tarfile's 'data' filter (nothing outside $dest). Its output is returned;
# $LASTEXITCODE says how it went.
function Expand-Ttt2TarWithPython([string]$python, [string]$file, [string]$dest, [int]$strip) {
    $code = @'
import sys, tarfile
src, dest, strip = sys.argv[1], sys.argv[2], int(sys.argv[3])
def cut(name):
    return '/'.join(name.replace('\\', '/').split('/')[strip:])
with tarfile.open(src) as t:
    for m in t:
        m.name = cut(m.name)
        if not m.name:
            continue
        if m.islnk():
            m.linkname = cut(m.linkname)
        t.extract(m, dest, filter='data')
print('unpacked')
'@
    $script = Join-Path $env:TEMP 'ttt2-untar.py'
    [IO.File]::WriteAllText($script, $code)
    $saved = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { & $python -I $script $file $dest $strip 2>&1 | ForEach-Object { "$_" } }
    finally { $ErrorActionPreference = $saved }
}

function Get-Ttt2ToolchainFile([string]$url, [string]$file, [string]$sha256) {
    if (Test-Path $file) {
        if ((Get-FileHash $file -Algorithm SHA256).Hash -eq $sha256.ToUpper()) { return }
        Remove-Item $file -Force
    }
    Write-Host "Downloading $url"
    $tmp = "$file.part"
    $saved = $ProgressPreference
    $ProgressPreference = 'SilentlyContinue'
    try { Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing } finally { $ProgressPreference = $saved }
    $got = (Get-FileHash $tmp -Algorithm SHA256).Hash
    if ($got -ne $sha256.ToUpper()) {
        Remove-Item $tmp -Force
        throw "The download of $url doesn't match its pinned SHA-256 (got $got): not used."
    }
    Move-Item $tmp $file -Force
}

function Test-Ttt2MsvcLayout([string]$dir) {
    foreach ($f in 'crt\include\vector', 'crt\lib\x64\msvcprt.lib', 'crt\lib\x64\vcruntime.lib', 'sdk\include\um\windows.h',
                   'sdk\include\ucrt\stdio.h', 'sdk\include\shared\winerror.h', 'sdk\lib\um\x64\kernel32.lib', 'sdk\lib\ucrt\x64\ucrt.lib') {
        if (-not (Test-Path (Join-Path $dir $f))) { return $false }
    }
    $true
}

# Downloads and unpacks what's missing. Microsoft's parts only with -AcceptMicrosoftLicense (the player accepted
# Microsoft's license in the installer's screen).
function Install-Ttt2Toolchain([switch]$AcceptMicrosoftLicense) {
    $root = Get-Ttt2ToolchainRoot
    $downloads = Join-Path $root 'downloads'
    New-Item -ItemType Directory -Force $downloads | Out-Null
    foreach ($k in $script:Ttt2ToolchainPins.Keys) {
        $p = $script:Ttt2ToolchainPins[$k]
        $dest = Join-Path $root $p.folder
        if (Test-Path (Join-Path $dest 'ttt2-unpacked.txt')) { continue }
        $file = Join-Path $downloads ($p.url -replace '^.*/', '')
        if ($p.needGB) {
            # (The archive already here counts as space already taken.)
            $have = if (Test-Path $file) { (Get-Item $file).Length / 1GB } else { 0 }
            Assert-Ttt2FreeSpace $root ($p.needGB - $have) "the compiler ($k $($p.version))"
        }
        Get-Ttt2ToolchainFile $p.url $file $p.sha256
        Write-Host "Unpacking $k $($p.version)"
        if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
        New-Item -ItemType Directory -Force $dest | Out-Null
        if ($p.kind -eq 'zip') {
            Expand-Archive $file $dest -Force
            if ($p.inner) {   # (the archive's own top folder, moved up)
                Get-ChildItem (Join-Path $dest $p.inner) -Force | Move-Item -Destination $dest
                Remove-Item (Join-Path $dest $p.inner) -Recurse -Force
            }
        } else {
            # Windows' own tar.exe (bsdtar) reads .tar.gz everywhere and .tar.xz on Windows 11; Windows 10's has no xz
            # ("Can't initialize filter; unable to run program "xz -d -qq"", a player's PC, 21 October): then the
            # portable Python the setup installs first unpacks it (Expand-Ttt2TarWithPython).
            $flag = if ($p.kind -eq 'tar.xz') { '-xJf' } else { '-xzf' }
            # (tar's own words kept for the error: "failed (1)" alone told a player nothing, 21 October.)
            $saved = $ErrorActionPreference
            $ErrorActionPreference = 'Continue'
            try {
                if ($env:TTT2_TOOLCHAIN_TEST_NO_TAR) { $said = @('tar skipped for a test (TTT2_TOOLCHAIN_TEST_NO_TAR)'); $global:LASTEXITCODE = 1 }   # (Windows 10's tar, on a Windows 11 PC)
                else { $said = @(& "$env:SystemRoot\System32\tar.exe" $flag $file -C $dest "--strip-components=$($p.strip)" 2>&1 | ForEach-Object { "$_" }) }
            }
            finally { $ErrorActionPreference = $saved }
            $code = $LASTEXITCODE
            if ($code -ne 0) {
                $python = Get-Ttt2Python
                if ($python) {
                    Write-Host "Windows' tar couldn't unpack it ($((($said | Where-Object { $_ } | Select-Object -First 1)))): unpacking with Python instead (a few minutes)"
                    Remove-Item $dest -Recurse -Force -ErrorAction SilentlyContinue
                    New-Item -ItemType Directory -Force $dest | Out-Null
                    $said = @(Expand-Ttt2TarWithPython $python $file $dest $p.strip)
                    $code = $LASTEXITCODE
                }
            }
            if ($code -ne 0) {
                Remove-Item $dest -Recurse -Force -ErrorAction SilentlyContinue   # (half unpacked: gone; the checked archive stays for the next try)
                $tail = ($said | Where-Object { $_ } | Select-Object -Last 4) -join "`n  "
                throw "Unpacking $file failed ($code). It said:`n  $tail`nThe usual causes: the disk filled up, or an antivirus blocked the new .exe files (allow the folder $root, then click Install tools again)."
            }
        }
        Set-Content (Join-Path $dest 'ttt2-unpacked.txt') "$($p.version) $($p.sha256)"
        Remove-Item $file -Force   # (unpacked and recorded: the archive's 1 GB isn't kept)
    }
    $msvc = Join-Path $root $script:Ttt2MsvcFolder
    if (-not (Test-Ttt2MsvcLayout $msvc)) {
        if (-not $AcceptMicrosoftLicense) { throw "Microsoft's C++ runtime and Windows SDK need Microsoft's license accepted first." }
        $xwin = Join-Path (Join-Path $root $script:Ttt2ToolchainPins.xwin.folder) 'xwin.exe'
        Write-Host "Downloading Microsoft's C++ runtime $($script:Ttt2MsvcCrt) and Windows SDK $($script:Ttt2WinSdk) (from Microsoft, about 85 MB)"
        $saved = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        $said = @()
        try {
            $said = @(& $xwin --accept-license --log-level warn --cache-dir (Join-Path $root 'xwin-cache') --arch x86_64 `
                --crt-version $script:Ttt2MsvcCrt --sdk-version $script:Ttt2WinSdk `
                splat --disable-symlinks --preserve-ms-arch-notation --output $msvc 2>&1 | ForEach-Object { "$_" })
        } finally { $ErrorActionPreference = $saved }
        # (xwin's one version-folder symbolic link fails without Developer Mode, "A required privilege is not held (os error
        # 1314)", as an error a player took for a failed install, 21 October: those lines become one plain line; the
        # layout is checked below either way.)
        $symlink = ($said -join "`n") -match 'unable to symlink' -and ($said -join "`n") -match 'os error 1314'
        $said | Where-Object { -not ($symlink -and $_ -match 'failed to splat|RemoteException|^Caused by|^\s*\d+: |unable to symlink|required privilege|^\s*$') } |
            ForEach-Object { Write-Host $_ }
        if ($symlink) { Write-Host "(One shortcut link in the SDK folder needs Windows' Developer Mode; nothing uses it, so it is skipped.)" }
        # (Never another version in its place: the game's libraries were built against exactly these.)
        if (($said -join "`n") -match 'does not exist in the manifest|unable to locate SDK') {
            throw "The compiler's Microsoft part isn't available any more (C++ runtime $($script:Ttt2MsvcCrt), Windows SDK $($script:Ttt2WinSdk)): tell the BlueSpark team."
        }
        if (-not (Test-Ttt2MsvcLayout $msvc)) { throw "xwin didn't lay out Microsoft's C++ runtime and Windows SDK in $msvc." }
        $vsman = Get-ChildItem (Join-Path $root 'xwin-cache\dl') -Filter 'pkg_manifest_*.vsman' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime | Select-Object -Last 1
        if ($vsman -and ([IO.File]::ReadAllText($vsman.FullName) -match "`"id`":`"Win11SDK_$([regex]::Escape($script:Ttt2WinSdk))`",`"version`":`"([^`"]+)`"")) {
            if ($Matches[1] -ne $script:Ttt2WinSdkBuild) { Write-Warning "Windows SDK build $($Matches[1]) laid out (the release was built with $($script:Ttt2WinSdkBuild))." }
            Set-Content (Join-Path $msvc 'ttt2-sdk-build.txt') $Matches[1]
        }
        Remove-Item (Join-Path $root 'xwin-cache') -Recurse -Force -ErrorAction SilentlyContinue   # (laid out: the packages aren't kept)
    }
    Write-Host "Toolchain: $(Get-Ttt2ToolchainPinText)"
}

# The VC++ runtime the game runs on (the build is /MD): the installed one's version, or $null.
function Get-Ttt2VcRuntimeVersion {
    $r = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64' -ErrorAction SilentlyContinue
    if (-not $r -or -not $r.Installed) { return $null }
    try { [version]("$($r.Version)".TrimStart('v')) } catch { $null }
}
# Microsoft's vc_redist.x64.exe when the installed runtime is older than the pinned toolset's (one UAC prompt).
# Never shipped app-local.
function Install-Ttt2VcRuntime([string]$Downloads) {
    $have = Get-Ttt2VcRuntimeVersion
    if ($have -and $have -ge $script:Ttt2VcRuntimeMin) { Write-Host "VC++ runtime: $have"; return }
    $exe = Join-Path $Downloads 'vc_redist.x64.exe'
    $saved = $ProgressPreference
    $ProgressPreference = 'SilentlyContinue'
    try { Invoke-WebRequest -Uri 'https://aka.ms/vs/17/release/vc_redist.x64.exe' -OutFile $exe -UseBasicParsing } finally { $ProgressPreference = $saved }
    $sig = Get-AuthenticodeSignature $exe
    if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'O=Microsoft Corporation') { throw "vc_redist.x64.exe isn't signed by Microsoft: not run." }
    Write-Host 'Installing the Microsoft Visual C++ runtime (Windows asks for permission once)'
    $p = Start-Process $exe -ArgumentList '/install', '/quiet', '/norestart' -Verb RunAs -Wait -PassThru
    if ($p.ExitCode -notin 0, 1638, 3010) { throw "The Visual C++ runtime didn't install (exit $($p.ExitCode))." }
    Write-Host "VC++ runtime: $(Get-Ttt2VcRuntimeVersion)"
}

# The toolchain for this PowerShell: PATH (LLVM, CMake, Ninja, then Windows' own folders and whatever else was on it
# minus Visual Studio's), INCLUDE and LIB as a VS developer shell sets them, and VS's own settings cleared, so that
# nothing of an installed Visual Studio is picked up.
function Use-Ttt2Toolchain {
    $root = Get-Ttt2ToolchainRoot
    $p = $script:Ttt2ToolchainPins
    $llvm = Join-Path (Join-Path $root $p.llvm.folder) 'bin'
    $cmake = Join-Path (Join-Path $root $p.cmake.folder) 'bin'
    $ninja = Join-Path $root $p.ninja.folder
    $msvc = Join-Path $root $script:Ttt2MsvcFolder
    foreach ($need in (Join-Path $llvm 'clang++.exe'), (Join-Path $cmake 'cmake.exe'), (Join-Path $ninja 'ninja.exe')) {
        if (-not (Test-Path $need)) { throw "The toolchain is not installed ($need missing): run Install-Ttt2Toolchain." }
    }
    if (-not (Test-Ttt2MsvcLayout $msvc)) { throw "Microsoft's C++ runtime and Windows SDK are not installed ($msvc)." }
    foreach ($v in 'VCINSTALLDIR', 'VCToolsInstallDir', 'VCToolsVersion', 'VSINSTALLDIR', 'VCIDEInstallDir', 'DevEnvDir', 'VisualStudioVersion',
                   'WindowsSdkDir', 'WindowsSDKVersion', 'WindowsSdkBinPath', 'WindowsSdkVerBinPath', 'UCRTVersion', 'UniversalCRTSdkDir',
                   'ExtensionSdkDir', 'LIBPATH', 'TTT2_LLVM', 'VSCMD_ARG_TGT_ARCH', 'VSCMD_VER', 'Platform') {
        Remove-Item "Env:\$v" -ErrorAction SilentlyContinue
    }
    $kept = @($env:PATH -split ';' | Where-Object { $_ -and $_ -notmatch 'Microsoft Visual Studio|Windows Kits|\\LLVM\\|\\CMake\\' })
    $env:PATH = (@($llvm, $cmake, $ninja) + $kept) -join ';'
    $env:INCLUDE = (@('crt\include', 'sdk\include\ucrt', 'sdk\include\um', 'sdk\include\shared', 'sdk\include\winrt', 'sdk\include\cppwinrt') |
        ForEach-Object { Join-Path $msvc $_ }) -join ';'
    $env:LIB = (@('crt\lib\x64', 'sdk\lib\ucrt\x64', 'sdk\lib\um\x64') | ForEach-Object { Join-Path $msvc $_ }) -join ';'
    $env:TTT2_TOOLCHAIN_IN_USE = Get-Ttt2ToolchainPinText
    # (CMake's resource compiler and manifest tool: LLVM's, not the Windows Kits' rc.exe / mt.exe.)
    $env:RC = Join-Path $llvm 'llvm-rc.exe'
    Write-Host "Portable toolchain: $env:TTT2_TOOLCHAIN_IN_USE"
}
