/**
 * @file        system/guest_trace.h
 * @brief       What each guest thread is doing: with guest_thread_log, a periodic log of the
 *              guest's threads, the processor time each used and the kernel calls each made.
 *
 * @license     BSD 3-Clause License
 *              See LICENSE file in the project root for full license text.
 */

#pragma once

#include <atomic>
#include <cstdint>

struct PPCContext;

namespace rex::system {

// For a title's own diagnostics and for what it must make the same on a re-run of a frame:
// a function called on entry to every kernel export, with its name (a string literal) and the
// guest registers (its arguments), and again when it has returned (its results); and one
// called with every reading of the guest's time base, the host address the reading is
// returned to, which may give another value in its place. One of each, nullptr for none.
//
// The registers an export was called with, r3..r10, copied before the host function ran: the
// arguments the observer is handed with the second call (returned = true), by which time r3 holds
// the export's result and a pointer that was passed there is gone. nullptr when no observer was
// set at the first call (the registers are then all there is).
struct ExportArgs {
  uint32_t r[8];   // r3..r10 (the low 32 bits: the guest's addresses and values)
  bool valid = false;
};
using ExportObserver = void (*)(const char* name, ::PPCContext& ctx, bool returned, const ExportArgs* args);
using GuestTickObserver = uint64_t (*)(uint64_t ticks, void* return_address);
void SetExportObserver(ExportObserver observer);
// A kernel export's function by its registered name ("__imp__XamEnumerate"), nullptr if there is none: for a title's tests that call an export with a made
// context (the registry itself is not reachable from outside the runtime's library). The function takes the context and the guest memory base.
using ExportFunction = void (*)(::PPCContext& ctx, uint8_t* base);
ExportFunction FindExportByName(const char* name);
void SetGuestTickObserver(GuestTickObserver observer);

namespace detail {
extern std::atomic<bool> g_guest_trace_enabled;
extern std::atomic<ExportObserver> g_export_observer;
uint64_t ObserveGuestTick(uint64_t ticks, void* return_address);
void TraceExportCallSlow(const char* name, uint32_t lr, uint32_t sp);
void TraceExportReturnSlow();
}  // namespace detail

// Takes up the guest_thread_log setting. Called once a guest frame.
void RefreshGuestTraceSetting();

// Called by every kernel export on entry, with its name (a string literal), the guest address
// it returns to and the guest stack pointer, and again when it returns. Each costs one load
// when guest_thread_log is off.
inline void TraceExportCall(const char* name, uint64_t lr, uint32_t sp) {
  if (detail::g_guest_trace_enabled.load(std::memory_order_relaxed)) {
    detail::TraceExportCallSlow(name, uint32_t(lr), sp);
  }
}
inline void TraceExportReturn() {
  if (detail::g_guest_trace_enabled.load(std::memory_order_relaxed)) {
    detail::TraceExportReturnSlow();
  }
}

// (A template on the context so that this header needs no definition of it; hook.h's macro is the one caller.)
template <typename Ctx>
inline void ObserveExport(const char* name, Ctx& ctx, bool returned, ExportArgs& args) {
  if (ExportObserver observer = detail::g_export_observer.load(std::memory_order_relaxed)) {
    if (!returned) {
      args.r[0] = ctx.r3.u32;
      args.r[1] = ctx.r4.u32;
      args.r[2] = ctx.r5.u32;
      args.r[3] = ctx.r6.u32;
      args.r[4] = ctx.r7.u32;
      args.r[5] = ctx.r8.u32;
      args.r[6] = ctx.r9.u32;
      args.r[7] = ctx.r10.u32;
      args.valid = true;
    }
    observer(name, ctx, returned, args.valid ? &args : nullptr);
  }
}

}  // namespace rex::system
