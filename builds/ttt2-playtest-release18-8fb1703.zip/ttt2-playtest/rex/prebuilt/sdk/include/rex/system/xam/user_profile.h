/**
 ******************************************************************************
 * Xenia : Xbox 360 Emulator Research Project                                 *
 ******************************************************************************
 * Copyright 2022 Ben Vanik. All rights reserved.                             *
 * Released under the BSD license - see LICENSE in the root for more details. *
 ******************************************************************************
 *
 * @modified    Tom Clay, 2026 - Adapted for ReXGlue runtime
 */

#pragma once

#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

#include <fmt/format.h>

#include <rex/memory.h>
#include <rex/stream.h>
#include <rex/system/xtypes.h>

namespace rex::system {
class KernelState;
}

namespace rex {
namespace system {
namespace xam {

// --live_signin: user 0 is signed into Xbox Live (state 2, an online XUID, the privileges, a link). Defined in xam_user.cpp.
bool LiveSignedIn();
uint64_t LiveOnlineXuid(uint64_t offline_xuid);   // 0x0009xxxxxxxxxxxx form of the profile's XUID
void SetLiveIdentity(uint64_t online_xuid, const std::string& gamertag);   // a backend overrides both
const std::string& LiveGamertag();

// (Patch 62) --live_guest_signin: users 1-3 signed in as Live guests of user 0 when the title asks (XamShowSigninUI, after a
// confirm box). Defined in xam_user.cpp (the box in xam_ui.cpp). Nothing of a guest's is saved: no content, storage, achievements
// or profile settings under user 0's XUID.
bool GuestSigninOn();                          // live_signin and live_guest_signin
bool GuestSigninAuto();                        // tests: the box answered Yes at once
bool IsGuestUser(uint32_t user_index);         // user 1-3, signed in as a guest
uint64_t GuestXuid(uint32_t user_index);       // user 0's online XUID | (n << 54)
int32_t GuestIndexForXuid(uint64_t xuid);      // the signed-in guest with that XUID, or -1
std::string GuestName(uint32_t user_index);    // "<user 0's name>(n)", 15 characters at most
uint32_t GuestMask();                          // bit n: user n is a guest (0 with the switch off)
uint32_t SignedInMask();                       // 1 | GuestMask(): XN_SYS_SIGNINCHANGED's parameter
void NoteUnsignedAsked(uint32_t user_index);
int32_t LastUnsignedAsked();
void SetSigninCandidate(uint32_t user_index);   // the game's code: the next XamShowSigninUI is for this user (first; else the last unsigned user asked)
int32_t TakeSigninCandidate();
void SignInGuest(uint32_t user_index);
void SignOutGuest(uint32_t user_index, const char* why);
void SignOutGuests(const char* why);           // (the game's own code, at the online menus' exit)
void TraceUser(const char* fn, uint32_t user_index, const std::string& answer);   // --live_user_trace
bool GuestBoxOpen();
bool GuestBoxPad(uint32_t user_index, uint16_t buttons);   // a pad's buttons while the box is up: true = hide them from the title
bool StartGuestSignin(uint32_t user_index);

struct X_USER_PROFILE_SETTING_DATA {
  // UserProfile::Setting::Type. Appears to be 8-in-32 field, and the upper 24
  // are not always zeroed by the game.
  uint8_t type;
  uint8_t unk_1[3];
  rex::be<uint32_t> unk_4;
  // TODO(sabretooth): not sure if this is a union, but it seems likely.
  // Haven't run into cases other than "binary data" yet.
  union {
    rex::be<int32_t> s32;
    rex::be<int64_t> s64;
    rex::be<uint32_t> u32;
    rex::be<double> f64;
    struct {
      rex::be<uint32_t> size;
      rex::be<uint32_t> ptr;
    } unicode;
    rex::be<float> f32;
    struct {
      rex::be<uint32_t> size;
      rex::be<uint32_t> ptr;
    } binary;
    rex::be<uint64_t> filetime;
  };
};
static_assert_size(X_USER_PROFILE_SETTING_DATA, 16);

struct X_USER_PROFILE_SETTING {
  rex::be<uint32_t> from;
  rex::be<uint32_t> unk04;
  union {
    rex::be<uint32_t> user_index;
    rex::be<uint64_t> xuid;
  };
  rex::be<uint32_t> setting_id;
  rex::be<uint32_t> unk14;
  union {
    uint8_t data_bytes[sizeof(X_USER_PROFILE_SETTING_DATA)];
    X_USER_PROFILE_SETTING_DATA data;
  };
};
static_assert_size(X_USER_PROFILE_SETTING, 40);

class UserProfile {
 public:
  class SettingByteStream : public stream::ByteStream {
   public:
    SettingByteStream(uint32_t ptr, uint8_t* data, size_t data_length, size_t offset = 0)
        : stream::ByteStream(data, data_length, offset), ptr_(ptr) {}

    uint32_t ptr() const { return static_cast<uint32_t>(ptr_ + offset()); }

   private:
    uint32_t ptr_;
  };
  struct Setting {
    enum class Type {
      CONTENT = 0,
      INT32 = 1,
      INT64 = 2,
      DOUBLE = 3,
      WSTRING = 4,
      FLOAT = 5,
      BINARY = 6,
      DATETIME = 7,
      UNSET = 0xFF,
    };
    union Key {
      uint32_t value;
      struct {
        uint32_t id : 14;
        uint32_t unk : 2;
        uint32_t size : 12;
        uint32_t type : 4;
      };
    };
    uint32_t setting_id;
    Type type;
    size_t size;
    bool is_set;
    uint32_t loaded_title_id;
    Setting(uint32_t setting_id, Type type, size_t size, bool is_set)
        : setting_id(setting_id), type(type), size(size), is_set(is_set), loaded_title_id(0) {}
    virtual void Append(X_USER_PROFILE_SETTING_DATA* data, SettingByteStream* stream) {
      (void)stream;
      data->type = static_cast<uint8_t>(type);
    }
    virtual std::vector<uint8_t> Serialize() const { return std::vector<uint8_t>(); }
    virtual void Deserialize(std::vector<uint8_t>) {}
    bool is_title_specific() const { return (setting_id & 0x3F00) == 0x3F00; }
  };
  struct Int32Setting : public Setting {
    Int32Setting(uint32_t setting_id, int32_t value)
        : Setting(setting_id, Type::INT32, 4, true), value(value) {}
    int32_t value;
    void Append(X_USER_PROFILE_SETTING_DATA* data, SettingByteStream* stream) override {
      Setting::Append(data, stream);
      data->s32 = value;
    }
  };
  struct Int64Setting : public Setting {
    Int64Setting(uint32_t setting_id, int64_t value)
        : Setting(setting_id, Type::INT64, 8, true), value(value) {}
    int64_t value;
    void Append(X_USER_PROFILE_SETTING_DATA* data, SettingByteStream* stream) override {
      Setting::Append(data, stream);
      data->s64 = value;
    }
  };
  struct DoubleSetting : public Setting {
    DoubleSetting(uint32_t setting_id, double value)
        : Setting(setting_id, Type::DOUBLE, 8, true), value(value) {}
    double value;
    void Append(X_USER_PROFILE_SETTING_DATA* data, SettingByteStream* stream) override {
      Setting::Append(data, stream);
      data->f64 = value;
    }
  };
  struct UnicodeSetting : public Setting {
    UnicodeSetting(uint32_t setting_id, const std::u16string& value)
        : Setting(setting_id, Type::WSTRING, 8, true), value(value) {}
    std::u16string value;
    void Append(X_USER_PROFILE_SETTING_DATA* data, SettingByteStream* stream) override {
      Setting::Append(data, stream);
      if (value.empty()) {
        data->unicode.size = 0;
        data->unicode.ptr = 0;
      } else {
        size_t count = value.size() + 1;
        size_t size = 2 * count;
        assert_true(size <= std::numeric_limits<uint32_t>::max());
        data->unicode.size = static_cast<uint32_t>(size);
        data->unicode.ptr = stream->ptr();
        auto buffer = reinterpret_cast<uint16_t*>(&stream->data()[stream->offset()]);
        stream->Advance(size);
        memory::copy_and_swap(buffer, (uint16_t*)value.data(), count);
      }
    }
  };
  struct FloatSetting : public Setting {
    FloatSetting(uint32_t setting_id, float value)
        : Setting(setting_id, Type::FLOAT, 4, true), value(value) {}
    float value;
    void Append(X_USER_PROFILE_SETTING_DATA* data, SettingByteStream* stream) override {
      Setting::Append(data, stream);
      data->f32 = value;
    }
  };
  struct BinarySetting : public Setting {
    BinarySetting(uint32_t setting_id) : Setting(setting_id, Type::BINARY, 8, false), value() {}
    BinarySetting(uint32_t setting_id, const std::vector<uint8_t>& value)
        : Setting(setting_id, Type::BINARY, 8, true), value(value) {}
    std::vector<uint8_t> value;
    void Append(X_USER_PROFILE_SETTING_DATA* data, SettingByteStream* stream) override {
      Setting::Append(data, stream);
      if (value.empty()) {
        data->binary.size = 0;
        data->binary.ptr = 0;
      } else {
        size_t size = value.size();
        assert_true(size <= std::numeric_limits<uint32_t>::max());
        data->binary.size = static_cast<uint32_t>(size);
        data->binary.ptr = stream->ptr();
        stream->Write(value.data(), size);
      }
    }
    std::vector<uint8_t> Serialize() const override {
      return std::vector<uint8_t>(value.data(), value.data() + value.size());
    }
    void Deserialize(std::vector<uint8_t> data) override {
      value = data;
      is_set = true;
    }
  };
  struct DateTimeSetting : public Setting {
    DateTimeSetting(uint32_t setting_id, int64_t value)
        : Setting(setting_id, Type::DATETIME, 8, true), value(value) {}
    int64_t value;
    void Append(X_USER_PROFILE_SETTING_DATA* data, SettingByteStream* stream) override {
      Setting::Append(data, stream);
      data->filetime = value;
    }
  };

  UserProfile();

  uint64_t xuid() const { return xuid_; }
  std::string name() const { return LiveSignedIn() && !LiveGamertag().empty() ? LiveGamertag() : name_; }
  uint32_t signin_state() const { return LiveSignedIn() ? 2 : 1; }
  uint32_t type() const { return 1 | 2; /* local | online profile? */ }

  void set_kernel_state(KernelState* ks) { kernel_state_ = ks; }

  void AddSetting(std::unique_ptr<Setting> setting);
  Setting* GetSetting(uint32_t setting_id);

 private:
  uint64_t xuid_;
  std::string name_;
  std::vector<std::unique_ptr<Setting>> setting_list_;
  std::unordered_map<uint32_t, Setting*> settings_;
  KernelState* kernel_state_ = nullptr;

  void LoadSetting(UserProfile::Setting*);
  void SaveSetting(UserProfile::Setting*);
};

}  // namespace xam
}  // namespace system
}  // namespace rex

// fmt formatter for UserProfile::Setting::Type
template <>
struct fmt::formatter<rex::system::xam::UserProfile::Setting::Type> : fmt::formatter<int> {
  template <typename FormatContext>
  auto format(rex::system::xam::UserProfile::Setting::Type t, FormatContext& ctx) const {
    return fmt::formatter<int>::format(static_cast<int>(t), ctx);
  }
};
