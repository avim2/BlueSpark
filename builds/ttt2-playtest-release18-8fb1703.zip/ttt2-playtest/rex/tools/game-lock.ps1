# The game lock, v2 (docs/GAME_LOCK_RULES_20261102.md): which games may run together on this PC, whichever clone starts them.
#
#   Exclusive: one holder and no other game. With -Quiet no build starts either (and it waits for the builds running). For
#              timing numbers, the live Worker, two PCs, UPnP, real devices, the window in front, the player's path.
#   Shared:    several holders and builds, up to the PC's limit of games. For isolated runs whose verdicts hold under any load.
#   Owner:     the owner's Play (Start Here): exclusive, first in line, and it sets the stop flag: the shared tests' games are
#              stopped (each take starts a small watcher for that, below). Exclusive holders aren't stopped; Play waits for them.
#
# One file, %USERPROFILE%\ttt2-game.lock, read and written under a named mutex. A waiting exclusive keeps new shared takes out, so
# measurements don't starve. A holder is a process and its games, by id and start time (ids are used again); a holder with none
# of them left is cleared. A script started by one that holds the lock (runs.ps1 starts autotest-windows.ps1, which starts
# run-windows.ps1) sees that through the environment and neither waits nor releases.
#
# The file keeps the old fields (clone, pid, started, taken, others) naming a live holder and everything else with it, so a clone
# with the old script (or the fast client's app, gamestart.cpp) sees a live lock and waits; an old-style file is read as exclusive.
#
# Dot-source it for the functions:
#   . "$PSScriptRoot\game-lock.ps1"            (from rex\tools; "$PSScriptRoot\tools\..." from rex)
#   $mine = Take-GameLock $rex -Shared -Purpose 'sync, frame-driven'      (or -Exclusive [-Quiet]; with neither: exclusive)
#   try { ... } finally { if ($mine) { Release-GameLock } }
# -Games 2 for a pair (a pair counts as 2 games). -NoWait: refused takes throw, for callers that never wait.
# Or run it:  game-lock.ps1 show | take | release
#
# Also here: which game is this clone's (rex\out\game-pid.txt, written by run-windows.ps1), so
# that a script stops the game it started and never every ttt2 process.
param([string]$Action, [string]$HoldId)

$script:GameLockFile = Join-Path $env:USERPROFILE 'ttt2-game.lock'
$script:GameLockScript = $PSCommandPath
$script:GameLockMutexName = 'Global\ttt2-game-lock'
# (Every take, takeover, hand-over, added game, refusal, stop and release, one line each: the time, what, the clone's folder, the
# script, the process; so that a game that ends with no trace can be placed. The lead's order of 24 Oct, 576aa5c, after two games
# ended together on 23 Oct with nothing to say who. 1 MB, then one older file kept.)
# (The user's own local app data, not $env:LOCALAPPDATA: a test that points that at a scratch folder still logs here.)
$script:GameLockLog = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'TTT2Native\game-lock.log'

# How many games may share this PC: 3 on the owner's (RTX 4060, 32 GB), 4 on the helper's (RX 7900 XTX, 64 GB); TTT2_GAME_LOCK_LIMIT overrides.
function Get-GameLockLimit {
    if ($env:TTT2_GAME_LOCK_LIMIT) { return [int]$env:TTT2_GAME_LOCK_LIMIT }
    try { if ((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory -ge 48GB) { return 4 } } catch {}
    return 3
}

function Write-GameLockLog([string]$What, [string]$Clone, [int]$Process, [string]$Note = '') {
    try {
        # (The outermost script that isn't this one: run-windows.ps1, a test script; this one when it was run by itself.)
        $caller = (Get-PSCallStack | Where-Object { $_.ScriptName -and $_.ScriptName -notlike '*\game-lock.ps1' } |
                   Select-Object -Last 1).ScriptName
        if (-not $caller) { $caller = $PSCommandPath }
        $dir = Split-Path $script:GameLockLog -Parent
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force $dir | Out-Null }
        if ((Test-Path -LiteralPath $script:GameLockLog) -and (Get-Item -LiteralPath $script:GameLockLog).Length -gt 1MB) {
            Move-Item -Force -LiteralPath $script:GameLockLog ($script:GameLockLog + '.old')
        }
        $line = '{0}  {1,-9} {2}  {3}  process {4} (from {5}){6}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'), $What, $Clone, $caller, $Process, $PID, $(if ($Note) { "  $Note" })
        Add-Content -LiteralPath $script:GameLockLog -Value $line -Encoding UTF8
    } catch {}   # (the log never stops a run)
}

# Runs the block holding the mutex. Open to every user: a game or script of ours may run elevated. If it can't be had (it never
# should), the block runs anyway: the lock never stops a player's Play.
function Invoke-UnderGameLockMutex([scriptblock]$Body) {
    $mutex = $null; $held = $false
    try {
        try {
            $security = New-Object Security.AccessControl.MutexSecurity
            $everyone = New-Object Security.Principal.SecurityIdentifier([Security.Principal.WellKnownSidType]::WorldSid, $null)
            $security.AddAccessRule((New-Object Security.AccessControl.MutexAccessRule($everyone, [Security.AccessControl.MutexRights]::FullControl, [Security.AccessControl.AccessControlType]::Allow)))
            $created = $false
            $mutex = New-Object Threading.Mutex($false, $script:GameLockMutexName, [ref]$created, $security)
        } catch { $mutex = [Threading.Mutex]::OpenExisting($script:GameLockMutexName) }
        try { $held = $mutex.WaitOne(10000) } catch [Threading.AbandonedMutexException] { $held = $true }
    } catch { $held = $false }
    try { & $Body } finally {
        if ($held) { try { $mutex.ReleaseMutex() } catch {} }
        if ($mutex) { try { $mutex.Dispose() } catch {} }
    }
}

function Get-GameLock {
    if (-not (Test-Path -LiteralPath $script:GameLockFile)) { return $null }
    try { return Get-Content -LiteralPath $script:GameLockFile -Raw -ErrorAction Stop | ConvertFrom-Json } catch { return $null }
}

# Whether the process a lock names is still there (the same one: by its start time), or any of
# the others it lists (the pair mode: the script that started two games and both games; the
# lock is live while any of them is, so that a pair script that dies leaves no two games running
# with no live holder).
function Test-GameProcessLive([int]$Id, [long]$Started) {
    if (-not $Id) { return $false }
    $p = Get-Process -Id $Id -ErrorAction SilentlyContinue
    if (-not $p) { return $false }
    # (28 Oct: a reused pid may belong to another user's process, whose start time cannot be read: SearchFilterHost took a dead
    # test's pid and the lock read as live for hours while the owner's Play waited on it. Our games are our own processes,
    # always readable: an unreadable start time means the process is not ours, so the lock entry is dead. Unless it is named
    # as ours (the main line, 4.5): a game or script of ours run elevated can't be read either, and must not read as dead.)
    try { return $p.StartTime.ToFileTimeUtc() -eq $Started } catch { return ($p.ProcessName -in @('ttt2', 'powershell', 'pwsh')) }
}
function Test-GameLockLive($lock) {
    if (-not $lock -or -not $lock.pid) { return $false }
    if (Test-GameProcessLive ([int]$lock.pid) ([long]$lock.started)) { return $true }
    foreach ($other in @($lock.others)) {
        if ($other -and (Test-GameProcessLive ([int]$other.pid) ([long]$other.started))) { return $true }
    }
    return $false
}

function Test-GameLockHoldLive($hold) {
    if (-not $hold) { return $false }
    if (Test-GameProcessLive ([int]$hold.pid) ([long]$hold.started)) { return $true }
    foreach ($g in @($hold.games)) { if ($g -and (Test-GameProcessLive ([int]$g.pid) ([long]$g.started))) { return $true } }
    return $false
}

# The file as the state: holds with no live process cleared, an old-style file read as an exclusive holder. Call under the mutex.
function Read-GameLockState {
    $state = [pscustomobject]@{ exclusive = $null; shared = @(); waiting = $null; stop = $null; builds = @() }
    $raw = Get-GameLock
    if (-not $raw) { return $state }
    if (-not $raw.v) {
        if ($raw.pid) {
            $state.exclusive = [pscustomobject]@{ id = 'old'; clone = $raw.clone; pid = [int]$raw.pid; started = [long]$raw.started; taken = $raw.taken; purpose = '(an old-style lock)'; quiet = $false; owner = $false; want = 1; games = @($raw.others | Where-Object { $_ }) }
        }
    } else {
        $state.exclusive = $raw.exclusive; $state.shared = @($raw.shared | Where-Object { $_ }); $state.waiting = $raw.waiting
        $state.stop = $raw.stop; $state.builds = @($raw.builds | Where-Object { $_ })
    }
    if ($state.exclusive -and -not (Test-GameLockHoldLive $state.exclusive)) {
        Write-GameLockLog 'takeover' $state.exclusive.clone ([int]$state.exclusive.pid) 'a dead exclusive holder cleared'
        $state.exclusive = $null
    }
    foreach ($h in @($state.shared | Where-Object { -not (Test-GameLockHoldLive $_) })) { Write-GameLockLog 'takeover' $h.clone ([int]$h.pid) 'a dead shared holder cleared' }
    $state.shared = @($state.shared | Where-Object { Test-GameLockHoldLive $_ })
    if ($state.waiting -and -not (Test-GameLockHoldLive $state.waiting)) { $state.waiting = $null }
    $state.builds = @($state.builds | Where-Object { Test-GameLockHoldLive $_ })
    if (-not $state.exclusive -and -not $state.shared.Count -and -not $state.waiting) { $state.stop = $null }
    return $state
}

# Writes the state whole (a temporary file put in the old one's place, so a reader without the mutex never sees half), or removes
# the file when nothing is left. The old fields: the exclusive holder or the first shared one, with everything else as "others".
function Write-GameLockState($state) {
    $holds = @(@($state.exclusive) + @($state.shared) | Where-Object { $_ })
    if (-not $holds.Count -and -not $state.waiting -and -not $state.builds.Count) {
        Remove-Item -LiteralPath $script:GameLockFile -Force -ErrorAction SilentlyContinue
        return
    }
    $first = if ($holds.Count) { $holds[0] } else { $state.waiting }
    $others = @()
    foreach ($h in $holds) {
        if ($h.id -ne $first.id) { $others += [pscustomobject]@{ pid = [int]$h.pid; started = [long]$h.started } }
        foreach ($g in @($h.games | Where-Object { $_ })) { $others += [pscustomobject]@{ pid = [int]$g.pid; started = [long]$g.started } }
    }
    $text = [pscustomobject]@{
        v = 2
        clone = "$($first.clone)"; pid = if ($first) { [int]$first.pid } else { 0 }; started = if ($first) { [long]$first.started } else { 0 }; taken = "$($first.taken)"; others = @($others)
        exclusive = $state.exclusive; shared = @($state.shared); waiting = $state.waiting; stop = $state.stop; builds = @($state.builds)
    } | ConvertTo-Json -Compress -Depth 6
    $temp = "$($script:GameLockFile).$PID.tmp"
    [IO.File]::WriteAllText($temp, $text, (New-Object Text.UTF8Encoding($false)))
    foreach ($try in 1..20) {
        try {
            if (Test-Path -LiteralPath $script:GameLockFile) { [IO.File]::Replace($temp, $script:GameLockFile, [NullString]::Value) } else { [IO.File]::Move($temp, $script:GameLockFile) }
            break
        } catch { if ($try -eq 20) { throw }; Start-Sleep -Milliseconds 100 }
    }
}

function New-GameLockHold([string]$Clone, [int]$Holder, [string]$Purpose, [bool]$Quiet, [bool]$Owner, [int]$Games) {
    [pscustomobject]@{
        id = [guid]::NewGuid().ToString('N'); clone = $Clone; pid = $Holder; started = (Get-Process -Id $Holder -ErrorAction Stop).StartTime.ToFileTimeUtc()
        taken = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'); purpose = $Purpose; quiet = $Quiet; owner = $Owner; want = $Games; games = @()
    }
}

# The games shared holders have or said they'd start (-Games).
function Get-GameLockSharedGames($state) {
    $n = 0
    foreach ($h in @($state.shared)) {
        $live = @($h.games | Where-Object { $_ -and (Test-GameProcessLive ([int]$_.pid) ([long]$_.started)) }).Count
        $n += [Math]::Max([int]$h.want, $live)
    }
    return $n
}

function Get-GameLockHoldText($hold) {
    if (-not $hold) { return '' }
    "process $($hold.pid) since $($hold.taken), from $($hold.clone)$(if ($hold.purpose) { " ($($hold.purpose))" })"
}

# This process's hold (its own, or the one the script that started it took).
function Find-OwnGameLockHold($state) {
    foreach ($h in @(@($state.exclusive) + @($state.shared) | Where-Object { $_ })) {
        if ($env:TTT2_GAME_LOCK_ID -and $h.id -eq $env:TTT2_GAME_LOCK_ID) { return $h }
        if ([int]$h.pid -eq $PID) { return $h }
        if ($h.id -eq 'old' -and $env:TTT2_GAME_LOCK -and "$($h.pid)" -eq $env:TTT2_GAME_LOCK) { return $h }
    }
    return $null
}

# Takes the lock for this process. Returns $true if it was taken here (and is to be released here), $false if a script that started
# this one has it already. Waits, with a message, unless -NoWait (then a refusal throws, its text saying who has it).
function Take-GameLock([string]$Clone, [switch]$Shared, [switch]$Exclusive, [switch]$Quiet, [switch]$Owner, [string]$Purpose = '', [int]$Games = 1, [switch]$NoWait) {
    if ($Shared -and ($Exclusive -or $Quiet -or $Owner)) { throw 'Take-GameLock: -Shared or -Exclusive, not both.' }
    $result = $null; $reason = ''; $said = $null; $refusedLogged = $false
    while ($null -eq $result) {
        Invoke-UnderGameLockMutex {
            $state = Read-GameLockState
            $own = Find-OwnGameLockHold $state
            if ($own) {
                $script:gameLockTakeResult = ([int]$own.pid -eq $PID)   # (taken here before: as the old lock, still ours to release)
                return
            }
            $script:gameLockTakeResult = $null
            $script:gameLockTakeReason = ''
            if ($Shared) {
                $limit = Get-GameLockLimit
                if ($state.exclusive) { $script:gameLockTakeReason = "exclusive: $(Get-GameLockHoldText $state.exclusive)" }
                elseif ($state.waiting) { $script:gameLockTakeReason = "an exclusive is waiting: $(Get-GameLockHoldText $state.waiting)" }
                elseif ($state.stop) { $script:gameLockTakeReason = 'the owner''s Play is starting' }
                elseif ((Get-GameLockSharedGames $state) + $Games -gt $limit) { $script:gameLockTakeReason = "this PC's limit of $limit shared games is reached" }
                else {
                    $hold = New-GameLockHold $Clone $PID $Purpose $false $false $Games
                    $state.shared = @($state.shared) + @($hold)
                    Write-GameLockState $state
                    $env:TTT2_GAME_LOCK = "$PID"; $env:TTT2_GAME_LOCK_ID = $hold.id
                    Write-GameLockLog 'take' $Clone $PID "shared, $Games game(s): $Purpose"
                    $script:gameLockTakeResult = $true
                }
            } else {
                $blocked = ''
                if ($state.exclusive) { $blocked = "exclusive: $(Get-GameLockHoldText $state.exclusive)" }
                elseif ($state.shared.Count) { $blocked = "$($state.shared.Count) shared holder(s): $(Get-GameLockHoldText $state.shared[0])" }
                elseif ($Quiet -and $state.builds.Count) { $blocked = "a build: process $($state.builds[0].pid), from $($state.builds[0].clone)" }
                $waitingOther = $state.waiting -and [int]$state.waiting.pid -ne $PID
                if (($waitingOther -and -not $Owner) -or ($waitingOther -and $state.waiting.owner)) {
                    if (-not $blocked) { $blocked = "another exclusive is first: $(Get-GameLockHoldText $state.waiting)" }
                }
                if ($blocked) {
                    if (-not $NoWait) {
                        # (One waiting exclusive; the owner's Play takes that place from any other, which then waits behind it.)
                        if (-not $state.waiting -or ($Owner -and $waitingOther -and -not $state.waiting.owner)) {
                            $state.waiting = New-GameLockHold $Clone $PID $Purpose ([bool]$Quiet) ([bool]$Owner) $Games
                        }
                        if ($Owner -and $state.shared.Count -and -not $state.stop) {
                            $state.stop = [pscustomobject]@{ by = $Clone; since = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') }
                            Write-GameLockLog 'stop flag' $Clone $PID 'the owner''s Play: shared tests stop'
                        }
                        Write-GameLockState $state
                    }
                    $script:gameLockTakeReason = $blocked
                } else {
                    $hold = New-GameLockHold $Clone $PID $Purpose ([bool]$Quiet) ([bool]$Owner) $Games
                    $state.exclusive = $hold
                    if ($state.waiting -and [int]$state.waiting.pid -eq $PID) { $state.waiting = $null }
                    $state.stop = $null
                    Write-GameLockState $state
                    $env:TTT2_GAME_LOCK = "$PID"; $env:TTT2_GAME_LOCK_ID = $hold.id
                    Write-GameLockLog 'take' $Clone $PID "exclusive$(if ($Quiet) { ', quiet' })$(if ($Owner) { ', the owner''s Play' }): $Purpose"
                    $script:gameLockTakeResult = $true
                }
            }
        }
        $result = $script:gameLockTakeResult
        if ($null -ne $result) { break }
        $reason = $script:gameLockTakeReason
        if (-not $refusedLogged) {
            Write-GameLockLog $(if ($NoWait -or $Shared) { 'refused' } else { 'waiting' }) $Clone $PID "$(if ($Shared) { 'shared' } else { 'exclusive' }): $reason"
            $refusedLogged = $true
        }
        if ($NoWait) { throw "The game lock refuses this run. $reason. Not waiting: try again later." }
        if (-not $said -or ((Get-Date) - $said).TotalSeconds -ge 30) {
            Write-Host "Waiting for the game lock: $reason" -ForegroundColor Yellow
            $said = Get-Date
        }
        Start-Sleep -Seconds 2
    }
    if ($result -and $Shared) { Start-GameLockStopWatch }
    return $result
}

# A shared holder's small watcher: a process of its own, so it works whatever the script is doing and whatever became of it.
function Start-GameLockStopWatch {
    try {
        Start-Process powershell -WindowStyle Hidden -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$script:GameLockScript`"", 'watch-stop', $env:TTT2_GAME_LOCK_ID) | Out-Null
    } catch { Write-GameLockLog 'no watch' '' $PID "$($_.Exception.Message)" }
}

function Invoke-GameLockStopWatch([string]$Id) {
    while ($true) {
        Start-Sleep -Seconds 1
        $raw = Get-GameLock
        if (-not $raw) { return }
        $hold = @($raw.shared | Where-Object { $_ -and $_.id -eq $Id }) | Select-Object -First 1
        if (-not $hold) { return }
        if (-not $raw.stop) { continue }
        # (Only this holder's own games, by id and start time; its script sees its game gone.)
        foreach ($g in @(@($hold.games | Where-Object { $_ }) + @([pscustomobject]@{ pid = $hold.pid; started = $hold.started }))) {
            $p = Get-Process -Id ([int]$g.pid) -ErrorAction SilentlyContinue
            if ($p -and $p.ProcessName -eq 'ttt2' -and (Test-GameProcessLive ([int]$g.pid) ([long]$g.started))) {
                Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
                try { $p.WaitForExit(5000) | Out-Null } catch {}
            }
        }
        Invoke-UnderGameLockMutex {
            $state = Read-GameLockState
            $state.shared = @($state.shared | Where-Object { $_.id -ne $Id })
            Write-GameLockState $state
        }
        Write-GameLockLog 'stopped' $hold.clone ([int]$hold.pid) "stopped for the owner's Play: $($hold.purpose)"
        try { Set-Content -LiteralPath (Join-Path (Split-Path $script:GameLockLog -Parent) "game-lock-stopped-$Id.txt") -Value 'stopped for the owner''s Play' } catch {}
        return
    }
}

# For a shared run's script, after its game has gone: whether Play stopped it (it says so, and tries again later).
function Test-GameLockStoppedForPlay {
    if (-not $env:TTT2_GAME_LOCK_ID) { return $false }
    $file = Join-Path (Split-Path $script:GameLockLog -Parent) "game-lock-stopped-$($env:TTT2_GAME_LOCK_ID).txt"
    if (-not (Test-Path -LiteralPath $file)) { return $false }
    Remove-Item -LiteralPath $file -Force -ErrorAction SilentlyContinue
    return $true
}

function Release-GameLock {
    Invoke-UnderGameLockMutex {
        $state = Read-GameLockState
        $own = Find-OwnGameLockHold $state
        if ($state.waiting -and [int]$state.waiting.pid -eq $PID) { $state.waiting = $null }
        if ($own -and ([int]$own.pid -eq $PID -or $own.id -eq $env:TTT2_GAME_LOCK_ID)) {
            if ($state.exclusive -and $state.exclusive.id -eq $own.id) { $state.exclusive = $null }
            $state.shared = @($state.shared | Where-Object { $_.id -ne $own.id })
            Write-GameLockLog 'release' $own.clone $PID
        }
        Write-GameLockState $state
    }
    if ($env:TTT2_GAME_LOCK -eq "$PID") { $env:TTT2_GAME_LOCK = $null; $env:TTT2_GAME_LOCK_ID = $null }
}

# Adds a process (a game this script, or the script that started it, started) to the hold: the lock stays live while that
# process is, even after the script is gone (the pair mode), and a stop for Play knows it.
function Add-GameLockProcess([int]$Id) {
    $p = Get-Process -Id $Id -ErrorAction SilentlyContinue
    if (-not $p) { return }
    Invoke-UnderGameLockMutex {
        $state = Read-GameLockState
        $own = Find-OwnGameLockHold $state
        if (-not $own) { return }
        if (@($own.games | Where-Object { $_ -and [int]$_.pid -eq $Id }).Count) { return }
        $own.games = @($own.games | Where-Object { $_ }) + @([pscustomobject]@{ pid = $Id; started = $p.StartTime.ToFileTimeUtc() })
        Write-GameLockState $state
        Write-GameLockLog 'add game' $own.clone $Id
    }
}

# Hands a lock this process has to another process (the game itself, when it is started by
# hand: the lock is then held for as long as the game runs).
function Move-GameLock([int]$Holder) {
    $p = Get-Process -Id $Holder -ErrorAction Stop
    Invoke-UnderGameLockMutex {
        $state = Read-GameLockState
        $own = Find-OwnGameLockHold $state
        if (-not $own -or [int]$own.pid -ne $PID) { return }
        $own.pid = $Holder; $own.started = $p.StartTime.ToFileTimeUtc(); $own.games = @()
        Write-GameLockState $state
        Write-GameLockLog 'hand to' $own.clone $Holder
    }
    $env:TTT2_GAME_LOCK = $null; $env:TTT2_GAME_LOCK_ID = $null
}

# A build: runs freely in its own folder, but waits while a -Quiet exclusive is held or waiting, and a -Quiet take waits for it.
# (A build a -Quiet holder started itself, build-measure.ps1, goes on.) Never stops a build for the lock's own sake.
function Enter-GameLockBuild([string]$Clone) {
    $said = $null
    try {
        while ($true) {
            Invoke-UnderGameLockMutex {
                $state = Read-GameLockState
                $own = Find-OwnGameLockHold $state
                $quiet = @(@($state.exclusive) + @($state.waiting) | Where-Object { $_ -and $_.quiet -and (-not $own -or $_.id -ne $own.id) }) | Select-Object -First 1
                $script:gameLockBuildWait = Get-GameLockHoldText $quiet
                if (-not $quiet) {
                    $state.builds = @($state.builds) + @([pscustomobject]@{ id = "build-$PID"; clone = $Clone; pid = $PID; started = (Get-Process -Id $PID).StartTime.ToFileTimeUtc(); games = @() })
                    Write-GameLockState $state
                    Write-GameLockLog 'build' $Clone $PID
                }
            }
            if (-not $script:gameLockBuildWait) { return }
            if (-not $said -or ((Get-Date) - $said).TotalSeconds -ge 30) {
                Write-Host "The build waits for a quiet measurement: $script:gameLockBuildWait" -ForegroundColor Yellow
                $said = Get-Date
            }
            Start-Sleep -Seconds 2
        }
    } catch { Write-Host "The game lock's build check failed, the build goes on: $($_.Exception.Message)" }
}
function Exit-GameLockBuild {
    try {
        Invoke-UnderGameLockMutex {
            $state = Read-GameLockState
            $state.builds = @($state.builds | Where-Object { [int]$_.pid -ne $PID })
            Write-GameLockState $state
        }
    } catch {}
}

# The exclusive holder if a live one has it, for Start Here ("the game is running", who holds the lock and since when). Shared tests
# aren't "the game": Play stops them.
function Get-GameLockExclusive {
    $raw = Get-GameLock
    if (-not $raw) { return $null }
    if (-not $raw.v) {
        if (Test-GameLockLive $raw) { return [pscustomobject]@{ clone = $raw.clone; pid = $raw.pid; taken = $raw.taken; purpose = '' } }
        return $null
    }
    if ($raw.exclusive -and (Test-GameLockHoldLive $raw.exclusive)) { return $raw.exclusive }
    return $null
}

# This clone's game: the process run-windows.ps1 started last, if it is still running.
function Get-OwnGame([string]$Rex) {
    $file = if ($env:TTT2_GAME_PID_FILE) { $env:TTT2_GAME_PID_FILE } else { Join-Path $Rex 'out\game-pid.txt' }
    if (-not (Test-Path -LiteralPath $file)) { return $null }
    $parts = "$(Get-Content -LiteralPath $file -Raw)".Trim() -split ' '
    if ($parts.Count -lt 2) { return $null }
    $p = Get-Process -Id ([int]$parts[0]) -ErrorAction SilentlyContinue
    if (-not $p -or $p.ProcessName -ne 'ttt2') { return $null }
    try { if ($p.StartTime.ToFileTimeUtc() -ne [long]$parts[1]) { return $null } } catch {}
    return $p
}

function Stop-OwnGame([string]$Rex) {
    $p = Get-OwnGame $Rex
    if ($p) {
        Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
        try { $p.WaitForExit(5000) | Out-Null } catch {}
    }
}

if ($Action) {
    $rexFolder = Split-Path $PSScriptRoot -Parent
    switch ($Action) {
        'show' {
            Invoke-UnderGameLockMutex { $script:gameLockShowState = Read-GameLockState }
            $state = $script:gameLockShowState
            if (-not $state.exclusive -and -not $state.shared.Count -and -not $state.waiting -and -not $state.builds.Count) { 'No game lock.' }
            else {
                if ($state.exclusive) { "Exclusive$(if ($state.exclusive.quiet) { ', quiet' }): $(Get-GameLockHoldText $state.exclusive)" }
                foreach ($h in $state.shared) { "Shared: $(Get-GameLockHoldText $h); games: $((@($h.games | Where-Object { $_ }) | ForEach-Object { "$($_.pid)" }) -join ', ')" }
                if ($state.waiting) { "Waiting$(if ($state.waiting.owner) { ', the owner''s Play' }): $(Get-GameLockHoldText $state.waiting)" }
                if ($state.stop) { "The stop flag is set, since $($state.stop.since)." }
                foreach ($b in $state.builds) { "Build: process $($b.pid), from $($b.clone)" }
                "Shared games: $(Get-GameLockSharedGames $state) of $(Get-GameLockLimit)."
            }
        }
        'take' { if (Take-GameLock $rexFolder) { "Taken by process $PID." } else { 'Held already by the script that started this one.' } }
        'release' { Release-GameLock; 'Released.' }
        'watch-stop' { Invoke-GameLockStopWatch $HoldId }
        default { throw "game-lock.ps1 show | take | release" }
    }
}
