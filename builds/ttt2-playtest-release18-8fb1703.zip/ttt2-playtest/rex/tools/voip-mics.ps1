# The recording devices present on this PC, by the names the game's SDL3 lists (voice chat's microphone picker in launcher.ps1; rex\src\online\voip_audio.cpp).
# SDL's WASAPI backend names a device by PKEY_Device_FriendlyName of its IMMDevice endpoint (SDL_immdevice.c), active capture endpoints only, so this asks the same
# interface for the same property (Get-PnpDevice's FriendlyName is the same text in practice, but it lists devices Windows has disabled or unplugged unless filtered, and the
# endpoint API is what SDL itself uses: the strings match by construction). Names are shown on the form only; they are never logged or sent anywhere.
#   . "$PSScriptRoot\voip-mics.ps1"; Get-VoipMicrophones      -> an array of names (empty when none or the query fails)
if (-not ('Ttt2VoipMics' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

public static class Ttt2VoipMics {
    [StructLayout(LayoutKind.Sequential)] struct PropertyKey { public Guid fmtid; public uint pid; }
    [StructLayout(LayoutKind.Explicit, Size = 24)] struct PropVariant { [FieldOffset(0)] public ushort vt; [FieldOffset(8)] public IntPtr p; }

    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class MMDeviceEnumeratorCom { }
    [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDeviceEnumerator {
        [PreserveSig] int EnumAudioEndpoints(int dataFlow, uint stateMask, out IMMDeviceCollection devices);
        [PreserveSig] int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice device);
        [PreserveSig] int GetDevice([MarshalAs(UnmanagedType.LPWStr)] string id, out IMMDevice device);
        [PreserveSig] int RegisterEndpointNotificationCallback(IntPtr client);
        [PreserveSig] int UnregisterEndpointNotificationCallback(IntPtr client);
    }
    [ComImport, Guid("0BD7A1BE-7A1A-44DB-8397-CC5392387B5E"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDeviceCollection {
        [PreserveSig] int GetCount(out uint count);
        [PreserveSig] int Item(uint index, out IMMDevice device);
    }
    [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDevice {
        [PreserveSig] int Activate(ref Guid iid, uint clsctx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object iface);
        [PreserveSig] int OpenPropertyStore(uint access, out IPropertyStore props);
        [PreserveSig] int GetId([MarshalAs(UnmanagedType.LPWStr)] out string id);
        [PreserveSig] int GetState(out uint state);
    }
    [ComImport, Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IPropertyStore {
        [PreserveSig] int GetCount(out uint count);
        [PreserveSig] int GetAt(uint index, out PropertyKey key);
        [PreserveSig] int GetValue(ref PropertyKey key, out PropVariant value);
        [PreserveSig] int SetValue(ref PropertyKey key, ref PropVariant value);
        [PreserveSig] int Commit();
    }
    [DllImport("ole32.dll")] static extern int PropVariantClear(ref PropVariant pv);

    // eCapture = 1, DEVICE_STATE_ACTIVE = 1 (the devices SDL lists as recording devices: active ones only)
    public static string[] Names() {
        var names = new List<string>();
        try {
            var en = (IMMDeviceEnumerator)new MMDeviceEnumeratorCom();
            IMMDeviceCollection col;
            if (en.EnumAudioEndpoints(1, 1, out col) != 0) return names.ToArray();
            uint n; col.GetCount(out n);
            var friendly = new PropertyKey { fmtid = new Guid("a45c254e-df1c-4efd-8020-67d146a850e0"), pid = 14 };   // PKEY_Device_FriendlyName
            for (uint i = 0; i < n; i++) {
                IMMDevice dev; if (col.Item(i, out dev) != 0) continue;
                IPropertyStore ps; if (dev.OpenPropertyStore(0, out ps) != 0) continue;   // STGM_READ
                PropVariant v; var key = friendly;
                if (ps.GetValue(ref key, out v) == 0) {
                    if (v.vt == 31 && v.p != IntPtr.Zero) { string s = Marshal.PtrToStringUni(v.p); if (!string.IsNullOrEmpty(s)) names.Add(s); }   // VT_LPWSTR
                    PropVariantClear(ref v);
                }
            }
        } catch { }
        return names.ToArray();
    }
}
'@
}
function Get-VoipMicrophones { try { @([Ttt2VoipMics]::Names()) } catch { @() } }
