# Uninstall (the owner, 31 Oct; docs/UNINSTALL_PLAN_20261031.md): what Start Here's Uninstall button deletes, worked out here, and
# deleted by uninstall-finish.ps1 from a copy in %TEMP% after Start Here has closed. Nothing here deletes.
#
# An install folder is never deleted whole: only the package's own files (rex\package-files.txt, or the known top-level names of an
# older package) and what the game made, then folders that end up empty. Anything else a player keeps there stays, and is named.
#
#   . rex\tools\uninstall.ps1
#   Get-Ttt2OtherInstalls $thisInstall            the other copies installs.txt names (dev clones never)
#   Get-Ttt2UninstallBlockers $installs           what must close first
#   Get-Ttt2UninstallPlan $this $scope            'one' or 'all'
#   Set-Ttt2UninstallKeep $plan                   leaves the saves and the Ranked account out of an 'all' plan
#   Test-Ttt2UninstallItem $item $plan            the guard, on every item before it's deleted

function Get-Ttt2UninstallHome { Join-Path $env:LOCALAPPDATA 'TTT2Native' }

if (-not ('Ttt2Uninstall.Paths' -as [type])) {
    Add-Type -Namespace Ttt2Uninstall -Name Paths -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("kernel32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
public static extern uint GetLongPathNameW(string s, System.Text.StringBuilder l, uint n);
'@
}

# One spelling of a path: absolute, 8.3 names and .. resolved, no trailing \. '' when it isn't a full path (C:\... or \\server\...).
function Get-Ttt2FullPath([string]$path) {
    if (-not $path -or $path -notmatch '^([A-Za-z]:\\|\\\\)') { return '' }
    try { $full = [IO.Path]::GetFullPath($path) } catch { return '' }
    $long = New-Object Text.StringBuilder 1024
    if ([Ttt2Uninstall.Paths]::GetLongPathNameW($full, $long, 1024) -gt 0) { $full = $long.ToString() }
    if ($full.Length -le 3) { return $full }
    $full.TrimEnd('\')
}

# True when $inner is $outer or inside it.
function Test-Ttt2Inside([string]$inner, [string]$outer) {
    if (-not $inner -or -not $outer) { return $false }
    $inner -ieq $outer -or $inner.StartsWith("$outer\", [StringComparison]::OrdinalIgnoreCase)
}

function Test-Ttt2IsInstall([string]$path) {
    $path -and (Test-Path -LiteralPath (Join-Path $path 'rex\setup-steps.ps1')) -and -not (Test-Path -LiteralPath (Join-Path $path '.git'))
}

function Get-Ttt2InstallLines {
    $file = Join-Path (Get-Ttt2UninstallHome) 'installs.txt'
    if (-not (Test-Path -LiteralPath $file)) { return @() }
    @([IO.File]::ReadAllLines($file, [Text.Encoding]::Default) | ForEach-Object { Get-Ttt2FullPath "$_".Trim() } | Where-Object { $_ -and $_.Length -gt 3 } | Select-Object -Unique)
}

function Get-Ttt2OtherInstalls([string]$thisInstall) {
    $me = Get-Ttt2FullPath $thisInstall
    @(Get-Ttt2InstallLines | Where-Object { $_ -ine $me -and (Test-Ttt2IsInstall $_) })
}

# An install's name for the boxes: the package's, when it can be read cheaply.
function Get-Ttt2InstallLabel([string]$install) {
    $info = Join-Path $install 'rex\package-info.txt'
    if (Test-Path -LiteralPath $info) {
        $line = @(Get-Content -LiteralPath $info | Where-Object { $_ -like 'name=*' }) | Select-Object -First 1
        if ($line) { return $line.Substring(5) }
    }
    ''
}

# A folder's size, not following a junction or a link out of it.
function Get-Ttt2FolderBytes([string]$path) {
    if ([IO.File]::Exists($path)) { return (New-Object IO.FileInfo $path).Length }
    if (-not [IO.Directory]::Exists($path)) { return 0L }
    $total = 0L
    $stack = New-Object Collections.Stack
    $stack.Push((New-Object IO.DirectoryInfo $path))
    while ($stack.Count) {
        $d = $stack.Pop()
        if (($d.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -and $d.LinkType) { continue }
        try {
            foreach ($e in $d.GetFileSystemInfos()) {
                if ($e -is [IO.DirectoryInfo]) { $stack.Push($e) } else { $total += $e.Length }
            }
        } catch { }
    }
    $total
}

# What has to close first: any game or BlueSpark (the warm-up is a game too), or another copy's open Start Here.
function Get-Ttt2UninstallBlockers([string[]]$otherInstalls) {
    $blockers = @()
    if (Get-Process -Name ttt2 -ErrorAction SilentlyContinue) { $blockers += 'TTT2' }
    if (Get-Process -Name ttt2-fastclient -ErrorAction SilentlyContinue) { $blockers += 'BlueSpark' }
    foreach ($install in @($otherInstalls)) {
        $file = Join-Path $install 'rex\start-here.pid'
        if (-not (Test-Path -LiteralPath $file)) { continue }
        $parts = "$(Get-Content -LiteralPath $file -Raw -ErrorAction SilentlyContinue)".Trim() -split '\s+'
        if ($parts.Count -lt 2 -or $parts[0] -notmatch '^\d+$') { continue }
        $p = Get-Process -Id ([int]$parts[0]) -ErrorAction SilentlyContinue
        if ($p -and "$($p.StartTime.ToFileTimeUtc())" -eq $parts[1]) { $blockers += "Start Here in $install" }
    }
    $blockers
}

# Folders a delete must never be, or be above: the user's own places and the system's.
function Get-Ttt2NeverPaths {
    $up = "$env:USERPROFILE"
    @($up, $env:LOCALAPPDATA, $env:APPDATA, $env:TEMP, $env:SystemRoot, $env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:ProgramData,
      $env:OneDrive, $env:OneDriveConsumer, $env:OneDriveCommercial,
      [Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('MyDocuments'), [Environment]::GetFolderPath('MyMusic'),
      [Environment]::GetFolderPath('MyPictures'), [Environment]::GetFolderPath('MyVideos'),
      (Join-Path $up 'Desktop'), (Join-Path $up 'Documents'), (Join-Path $up 'Music'), (Join-Path $up 'Downloads'), (Join-Path $up 'Pictures'), (Join-Path $up 'Videos')) |
        ForEach-Object { Get-Ttt2FullPath $_ } | Where-Object { $_ } | Select-Object -Unique
}

# The guard. Item kinds: entry (a package file or a generated one, in an install), data (ours, in a folder named TTT2Native), file (a file of ours
# with a known name), link (a junction), folder (a folder of ours with a known name). False: not deleted, and listed.
function Test-Ttt2UninstallItem($item, $plan) {
    $full = Get-Ttt2FullPath $item.path
    if (-not $full -or $full.Length -le 3 -or -not (Test-Path -LiteralPath $full)) { return $false }
    foreach ($never in @(Get-Ttt2NeverPaths)) {
        if ($full -ieq $never) { return $false }
        if ($never.StartsWith("$full\", [StringComparison]::OrdinalIgnoreCase)) { return $false }
    }
    # (Never through something the player or another copy keeps: a game disc, a nested copy, the data folder.)
    $kept = if ($item.kind -eq 'entry') { @($plan.protectAll) } else { @($plan.protectUser) }
    if ($item.kind -ne 'link') { foreach ($p in $kept) { if (Test-Ttt2Inside $p $full) { return $false } } }
    switch ($item.kind) {
        'entry' { return (Test-Ttt2Inside $full (Get-Ttt2FullPath $item.root)) -and $full -ine (Get-Ttt2FullPath $item.root) }
        'data' {
            if ($full -imatch '(^|\\)TTT2Native(\\|$)') {
                $home3 = Get-Ttt2FullPath $plan.home
                return ($full -ine $home3 -and -not (Test-Ttt2Inside $home3 $full)) -or $item.homePart
            }
            return $false
        }
        'link' { $i = Get-Item -LiteralPath $full -Force; return [bool]$i.LinkType }
        'file' { return [IO.File]::Exists($full) }
        'folder' { return [IO.Directory]::Exists($full) }
    }
    $false
}

# The Desktop's and Music's real places. (A test's scratch USERPROFILE never reaches the real ones.)
function Get-Ttt2UserFolder([string]$special, [string]$plain) {
    if ((Get-Ttt2FullPath ([Environment]::GetFolderPath('UserProfile'))) -ieq (Get-Ttt2FullPath $env:USERPROFILE)) { return [Environment]::GetFolderPath($special) }
    Join-Path $env:USERPROFILE $plain
}

function Get-Ttt2OutboxCount {
    $outbox = Join-Path (Get-Ttt2UninstallHome) 'profile\live\outbox'
    if (-not (Test-Path -LiteralPath $outbox)) { return 0 }
    @(Get-ChildItem -LiteralPath $outbox -Filter '*.res' -File -ErrorAction SilentlyContinue).Count
}

# An older package's top-level names (it has no rex\package-files.txt).
$script:Ttt2KnownTopNames = @('rex', 'recomp', 'source', 'fastclient', 'Start Here.cmd', 'Report a problem.cmd', 'Report a sound problem.cmd', 'Start Fast Client.cmd', 'README.txt', 'TRAINING.txt', 'CHANGELOG.txt',
                              'VERSION.txt', 'TEST-NOTES.txt', 'SOURCE_OFFER.txt', 'THIRD_PARTY_NOTICES.txt', '.gitignore', 'gamedata\README.txt')
# What the game and Start Here make in a copy.
$script:Ttt2MadeEntries = @('rex\out', 'rex\userdata', 'rex\generated', 'rex\start-here.pid', 'rex\game-folder.txt', 'gamedata\default_tu.xex')

function Get-Ttt2InstallEntries([string]$install) {
    $names = @($script:Ttt2MadeEntries)
    $list = Join-Path $install 'rex\package-files.txt'
    if (Test-Path -LiteralPath $list) {
        $names += @([IO.File]::ReadAllLines($list) | ForEach-Object { "$_".Trim().Replace('/', '\') } | Where-Object { $_ -and $_ -notmatch '(^|\\)\.\.(\\|$)' -and $_ -notmatch '^([A-Za-z]:|\\)' })
    } else {
        $names += $script:Ttt2KnownTopNames
    }
    @($names | Select-Object -Unique | ForEach-Object { Join-Path $install $_ } | Where-Object { Test-Path -LiteralPath $_ })
}

# What's kept in a copy or another place and may not be deleted through. All: the player's picks, other copies, the data folder and the home. User: without
# our own two folders, for the items inside those.
function Get-Ttt2Protected([string[]]$installs, [string]$home2, [string]$picked) {
    $user = New-Object Collections.ArrayList
    foreach ($line in @(Get-Ttt2InstallLines)) { [void]$user.Add($line) }
    foreach ($install in @($installs)) {
        [void]$user.Add((Get-Ttt2FullPath $install))
        $settings = Join-Path $install 'rex\userdata\launcher-settings.txt'
        if (Test-Path -LiteralPath $settings) {
            foreach ($l in @(Get-Content -LiteralPath $settings -ErrorAction SilentlyContinue)) {
                if ($l -match '^(game-source|game-update)=(.+)$') { [void]$user.Add((Get-Ttt2FullPath $Matches[2].Trim())) }
            }
        }
        $saved = Join-Path $install 'rex\game-folder.txt'
        if (Test-Path -LiteralPath $saved) {
            $game = Get-Ttt2FullPath "$(Get-Content -LiteralPath $saved -TotalCount 1 -ErrorAction SilentlyContinue)".Trim()
            if ($game -and -not (Test-Ttt2Inside $game $home2) -and -not ($picked -and (Test-Ttt2Inside $game $picked))) { [void]$user.Add($game) }
        }
    }
    $userList = @($user | Where-Object { $_ } | Select-Object -Unique)
    # (A copy being uninstalled protects its neighbours, not itself: an entry is judged by what's below it.)
    [pscustomobject]@{ user = $userList; all = @(@($userList) + @($home2, $picked) | Where-Object { $_ } | Select-Object -Unique) }
}

# The plan: what to delete in order, what's left and why. Paths only: nothing is read from a save or the identity.
function Get-Ttt2UninstallPlan([string]$thisInstall, [string]$scope) {
    $thisFull = Get-Ttt2FullPath $thisInstall
    $home2 = Get-Ttt2FullPath (Get-Ttt2UninstallHome)
    $items = New-Object Collections.ArrayList
    $left = New-Object Collections.ArrayList
    function Add-Item2([string]$path, [string]$kind, [string]$root = '', [bool]$homePart = $false) {
        [void]$items.Add([pscustomobject]@{ path = $path; kind = $kind; root = $root; homePart = $homePart; bytes = [long](Get-Ttt2FolderBytes $path) })
    }

    $others = @(if ($scope -eq 'all') { Get-Ttt2OtherInstalls $thisFull })
    $installs = @($thisFull) + $others

    # The data folder, when it was moved: <picked>\TTT2Native. The same folder as the home under another spelling is the home.
    $picked = ''
    $dataFile = Join-Path $home2 'data-folder.txt'
    if (Test-Path -LiteralPath $dataFile) {
        $picked = Get-Ttt2FullPath "$(Get-Content -LiteralPath $dataFile -TotalCount 1 -ErrorAction SilentlyContinue)".Trim()
        if ($picked -ieq $home2) { $picked = '' }
    }
    $protected = Get-Ttt2Protected $installs $home2 $picked

    # The links first: a path-alias junction of a copy going, the link only, never its target.
    $aliasRoot = Join-Path $home2 'path-alias'
    if (Test-Path -LiteralPath $aliasRoot) {
        foreach ($link in @(Get-ChildItem -LiteralPath $aliasRoot -Force -ErrorAction SilentlyContinue)) {
            if (-not $link.LinkType) { continue }
            $target = Get-Ttt2FullPath "$(@($link.Target) | Select-Object -First 1)"
            if ($scope -eq 'all' -or @($installs | Where-Object { $_ -ieq $target }).Count) { [void]$items.Add([pscustomobject]@{ path = $link.FullName; kind = 'link'; root = ''; homePart = $false; bytes = 0L }) }
        }
    }
    # The player's own game folder: only the files we put there, read before the copies go.
    $gameFiles = @()
    if ($scope -eq 'all') {
        foreach ($install in $installs) {
            $saved = Join-Path $install 'rex\game-folder.txt'
            if (-not (Test-Path -LiteralPath $saved)) { continue }
            $game = Get-Ttt2FullPath "$(Get-Content -LiteralPath $saved -TotalCount 1 -ErrorAction SilentlyContinue)".Trim()
            if (-not $game -or (Test-Ttt2Inside $game $home2) -or ($picked -and (Test-Ttt2Inside $game $picked))) { continue }
            $gameFiles += (Join-Path $game 'default_tu.xex')
            $update = Join-Path (Split-Path $game -Parent) 'update'
            foreach ($name in 'Default.xexp', 'data100.bin', 'data100.ofs') { $gameFiles += (Join-Path $update $name) }
        }
    }
    foreach ($install in $installs) {
        foreach ($entry in @(Get-Ttt2InstallEntries $install)) { Add-Item2 $entry 'entry' $install }
    }
    $devPc = $false
    if ($scope -eq 'all') {
        foreach ($f in @($gameFiles | Select-Object -Unique | Where-Object { Test-Path -LiteralPath $_ })) { Add-Item2 $f 'file' }
        if (Test-Path -LiteralPath $dataFile) {
            $line = "$(Get-Content -LiteralPath $dataFile -TotalCount 1 -ErrorAction SilentlyContinue)".Trim()
            if ($picked) {
                if ((Split-Path $picked -Leaf) -ieq 'TTT2Native') { Add-Item2 $picked 'data' } else { [void]$left.Add("$line (the tools and game files: it isn't a folder named TTT2Native)") }
            }
        }
        # Our home, a part at a time: a dev PC's keys and Qt stay, and so do the saves and the Ranked account if asked.
        if (Test-Path -LiteralPath $home2) {
            foreach ($part in @(Get-ChildItem -LiteralPath $home2 -Force -ErrorAction SilentlyContinue)) {
                if ($part.Name -in 'keys', 'qt') { $devPc = $true; [void]$left.Add("$($part.FullName) (a developer's folder)"); continue }
                if ($part.Name -eq 'logs') { continue }   # (last)
                Add-Item2 $part.FullName 'data' '' $true
            }
            $logs = Join-Path $home2 'logs'
            if (Test-Path -LiteralPath $logs) { Add-Item2 $logs 'data' '' $true }
        }
        if (-not $devPc) {
            foreach ($d in @(Get-ChildItem -LiteralPath $env:USERPROFILE -Directory -Filter 'rexsdk-playtest*' -Force -ErrorAction SilentlyContinue)) { Add-Item2 $d.FullName 'folder' }
            $old = Join-Path $env:USERPROFILE 'rexsdk\xexpatch'
            if (Test-Path -LiteralPath $old) { Add-Item2 $old 'folder' }
            $lock = Join-Path $env:USERPROFILE 'ttt2-game.lock'
            if (Test-Path -LiteralPath $lock) { Add-Item2 $lock 'file' }
        }
        $cache = Join-Path $env:LOCALAPPDATA 'BlueSpark\cache'   # (BlueSpark's Qt Quick cache)
        if (Test-Path -LiteralPath $cache) { Add-Item2 $cache 'folder' }
        $desktop = Get-Ttt2UserFolder 'Desktop' 'Desktop'
        foreach ($pattern in 'ttt2-problem-report-*.zip', 'ttt2-sound-report-*.zip', 'ttt2-sound-clips-*.zip') {
            foreach ($z in @(Get-ChildItem -LiteralPath $desktop -Filter $pattern -File -ErrorAction SilentlyContinue)) { Add-Item2 $z.FullName 'file' }
        }
        $tunes = Join-Path (Get-Ttt2UserFolder 'MyMusic' 'Music') 'TTT2 Tunes'
        if ((Test-Path -LiteralPath $tunes) -and @(Get-ChildItem -LiteralPath $tunes -Force -ErrorAction SilentlyContinue).Count) { [void]$left.Add("$tunes (your music)") }
    }
    [pscustomobject]@{
        scope = $scope; keep = $false; this = $thisFull; installs = @($installs); devPc = $devPc
        items = @($items); left = @($left); bytes = [long](@($items) | Measure-Object -Property bytes -Sum).Sum
        protectAll = @($protected.all); protectUser = @($protected.user)
        tunes = $(if ($scope -eq 'all') { Join-Path (Get-Ttt2UserFolder 'MyMusic' 'Music') 'TTT2 Tunes' } else { '' })
        gameUpdateFolders = @($gameFiles | Where-Object { $_ -notlike '*default_tu.xex' } | ForEach-Object { Split-Path $_ -Parent } | Select-Object -Unique)
        installsFile = (Join-Path $home2 'installs.txt'); home = $home2
        log = (Join-Path $env:TEMP 'ttt2-uninstall.log')
    }
}

# The keep box: the saves and the Ranked account stay.
function Set-Ttt2UninstallKeep($plan) {
    $profile2 = Join-Path $plan.home 'profile'; $backup = Join-Path $plan.home 'backup'
    $plan.items = @($plan.items | Where-Object { -not ($_.kind -eq 'data' -and ($_.path -ieq $profile2 -or $_.path -ieq $backup)) })
    $plan.bytes = [long](@($plan.items) | Measure-Object -Property bytes -Sum).Sum
    $plan.keep = $true
    $plan
}
