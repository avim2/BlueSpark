# Remove-Ttt2Folder: deletes folders (with everything in them) and files through .NET ([IO.Directory]::Delete,
# [IO.File]::Delete), not PowerShell's FileSystem provider. A player's step 2 under Desktop\<a non-ASCII name> stopped at
# prepare-game.ps1's Remove-Item -Recurse with "An object at the specified path ... does not exist" although Test-Path had
# found the folder (Windows PowerShell 5.1, 27 Oct). Paths are taken as they are (no wildcards), relative ones from the
# current location. Read-only files are made writable first (Directory.Delete refuses them). Nothing there: nothing done.
# A junction or link is removed as a link, never walked into: its target stays (the uninstall's path-alias, xwin's symlink).
#
#   . rex\tools\remove-folder.ps1
#   Remove-Ttt2Folder $path [-Quiet]      (-Quiet: a failure is not thrown; it returns $false)

function Clear-Ttt2ReadOnly([string]$folder) {
    foreach ($entry in [IO.Directory]::GetFileSystemEntries($folder)) {
        $attributes = [IO.File]::GetAttributes($entry)
        # (Only a junction or a symbolic link is a link: OneDrive's online-only folders carry a reparse point too.)
        if (($attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -and (Get-Item -LiteralPath $entry -Force).LinkType) {
            if (($attributes -band [IO.FileAttributes]::Directory) -ne 0) { [IO.Directory]::Delete($entry) } else { [IO.File]::SetAttributes($entry, [IO.FileAttributes]::Normal); [IO.File]::Delete($entry) }
        } elseif (($attributes -band [IO.FileAttributes]::Directory) -ne 0) {
            Clear-Ttt2ReadOnly $entry
        } elseif (($attributes -band [IO.FileAttributes]::ReadOnly) -ne 0) {
            [IO.File]::SetAttributes($entry, $attributes -band (-bnot [IO.FileAttributes]::ReadOnly))
        }
    }
}

function Remove-Ttt2Folder {
    param([Parameter(Mandatory, Position = 0)][string[]]$Path, [switch]$Quiet)
    $ok = $true
    foreach ($p in $Path) {
        try {
            $full = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($p)
            if ([IO.Directory]::Exists($full)) {
                if (([IO.File]::GetAttributes($full) -band [IO.FileAttributes]::ReparsePoint) -ne 0 -and (Get-Item -LiteralPath $full -Force).LinkType) { [IO.Directory]::Delete($full); continue }
                Clear-Ttt2ReadOnly $full
                [IO.Directory]::Delete($full, $true)
            } elseif ([IO.File]::Exists($full)) {
                [IO.File]::SetAttributes($full, [IO.FileAttributes]::Normal)
                [IO.File]::Delete($full)
            }
        } catch {
            $ok = $false
            if (-not $Quiet) { throw "Could not delete ${p}: $($_.Exception.GetBaseException().Message)" }
        }
    }
    if ($Quiet) { return $ok }
}
