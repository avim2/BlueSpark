# Uninstall's last part, run hidden from a copy in %TEMP% once Start Here has closed (docs/UNINSTALL_PLAN_20261031.md): waits for Start Here to
# go, checks every path again, deletes what the plan lists, removes folders left empty, says what happened, removes itself.
#
#   powershell -NoProfile -ExecutionPolicy Bypass -File uninstall-finish.ps1 -Plan <plan.json> [-WaitPid <id>] [-NoBox]
#
# The log is %TEMP%\ttt2-uninstall.log: paths and results only.
param([Parameter(Mandatory)][string]$Plan, [int]$WaitPid = 0, [switch]$NoBox)
$ErrorActionPreference = 'Continue'
. (Join-Path $PSScriptRoot 'remove-folder.ps1')
. (Join-Path $PSScriptRoot 'uninstall.ps1')
$p = Get-Content -LiteralPath $Plan -Raw -Encoding UTF8 | ConvertFrom-Json
function Note([string]$text) { try { Add-Content -LiteralPath $p.log "$(Get-Date -Format 'HH:mm:ss') $text" -Encoding utf8 } catch { } }
Note "Uninstall: scope $($p.scope), keep the saves: $($p.keep)"

if ($WaitPid) {
    $until = (Get-Date).AddSeconds(30)
    while ((Get-Process -Id $WaitPid -ErrorAction SilentlyContinue) -and (Get-Date) -lt $until) { Start-Sleep -Milliseconds 300 }
    if (Get-Process -Id $WaitPid -ErrorAction SilentlyContinue) {
        Note 'Start Here is still open after 30 s: nothing deleted'
        if (-not $NoBox) { Add-Type -AssemblyName System.Windows.Forms; $top = New-Object Windows.Forms.Form -Property @{ TopMost = $true }; [void][Windows.Forms.MessageBox]::Show($top, 'Start Here is still open, so nothing was uninstalled. Close it and press Uninstall again.', 'Uninstall TTT2', 'OK', 'Warning') }
        exit 1
    }
}
# (The hidden replay uploader is ours, and holds nothing the player should wait for.)
$uploaders = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue)
foreach ($install in @($p.installs)) {
    $wanted = Join-Path $install 'rex\tools\replay-uploader.ps1'
    foreach ($u in $uploaders) {
        if ($u.CommandLine -and $u.ProcessId -ne $PID -and $u.CommandLine.IndexOf($wanted, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
            Stop-Process -Id $u.ProcessId -Force -ErrorAction SilentlyContinue; Note "stopped the replay uploader ($($u.ProcessId))"
        }
    }
}
$freed = 0L
$notDone = New-Object Collections.ArrayList
$foldersOfEntries = @{}
foreach ($item in @($p.items)) {
    if (-not (Test-Path -LiteralPath $item.path)) { Note "gone already: $($item.path)"; continue }
    if (-not (Test-Ttt2UninstallItem $item $p)) { Note "KEPT by the guard ($($item.kind)): $($item.path)"; [void]$notDone.Add($item.path); continue }
    $full = Get-Ttt2FullPath $item.path
    if ($item.kind -eq 'entry') {
        $d = Split-Path $full -Parent
        $root = Get-Ttt2FullPath $item.root
        while ($d -and (Test-Ttt2Inside $d $root)) { $foldersOfEntries[$d] = $root; if ($d -ieq $root) { break }; $d = Split-Path $d -Parent }
    }
    $ok = $false
    for ($try = 1; $try -le 5 -and -not $ok; ++$try) {
        if ($item.kind -eq 'link') {
            try { [IO.Directory]::Delete($full); $ok = $true } catch { }
        } else {
            $ok = Remove-Ttt2Folder $full -Quiet
        }
        if (-not $ok) { Start-Sleep -Seconds 1 }
    }
    if ($ok) { $freed += [long]$item.bytes; Note "deleted: $full" } else { Note "LEFT: $full"; [void]$notDone.Add($full) }
}
# Folders the entries were in, deepest first, only when empty: a copy's own folder last, and never one of the user's places.
$never = @(Get-Ttt2NeverPaths)
$kept = New-Object Collections.ArrayList
foreach ($d in @($foldersOfEntries.Keys | Sort-Object Length -Descending)) {
    if (-not (Test-Path -LiteralPath $d)) { continue }
    if ($never -icontains $d) { if ($foldersOfEntries[$d] -ieq $d -and @(Get-ChildItem -LiteralPath $d -Force -ErrorAction SilentlyContinue).Count) { [void]$kept.Add($d) }; continue }
    $until = (Get-Date).AddSeconds($(if ($foldersOfEntries[$d] -ieq $d) { 30 } else { 2 }))
    while (Test-Path -LiteralPath $d) {
        if (@(Get-ChildItem -LiteralPath $d -Force -ErrorAction SilentlyContinue).Count) { if ($foldersOfEntries[$d] -ieq $d) { [void]$kept.Add($d) }; Note "kept, not empty: $d"; break }
        try { [IO.Directory]::Delete($d); Note "deleted the empty folder: $d" } catch { if ((Get-Date) -gt $until) { Note "the empty folder stays: $d"; break }; Start-Sleep -Milliseconds 500 }
    }
}
# The list of copies, when a copy stays; the folders we emptied, only if empty.
if ($p.scope -ne 'all' -and (Test-Path -LiteralPath $p.installsFile)) {
    try {
        $keepLines = @([IO.File]::ReadAllLines($p.installsFile, [Text.Encoding]::Default) | Where-Object { (Get-Ttt2FullPath "$_".Trim()) -ine $p.this })
        [IO.File]::WriteAllLines($p.installsFile, [string[]]$keepLines, [Text.Encoding]::Default)
        Note 'the list of copies updated'
    } catch { Note "the list of copies not updated: $($_.Exception.Message)" }
}
$empties = @($p.gameUpdateFolders) + @($p.tunes)
if ($p.scope -eq 'all') {
    $empties += (Join-Path $env:LOCALAPPDATA 'BlueSpark')
    if (-not $p.devPc) { $empties += (Join-Path $env:USERPROFILE 'rexsdk') }
    $empties += $p.home
}
foreach ($empty in $empties) {
    if ($empty -and (Test-Path -LiteralPath $empty) -and -not @(Get-ChildItem -LiteralPath $empty -Force -ErrorAction SilentlyContinue).Count) {
        try { [IO.Directory]::Delete($empty); Note "deleted the empty folder: $empty" } catch { Note "the empty folder stays: $empty" }
    }
}
$text = @($(if ($notDone.Count) { "TTT2 is mostly uninstalled, but these weren't deleted (they're in use, or something you keep is inside them):`r`n" + (($notDone | Select-Object -First 10) -join "`r`n") } else { 'TTT2 is uninstalled.' }))
$text += ('About {0:N1} GB came back.' -f ($freed / 1GB))
foreach ($k in @($kept)) { $text += "Kept: files you added in $k" }
if ($p.scope -eq 'all') {
    if ($p.keep) { $text += 'Your saves and Ranked account were kept.' }
    foreach ($l in @($p.left)) { $text += "Left alone: $l" }
    $text += "Left alone: Microsoft's Visual C++ runtime, which other programs use, and Visual Studio Build Tools if an old package installed them. Your own game disc or folder too, apart from the files TTT2 added."
    $text += 'If Windows Firewall asked about TTT2, its rule is still there: Windows Security > Firewall > Allow an app.'
    $text += 'If you unzipped other copies before 23 October, delete those folders yourself.'
}
Note ($text -join ' | ')
if (-not $NoBox) {
    Add-Type -AssemblyName System.Windows.Forms
    $top = New-Object Windows.Forms.Form -Property @{ TopMost = $true }
    [void][Windows.Forms.MessageBox]::Show($top, ($text -join "`r`n`r`n"), 'Uninstall TTT2', 'OK', 'Information')
}
# This copy of the scripts, once this process has ended.
$me = $PSScriptRoot
if ($me -like '*ttt2-uninstall-*') { Start-Process cmd.exe -WindowStyle Hidden -WorkingDirectory $env:TEMP -ArgumentList '/c', "ping -n 3 127.0.0.1 >nul & rd /s /q `"$me`"" }
