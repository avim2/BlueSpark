/**
 * @file        latency.h
 * @brief       Timestamps along the path from a controller read to the host present, and a log
 *              of the delays between them (latency_log).
 *
 * @license     BSD 3-Clause License
 *              See LICENSE file in the project root for full license text.
 */

#pragma once

#include <cstdint>

namespace rex::latency {

enum class Event : uint32_t {
  // The host polled the controllers.
  kInputPoll,
  // The guest read the first controller's state (XamInputGetState).
  kInputRead,
  // The guest's vertical blank interrupt.
  kGuestVblank,
  // The guest called VdSwap.
  kGuestSwap,
  // The GPU command processor reached that swap.
  kSwapExecute,
  // The presenter started painting a frame for the host, and its Present call returned.
  kPresentBegin,
  kPresentEnd,
  // The host GPU finished drawing the frame that was presented.
  kGpuDone,
  // The host display's vertical blank.
  kHostVblank,

  kCount,
};

// Monotonic host time in nanoseconds.
uint64_t NowNs();

// Records the event as happening now. Cheap when latency_log is off.
void Mark(Event event);

// Adds a duration to a named statistic of the log, for timing a stretch of code. The name must be
// a string literal. Does nothing when latency_log is off.
void AddSample(const char* name, uint64_t duration_ns);

// When the event last happened (NowNs time), 0 if it never has.
uint64_t Last(Event event);

// The host display's refresh period measured from kHostVblank marks, 0 while unknown.
uint64_t HostVblankPeriodNs();

}  // namespace rex::latency
