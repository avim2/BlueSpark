# The TTT2 launcher: a small window with four buttons (install tools, choose game, build, play)
# over rex\setup-steps.ps1. Started by "Start Here.cmd" at the top of the package.

param([string]$UpdateUrl = 'https://raw.githubusercontent.com/avim2/BlueSpark/main/latest.json', [switch]$AutoBuild)
$DefaultUpdateUrl = 'https://raw.githubusercontent.com/avim2/BlueSpark/main/latest.json'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$Rex = $PSScriptRoot
$Steps = Join-Path $Rex 'setup-steps.ps1'
$Logs = Join-Path $env:LOCALAPPDATA 'TTT2Native\logs'
New-Item -ItemType Directory -Force $Logs | Out-Null
# (Where the tools and game files go, the free space and synced-folder checks: the lead's E and F, 27 Oct. Defender's
# detections and our missing files: D and G3. The toolchain's script, in the prebuilt package, for the tools' files.)
. (Join-Path $Rex 'tools\data-folder.ps1')
if (Test-Path (Join-Path $Rex 'tools\toolchain.ps1')) { . (Join-Path $Rex 'tools\toolchain.ps1') }
. (Join-Path $Rex 'tools\defender.ps1')

$script:proc = $null
$script:logFile = $null
$script:logPos = 0
$script:current = ''
$script:partial = ''
$script:phase = ''
$script:lastTen = -1

# --- the window -------------------------------------------------------------------------------
$form = New-Object Windows.Forms.Form
$form.Text = 'Tekken Tag Tournament 2: native'
$form.ClientSize = New-Object Drawing.Size(640, 716)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$font = New-Object Drawing.Font('Segoe UI', 10)
$big = New-Object Drawing.Font('Segoe UI', 12, [Drawing.FontStyle]::Bold)
$form.Font = $font

$intro = New-Object Windows.Forms.Label
# (The prebuilt package, rex\prebuilt: a portable compiler is downloaded; no Visual Studio, no Git.)
$script:prebuilt = Test-Path (Join-Path $Rex 'prebuilt\manifest.txt')
$intro.Text = if ($script:prebuilt) {
    'Do the steps in order; each turns green when done. Step 1 downloads a compiler (about 1.1 GB, no Visual Studio needed) and step 3 builds the game on this PC: both take a while the first time.'
} else { 'Do the steps in order. Each one turns green when done. Steps 1 and 3 take a while the first time; leave this window open.' }
$intro.SetBounds(16, 12, 608, 44)
$form.Controls.Add($intro)

function New-StepButton($y, $text) {
    $b = New-Object Windows.Forms.Button
    $b.Text = $text
    $b.Font = $big
    $b.SetBounds(16, $y, 300, 48)
    $form.Controls.Add($b)
    $l = New-Object Windows.Forms.Label
    $l.SetBounds(330, $y + 12, 294, 28)
    $form.Controls.Add($l)
    return @($b, $l)
}
$tools, $toolsState = New-StepButton 64 '1.  Install tools'
$files, $filesState = New-StepButton 120 '2.  Choose my game + update'
$build, $buildState = New-StepButton 176 '3.  Build the game'
$play, $playState = New-StepButton 232 '4.  Play TTT2'
# The fast client (the lead's I, 26 Oct; the owner: "combine fast client into start here through a second play button";
# fastclient/PACKAGING.md 4-8): a second way to play, beside Play, once Build is done; Play itself is unchanged. A package
# without the client (fastclient\bin\) shows it greyed, "coming soon" (the owner, 26 Oct: "grey out the fast client play
# button, i want to tease players with it"). Play's own line goes under the row.
$script:fastClientExe = Join-Path (Split-Path $Rex -Parent) 'fastclient\bin\ttt2-fastclient.exe'
$script:fastClientReady = Test-Path $script:fastClientExe
$fastPlay = New-Object Windows.Forms.Button
$fastPlay.Text = if ($script:fastClientReady) { 'Play BlueSpark' } else { 'Play BlueSpark (coming soon)' }
$fastPlay.Font = if ($script:fastClientReady) { $big } else { New-Object Drawing.Font('Segoe UI', 10, [Drawing.FontStyle]::Bold) }
$fastPlay.SetBounds(330, 232, 294, 48)
$form.Controls.Add($fastPlay)
$playState.SetBounds(16, 281, 608, 15)
# (the owner, 27 Oct: both buttons run the same game; players on either match each other)
$bothPlay = New-Object Windows.Forms.Label
$bothPlay.Text = 'Both run the same game: players on either match each other, with the same account, rating and saves.'
$bothPlay.ForeColor = [Drawing.Color]::DimGray
$bothPlay.SetBounds(16, 297, 608, 15)
$form.Controls.Add($bothPlay)
$playState.Font = New-Object Drawing.Font('Segoe UI', 8)

$log = New-Object Windows.Forms.TextBox
$log.Multiline = $true
$log.ReadOnly = $true
$log.ScrollBars = 'Vertical'
$log.Font = New-Object Drawing.Font('Consolas', 9)
$log.MaxLength = 0
$log.SetBounds(16, 314, 608, 178)   # (under the two buttons' note)
$form.Controls.Add($log)

$openLogs = New-Object Windows.Forms.Button
$openLogs.Text = 'Open log folder'
$openLogs.SetBounds(16, 500, 150, 32)
# (The setup's logs, and the game's own: one window each.)
$GameLogs = Join-Path $Rex 'out\build\win-amd64-release\logs'
$openLogs.Add_Click({
    Start-Process explorer.exe $Logs
    if (Test-Path $GameLogs) { Start-Process explorer.exe $GameLogs }
})
$form.Controls.Add($openLogs)

# Packs the logs, any crash dumps, the build's version and the PC's parts into one zip on the Desktop
# (problem-report.ps1: never the identity, the saves or the rest of rex\userdata), in a window of its own.
$problemReport = New-Object Windows.Forms.Button
$problemReport.Text = 'Report a problem'
$problemReport.SetBounds(176, 500, 160, 32)
$problemReport.Add_Click({
    Start-Process powershell -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$(Join-Path $Rex 'problem-report.ps1')`"")
})
$form.Controls.Add($problemReport)

# Plays the game with its sound recorders on and packs a report for whoever gave out the build
# (sound-report.ps1), in a window of its own.
$soundReport = New-Object Windows.Forms.Button
$soundReport.Text = 'Report a sound problem'
$soundReport.SetBounds(444, 500, 180, 32)
$soundReport.Add_Click({
    Start-Process powershell -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$(Join-Path $Rex 'sound-report.ps1')`"")
})
$form.Controls.Add($soundReport)

$oldSdk = New-Object Windows.Forms.Button
$oldSdk.Text = 'Delete the old SDK folder'
$oldSdk.SetBounds(444, 184, 180, 32)   # (beside Build, whose label is short; Play's row has the fast client's button)
$oldSdk.Visible = $false
$oldSdk.Add_Click({
    $folders = @(Get-ChildItem $env:USERPROFILE -Directory -Filter 'rexsdk-playtest*' -ErrorAction SilentlyContinue)
    $gb = [math]::Round(($folders | ForEach-Object { (Get-ChildItem $_.FullName -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum } | Measure-Object -Sum).Sum / 1GB, 1)
    $text = "This package doesn't use the SDK folder older packages built ($(($folders | ForEach-Object { $_.FullName }) -join ', '), $gb GB).`r`n`r`nDelete it? (No: it stays, and this isn't asked again.)"
    $answer = [Windows.Forms.MessageBox]::Show($form, $text, 'The old SDK folder', 'YesNo', 'Question')
    if ($answer -eq 'Yes') { Start-Step 'cleanup' @() } else { Write-Setting 'oldsdk' 'kept'; Refresh-Buttons }
})
$form.Controls.Add($oldSdk)
$oldSdk.BringToFront()

$busy = New-Object Windows.Forms.Label
$busy.SetBounds(16, 536, 608, 20)
$form.Controls.Add($busy)

# Shown while a step reports progress ("PROGRESS <percent> <text>" lines, e.g. extracting the ISO).
$bar = New-Object Windows.Forms.ProgressBar
$bar.SetBounds(16, 560, 608, 22)
$bar.Minimum = 0
$bar.Maximum = 100
$bar.Visible = $false
$form.Controls.Add($bar)

# --- state ------------------------------------------------------------------------------------
function Read-Status {
    $s = @{}
    $out = & powershell -NoProfile -ExecutionPolicy Bypass -File $Steps -Step status 2>$null
    foreach ($line in $out) { if ($line -match '^(\w+)=(True|False)$') { $s[$Matches[1]] = $Matches[2] -eq 'True' } }
    return $s
}

function Show-State($label, $done, $text) {
    if ($done) { $label.Text = 'Done'; $label.ForeColor = [Drawing.Color]::Green }
    else { $label.Text = $text; $label.ForeColor = [Drawing.Color]::DimGray }
}

function Refresh-Buttons {
    $s = Read-Status
    Show-State $toolsState $s.tools 'Not done yet'
    Show-State $filesState $s.files 'Not done yet'
    Show-State $buildState $s.build 'Not done yet'
    $playState.Text = ''
    $idle = -not $script:proc
    $tools.Enabled = $idle
    $files.Enabled = $idle -and $s.tools
    $build.Enabled = $idle -and $s.tools -and $s.files
    $play.Enabled = $idle -and $s.build
    $fastPlay.Enabled = $idle -and $s.build -and $script:fastClientReady   # (greyed, "coming soon", in a package without the client)
    # (The prebuilt package, once it built: the old Visual Studio-era SDK folders can go; asked, never automatic.)
    $oldSdk.Visible = [bool]$s.oldsdk -and (Read-Setting 'oldsdk' '') -ne 'kept'
    $oldSdk.Enabled = $idle
    if ($changeData) { $changeData.Enabled = $idle }
}

# --- running a step in the background ---------------------------------------------------------
function Start-Step($name, [string[]]$extra) {
    $script:current = $name
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $script:logFile = Join-Path $Logs "$stamp-$name.log"
    $script:logPos = 0
    $script:partial = ''
    $script:phase = ''
    $script:lastTen = -1
    $bar.Visible = $false
    $log.Clear()
    $arguments = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$Steps`"", '-Step', $name) + $extra
    $script:proc = Start-Process powershell -ArgumentList $arguments -WindowStyle Hidden -PassThru `
        -RedirectStandardOutput $script:logFile -RedirectStandardError "$($script:logFile).err"
    $null = $script:proc.Handle   # without this, Windows PowerShell may not report the exit code
    $busy.Text = "Working on step: $name ... (leave this window open)"
    $busy.ForeColor = [Drawing.Color]::DarkOrange
    Refresh-Buttons
}

# A failed build's first error (the lead's F, 27 Oct: a player saw only "ninja: build stopped: subcommand failed"): the
# first compiler or linker error line in the step's log, else Ninja's or CMake's own; with the file Ninja was making.
function Get-FirstBuildError([string]$file) {
    if (-not $file -or -not (Test-Path $file)) { return $null }
    $lines = @(Get-Content $file -ErrorAction SilentlyContinue)
    $first = $null; $failed = $null
    foreach ($l in $lines) {
        if (-not $failed -and $l -match '^FAILED: (.+)$') { $failed = $Matches[1] }
        if ($l -match '(?i)(^|[\s:)])(fatal )?error( [A-Z]+\d+)?\s*:' -and $l -notmatch '^\s*\[\d+/\d+\]') { $first = $l.Trim(); break }
    }
    if (-not $first) { $first = ($lines | Where-Object { $_ -match '^ninja: error|CMake Error|^FAILED:' } | Select-Object -First 1) }
    if (-not $first) { return $null }
    if ($first.Length -gt 400) { $first = $first.Substring(0, 400) + '...' }
    [pscustomobject]@{ Line = $first; Making = $failed }
}
function Show-BuildFailure([string]$file) {
    $e = Get-FirstBuildError $file
    $what = if ($e) { "The first error:`r`n$($e.Line)" + $(if ($e.Making) { "`r`n(while making $($e.Making))" }) } else { 'The build stopped without naming an error.' }
    if ($e) { $log.AppendText("`r`nThe build's first error: $($e.Line)`r`n") }
    $free = Get-Ttt2FreeGB $ThisInstall
    $causes = "The usual causes:`r`n" +
        ("- The disk is full: the build needs about 1 GB free on {0} (it has {1:N1} GB).`r`n" -f (Get-Ttt2DriveName $ThisInstall), $free) +
        "- The folder is inside OneDrive or another synced folder (the Desktop and Documents often are): move the whole folder to C:\ttt2 or another drive and start Start Here from there.`r`n" +
        "- An antivirus (Windows Defender) blocked or removed a file: allow this folder in it, then click Build again."
    $synced = Get-Ttt2SyncedFolder $ThisInstall
    if ($synced) { $causes = "This folder is inside $synced, the most likely cause: move it to C:\ttt2 or another drive.`r`n`r`n$causes" }
    [void][Windows.Forms.MessageBox]::Show($form, "$what`r`n`r`n$causes`r`n`r`nIf it still fails, click Report a problem: it sends us the build's log.", 'The build failed', 'OK', 'Warning')
}

$timer = New-Object Windows.Forms.Timer
$timer.Interval = 700
$timer.Add_Tick({
    Finish-UpdateCheck
    if ($script:logFile -and (Test-Path $script:logFile)) {
        try {
            $fs = [IO.File]::Open($script:logFile, 'Open', 'Read', 'ReadWrite')
            $fs.Seek($script:logPos, 'Begin') | Out-Null
            $reader = New-Object IO.StreamReader($fs)
            $new = $reader.ReadToEnd()
            $script:logPos = $fs.Position
            $reader.Close()
            if ($new) {
                # Whole lines only. PROGRESS lines and Ninja's "[done/total]" lines drive the bar.
                $text = $script:partial + $new.Replace("`r", '')
                $lines = $text.Split("`n")
                $script:partial = $lines[-1]
                $whole = if ($lines.Count -gt 1) { $lines[0..($lines.Count - 2)] } else { @() }
                foreach ($line in $whole) {
                    if ($line -match '^PROGRESS (\d+) ?(.*)$') {
                        # A step's own progress (extracting the ISO): the bar, and a line in the
                        # text at every tenth.
                        $pct = [math]::Min(100, [int]$Matches[1])
                        $what = if ($Matches[2]) { $Matches[2] } else { 'Working' }
                        $bar.Value = $pct
                        $bar.Visible = $true
                        $busy.Text = "${what}: $pct%"
                        if ([int][math]::Floor($pct / 10) -gt $script:lastTen) {
                            $script:lastTen = [int][math]::Floor($pct / 10)
                            $log.AppendText("${what}: $pct%`r`n")
                        }
                        continue
                    }
                    $log.AppendText($line + "`r`n")
                    if ($line -match '^== (.+)$') { $script:phase = $Matches[1] }
                    if ($line -match '^\[(\d+)/(\d+)\]') {
                        # The build's progress, from Ninja's "[done/total]" lines.
                        $done = [int]$Matches[1]; $total = [math]::Max(1, [int]$Matches[2])
                        $bar.Value = [math]::Min(100, [int](100 * $done / $total))
                        $bar.Visible = $true
                        $what = if ($script:phase) { $script:phase } else { 'Building' }
                        $busy.Text = "${what}: $done of $total"
                    }
                }
            }
            # A build writes thousands of lines: keep the window's text to the last part.
            if ($log.TextLength -gt 300000) { $log.Text = $log.Text.Substring($log.TextLength - 150000); $log.SelectionStart = $log.TextLength; $log.ScrollToCaret() }
        } catch { }
    }
    if ($script:proc -and $script:proc.HasExited) {
        if ($script:current -eq 'play') { Update-DisplayNote }
        $code = $script:proc.ExitCode
        $err = "$($script:logFile).err"
        $script:proc = $null
        $bar.Visible = $false
        if ($script:partial -and $script:partial -notmatch '^PROGRESS ') { $log.AppendText($script:partial + "`r`n") }
        $script:partial = ''
        if ($code -eq 0) {
            $busy.Text = "Step finished: $($script:current)"
            $busy.ForeColor = [Drawing.Color]::Green
            if ($script:current -eq 'update') { Restart-AfterUpdate; return }
            if ($script:current -eq 'update-file') { Finish-FileUpdate; return }
            if ($script:current -eq 'adopt') { Finish-Adopt; return }
            if ($script:current -eq 'move') { Update-DataRow }
        } else {
            $busy.Text = "Step failed: $($script:current). See the messages above."
            $busy.ForeColor = [Drawing.Color]::Red
            $errText = if (Test-Path $err) { "$(Get-Content $err -Raw)" } else { '' }
            if ($errText) { $log.AppendText("`r`n" + $errText) }
            # (Windows Defender took xexpatch.exe, the title update's patcher: what to do, in a box as well; the lead's G1.)
            $tail = $log.Text.Substring([Math]::Max(0, $log.TextLength - 4000))
            $shown = $false
            if (($errText + $tail) -match 'Windows Defender removed xexpatch\.exe') {
                [Windows.Forms.MessageBox]::Show($form, $DefenderXexpatchNote, 'Windows Defender removed a file', 'OK', 'Warning') | Out-Null
                $shown = $true
            }
            # (D2 and G3: any of our files gone, named with Defender's threat when it took them.)
            if (-not $shown -and ($missingNote = Get-Ttt2MissingFilesNote $ThisInstall)) {
                [Windows.Forms.MessageBox]::Show($form, $missingNote, 'Files are missing', 'OK', 'Warning') | Out-Null
                $shown = $true
            }
            # (The lead's F: a failed build says its first error, not only Ninja's last line, and the usual causes.)
            if (-not $shown -and $script:current -eq 'build') { Show-BuildFailure $script:logFile }
        }
        Refresh-Buttons
    }
})
$timer.Start()

# --- the buttons ------------------------------------------------------------------------------
$tools.Add_Click({
    if (-not $script:prebuilt) { Start-Step 'tools' @(); return }
    # (The lead's E: room for the compiler first, unless it is all there; what is there counts as taken.)
    $root = Get-Ttt2ToolchainRoot
    if (-not (Test-Path (Join-Path (Get-Ttt2PinFolder $root $script:Ttt2ToolchainPins.llvm) 'ttt2-unpacked.txt')) -and
        -not (Confirm-StepSpace 1 (Get-Ttt2DataFolder) (Get-Ttt2FolderGB $root))) { return }
    # The prebuilt package's compiler needs Microsoft's C++ runtime libraries and Windows SDK, downloaded from
    # Microsoft: only after the player accepts Microsoft's license.
    $text = "Step 1 downloads a compiler: LLVM, CMake and Ninja from their official releases, and Microsoft's C++ runtime libraries and Windows SDK from Microsoft.`r`n`r`n" +
            "Microsoft's parts come under Microsoft's license terms:`r`nhttps://go.microsoft.com/fwlink/?LinkId=2086102`r`n`r`n" +
            "Do you accept Microsoft's license terms? (No: nothing is downloaded.)"
    $answer = [Windows.Forms.MessageBox]::Show($form, $text, "Microsoft's license", 'YesNo', 'Question')
    if ($answer -eq 'Yes') { Start-Step 'tools' @('-AcceptMicrosoftLicense') }
})

# What is wrong with the file picked as the title update, or $null (the same check as setup-steps.ps1's, whose
# param block can't be loaded here; keep the two alike). A friend picked the ISO again (23 Oct).
function Get-UpdateFileProblem([string]$update, [string]$source) {
    if (-not (Test-Path $update -PathType Leaf)) { return 'Choose your title update file (named like TU_174Q22P_...).' }
    $full = [IO.Path]::GetFullPath($update)
    if (($source -and $full -eq [IO.Path]::GetFullPath($source)) -or $full -match '(?i)\.iso$') {
        return "That's your game's disc image, not the title update. The second file is the game's update from your Xbox 360. It's named like TU_174Q22P_0000008000000.00000000000O2 and is about 3 MB. See `"The title update`" in README.txt."
    }
    $size = (Get-Item $full).Length
    if ($size -gt 100MB) { return ("That file is {0:N0} MB, but the title update is about 3 MB and named like TU_174Q22P_... See `"The title update`" in README.txt." -f ($size / 1MB)) }
    $head = New-Object byte[] 4
    $f = [IO.File]::OpenRead($full)
    try { $n = $f.Read($head, 0, 4) } finally { $f.Close() }
    $magic = [Text.Encoding]::ASCII.GetString($head, 0, $n)
    if ($magic -notin @('CON ', 'LIVE', 'PIRS')) {
        return "That file isn't an Xbox 360 update package (it should start with LIVE, CON or PIRS). Pick the file named like TU_174Q22P_0000008000000.00000000000O2, copied off the console as it is."
    }
    return $null
}

$files.Add_Click({
    $choice = [Windows.Forms.MessageBox]::Show(
        "Do you have an ISO file of your TTT2 disc?`n`nYes: pick the .iso file.`nNo: pick the folder that has default.xex and the data*.bin files.",
        'Your game', 'YesNoCancel', 'Question')
    if ($choice -eq 'Cancel') { return }
    $source = $null
    if ($choice -eq 'Yes') {
        $d = New-Object Windows.Forms.OpenFileDialog
        $d.Title = 'Your TTT2 ISO'
        $d.Filter = 'Disc images (*.iso)|*.iso|All files (*.*)|*.*'
        if ($d.ShowDialog() -eq 'OK') { $source = $d.FileName }
    } else {
        $d = New-Object Windows.Forms.FolderBrowserDialog
        $d.Description = 'The folder with default.xex and the data*.bin files'
        if ($d.ShowDialog() -eq 'OK') { $source = $d.SelectedPath }
    }
    if (-not $source) { return }
    $u = New-Object Windows.Forms.OpenFileDialog
    $u.Title = 'Your title update file (named like TU_174Q22P_...)'
    $u.Filter = 'All files (*.*)|*.*'
    # (Checked before the step starts, so a wrong pick costs no ISO extraction: setup-steps.ps1's
    # Get-UpdateFileProblem checks the same again. Asked again until it's right or cancelled.)
    while ($true) {
        if ($u.ShowDialog() -ne 'OK') { return }
        $problem = Get-UpdateFileProblem $u.FileName $source
        if (-not $problem) { break }
        [void][Windows.Forms.MessageBox]::Show($form, $problem, 'Your title update', 'OK', 'Warning')
    }
    # (An ISO is extracted into the data folder: room for it first; the old extraction there is replaced.)
    if ((Test-Path $source -PathType Leaf) -and -not (Confirm-StepSpace 2 (Get-Ttt2DataFolder) (Get-Ttt2FolderGB (Join-Path (Get-Ttt2DataFolder) 'game')))) { return }
    Start-Step 'files' @('-Source', "`"$source`"", '-Update', "`"$($u.FileName)`"")
})

$build.Add_Click({
    # (The lead's F: a build inside OneDrive or another synced folder failed with only "ninja: build stopped"; E: its room.)
    if ($note = Get-Ttt2SyncedFolderNote $ThisInstall 'This folder') {
        $r = [Windows.Forms.MessageBox]::Show($form, "$note`r`n`r`nBuild here anyway?", 'A synced folder', 'YesNo', 'Warning')
        if ($r -ne 'Yes') { return }
    }
    if (-not (Confirm-StepSpace 3 $ThisInstall)) { return }
    Start-Step 'build' @()
})

# The player's name (the gamertag the game shows): kept in player-name.txt in the profile folder
# (%LOCALAPPDATA%\TTT2Native\profile, tools\profile-folder.ps1; rex\userdata\player-name.txt before 23 October, copied
# over once), asked for the first time Play is pressed, changed from the button below. 1 to 15 letters, digits and
# spaces (the game refuses anything else and shows "User").
. (Join-Path $Rex 'tools\profile-folder.ps1')
$NameFile = Join-Path (Get-ProfileFolder) 'player-name.txt'
if (-not (Test-Path $NameFile) -and (Test-Path (Join-Path $Rex 'userdata\player-name.txt'))) {
    New-Item -ItemType Directory -Force (Split-Path $NameFile -Parent) | Out-Null
    Copy-Item (Join-Path $Rex 'userdata\player-name.txt') $NameFile -ErrorAction SilentlyContinue
}
function Get-PlayerName {
    if (Test-Path $NameFile) { return "$(Get-Content $NameFile -Raw)".Trim() }
    return ''
}
function Ask-PlayerName {
    $dialog = New-Object Windows.Forms.Form
    $dialog.Text = 'Your name'
    $dialog.ClientSize = New-Object Drawing.Size(360, 120)
    $dialog.StartPosition = 'CenterParent'
    $dialog.FormBorderStyle = 'FixedDialog'
    $dialog.MaximizeBox = $false; $dialog.MinimizeBox = $false
    $dialog.Font = $font
    $label = New-Object Windows.Forms.Label
    $label.Text = 'The name the game shows for you (1 to 15 letters, digits and spaces):'
    $label.SetBounds(12, 10, 340, 36)
    $dialog.Controls.Add($label)
    $box = New-Object Windows.Forms.TextBox
    $box.Text = Get-PlayerName
    $box.MaxLength = 15
    $box.SetBounds(12, 50, 336, 26)
    $dialog.Controls.Add($box)
    $ok = New-Object Windows.Forms.Button
    $ok.Text = 'OK'; $ok.SetBounds(188, 84, 76, 28); $ok.DialogResult = 'OK'
    $cancel = New-Object Windows.Forms.Button
    $cancel.Text = 'Cancel'; $cancel.SetBounds(272, 84, 76, 28); $cancel.DialogResult = 'Cancel'
    $dialog.Controls.Add($ok); $dialog.Controls.Add($cancel)
    $dialog.AcceptButton = $ok; $dialog.CancelButton = $cancel
    while ($true) {
        if ($dialog.ShowDialog($form) -ne 'OK') { return $false }
        $name = $box.Text.Trim()
        if ($name -match '^[A-Za-z0-9 ]{1,15}$') {
            New-Item -ItemType Directory -Force (Split-Path $NameFile -Parent) | Out-Null
            [IO.File]::WriteAllText($NameFile, $name)
            return $true
        }
        [Windows.Forms.MessageBox]::Show('1 to 15 letters, digits and spaces, please.', 'Your name', 'OK', 'Information') | Out-Null
    }
}
# (The "Your name..." button that was here is "Change name..." in the profile row since 24 October: further down.)

# --- keeping itself up to date (the lead's order of 17 Oct, the owner's word) --------------------------
# At every launch, in the background: rex\package-info.txt (track, patch) against the feed's latest.json
# (-UpdateUrl: the public feed by default, or a local folder for a test). A newer patch of this track is
# downloaded, checked, unzipped and copied over this folder by setup-steps.ps1 -Step update (the saves, the
# game files, the builds and rex\game-folder.txt never touched), then Start Here restarts and builds.
# "Update automatically" (rex\userdata\launcher-settings.txt) off: a banner and an "Update now" button
# instead. Not while the game runs (the game lock): deferred to the next launch.
. (Join-Path $Rex 'tools\game-lock.ps1')
$SettingsFile = Join-Path $Rex 'userdata\launcher-settings.txt'
$UpdateLog = Join-Path $Logs 'update-check.log'
$script:package = @{ track = 'main'; patch = 0; commit = '' }
$script:latest = $null
$script:checkJob = $null
$script:updating = $false

function Read-Package {
    $info = @{ track = 'main'; patch = 0; commit = '' }
    $file = Join-Path $Rex 'package-info.txt'
    if (Test-Path $file) {
        foreach ($line in Get-Content $file) { if ($line -match '^(\w+)=(.*)$') { $info[$Matches[1]] = $Matches[2].Trim() } }
        $info.patch = [int]$info.patch
    }
    return $info
}
function Read-Setting($name, $default) {
    if (Test-Path $SettingsFile) {
        foreach ($line in Get-Content $SettingsFile) { if ($line -match "^$name=(.*)$") { return $Matches[1].Trim() } }
    }
    return $default
}
function Write-Setting($name, $value) {
    $lines = @()
    if (Test-Path $SettingsFile) { $lines = @(Get-Content $SettingsFile | Where-Object { $_ -notmatch "^$name=" }) }
    New-Item -ItemType Directory -Force (Split-Path $SettingsFile -Parent) | Out-Null
    Set-Content $SettingsFile ($lines + "$name=$value")
}
# --- the display (the lead's item A, 17 Oct; the sizes and the greying, 19 Oct) ----------------------
# "Display": Borderless fullscreen (a borderless window over the monitor; the default), Fullscreen (the
# display taken over in its own mode), or a window of a set size: 1280x720 and 1920x1080, and 2560x1440 and
# 3840x2160 only where the monitor the game opens on (the main one) is at least that big. The sizes are the
# window's inside in real pixels (--window_pixel_width/height, runtime patch 32); the game draws at its own
# 1280x720 as on the console and the runtime scales the finished frame to the window.
# "Allow tearing": each frame goes to the screen the moment it is ready (vsync off, the lowest lag); a window
# never tears: while a window size is chosen the box is unticked and greyed (a fullscreen choice again makes it
# tickable; it stays unticked). The window sizes are always in the list (the owner, 21 October: ticking the box
# hid them, and they couldn't be found). Both kept in launcher-settings.txt (display=,
# tearing=), read by run-windows.ps1 and passed to the game as switches. F11 or Alt+Enter toggles fullscreen
# in the game for that run only. When the game's log says the PC can't do tearing, a note says so here.
Add-Type -Namespace TTT2 -Name Screen -MemberDefinition @'
[DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr h);
[DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr h, IntPtr dc);
[DllImport("gdi32.dll")] public static extern int GetDeviceCaps(IntPtr dc, int index);
'@
# The main monitor's size in real pixels (DESKTOPHORZRES, DESKTOPVERTRES: not scaled by Windows' text size).
$dc = [TTT2.Screen]::GetDC([IntPtr]::Zero)
$script:screenWidth = [TTT2.Screen]::GetDeviceCaps($dc, 118)
$script:screenHeight = [TTT2.Screen]::GetDeviceCaps($dc, 117)
[void][TTT2.Screen]::ReleaseDC([IntPtr]::Zero, $dc)
$DisplayNames = [ordered]@{ borderless = 'Borderless fullscreen'; fullscreen = 'Fullscreen' }
foreach ($size in @(@(1280, 720), @(1920, 1080), @(2560, 1440), @(3840, 2160))) {
    $w, $h = $size
    if ($w -gt 1920 -and ($w -gt $script:screenWidth -or $h -gt $script:screenHeight)) { continue }
    $DisplayNames["windowed-${w}x$h"] = "Windowed ${w}x$h"
}
function Is-Windowed($key) { return "$key" -like 'windowed*' }
$displayLabel = New-Object Windows.Forms.Label
$displayLabel.Text = 'Display:'
$displayLabel.SetBounds(16, 664, 56, 20)
$form.Controls.Add($displayLabel)
$displayBox = New-Object Windows.Forms.ComboBox
$displayBox.DropDownStyle = 'DropDownList'
$displayBox.SetBounds(72, 660, 170, 24)
$form.Controls.Add($displayBox)
$allowTearing = New-Object Windows.Forms.CheckBox
$allowTearing.Text = 'Allow tearing (lowest lag, vsync off)'
$allowTearing.SetBounds(256, 660, 368, 24)
$allowTearing.Checked = (Read-Setting 'tearing' 'false') -eq 'true'
$form.Controls.Add($allowTearing)
$displayNote = New-Object Windows.Forms.Label
$displayNote.SetBounds(16, 688, 608, 24)
$displayNote.ForeColor = [Drawing.Color]::Gray
$form.Controls.Add($displayNote)
$script:displayChoice = "$(Read-Setting 'display' 'borderless')".ToLower()
# (An old "windowed" is the 1920x1080 window, or 1280x720 on a monitor too small for it.)
if ($script:displayChoice -eq 'windowed') {
    $script:displayChoice = if ($DisplayNames.Contains('windowed-1920x1080') -and $script:screenWidth -ge 1920 -and $script:screenHeight -ge 1080) { 'windowed-1920x1080' } else { 'windowed-1280x720' }
    Write-Setting 'display' $script:displayChoice
}
if (-not $DisplayNames.Contains($script:displayChoice)) { $script:displayChoice = 'borderless' }
if ($allowTearing.Checked -and (Is-Windowed $script:displayChoice)) { $allowTearing.Checked = $false; Write-Setting 'tearing' 'false' }
$script:filling = $false
function Fill-DisplayBox {
    $script:filling = $true
    $displayBox.Items.Clear()
    foreach ($key in $DisplayNames.Keys) {
        [void]$displayBox.Items.Add($DisplayNames[$key])
    }
    $displayBox.SelectedItem = $DisplayNames[$script:displayChoice]
    $script:filling = $false
}
function Update-TearingBox {
    # A window never tears: the box unticked and greyed while a window size is chosen.
    if (Is-Windowed $script:displayChoice) {
        if ($allowTearing.Checked) { $allowTearing.Checked = $false }
        $allowTearing.Enabled = $false
    } else {
        $allowTearing.Enabled = $true
    }
}
# The game's newest log says whether this PC can do tearing (the runtime asks DXGI at its start).
function Update-DisplayNote {
    $note = 'F11 or Alt+Enter toggles fullscreen in the game for that run (the choice here stays).'
    if (Is-Windowed $script:displayChoice) { $note = 'A window never tears: "Allow tearing" needs a fullscreen choice.' }
    $displayNote.ForeColor = [Drawing.Color]::Gray
    $last = Get-ChildItem $GameLogs -Filter 'ttt2_*.log' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime | Select-Object -Last 1
    if ($last) {
        $line = Select-String -Path $last.FullName -Pattern 'DXGI tearing \(vertical sync off\): (NOT supported|supported)' | Select-Object -First 1
        if ($line -and $line.Matches[0].Groups[1].Value -eq 'NOT supported') {
            $note = "This PC can't do tearing (so says the game's log): frames are shown with vsync as usual."
            if ($allowTearing.Checked) { $displayNote.ForeColor = [Drawing.Color]::DarkOrange }
        }
    }
    $displayNote.Text = $note
}
Fill-DisplayBox
Update-TearingBox
Update-DisplayNote
$displayBox.Add_SelectedIndexChanged({
    if ($script:filling) { return }
    foreach ($key in $DisplayNames.Keys) { if ($DisplayNames[$key] -eq $displayBox.SelectedItem) { $script:displayChoice = $key } }
    Write-Setting 'display' $script:displayChoice
    Update-TearingBox
    Update-DisplayNote
})
$allowTearing.Add_CheckedChanged({
    Write-Setting 'tearing' $(if ($allowTearing.Checked) { 'true' } else { 'false' })
    if ($allowTearing.Checked -and (Is-Windowed $script:displayChoice)) { $script:displayChoice = 'borderless'; Write-Setting 'display' 'borderless' }
    Fill-DisplayBox
    Update-DisplayNote
})

# --- online (the lead's order of 19 Oct): one Play, training always on --------------------------------
# A build with the online code (rex\src\online, Themail's) shows "Online play (test)" here, on by default
# (the owner, 21 Oct; unticked, online=false is kept); with it on, Play signs in to the game's Live
# menus over the internet (setup-steps.ps1's Step-Play adds the switches), and "Play offline (no internet)"
# plays without them. A build without the online code shows neither.
$script:hasOnline = (Test-Path (Join-Path $Rex 'online-build.txt')) -or (Test-Path (Join-Path $Rex 'src\online'))   # (the prebuilt package: the marker)
$onlineBox = New-Object Windows.Forms.CheckBox
$onlineBox.Text = 'Online play (test: training on as well)'
$onlineBox.SetBounds(16, 718, 300, 24)
$onlineBox.Checked = (Read-Setting 'online' 'true') -ne 'false'   # (on by default: the owner, 21 Oct; unticking keeps online=false)
$onlineBox.Add_CheckedChanged({ Write-Setting 'online' $(if ($onlineBox.Checked) { 'true' } else { 'false' }); $playOffline.Enabled = $onlineBox.Checked })
$playOffline = New-Object Windows.Forms.Button
$playOffline.Text = 'Play offline (no internet)'
$playOffline.SetBounds(330, 716, 200, 28)
$playOffline.Enabled = $onlineBox.Checked
if ($script:hasOnline) {
    $form.Controls.Add($onlineBox)
    $form.Controls.Add($playOffline)
    $form.ClientSize = New-Object Drawing.Size(640, 752)
}
# --- the keyboard as player one (the lead's order of 23 Oct, the owner's word): on by default (keyboard=false
# keeps it off); Play then gives the game --ttt2_keyboard=true, our keyboard layer with rex\userdata\keyboard.txt's keys,
# and the SDK's own keyboard always off (--mnk_mode=false; setup-steps.ps1's Step-Play).
$keyboardBox = New-Object Windows.Forms.CheckBox
$keyboardBox.Text = 'Keyboard (player 1): W A S D, U I J K = 1 2 3 4, P = Tag'
$keyboardBox.Checked = (Read-Setting 'keyboard' 'true') -ne 'false'
$keyboardBox.Add_CheckedChanged({ Write-Setting 'keyboard' $(if ($keyboardBox.Checked) { 'true' } else { 'false' }) })
$keyboardRow = $form.ClientSize.Height
$keyboardBox.SetBounds(16, $keyboardRow + 2, 600, 24)
$form.Controls.Add($keyboardBox)
$form.ClientSize = New-Object Drawing.Size(640, ($keyboardRow + 30))
# --- controller vibration (the owner, 24 Oct: off by default, with an option): vibration=true gives Play --ttt2_vibration=true.
$vibrationBox = New-Object Windows.Forms.CheckBox
$vibrationBox.Text = 'Controller vibration'
$vibrationBox.Checked = (Read-Setting 'vibration' 'false') -eq 'true'
$vibrationBox.Add_CheckedChanged({ Write-Setting 'vibration' $(if ($vibrationBox.Checked) { 'true' } else { 'false' }) })
$vibrationRow = $form.ClientSize.Height
$vibrationBox.SetBounds(16, $vibrationRow + 2, 600, 24)
$form.Controls.Add($vibrationBox)
$form.ClientSize = New-Object Drawing.Size(640, ($vibrationRow + 30))
# --- No intro (the owner, 24 Oct: the splash, then straight to the main menu): on by default (nointro=false keeps the
# game's own intro); Play then gives --ttt2_no_intro=true (quick_boot.cpp).
$noIntroBox = New-Object Windows.Forms.CheckBox
$noIntroBox.Text = 'No intro (the splash, then straight to the main menu)'
$noIntroBox.Checked = (Read-Setting 'nointro' 'true') -ne 'false'
$noIntroBox.Add_CheckedChanged({ Write-Setting 'nointro' $(if ($noIntroBox.Checked) { 'true' } else { 'false' }) })
$noIntroRow = $form.ClientSize.Height
$noIntroBox.SetBounds(16, $noIntroRow + 2, 600, 24)
$form.Controls.Add($noIntroBox)
$form.ClientSize = New-Object Drawing.Size(640, ($noIntroRow + 30))
# --- the logs sent by themselves (23 Oct, the owner: "make sure the log is still on, just with an option to turn it off"). "Send each online fight's log" is
# OFF by default since the public launch (27 Oct, the owner's launch decision of 23 Oct; logupload=true turns it on) and gives Play --ttt2_log_autoupload; "Send crash logs" (crashlog=false keeps
# it off) is the game's --ttt2_log_autoupload_crash: a run that crashed has its log sent at the next start (setup-steps.ps1's Step-Play; rex\src\online\log_upload.cpp).
$fightLogBox = New-Object Windows.Forms.CheckBox
$fightLogBox.Text = "Send each online fight's log (play test)"
$fightLogBox.Checked = (Read-Setting 'logupload' 'false') -eq 'true'
$fightLogBox.Add_CheckedChanged({ Write-Setting 'logupload' $(if ($fightLogBox.Checked) { 'true' } else { 'false' }) })
$crashLogBox = New-Object Windows.Forms.CheckBox
$crashLogBox.Text = 'Send crash logs'
$crashLogBox.Checked = (Read-Setting 'crashlog' 'true') -ne 'false'
$crashLogBox.Add_CheckedChanged({ Write-Setting 'crashlog' $(if ($crashLogBox.Checked) { 'true' } else { 'false' }) })
if ($script:hasOnline) {
    $logRow = $form.ClientSize.Height
    $fightLogBox.SetBounds(16, $logRow + 2, 330, 24)
    $crashLogBox.SetBounds(350, $logRow + 2, 270, 24)
    $form.Controls.Add($fightLogBox)
    $form.Controls.Add($crashLogBox)
    $form.ClientSize = New-Object Drawing.Size(640, ($logRow + 30))
}

function Note-Update($text) { Add-Content $UpdateLog "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $text" }
function Game-Running { $l = Get-GameLock; return [bool]($l -and (Test-GameLockLive $l)) }
# This install's fast client is open (it runs its game hidden behind it; closing it closes the game). An update can't
# replace its exe or Qt's DLLs while it runs: it's closed first, or the update waits (fastclient/PACKAGING.md 5).
function FastClient-Running {
    $exe = $script:fastClientExe
    return [bool](Get-Process ttt2-fastclient -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path -eq $exe })
}
# The downloaded mark (the zip's Mark of the Web, which Explorer passes to every file unpacked) cleared on the client's
# files, so Windows doesn't warn on its first start: at each Start Here start (so after an install or an update, which
# restarts it) and before the client starts. The owner's choice of 24 Oct, rather than code-signing.
function Unblock-FastClient {
    $dir = Split-Path (Split-Path $script:fastClientExe)
    if (Test-Path $dir) { Get-ChildItem $dir -Recurse -File | Unblock-File -ErrorAction SilentlyContinue }
}

# (A release by its package-info name, "Release 4.1", as the Discord post calls it; else "Release <patch>".)
function Release-Label($p) { if ($p.name) { "$($p.name)" } else { "Release $($p.patch)" } }

$script:package = Read-Package
$form.Text = 'TTT2 native - ' + $(switch ($script:package.track) {
    'release' { Release-Label $script:package }
    'training' { "training Patch $($script:package.patch)" }
    default { "Patch $($script:package.patch) (main)" } })

$updateBanner = New-Object Windows.Forms.Label
$updateBanner.SetBounds(16, 626, 608, 24)
$updateBanner.ForeColor = [Drawing.Color]::DarkOrange
$updateBanner.Visible = $false
$form.Controls.Add($updateBanner)
$updateNow = New-Object Windows.Forms.Button
$updateNow.Text = 'Update now'
$updateNow.SetBounds(154, 592, 100, 28)
$updateNow.Visible = $false
$form.Controls.Add($updateNow)
$checkUpdates = New-Object Windows.Forms.Button
$checkUpdates.Text = 'Check for updates'
$checkUpdates.SetBounds(262, 592, 160, 28)
$form.Controls.Add($checkUpdates)
$autoUpdate = New-Object Windows.Forms.CheckBox
$autoUpdate.Text = 'Update automatically'
$autoUpdate.SetBounds(432, 594, 192, 24)
$autoUpdate.Checked = (Read-Setting 'auto-update' 'true') -ne 'false'
$autoUpdate.Add_CheckedChanged({ Write-Setting 'auto-update' $(if ($autoUpdate.Checked) { 'true' } else { 'false' }) })
$form.Controls.Add($autoUpdate)

# --- the player's profile: name and icon (the owner, 24 October: a profile icon picker; native_port/PROFILE_ICONS_SPEC_20261024.md) ----------------
# A row under the intro: the player's icon, name, and "Change icon..." / "Change name...". The icon shows beside the name on the leaderboard website and in
# the game. The set is rex\assets\profile-icons (icons.json and a 64 x 64 PNG each: the designer's art, rex\tools\import-profile-icons.ps1). The choice is
# kept in profile-icon.txt in the profile folder (beside player-name.txt) and sent to the server signed with the player's key (rex\tools\identity.ps1);
# the server takes only an icon the player has: the free ones, and the ones it has unlocked for them (their rank in Ranked). Without internet, or before the
# game's first online start (no identity yet), the choice stays here and the game sends it at its next online start (live\icon.reg: the one the server took).
. (Join-Path $Rex 'tools\identity.ps1')
$IconDir = Join-Path $Rex 'assets\profile-icons'
$IconFile = Join-Path (Get-ProfileFolder) 'profile-icon.txt'
$IconCache = Join-Path (Get-ProfileFolder) 'icon-unlocks.json'
$IconSent = Join-Path (Get-ProfileFolder) 'live\icon.reg'
$Worker = if ($env:TTT2_WORKER) { $env:TTT2_WORKER } else { Read-Setting 'worker' 'https://elo.bluespark.site' }

function Read-IconSet {
    $f = Join-Path $IconDir 'icons.json'
    if (-not (Test-Path $f)) { return @() }
    try { return @((Get-Content $f -Raw | ConvertFrom-Json).icons | Where-Object { -not $_.retired -and (Test-Path (Join-Path $IconDir $_.file)) }) } catch { return @() }
}
function Get-IconChoice {
    if (Test-Path $IconFile) { $t = "$(Get-Content $IconFile -Raw)".Trim(); if ($t -match '^\d{1,5}$') { return [int]$t } }
    return 0
}
function Open-IconBitmap($icon) {
    # (a copy in memory: the file is not kept open, so an update can replace it)
    try {
        $ms = New-Object IO.MemoryStream(, [IO.File]::ReadAllBytes((Join-Path $IconDir $icon.file)))
        $img = [Drawing.Image]::FromStream($ms); $bmp = New-Object Drawing.Bitmap($img); $img.Dispose(); $ms.Dispose()
        return $bmp
    } catch { return $null }
}
# A locked icon: dimmed (its colour kept: the set's icons differ by colour), with a padlock in the corner.
function New-LockedBitmap($bmp) {
    $out = New-Object Drawing.Bitmap(64, 64, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [Drawing.Graphics]::FromImage($out)
    $g.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
    [single[][]]$m = @([single[]](0.55, 0, 0, 0, 0), [single[]](0, 0.55, 0, 0, 0), [single[]](0, 0, 0.55, 0, 0), [single[]](0, 0, 0, 0.8, 0), [single[]](0, 0, 0, 0, 1))
    $attr = New-Object Drawing.Imaging.ImageAttributes
    $attr.SetColorMatrix((New-Object Drawing.Imaging.ColorMatrix(, $m)))
    $g.DrawImage($bmp, (New-Object Drawing.Rectangle(0, 0, 64, 64)), 0, 0, $bmp.Width, $bmp.Height, [Drawing.GraphicsUnit]::Pixel, $attr)
    $pen = New-Object Drawing.Pen([Drawing.Color]::White, 3)
    $g.DrawArc($pen, 42, 30, 14, 16, 180, 180)
    $g.FillRectangle((New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(235, 30, 30, 36))), 38, 38, 22, 18)
    $g.DrawRectangle((New-Object Drawing.Pen([Drawing.Color]::White, 2)), 38, 38, 22, 18)
    $g.FillEllipse([Drawing.Brushes]::White, 46, 43, 6, 6)
    $g.Dispose()
    return $out
}
# How to get a locked icon when the server hasn't said (offline): from the rule in icons.json.
function Get-LocalHint($icon) {
    $u = $icon.unlock
    if ($u -is [string]) { if ($u -eq 'manual') { return 'Given by the BlueSpark team' } else { return '' } }
    if ($u.rank) { if ($u.rank -eq 'True Tekken God') { return 'Reach True Tekken God in Ranked (top 20 on the leaderboard, 100+ games)' } else { return "Reach $($u.rank) in Ranked" } }
    if ($u.list) { if ($u.list -eq 'developers') { return 'Given to the BlueSpark developers' } else { return 'Given by the BlueSpark team' } }
    if ($null -ne $u.season) { $last = (@($u.season) | Measure-Object -Maximum).Maximum; if ($last -eq 1) { return 'Playtesters: play a Ranked match before the release reset' } else { return "Players of season $last" } }
    if ($u.games) { return "Play $($u.games) Ranked games" }
    if ($u.wins) { return "Win $($u.wins) Ranked games" }
    return ''
}
function Read-IconCache { if (Test-Path $IconCache) { try { return (Get-Content $IconCache -Raw | ConvertFrom-Json) } catch { } }; return $null }

$ProfileTop = 64; $ProfileShift = 60
foreach ($c in @($form.Controls)) { if ($c.Top -ge $ProfileTop) { $c.Top += $ProfileShift } }   # (everything below the intro moves down for the row)
$form.ClientSize = New-Object Drawing.Size(640, ($form.ClientSize.Height + $ProfileShift))
$profilePic = New-Object Windows.Forms.PictureBox
$profilePic.SetBounds(16, $ProfileTop, 48, 48)
$profilePic.SizeMode = 'Zoom'
$profilePic.Cursor = [Windows.Forms.Cursors]::Hand
$form.Controls.Add($profilePic)
$profileName = New-Object Windows.Forms.Label
$profileName.SetBounds(74, ($ProfileTop + 2), 300, 24)
$profileName.Font = $big
$form.Controls.Add($profileName)
$profileIcon = New-Object Windows.Forms.Label
$profileIcon.SetBounds(74, ($ProfileTop + 27), 300, 20)
$profileIcon.ForeColor = [Drawing.Color]::DimGray
$form.Controls.Add($profileIcon)
$changeIcon = New-Object Windows.Forms.Button
$changeIcon.Text = 'Change icon...'
$changeIcon.SetBounds(384, ($ProfileTop + 8), 120, 32)
$form.Controls.Add($changeIcon)
$changeName = New-Object Windows.Forms.Button
$changeName.Text = 'Change name...'
$changeName.SetBounds(510, ($ProfileTop + 8), 114, 32)
$form.Controls.Add($changeName)

# --- where the tools and game files go (the lead's E, 27 Oct; a player's C: was full): a row under the profile's. The
# choice is kept in %LOCALAPPDATA%\TTT2Native\data-folder.txt (rex\tools\data-folder.ps1); the profile, logs, backups
# and installs.txt stay where they are.
$DataTop = $ProfileTop + $ProfileShift; $DataShift = 40
foreach ($c in @($form.Controls)) { if ($c.Top -ge $DataTop) { $c.Top += $DataShift } }
$form.ClientSize = New-Object Drawing.Size(640, ($form.ClientSize.Height + $DataShift))
$dataLabel = New-Object Windows.Forms.Label
$dataLabel.Text = 'Tools and game files:'
$dataLabel.SetBounds(16, ($DataTop + 8), 150, 22)
$form.Controls.Add($dataLabel)
$dataPath = New-Object Windows.Forms.Label
$dataPath.SetBounds(166, ($DataTop + 8), 336, 22)
$dataPath.AutoEllipsis = $true
$dataPath.ForeColor = [Drawing.Color]::DimGray
$form.Controls.Add($dataPath)
$changeData = New-Object Windows.Forms.Button
$changeData.Text = 'Change...'
$changeData.SetBounds(510, ($DataTop + 2), 114, 32)
$form.Controls.Add($changeData)
$dataTip = New-Object Windows.Forms.ToolTip
function Update-DataRow {
    $d = Get-Ttt2DataFolder
    $free = Get-Ttt2FreeGB $d
    $dataPath.Text = if ($free -ge 0) { "{0} {1:N0} GB free   {2}" -f (Get-Ttt2DriveName $d), $free, $d } else { "(that drive isn't there)   $d" }
    $dataTip.SetToolTip($dataPath, "Where to put the tools and game files: the compiler (step 1, about 5 GB) and your extracted ISO (step 2, about 8 GB).`r`n$d")
}
# The player picks a folder; a TTT2Native folder is made in it (unless it is one). The tools and game files already in
# the old folder: moved there (setup-steps.ps1 -Step move, in the background, with the bar), or left and installed again.
# A folder that already has the tools: used as it is.
function Choose-DataFolder {
    if ($script:proc) { return $false }
    $old = Get-Ttt2DataFolder
    $d = New-Object Windows.Forms.FolderBrowserDialog
    $d.Description = 'Where to put the tools and game files (about 13 GB: the compiler and your extracted ISO). A TTT2Native folder is made in the folder you pick.'
    $d.ShowNewFolderButton = $true
    if ($d.ShowDialog($form) -ne 'OK') { return $false }
    $picked = $d.SelectedPath.TrimEnd('\')
    $new = if ((Split-Path $picked -Leaf) -eq 'TTT2Native') { $picked } else { Join-Path $picked 'TTT2Native' }
    if ($new -eq $old.TrimEnd('\')) { return $false }
    if ($note = Get-Ttt2SyncedFolderNote $new 'That folder') {
        [void][Windows.Forms.MessageBox]::Show($form, "$note`r`n`r`nChoose a folder that isn't synced.", 'Tools and game files', 'OK', 'Warning')
        return $false
    }
    $newTools = (Get-Command Get-Ttt2PinFolder -ErrorAction SilentlyContinue) -and
                (Test-Path (Join-Path (Get-Ttt2PinFolder (Join-Path $new 'toolchain') $script:Ttt2ToolchainPins.llvm) 'ttt2-unpacked.txt'))
    if ($newTools) {
        $r = [Windows.Forms.MessageBox]::Show($form, "$new already has the tools. Use them?`r`n`r`n(What is in $old stays there; you can delete it yourself.)", 'Tools and game files', 'YesNo', 'Question')
        if ($r -ne 'Yes') { return $false }
        Set-Ttt2DataFolder $new; Update-DataRow; Refresh-Buttons
        return $true
    }
    $have = @($script:Ttt2DataParts | Where-Object { Test-Path (Join-Path $old $_) })
    if ($have.Count) {
        $gb = ($have | ForEach-Object { Get-Ttt2FolderGB (Join-Path $old $_) } | Measure-Object -Sum).Sum
        $r = [Windows.Forms.MessageBox]::Show($form,
            ("Move the tools and game files you have ({0:N1} GB in {1}) to {2}?`r`n`r`nYes: move them (a few minutes to another drive).`r`nNo: leave them where they are and install again in the new folder (steps 1 and 2 again; then you can delete {1} yourself)." -f $gb, $old, $new),
            'Tools and game files', 'YesNoCancel', 'Question')
        if ($r -eq 'Cancel') { return $false }
        if ($r -eq 'Yes') { Start-Step 'move' @('-From', "`"$old`"", '-To', "`"$new`""); return $true }
    }
    Set-Ttt2DataFolder $new; Update-DataRow; Refresh-Buttons
    return $true
}
$changeData.Add_Click({ [void](Choose-DataFolder) })
# Before steps 1, 2 and 3 (the lead's E): the drive's free space against what the step needs; short, the sentence and
# (steps 1 and 2) another folder offered. True when the step may start.
function Confirm-StepSpace([int]$n, [string]$path, [double]$haveGB = 0) {
    $problem = Get-Ttt2SpaceProblem $n $path $haveGB
    if (-not $problem) { return $true }
    if ($n -eq 3) {
        [void][Windows.Forms.MessageBox]::Show($form, "$problem The build goes in this folder. Free some space on that drive, then click Build again.", 'Not enough disk space', 'OK', 'Warning')
        return $false
    }
    $r = [Windows.Forms.MessageBox]::Show($form, "$problem`r`n`r`nChoose another folder for the tools and game files? (No: free some space on that drive yourself first.)", 'Not enough disk space', 'YesNo', 'Warning')
    if ($r -eq 'Yes') { [void](Choose-DataFolder) }
    return $false
}
Update-DataRow

function Update-ProfileRow {
    $set = Read-IconSet
    $id = Get-IconChoice
    $icon = $set | Where-Object { [int]$_.id -eq $id } | Select-Object -First 1
    if (-not $icon) { $icon = $set | Where-Object { [int]$_.id -eq 0 } | Select-Object -First 1 }
    if ($profilePic.Image) { $profilePic.Image.Dispose() }
    $profilePic.Image = if ($icon) { Open-IconBitmap $icon } else { $null }
    $n = Get-PlayerName
    $profileName.Text = if ($n) { $n } else { '(no name yet: Change name...)' }
    $profileIcon.Text = if ($icon) { "Icon: $($icon.name)" } else { 'Icon: none (this package has no icons)' }
    $changeIcon.Enabled = [bool]$set.Count
}
$changeName.Add_Click({ if (Ask-PlayerName) { Update-ProfileRow } })

# The picker: the player's icons first (the default emblem, the free ones, the ones earned), then the locked ones greyed with how to get them.
function Show-IconPicker {
    $set = Read-IconSet
    if (-not $set.Count) { return }
    $xuid = Read-IdentityXuid (Get-ProfileFolder)
    $dlg = New-Object Windows.Forms.Form
    $dlg.Text = 'Your profile icon'
    $dlg.ClientSize = New-Object Drawing.Size(600, 540)
    $dlg.StartPosition = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    $dlg.Font = $font
    $intro = New-Object Windows.Forms.Label
    $intro.Text = 'Shown beside your name on the leaderboard website and in the game. Locked icons unlock as you rank up in Ranked, and stay yours.'
    $intro.SetBounds(12, 10, 576, 40)
    $dlg.Controls.Add($intro)
    $lv = New-Object Windows.Forms.ListView
    $lv.View = 'LargeIcon'; $lv.MultiSelect = $false; $lv.HideSelection = $false
    $lv.SetBounds(12, 52, 576, 382)
    $images = New-Object Windows.Forms.ImageList
    $images.ImageSize = New-Object Drawing.Size(64, 64)
    $images.ColorDepth = 'Depth32Bit'
    $lv.LargeImageList = $images
    $gYours = New-Object Windows.Forms.ListViewGroup('Yours')
    $gLocked = New-Object Windows.Forms.ListViewGroup('Locked')
    [void]$lv.Groups.Add($gYours); [void]$lv.Groups.Add($gLocked)
    $dlg.Controls.Add($lv)
    $info = New-Object Windows.Forms.Label
    $info.SetBounds(12, 440, 576, 44)
    $dlg.Controls.Add($info)
    $status = New-Object Windows.Forms.Label
    $status.SetBounds(12, 488, 380, 44)
    $status.ForeColor = [Drawing.Color]::DimGray
    $dlg.Controls.Add($status)
    $ok = New-Object Windows.Forms.Button
    $ok.Text = 'Use this icon'; $ok.SetBounds(398, 496, 108, 32)
    $cancel = New-Object Windows.Forms.Button
    $cancel.Text = 'Cancel'; $cancel.SetBounds(512, 496, 76, 32); $cancel.DialogResult = 'Cancel'
    $dlg.Controls.Add($ok); $dlg.Controls.Add($cancel); $dlg.CancelButton = $cancel

    foreach ($icon in $set) {
        $bmp = Open-IconBitmap $icon
        if (-not $bmp) { continue }
        $images.Images.Add("u$($icon.id)", $bmp)
        $images.Images.Add("l$($icon.id)", (New-LockedBitmap $bmp))
    }
    # What the player has: the server's answer (GET /v1/icons), or the last one kept here, or (neither) only the free icons and the one chosen.
    $state = @{ answer = (Read-IconCache); fresh = $false; seen = @() }
    if ($state.answer -and $state.answer.xuid -ne $xuid) { $state.answer = $null }   # (another player's answer: not used)
    if ($state.answer) { $state.seen = @($state.answer.earned | ForEach-Object { [int]$_.id }) }
    $current = Get-IconChoice
    $fill = {
        $a = $state.answer
        $earned = @(); $locked = @{}
        if ($a) { $earned = @($a.earned | ForEach-Object { [int]$_.id }); foreach ($l in @($a.locked)) { $locked[[int]$l.id] = $l } }
        $keep = if ($lv.SelectedItems.Count) { [int]$lv.SelectedItems[0].Tag } else { $current }
        $lv.BeginUpdate(); $lv.Items.Clear()
        foreach ($icon in $set) {
            $id = [int]$icon.id
            if (-not $images.Images.ContainsKey("u$id")) { continue }
            $free = $icon.unlock -is [string] -and $icon.unlock -eq 'default'
            $have = $free -or ($earned -contains $id) -or (-not $a -and $id -eq $current)
            if ($a -and -not $have -and -not $locked.ContainsKey($id)) { continue }   # (the server doesn't list it: no longer offered, or given by hand)
            if (-not $a -and -not $have -and ($icon.unlock -eq 'manual' -or $icon.unlock.list)) { continue }   # (no answer: an icon only given by hand stays hidden)
            $text = "$($icon.name)"
            if ($have -and -not $free -and $state.fresh -and ($state.seen -notcontains $id)) { $text += ' (new!)' }
            $item = New-Object Windows.Forms.ListViewItem($text, $(if ($have) { "u$id" } else { "l$id" }))
            $item.Tag = $id
            $item.Group = if ($have) { $gYours } else { $gLocked }
            [void]$lv.Items.Add($item)
            if ($id -eq $keep) { $item.Selected = $true; $item.Focused = $true }
        }
        $lv.EndUpdate()
        if ($lv.SelectedItems.Count) { $lv.SelectedItems[0].EnsureVisible() }
    }
    $describe = {
        if (-not $lv.SelectedItems.Count) { $info.Text = ''; $ok.Enabled = $false; return }
        $item = $lv.SelectedItems[0]; $id = [int]$item.Tag
        $icon = $set | Where-Object { [int]$_.id -eq $id } | Select-Object -First 1
        if ($item.Group -eq $gYours) { $info.Text = "$($icon.name)$(if ($id -eq $current) { ' (your icon now)' })"; $ok.Enabled = $id -ne $current; return }
        $l = if ($state.answer) { @($state.answer.locked) | Where-Object { [int]$_.id -eq $id } | Select-Object -First 1 } else { $null }
        $hint = if ($l -and $l.hint) { $l.hint } else { Get-LocalHint $icon }
        $more = if ($l -and $l.now) { " You are $($l.now) now." } elseif ($l -and $l.need) { " $($l.have) / $($l.need) so far." } else { '' }
        $info.Text = "$($icon.name): locked. $hint.$more"
        $ok.Enabled = $false
    }
    $lv.Add_SelectedIndexChanged($describe)
    & $fill; & $describe

    # The server's answer, in the background (5 s).
    # (Handlers run in their own scope each time: what they change lives in these tables, never in plain variables.)
    $net = @{ job = $null }
    if (-not $xuid) { $status.Text = "Play online once and the icons you unlock in Ranked show here. Your choice is kept on this PC until then." }
    else {
        $status.Text = 'Checking what you have unlocked...'
        $net.job = Start-Job -ArgumentList $Worker, $xuid -ScriptBlock {
            param($worker, $x)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; return (Invoke-WebRequest -UseBasicParsing -Uri "$worker/v1/icons?x=$x" -TimeoutSec 6 -Headers @{ 'User-Agent' = 'ttt2-launcher' }).Content }
            catch { return 'ERROR ' + $_.Exception.Message }
        }
    }
    $saving = @{ job = $null; id = 0; at = $null }
    $tick = New-Object Windows.Forms.Timer
    $tick.Interval = 300
    $tick.Add_Tick({
        $j = $net.job
        if ($j -and $j.State -ne 'Running') {
            $text = "$(Receive-Job $j -ErrorAction SilentlyContinue | Select-Object -Last 1)"
            Remove-Job $j -Force -ErrorAction SilentlyContinue; $net.job = $null
            $a = $null; if ($text -and -not $text.StartsWith('ERROR')) { try { $a = $text | ConvertFrom-Json } catch { } }
            if ($a -and $a.ok) {
                $a | Add-Member -NotePropertyName xuid -NotePropertyValue $xuid -Force
                $state.answer = $a; $state.fresh = $true
                try { [IO.File]::WriteAllText($IconCache, ($a | ConvertTo-Json -Depth 5 -Compress)) } catch { }
                $status.Text = ''
                & $fill; & $describe
            } else {
                $status.Text = if ($state.answer) { "The server didn't answer: this is what this PC last heard." } else { "The server didn't answer: only the free icons are shown." }
            }
        }
        $s = $saving.job
        if ($s -and ($s.State -ne 'Running' -or ((Get-Date) - $saving.at).TotalSeconds -gt 10)) {
            $r = "$(Receive-Job $s -ErrorAction SilentlyContinue | Select-Object -Last 1)"
            Remove-Job $s -Force -ErrorAction SilentlyContinue; $saving.job = $null
            if ($r.StartsWith('OK')) {
                [IO.File]::WriteAllText($IconFile, "$($saving.id)")
                New-Item -ItemType Directory -Force (Split-Path $IconSent -Parent) | Out-Null
                [IO.File]::WriteAllText($IconSent, "$xuid $($saving.id)")
                $playState.Text = 'Icon saved. The leaderboard shows it soon.'
                $dlg.DialogResult = 'OK'; $dlg.Close()
            } elseif ($r.StartsWith('REFUSED')) {
                $status.Text = "The server didn't take it: $($r.Substring(8))"
                $lv.Enabled = $true; $cancel.Enabled = $true; & $describe
            } else {
                [IO.File]::WriteAllText($IconFile, "$($saving.id)")   # (offline: kept here; the game sends it at its next online start)
                $playState.Text = 'Icon saved here: sent when you next play online.'
                $dlg.DialogResult = 'OK'; $dlg.Close()
            }
        }
    })
    $tick.Start()
    $choose = {
        if (-not $ok.Enabled -or -not $lv.SelectedItems.Count) { return }
        $id = [int]$lv.SelectedItems[0].Tag
        New-Item -ItemType Directory -Force (Split-Path $IconFile -Parent) | Out-Null
        if (-not $xuid) {
            [IO.File]::WriteAllText($IconFile, "$id")
            $playState.Text = 'Icon saved here: sent when you next play online.'
            $dlg.DialogResult = 'OK'; $dlg.Close(); return
        }
        $ok.Enabled = $false; $lv.Enabled = $false; $cancel.Enabled = $false
        $status.Text = 'Saving...'
        $saving.id = $id; $saving.at = Get-Date
        $saving.job = Start-Job -ArgumentList $Rex, (Get-ProfileFolder), $Worker, $id -ScriptBlock {
            param($rex, $profile, $worker, $icon)
            . (Join-Path $rex 'tools\identity.ps1')
            $me = Read-Identity $profile
            if (-not $me) { return 'OFFLINE no key' }
            $ts = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
            $sig = Sign-Text $me.ec "TTT2-ICON`n1`n$($me.xuid)`n$icon`n$ts"
            $body = '{"xuid":"' + $me.xuid + '","icon":' + [int]$icon + ',"ts":' + $ts + ',"sig":"' + $sig + '"}'
            try {
                [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
                $null = Invoke-WebRequest -UseBasicParsing -Method Post -Uri "$worker/v1/icon" -Body $body -ContentType 'application/json' -TimeoutSec 8 -Headers @{ 'User-Agent' = 'ttt2-launcher' }
                return 'OK'
            } catch {
                $code = 0; try { $code = [int]$_.Exception.Response.StatusCode } catch { }
                if ($code -ge 400 -and $code -lt 500 -and $code -ne 429) {
                    $msg = "$($_.ErrorDetails.Message)"; try { $msg = ($msg | ConvertFrom-Json).msg } catch { }
                    return "REFUSED $msg"
                }
                return 'OFFLINE ' + $_.Exception.Message
            }
        }
    }
    $ok.Add_Click($choose)
    $lv.Add_ItemActivate($choose)
    [void]$dlg.ShowDialog($form)
    $tick.Stop(); $tick.Dispose()
    foreach ($j in @($net.job, $saving.job)) { if ($j) { Remove-Job $j -Force -ErrorAction SilentlyContinue } }
    # (what the player has now seen: no "new!" next time)
    if ($state.fresh -and $state.answer) { try { [IO.File]::WriteAllText($IconCache, ($state.answer | ConvertTo-Json -Depth 5 -Compress)) } catch { } }
    $dlg.Dispose()
    Update-ProfileRow
}
$changeIcon.Add_Click({ Show-IconPicker })
$profilePic.Add_Click({ Show-IconPicker })
Update-ProfileRow

# The check, in a job (5 s), its answer taken by the timer below.
function Start-UpdateCheck {
    if ($script:checkJob) { return }
    $updateBanner.Text = 'Checking for updates...'; $updateBanner.Visible = $true; $updateNow.Visible = $false
    $script:checkJob = Start-Job -ArgumentList $UpdateUrl, $script:package.track -ScriptBlock {
        param($url, $track)
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            if (Test-Path $url -PathType Container) { $feed = Get-Content (Join-Path $url 'latest.json') -Raw | ConvertFrom-Json }
            else { $feed = Invoke-RestMethod $url -TimeoutSec 5 -Headers @{ 'User-Agent' = 'ttt2-launcher' } }
            # (The public feed is flat: one build line, "release" N.)
            if ($feed.release) { return ($feed | ConvertTo-Json -Compress) }
            return 'ERROR: the feed has no release number'
        } catch { return 'ERROR: ' + $_.Exception.Message }
    }
}
function Finish-UpdateCheck {
    if (-not $script:checkJob -or $script:checkJob.State -eq 'Running') { return }
    $answer = Receive-Job $script:checkJob -ErrorAction SilentlyContinue | Select-Object -Last 1
    Remove-Job $script:checkJob -Force -ErrorAction SilentlyContinue
    $script:checkJob = $null
    # (A dropped zip being installed keeps its banner: the feed's answer only goes to the log then.)
    if ($script:zipUpdate) { Note-Update "The feed's answer (a dropped zip is being installed): $answer"; return }
    if (-not $answer -or "$answer" -like 'ERROR:*') {
        Note-Update "The check failed: $answer"
        $updateBanner.Visible = $false
        return
    }
    $script:latest = "$answer" | ConvertFrom-Json
    # (Only a public package, track=release with patch=N, updates itself: when the feed's release number is
    # higher. An internal one (main, training) only hears that a release is out.)
    $script:latest | Add-Member -NotePropertyName patch -NotePropertyValue ([int]$script:latest.release) -Force
    if ($script:package.track -ne 'release') {
        if ([int]$script:latest.patch -gt $script:package.patch) {
            Note-Update "$(Release-Label $script:latest) is out; this is an internal $($script:package.track) package (Patch $($script:package.patch)): it does not update from the public feed."
            $updateBanner.Text = "$(Release-Label $script:latest) is out (this is an internal build: it does not update itself)."
            $updateBanner.ForeColor = [Drawing.Color]::DarkOrange
        } else {
            Note-Update "$(Release-Label $script:latest) is the newest public build; this is an internal $($script:package.track) package (Patch $($script:package.patch))."
            $updateBanner.Visible = $false
        }
        return
    }
    if ([int]$script:latest.patch -le $script:package.patch) {
        Note-Update "$(Release-Label $script:latest) is the newest; this is $(Release-Label $script:package)."
        $updateBanner.Text = "You have the newest build ($(Release-Label $script:package))."
        $updateBanner.ForeColor = [Drawing.Color]::Green
        return
    }
    Note-Update "$(Release-Label $script:latest) is out (this is $(Release-Label $script:package))."
    # (Never the same package twice: an update that left the patch number behind (a feed and a zip that disagree)
    # would loop through restarts otherwise, 17 Oct.)
    if ((Read-Setting 'last-update' '') -eq "$($script:latest.commit)") {
        Note-Update "$(Release-Label $script:latest) ($($script:latest.commit)) was installed already and this folder still says $(Release-Label $script:package): not again."
        $updateBanner.Text = "$(Release-Label $script:latest) was installed, but this folder says $(Release-Label $script:package): tell whoever gave you the build."
        $updateBanner.ForeColor = [Drawing.Color]::Red
        return
    }
    $updateBanner.ForeColor = [Drawing.Color]::DarkOrange
    if ((Game-Running) -or (FastClient-Running)) {
        $updateBanner.Text = "$(Release-Label $script:latest) is out: it will be installed after you close the game, at the next start."
        $updateNow.Visible = $true
        return
    }
    if ($autoUpdate.Checked -and -not $script:proc) { Start-Update; return }
    $updateBanner.Text = "$(Release-Label $script:latest) is out."
    $updateNow.Visible = $true
}
function Start-Update {
    if ($script:proc -or -not $script:latest) { return }
    if (Game-Running) { $updateBanner.Text = 'Update after you close the game.'; return }
    if (FastClient-Running) { $updateBanner.Text = 'Update after you close Play BlueSpark.'; return }
    $script:updating = $true
    $updateBanner.Text = "Updating to $(Release-Label $script:latest)..."; $updateNow.Visible = $false
    Start-Step 'update' @('-UpdateUrl', "`"$UpdateUrl`"", '-Patch', "$($script:latest.patch)")
    $log.AppendText("Updating to $(Release-Label $script:latest):`r`n")
    foreach ($note in @($script:latest.notes)) { $log.AppendText("  - $note`r`n") }
}
# After the update step: this launcher is the old one, so the new one is started (it builds by itself).
function Restart-AfterUpdate {
    $script:updating = $false
    Write-Setting 'last-update' "$($script:latest.commit)"   # (only an update that went through counts)
    $arguments = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', "`"$(Join-Path $Rex 'launcher.ps1')`"", '-AutoBuild')
    if ($UpdateUrl -ne $DefaultUpdateUrl) { $arguments += @('-UpdateUrl', "`"$UpdateUrl`"") }
    Start-Process powershell -ArgumentList $arguments -WindowStyle Hidden
    $form.Close()
}
# --- updates from a downloaded zip (the lead's orders of 24 Oct, afdcf87 and 3db866c: the owner posts each release's zip
# on his Discord, whose links expire, so Start Here can't fetch it; and, on a hacker friend's advice, an update starts
# only when the player drags a zip onto this window: no Downloads scan, no file button). The zip is checked before
# anything else (rex\tools\package-check.ps1: the owner's signature over its file list, no entry outside its folder,
# this track), the player asked "Release N, built on <date>. Update now?", then the step (setup-steps.ps1 update-file)
# checks it again, unzips it in its work folder and copies it over this folder as an update does; then the zip can be
# deleted, and Start Here restarts and relinks. The GitHub feed above stays for when the builds repo is public.
. (Join-Path $Rex 'tools\package-check.ps1')
$script:zipUpdate = $null   # @{ path; patch; date; commit } of the zip being installed
function Start-FileUpdate([string]$path) {
    if ($script:proc) { [void][Windows.Forms.MessageBox]::Show($form, 'A step is running. Drop the zip again when it has finished.', 'TTT2'); return }
    if (FastClient-Running) { [void][Windows.Forms.MessageBox]::Show($form, 'Close Play BlueSpark first (its game closes with it), then drop the zip onto this window again.', 'TTT2'); return }
    if (Game-Running) { [void][Windows.Forms.MessageBox]::Show($form, 'Close the game first, then drop the zip onto this window again.', 'TTT2'); return }
    $check = Test-ReleaseZip $path
    if (-not $check.ok) { [void][Windows.Forms.MessageBox]::Show($form, $check.why, 'TTT2', 'OK', 'Warning'); return }
    $info = $check.info
    if ($info.track -ne $script:package.track) {
        [void][Windows.Forms.MessageBox]::Show($form, "$(Split-Path $path -Leaf) is a $($info.track) package, and this folder is a $($script:package.track) one, so it isn't installed here.", 'TTT2', 'OK', 'Warning')
        return
    }
    $built = if ($info.date) { ", built on $($info.date)" } else { '' }
    $older = $info.patch -le $script:package.patch
    $question = if ($older) { "$(Release-Label $info)$built. This folder has $(Release-Label $script:package), which is newer or the same.`r`n`r`nInstall $(Release-Label $info) anyway?" }
                else { "$(Release-Label $info)$built.`r`n`r`nUpdate now?" }
    if ([Windows.Forms.MessageBox]::Show($form, $question, 'TTT2', 'YesNo', 'Question') -ne 'Yes') { return }
    $info.path = $path
    $script:zipUpdate = $info
    $script:updating = $true
    $updateBanner.Text = "Updating to $(Release-Label $info)..."; $updateBanner.ForeColor = [Drawing.Color]::DarkOrange
    $updateBanner.Visible = $true; $updateNow.Visible = $false
    $extra = @('-ZipFile', "`"$path`"")
    if ($older) { $extra += '-AllowOlder' }
    $log.AppendText("Updating to $(Release-Label $info) from $(Split-Path $path -Leaf):`r`n")
    Start-Step 'update-file' $extra
}
# Whether a file is inside an install's folder (or a clone's, such as its rex\out\pkg): a folder above it holds
# rex\launcher.ps1, or is one installs.txt names. Such a zip isn't offered for deletion: in the owner's drop test of
# 24 Oct the zip dragged from rex\out\pkg was the package itself, and "Delete the downloaded zip?" took it.
function Test-InsideInstall([string]$path) {
    $full = [IO.Path]::GetFullPath($path)
    $lines = @(if (Test-Path $InstallsFile) { Get-Content $InstallsFile })
    $known = @($lines | Where-Object { $_ } | ForEach-Object { [IO.Path]::GetFullPath($_).TrimEnd('\') + '\' })
    if ($known | Where-Object { $full.StartsWith($_, [StringComparison]::OrdinalIgnoreCase) }) { return $true }
    $dir = Split-Path $full -Parent
    while ($dir) {
        if (Test-Path (Join-Path $dir 'rex\launcher.ps1')) { return $true }
        $up = Split-Path $dir -Parent
        if ($up -eq $dir) { break }
        $dir = $up
    }
    return $false
}
# After the update-file step: "Updated to Release N", the zip offered for deletion (not one inside an install), then the
# new Start Here (relinks).
function Finish-FileUpdate {
    $script:updating = $false
    $info = $script:zipUpdate
    $now = Read-Package
    $log.AppendText("Updated to $(Release-Label $now).`r`n")
    if ($info -and (Test-Path $info.path) -and -not (Test-InsideInstall $info.path)) {
        $r = [Windows.Forms.MessageBox]::Show($form, "Updated to $(Release-Label $now).`r`n`r`nDelete the downloaded zip ($(Split-Path $info.path -Leaf))?", 'TTT2', 'YesNo', 'Question')
        if ($r -eq 'Yes') {
            Remove-Item $info.path -Force -ErrorAction SilentlyContinue
            Remove-Item "$($info.path).sha256" -Force -ErrorAction SilentlyContinue
        }
    }
    if ($info) { Write-Setting 'last-update' "$($info.commit)" }
    $arguments = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', "`"$(Join-Path $Rex 'launcher.ps1')`"", '-AutoBuild')
    if ($UpdateUrl -ne $DefaultUpdateUrl) { $arguments += @('-UpdateUrl', "`"$UpdateUrl`"") }
    Start-Process powershell -ArgumentList $arguments -WindowStyle Hidden
    $form.Close()
}
# (The drop works anywhere on the window: the form and every control on it take it.)
$onDragEnter = {
    $files = $_.Data.GetData([Windows.Forms.DataFormats]::FileDrop)
    if ($files -and @($files).Count -eq 1 -and "$(@($files)[0])" -like '*.zip') { $_.Effect = 'Copy' } else { $_.Effect = 'None' }
}
$onDragDrop = {
    $files = $_.Data.GetData([Windows.Forms.DataFormats]::FileDrop)
    if ($files) { Start-FileUpdate "$(@($files)[0])" }
}
foreach ($target in @($form) + @($form.Controls)) {
    $target.AllowDrop = $true
    $target.Add_DragEnter($onDragEnter)
    $target.Add_DragDrop($onDragDrop)
}

# --- the new-folder rescue (the lead's order of 24 Oct, B): every Start Here writes its folder to
# %LOCALAPPDATA%\TTT2Native\installs.txt. A folder with no build that finds an earlier install with one offers to
# update that install with this package instead (setup-steps.ps1 adopt: copied over it as an update is, so it only
# relinks; the game's build folder knows its own path, and copied here it would be built again from nothing), then
# opens that install's Start Here; this folder can be deleted then (asked, never by itself).
$InstallsFile = Join-Path (Join-Path $env:LOCALAPPDATA 'TTT2Native') 'installs.txt'
$ThisInstall = (Resolve-Path (Split-Path $Rex -Parent)).Path
function Register-Install {
    $known = @(if (Test-Path $InstallsFile) { Get-Content $InstallsFile })
    if ($known -notcontains $ThisInstall) { Add-Content $InstallsFile $ThisInstall }
}
function Find-PreviousInstall {
    $exe = 'rex\out\build\win-amd64-release\ttt2.exe'
    if (Test-Path (Join-Path $ThisInstall $exe)) { return $null }
    $candidates = @(if (Test-Path $InstallsFile) { Get-Content $InstallsFile })
    # (Only the folders our own Start Here wrote there: nothing else on the PC is looked through, the lead's 24 Oct.)
    $found = @($candidates | Select-Object -Unique | Where-Object { $_ -and $_ -ne $ThisInstall -and (Test-Path (Join-Path $_ $exe)) -and
                                                          (Test-Path (Join-Path $_ 'rex\setup-steps.ps1')) -and -not (Test-Path (Join-Path $_ '.git')) })
    if (-not $found.Count) { return $null }
    return ($found | Sort-Object { (Get-Item (Join-Path $_ $exe)).LastWriteTime } | Select-Object -Last 1)
}
function Offer-PreviousInstall {
    $previous = Find-PreviousInstall
    if (-not $previous) { return }
    $r = [Windows.Forms.MessageBox]::Show($form, "This folder has no build yet, and you have a previous install:`r`n$previous`r`n`r`nUse your previous install? This package is copied over it, so your game files, settings, saves and build stay, and the game only needs a quick relink.`r`n`r`n(No: set this folder up from the start.)", 'TTT2', 'YesNo', 'Question')
    if ($r -ne 'Yes') { return }
    $script:adoptInto = $previous
    $log.AppendText("Copying this package over $previous...`r`n")
    Start-Step 'adopt' @('-Into', "`"$previous`"")
}
function Finish-Adopt {
    $previous = $script:adoptInto
    Start-Process powershell -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', "`"$(Join-Path $previous 'rex\launcher.ps1')`"", '-AutoBuild') -WindowStyle Hidden
    $r = [Windows.Forms.MessageBox]::Show($form, "Your previous install has this package now, and its Start Here is opening.`r`n`r`nDelete this new folder ($ThisInstall)?", 'TTT2', 'YesNo', 'Question')
    if ($r -eq 'Yes') {
        # (After this window closes: a hidden PowerShell waits for it, then removes the folder.)
        $me = $PID
        $script = "Wait-Process -Id $me -ErrorAction SilentlyContinue; Start-Sleep -Seconds 2; Remove-Item -LiteralPath '$ThisInstall' -Recurse -Force -ErrorAction SilentlyContinue"
        Start-Process powershell -ArgumentList @('-NoProfile', '-WindowStyle', 'Hidden', '-Command', $script) -WindowStyle Hidden
    }
    $form.Close()
}

$updateNow.Add_Click({ Start-Update })
$checkUpdates.Add_Click({ Start-UpdateCheck })

function Start-Play([switch]$Offline) {
    if (-not (Get-PlayerName)) { Ask-PlayerName | Out-Null }
    $arguments = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$Steps`"", '-Step', 'play')
    if ($Offline) { $arguments += '-Offline' }
    # (Hidden as before, but its output kept beside the other steps' logs, and an error shown: a Play that stopped
    # before the game started said nothing at all, 22 Oct.)
    $script:playLog = Join-Path $Logs "$(Get-Date -Format 'yyyyMMdd-HHmmss')-play.log"
    $script:playProc = Start-Process powershell -ArgumentList $arguments -WindowStyle Hidden -PassThru `
        -RedirectStandardOutput $script:playLog -RedirectStandardError "$($script:playLog).err"
    $null = $script:playProc.Handle   # (kept, or Windows PowerShell can't read its exit code later)
    $playWatch.Start()
    $playState.Text = $(if ($Offline) { 'Starting the game offline...' } else { 'Starting the game...' })
}
# Play's step ends once the game is up (run-windows.ps1 hands the game lock to it); ending with an error, or with
# anything on its error stream, means the game didn't start: its last lines in a message box.
$playWatch = New-Object Windows.Forms.Timer
$playWatch.Interval = 1000
$playWatch.Add_Tick({
    $p = $script:playProc
    if (-not $p) { $playWatch.Stop(); return }
    if (-not $p.HasExited) { return }
    $playWatch.Stop()
    $script:playProc = $null
    $err = @(Get-Content "$($script:playLog).err" -ErrorAction SilentlyContinue | Where-Object { "$_".Trim() })
    if ($p.ExitCode -ne 0 -or $err.Count) {
        $said = @(@(Get-Content $script:playLog -ErrorAction SilentlyContinue) + $err | Where-Object { "$_".Trim() } | Select-Object -Last 12)
        $playState.Text = 'Play TTT2 stopped before the game started: see the message.'
        [void][Windows.Forms.MessageBox]::Show($form, "Play TTT2 stopped before the game started:`r`n`r`n$($said -join "`r`n")`r`n`r`n(All of it: $($script:playLog). Report a problem sends it.)", 'TTT2', 'OK', 'Warning')
    }
})
$play.Add_Click({ if (FastClient-Running) { [void][Windows.Forms.MessageBox]::Show($form, 'Play BlueSpark is open, with its game behind it. Close it first, then Play TTT2.', 'TTT2'); return }; Start-Play })
$playOffline.Add_Click({ if (FastClient-Running) { [void][Windows.Forms.MessageBox]::Show($form, 'Play BlueSpark is open, with its game behind it. Close it first, then Play TTT2.', 'TTT2'); return }; Start-Play -Offline })

# "Play: Fast Client": Play's switches written first (setup-steps.ps1's 'switches' step: rex\userdata\play-switches.txt,
# the same list Play passes, which the client reads when it starts its game), the downloaded mark cleared, then the
# client started from this click (a client started from a background process couldn't bring its game to the front:
# Windows' foreground rule). The client starts the game itself, hidden, and the game closes with it.
function Start-FastClient {
    if (FastClient-Running) { [void][Windows.Forms.MessageBox]::Show($form, 'Play BlueSpark is open already.', 'TTT2'); return }
    if (Game-Running) { [void][Windows.Forms.MessageBox]::Show($form, 'The game is running (from Play TTT2). Close it first, then start Play BlueSpark.', 'TTT2'); return }
    if (-not (Get-PlayerName)) { Ask-PlayerName | Out-Null }
    $out = Join-Path $Logs "$(Get-Date -Format 'yyyyMMdd-HHmmss')-switches.log"
    $p = Start-Process powershell -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$Steps`"", '-Step', 'switches') `
        -WindowStyle Hidden -PassThru -Wait -RedirectStandardOutput $out -RedirectStandardError "$out.err"
    $err = @(Get-Content "$out.err" -ErrorAction SilentlyContinue | Where-Object { "$_".Trim() })
    if ($p.ExitCode -ne 0 -or $err.Count) {
        [void][Windows.Forms.MessageBox]::Show($form, "Play BlueSpark didn't start: its switches couldn't be written.`r`n`r`n$($err -join "`r`n")", 'TTT2', 'OK', 'Warning')
        return
    }
    Unblock-FastClient
    Start-Process $script:fastClientExe -WorkingDirectory (Split-Path $script:fastClientExe)
    $playState.Text = 'Starting Play BlueSpark (it starts the game behind it)...'
}
$fastPlay.Add_Click({ Start-FastClient })

$form.Add_FormClosing({
    if ($script:proc -and -not $script:proc.HasExited) {
        $r = [Windows.Forms.MessageBox]::Show('A step is still running. Stop it and close?', 'TTT2', 'YesNo', 'Warning')
        if ($r -ne 'Yes') { $_.Cancel = $true; return }
        try { $script:proc.Kill() } catch { }
    }
})

Refresh-Buttons
Register-Install
Unblock-FastClient
Start-UpdateCheck
if ($AutoBuild) { $s = Read-Status; if ($s.tools -and $s.files) { Start-Step 'build' @() } }
# (Once the window is up: the rescue for a new folder.)
$form.Add_Shown({
    # (The lead's F: an install folder inside OneDrive or another synced folder, said at every start.)
    if ($note = Get-Ttt2SyncedFolderNote $ThisInstall 'This folder') {
        [void][Windows.Forms.MessageBox]::Show($form, $note, 'A synced folder', 'OK', 'Warning')
    }
    # (D2 and G3: our files gone since the last start, named with Defender's threat when it took them.)
    if ($missingNote = Get-Ttt2MissingFilesNote $ThisInstall) {
        $log.AppendText("$missingNote`r`n")
        [void][Windows.Forms.MessageBox]::Show($form, $missingNote, 'Files are missing', 'OK', 'Warning')
    }
    if (-not $AutoBuild -and -not $script:proc) { Offer-PreviousInstall }
})
# --- resizing (the owner, 25 Oct: "the launcher is getting pretty tall. can we support resizing?"): the window can be
# made shorter or taller, and wider; its rows keep their places, so a window shorter than them scrolls. It opens no
# taller than the screen's working area, and never narrower than its rows and a scroll bar.
$rowsHeight = $form.ClientSize.Height
$scrollBar = [Windows.Forms.SystemInformation]::VerticalScrollBarWidth
$form.FormBorderStyle = 'Sizable'
$form.MaximizeBox = $true
$form.AutoScroll = $true
$form.AutoScrollMinSize = New-Object Drawing.Size(0, $rowsHeight)
$form.ClientSize = New-Object Drawing.Size((640 + $scrollBar), $rowsHeight)
$frame = $form.Height - $form.ClientSize.Height
$form.MinimumSize = New-Object Drawing.Size($form.Width, (240 + $frame))
$work = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea
if ($form.Height -gt $work.Height) { $form.ClientSize = New-Object Drawing.Size((640 + $scrollBar), ($work.Height - $frame)) }
[void]$form.ShowDialog()
