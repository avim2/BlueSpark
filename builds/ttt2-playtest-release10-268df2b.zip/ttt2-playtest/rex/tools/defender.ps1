# Windows Defender and our files (the lead's D, 27 Oct; G3): what Defender detected in our folders, and which of our
# files are missing, each named with the threat Defender gave it when it took it.
#   D1  Get-Ttt2DefenderLines: the detections as log lines (the steps' logs, the report zip's defender.txt).
#   D2  Get-Ttt2MissingFiles + Get-Ttt2MissingFilesNote: the box Start Here shows (at its start and after a failed step).
#   G3  a tool file the unpack put there and that went afterwards is one of D2's missing files.
# Read as the player (no administrator): Get-MpThreatDetection / Get-MpThreat, and Defender's own event log (1116
# detected, 1117 acted) where those aren't there. Nothing is changed in Defender.
#
#   . rex\tools\defender.ps1

# Our folders: this install, the data folder (tools, game) and %LOCALAPPDATA%\TTT2Native.
function Get-Ttt2OurFolders([string]$install) {
    $f = @($install, (Join-Path $env:LOCALAPPDATA 'TTT2Native'))
    if (Get-Command Get-Ttt2DataFolder -ErrorAction SilentlyContinue) { $f += Get-Ttt2DataFolder }
    @($f | Where-Object { $_ } | ForEach-Object { try { [IO.Path]::GetFullPath($_).TrimEnd('\') } catch { } } | Select-Object -Unique)
}

function Test-Ttt2InFolders([string]$path, [string[]]$folders) {
    foreach ($f in $folders) { if ($path.StartsWith("$f\", [StringComparison]::OrdinalIgnoreCase)) { return $true } }
    $false
}

# Defender's detections of the last $days days touching our folders: objects with When, Threat, Path, Action.
function Get-Ttt2DefenderDetections([string[]]$folders, [int]$days = 30) {
    $since = (Get-Date).AddDays(-$days)
    $out = New-Object System.Collections.Generic.List[object]
    try {
        $names = @{}
        foreach ($t in @(Get-MpThreat -ErrorAction Stop)) { $names["$($t.ThreatID)"] = $t.ThreatName }
        foreach ($d in @(Get-MpThreatDetection -ErrorAction Stop)) {
            if ($d.InitialDetectionTime -lt $since) { continue }
            foreach ($r in @($d.Resources)) {
                $path = "$r" -replace '^[a-z]+:_', ''   # ("file:_C:\...")
                if (-not (Test-Ttt2InFolders $path $folders)) { continue }
                $out.Add([pscustomobject]@{ When = $d.InitialDetectionTime; Threat = $(if ($names["$($d.ThreatID)"]) { $names["$($d.ThreatID)"] } else { "threat $($d.ThreatID)" })
                                            Path = $path; Action = "$($d.ThreatStatusID)" })
            }
        }
    } catch { }
    if (-not $out.Count) {
        try {
            $events = Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-Windows Defender/Operational'; Id = 1116, 1117; StartTime = $since } -ErrorAction Stop
            foreach ($e in $events) {
                $data = @{}
                foreach ($x in ([xml]$e.ToXml()).Event.EventData.Data) { $data[$x.Name] = $x.'#text' }
                foreach ($part in "$($data['Path'])" -split ';') {
                    $path = $part -replace '^[a-z]+:_', ''
                    if (-not $path -or -not (Test-Ttt2InFolders $path $folders)) { continue }
                    $out.Add([pscustomobject]@{ When = $e.TimeCreated; Threat = $data['Threat Name']; Path = $path; Action = $data['Action Name'] })
                }
            }
        } catch { }
    }
    @($out | Sort-Object When)
}

# D1: the detections as lines for a log ("none" when there are none, so a log shows it was looked at).
function Get-Ttt2DefenderLines([string]$install, [int]$days = 30) {
    $found = @(Get-Ttt2DefenderDetections (Get-Ttt2OurFolders $install) $days)
    if (-not $found.Count) { return @("Windows Defender: no detections in our folders in the last $days days") }
    @("Windows Defender: $($found.Count) detection(s) in our folders in the last $days days:") +
        @($found | ForEach-Object { "  $($_.When.ToString('yyyy-MM-dd HH:mm:ss')) $($_.Threat): $($_.Path)$(if ($_.Action) { " ($($_.Action))" })" })
}

# D2 and G3: our files that should be there and aren't: the install's (rex\package-signature.txt lists every file of
# the package), and the tools' that the compiler needs once step 1 recorded them unpacked.
function Get-Ttt2MissingFiles([string]$install) {
    $missing = New-Object System.Collections.Generic.List[string]
    $sig = Join-Path $install 'rex\package-signature.txt'
    if (Test-Path $sig) {
        foreach ($line in Get-Content $sig) {
            if ($line -notmatch '^[0-9a-f]{64} [^/]+/(.+)$') { continue }   # (the zip's paths: its top folder first)
            $p = Join-Path $install ($Matches[1] -replace '/', '\')
            if (-not (Test-Path -LiteralPath $p)) { $missing.Add($p) }
        }
    }
    if (Get-Command Get-Ttt2ToolchainRoot -ErrorAction SilentlyContinue) {
        $root = Get-Ttt2ToolchainRoot
        $need = @{ llvm = @('bin\clang.exe', 'bin\clang-cl.exe', 'bin\lld-link.exe', 'bin\llvm-lib.exe', 'bin\llvm-rc.exe'); cmake = @('bin\cmake.exe'); ninja = @('ninja.exe') }
        foreach ($k in $need.Keys) {
            $folder = Get-Ttt2PinFolder $root $script:Ttt2ToolchainPins[$k]
            if (-not (Test-Path (Join-Path $folder 'ttt2-unpacked.txt'))) { continue }
            foreach ($f in $need[$k]) { $p = Join-Path $folder $f; if (-not (Test-Path -LiteralPath $p)) { $missing.Add($p) } }
        }
    }
    @($missing)
}

# The box's text for missing files, each with Defender's threat name when Defender took it; $null when none is missing.
function Get-Ttt2MissingFilesNote([string]$install) {
    $missing = @(Get-Ttt2MissingFiles $install)
    if (-not $missing.Count) { return $null }
    $found = @(Get-Ttt2DefenderDetections (Get-Ttt2OurFolders $install) 60)
    $byDefender = 0
    $lines = foreach ($m in ($missing | Select-Object -First 8)) {
        $d = $found | Where-Object { $_.Path -ieq $m } | Select-Object -Last 1
        if ($d) { $byDefender++; "- $m`r`n    removed by Windows Defender as $($d.Threat) on $($d.When.ToString('d MMM HH:mm'))" } else { "- $m" }
    }
    if ($missing.Count -gt 8) { $lines += "- and $($missing.Count - 8) more" }
    $text = "$($missing.Count) of TTT2's files are missing:`r`n$($lines -join "`r`n")`r`n`r`n"
    if ($byDefender) {
        $text += "Windows Defender took them. It's a false alarm: open Windows Security, Virus & threat protection, Protection history, and choose Allow on device for each. " +
                 "To stop it happening again, add the folders under Exclusions (Virus & threat protection settings, Manage settings, Exclusions).`r`n`r`n"
    } else {
        $text += "An antivirus may have taken them (look in its quarantine or history), or they were deleted.`r`n`r`n"
    }
    $text + "Then: files in the tools folder: click Install tools again. Files of this package: download the release again and drop the zip onto this window, or unzip it over this folder."
}
