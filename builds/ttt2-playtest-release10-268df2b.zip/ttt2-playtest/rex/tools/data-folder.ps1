# Where step 1's tools and step 2's game files go (the lead's E, 27 Oct; a player's C: was full): the "data folder".
# By default %LOCALAPPDATA%\TTT2Native as before; Start Here's "Where to put the tools and game files" stores another in
# %LOCALAPPDATA%\TTT2Native\data-folder.txt (one line). Only the big folders move:
#   toolchain\   the compiler (step 1; about 4.8 GB, about 6.8 GB while it installs)
#   tools\       Python and extract-xiso (step 1 and 2; a few MB)
#   game\        the extracted ISO (step 2; about 8 GB) and update\ beside it (the title update)
# The profile, logs, backups, installs.txt and the steps' markers (tools.done ...) stay in %LOCALAPPDATA%\TTT2Native.
# $env:TTT2_DATA_FOLDER overrides the file (tests). Also here: the free space and synced-folder checks (E, F).
#
#   . rex\tools\data-folder.ps1

function Get-Ttt2HomeFolder { Join-Path $env:LOCALAPPDATA 'TTT2Native' }

function Get-Ttt2DataFolderFile { Join-Path (Get-Ttt2HomeFolder) 'data-folder.txt' }

function Get-Ttt2DataFolder {
    if ($env:TTT2_DATA_FOLDER) { return $env:TTT2_DATA_FOLDER }
    $file = Get-Ttt2DataFolderFile
    if (Test-Path $file) {
        $line = "$(Get-Content $file -TotalCount 1 -ErrorAction SilentlyContinue)".Trim()
        if ($line) { return $line }
    }
    Get-Ttt2HomeFolder
}

function Set-Ttt2DataFolder([string]$path) {
    New-Item -ItemType Directory -Force (Get-Ttt2HomeFolder) | Out-Null
    $full = [IO.Path]::GetFullPath($path).TrimEnd('\')
    if ($full -eq (Get-Ttt2HomeFolder).TrimEnd('\')) { Remove-Item (Get-Ttt2DataFolderFile) -Force -ErrorAction SilentlyContinue; return }
    [IO.File]::WriteAllText((Get-Ttt2DataFolderFile), "$full`r`n")
}

# The big folders a data folder holds (what a move takes along).
$script:Ttt2DataParts = @('toolchain', 'tools', 'game', 'update')

# What each step needs free (measured on the owner's PC, 27 Oct): step 1 the compiler at its peak (the 0.94 GB
# archive and xwin's 1 GB of packages beside the 4.8 GB unpacked), on the data folder's drive; step 2 the extracted
# ISO (8.0 GB; a game folder picked instead of an ISO is not copied), on the data folder's drive; step 3 the build
# (rex\out 0.3 GB, room for its objects), on the install folder's drive.
$script:Ttt2StepNeedGB = @{ 1 = 7.0; 2 = 8.5; 3 = 1.0 }

# GB free on the drive holding $path (a folder that doesn't exist yet: its nearest parent's), or -1 when unknown.
function Get-Ttt2FreeGB([string]$path) {
    try {
        $root = [IO.Path]::GetPathRoot([IO.Path]::GetFullPath($path))
        return (New-Object IO.DriveInfo $root).AvailableFreeSpace / 1GB
    } catch { return -1 }
}

function Get-Ttt2DriveName([string]$path) {
    try { return ([IO.Path]::GetPathRoot([IO.Path]::GetFullPath($path))).TrimEnd('\') } catch { return $path }
}

# GB already in a folder (what a step finds done counts as space already taken), 0 when it isn't there.
function Get-Ttt2FolderGB([string]$path) {
    if (-not (Test-Path $path)) { return 0 }
    [double](Get-ChildItem $path -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum / 1GB
}

# $null when step $n has room, else the plain sentence: "Step N needs about X GB on D:, which has Y GB free."
function Get-Ttt2SpaceProblem([int]$n, [string]$path, [double]$haveGB = 0) {
    $need = [math]::Max(0, $script:Ttt2StepNeedGB[$n] - $haveGB)
    if ($need -le 0) { return $null }
    $free = Get-Ttt2FreeGB $path
    if ($free -lt 0 -or $free -ge $need) { return $null }
    "Step $n needs about {0:N1} GB on {1}, which has {2:N1} GB free." -f $need, (Get-Ttt2DriveName $path), $free
}

# The sync service a folder is inside (OneDrive, Dropbox, Google Drive, iCloud), or $null. A build inside OneDrive
# stopped with only "ninja: build stopped: subcommand failed" (a player's screenshot, 27 Oct): the sync client holds or
# swaps out files while the compiler writes them.
function Get-Ttt2SyncedFolder([string]$path) {
    try { $full = [IO.Path]::GetFullPath($path).TrimEnd('\') + '\' } catch { return $null }
    foreach ($v in 'OneDrive', 'OneDriveConsumer', 'OneDriveCommercial') {
        $root = [Environment]::GetEnvironmentVariable($v)
        if ($root -and $full.StartsWith($root.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) { return 'OneDrive' }
    }
    if ($full -match '(?i)\\OneDrive( - [^\\]+)?\\') { return 'OneDrive' }
    if ($full -match '(?i)\\Dropbox\\') { return 'Dropbox' }
    if ($full -match '(?i)\\Google Drive\\|\\My Drive\\') { return 'Google Drive' }
    if ($full -match '(?i)\\iCloudDrive\\|\\iCloud Drive\\') { return 'iCloud Drive' }
    return $null
}

function Get-Ttt2SyncedFolderNote([string]$path, [string]$what) {
    $service = Get-Ttt2SyncedFolder $path
    if (-not $service) { return $null }
    "$what is inside $service ($path). $service copies and locks files while the build writes them, and the build can fail with only `"ninja: build stopped`".`r`n`r`n" +
    "Move the whole folder out of $service first, to C:\ttt2 or a folder on another drive (not the Desktop or Documents if they are synced), then start Start Here from there."
}
