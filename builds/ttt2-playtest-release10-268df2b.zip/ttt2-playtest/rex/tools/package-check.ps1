# The checks a release zip passes before anything of it is used (the lead's order of 24 Oct, 3db866c): its signature,
# its entries' paths (no zip-slip) and its package-info. Dot-sourced by launcher.ps1 (the drop onto Start Here's window)
# and setup-steps.ps1 (update-file, which checks again before it unzips).
#
# The signature: rex/package-signature.txt inside the zip, written by rex\tools\sign-package.ps1 when the package is made
# on the owner's PC: "TTT2 signed package 1", then one line per file of the zip ("<sha256> <path>", the paths as in the
# zip, sorted), then "signature <base64>": ECDSA P-256 over the lines above it (UTF-8, CRLF), with the owner's private
# key, which never leaves his PC. Start Here carries the public key below. A zip whose signature doesn't verify, or
# whose files aren't exactly the list (a file added, removed or changed), isn't installed.

Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.Core

# What a player is told when Windows Defender took the package's xexpatch.exe (the title update's patcher; the lead's G1,
# 26 Oct: a player couldn't update to 4.2.1). prepare-game.ps1 and setup-steps.ps1 stop with it, Start Here shows it in a
# box (it looks for its first words in the step's errors).
$DefenderXexpatchNote = "Windows Defender removed xexpatch.exe (the tool that applies your title update). It's a false alarm. " +
    "Open Windows Security, Virus & threat protection, Protection history, find xexpatch.exe and choose Allow on device. " +
    "To stop it happening again, add this folder under Exclusions. Then run this step again."

# The owner's release signing key's public half (CNG's ECCPUBLICBLOB, base64): rex\tools\signing-key.ps1 prints it.
$PackagePublicKey = 'RUNTMSAAAABLKNbE41jshACRu1ti3dBO8x2HO2e44EqGeEmGDsbVqlHyFMnnESlIX0WCVCt+YyZDZaGYA5FGPpVGe//LRVVG'
$PackageSignatureEntry = 'rex/package-signature.txt'
$PackageNotOfficial = "This isn't an official TTT2 playtest package."

# The zip's entry names that would land outside the folder it's unzipped into: absolute, a drive letter, a ".." part.
function Get-ZipSlipEntries([IO.Compression.ZipArchive]$archive) {
    @($archive.Entries | Where-Object {
        $n = $_.FullName -replace '\\', '/'
        $n.StartsWith('/') -or $n -match '^[A-Za-z]:' -or ($n -split '/') -contains '..'
    } | ForEach-Object { $_.FullName })
}

# The zip's top folder (its entries' first part, all the same) and its file list as the signature has it.
function Get-ZipFileList([IO.Compression.ZipArchive]$archive) {
    $sha = [Security.Cryptography.SHA256]::Create()
    $lines = foreach ($e in $archive.Entries) {
        if ($e.FullName.EndsWith('/')) { continue }   # (a folder's entry)
        $rel = ($e.FullName -split '/', 2)[1]
        if ($rel -eq $PackageSignatureEntry) { continue }
        $s = $e.Open()
        try { $hash = ($sha.ComputeHash($s) | ForEach-Object { $_.ToString('x2') }) -join '' } finally { $s.Close() }
        "$hash $($e.FullName)"
    }
    return @($lines | Sort-Object -CaseSensitive)
}

function Read-ZipEntryText([IO.Compression.ZipArchive]$archive, [string]$pattern) {
    $entry = $archive.Entries | Where-Object { $_.FullName -match $pattern } | Select-Object -First 1
    if (-not $entry) { return $null }
    $reader = New-Object IO.StreamReader($entry.Open())
    try { return $reader.ReadToEnd() } finally { $reader.Close() }
}

# Everything Start Here needs to know about a dropped zip, or why it can't be used: @{ ok; why; info (track, patch,
# commit, date) }. Reads the zip once; nothing is unzipped.
function Test-ReleaseZip([string]$zip) {
    $result = @{ ok = $false; why = ''; info = $null }
    $archive = $null
    try {
        try { $archive = [IO.Compression.ZipFile]::OpenRead($zip) } catch { $result.why = "$(Split-Path $zip -Leaf) isn't a zip file that opens."; return $result }
        $slip = @(Get-ZipSlipEntries $archive)
        if ($slip.Count) { $result.why = "$PackageNotOfficial (It has files that would land outside its folder: $($slip[0]).)"; return $result }
        $infoText = Read-ZipEntryText $archive '^[^/]+/rex/package-info\.txt$'
        if (-not $infoText) { $result.why = "$(Split-Path $zip -Leaf) isn't a TTT2 Native package."; return $result }
        $info = @{ track = 'main'; patch = 0; commit = ''; date = '' }
        foreach ($line in ($infoText -split "`r?`n")) { if ($line -match '^(\w+)=(.*)$') { $info[$Matches[1]] = $Matches[2].Trim() } }
        $info.patch = [int]$info.patch
        $result.info = $info
        $sigText = Read-ZipEntryText $archive ('^[^/]+/' + [regex]::Escape($PackageSignatureEntry) + '$')
        if (-not $sigText) { $result.why = "$PackageNotOfficial (It isn't signed.)"; return $result }
        $sigLines = @($sigText -split "`r?`n" | Where-Object { $_ -ne '' })
        if ($sigLines.Count -lt 3 -or $sigLines[0] -ne 'TTT2 signed package 1' -or $sigLines[-1] -notmatch '^signature (\S+)$') {
            $result.why = "$PackageNotOfficial (Its signature file is damaged.)"; return $result
        }
        $signature = [Convert]::FromBase64String($Matches[1])
        $signed = $sigLines[0..($sigLines.Count - 2)]
        if (-not (Test-PackageSignature (($signed -join "`r`n") + "`r`n") $signature)) {
            $result.why = "$PackageNotOfficial (Its signature doesn't match.)"; return $result
        }
        $listed = @($signed | Select-Object -Skip 1)
        $actual = @(Get-ZipFileList $archive)
        $diff = @(Compare-Object -ReferenceObject $listed -DifferenceObject $actual -CaseSensitive)
        if ($diff.Count) {
            $what = ($diff[0].InputObject -split ' ', 2)[1]
            $result.why = "$PackageNotOfficial (A file in it was changed, added or removed: $what.)"; return $result
        }
        $result.ok = $true
        return $result
    } catch {
        $result.why = "$PackageNotOfficial ($($_.Exception.Message))"
        return $result
    } finally {
        if ($archive) { $archive.Dispose() }
    }
}

function Test-PackageSignature([string]$text, [byte[]]$signature) {
    if ($PackagePublicKey -like '<*') { return $false }
    $key = [Security.Cryptography.CngKey]::Import([Convert]::FromBase64String($PackagePublicKey), [Security.Cryptography.CngKeyBlobFormat]::EccPublicBlob)
    $ecdsa = New-Object Security.Cryptography.ECDsaCng($key)
    try {
        $ecdsa.HashAlgorithm = [Security.Cryptography.CngAlgorithm]::Sha256
        return $ecdsa.VerifyData([Text.Encoding]::UTF8.GetBytes($text), $signature)
    } finally { $ecdsa.Dispose(); $key.Dispose() }
}
