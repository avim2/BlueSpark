# The player's identity for Start Here's own signed calls (the profile icon, 24 October): the XUID and the key the game made at its first online start
# (the profile folder's live\identity.reg and identity.key; the key is DPAPI-protected for this Windows user, so only this user on this PC can sign with it).
# The same key signs the game's match results; rex\tools\replay-uploader.ps1 has its own copy of these lines.
#
# Dot-source it:  . (Join-Path $Rex 'tools\identity.ps1')
#   Read-Identity <profile folder>     @{ xuid; ec } or $null (no identity yet: the game hasn't been online, or the server hasn't registered it)
#   Sign-Text <ec> <text>              the signature the Worker checks: raw P-256 (r || s), base64url

function Get-IdentityDir([string]$ProfileDir) {
    $dirs = @()
    if ($ProfileDir) { $dirs += (Join-Path $ProfileDir 'live') }
    if ($env:LOCALAPPDATA) { $dirs += (Join-Path $env:LOCALAPPDATA 'TTT2Native\profile\live') }
    foreach ($d in $dirs) { if ((Test-Path -LiteralPath (Join-Path $d 'identity.reg')) -and (Test-Path -LiteralPath (Join-Path $d 'identity.key'))) { return $d } }
    return $null
}

function Read-Identity([string]$ProfileDir) {
    $dir = Get-IdentityDir $ProfileDir
    if (-not $dir) { return $null }
    try {
        $x = ((Get-Content -LiteralPath (Join-Path $dir 'identity.reg') -Raw) -split '\s+')[0].Trim().ToLowerInvariant()
        if ($x -notmatch '^0009[0-9a-f]{12}$') { return $null }
        Add-Type -AssemblyName System.Security
        $raw = [Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes((Join-Path $dir 'identity.key')), $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
        $key = [Security.Cryptography.CngKey]::Import($raw, [Security.Cryptography.CngKeyBlobFormat]::EccPrivateBlob)
        $e = New-Object Security.Cryptography.ECDsaCng($key)
        $e.HashAlgorithm = [Security.Cryptography.CngAlgorithm]::Sha256
        return @{ xuid = $x; ec = $e }
    } catch { return $null }
}

# Only the XUID (no key read): what the picker asks the server about.
function Read-IdentityXuid([string]$ProfileDir) {
    $dir = Get-IdentityDir $ProfileDir
    if (-not $dir) { return $null }
    try { $x = ((Get-Content -LiteralPath (Join-Path $dir 'identity.reg') -Raw) -split '\s+')[0].Trim().ToLowerInvariant() } catch { return $null }
    if ($x -match '^0009[0-9a-f]{12}$') { return $x }
    return $null
}

function ConvertTo-B64Url([byte[]]$b) { return [Convert]::ToBase64String($b).TrimEnd('=').Replace('+', '-').Replace('/', '_') }

function Sign-Text($ec, [string]$text) { return ConvertTo-B64Url ($ec.SignData([Text.Encoding]::UTF8.GetBytes($text))) }
