# The player's profile in a folder of its own, outside every game folder (23 October): %LOCALAPPDATA%\TTT2Native\profile.
# A new test build, or a game folder deleted by mistake, no longer takes the player's XUID (the leaderboard profile), save data
# or name with it. Only the profile goes there:
#   live\identity.txt, identity.key, identity.reg   the XUID and its key (the key is bound to this Windows user)
#   live\stats_seen.txt, live\outbox\                the win/loss counts the ladder reads, ranked results not sent yet
#   live\storage\                                    the title's online storage (per XUID)
#   B13EBABEBABEBABE\                                the save data (unlocks, customizations, records)
#   achievements\, player-name.txt                   the achievements, the name the game shows
# Everything else (caches, logs, replays, settings) stays in the game folder's rex\userdata.
#
# Dot-source it:  . (Join-Path $Rex 'tools/profile-folder.ps1')
#   Get-ProfileFolder                      the folder (TTT2_PROFILE_DIR names another one, for a test)
#   Copy-ProfileOnce <userdata> <profile>  the first time: what the profile folder lacks is copied from that user data folder (never over
#                                          anything, and nothing is deleted: an older build started on its own still finds its files)

function Get-ProfileFolder {
    if ($env:TTT2_PROFILE_DIR) { return $env:TTT2_PROFILE_DIR }
    $base = if ($env:LOCALAPPDATA) { $env:LOCALAPPDATA } else { Join-Path $env:USERPROFILE 'AppData\Local' }
    return Join-Path $base 'TTT2Native\profile'
}

function Copy-ProfileOnce([string]$UserData, [string]$Profile) {
    if (-not $UserData -or -not (Test-Path -LiteralPath $UserData)) { return }
    New-Item -ItemType Directory -Force $Profile | Out-Null
    $copied = @()
    $copyTree = {
        param([string]$rel)
        $from = Join-Path $UserData $rel
        $to = Join-Path $Profile $rel
        if (-not (Test-Path -LiteralPath $from) -or (Test-Path -LiteralPath $to)) { return $false }
        New-Item -ItemType Directory -Force (Split-Path $to -Parent) | Out-Null
        Copy-Item -LiteralPath $from $to -Recurse -ErrorAction SilentlyContinue
        return $true
    }
    # The identity: only as a whole, and only when the profile has none (one player's XUID is never mixed with another's key).
    $hasIdentity = (Test-Path -LiteralPath (Join-Path $Profile 'live\identity.txt')) -or (Test-Path -LiteralPath (Join-Path $Profile 'live\identity.key'))
    if (-not $hasIdentity -and (Test-Path -LiteralPath (Join-Path $UserData 'live\identity.txt'))) {
        foreach ($rel in 'live\identity.txt', 'live\identity.key', 'live\identity.reg', 'live\stats_seen.txt', 'live\outbox') {
            if (& $copyTree $rel) { $copied += $rel }
        }
    } elseif ($hasIdentity -and (Test-Path -LiteralPath (Join-Path $UserData 'live\identity.txt'))) {
        $mineHere = "$(Get-Content -LiteralPath (Join-Path $UserData 'live\identity.txt') -Raw -ErrorAction SilentlyContinue)".Trim()
        $profileId = "$(Get-Content -LiteralPath (Join-Path $Profile 'live\identity.txt') -Raw -ErrorAction SilentlyContinue)".Trim()
        if ($mineHere -and $profileId -and $mineHere -ne $profileId) {
            Write-Host "Profile: this game folder has another identity ($mineHere) than the profile folder ($profileId): the profile folder's is used."
        }
    }
    foreach ($rel in 'B13EBABEBABEBABE', 'live\storage', 'achievements', 'player-name.txt') {
        if (& $copyTree $rel) { $copied += $rel }
    }
    if ($copied.Count -gt 0) {
        Write-Host "Profile: copied to $Profile from this game folder: $($copied -join ', ')"
        $note = "The player's profile (identity, save data, name) is kept in $Profile since $(Get-Date -Format 'yyyy-MM-dd HH:mm').`r`n" +
                "The copies here are no longer used by this build; they are left for older builds."
        Set-Content -LiteralPath (Join-Path $UserData 'PROFILE-MOVED.txt') $note -Encoding utf8 -ErrorAction SilentlyContinue
    }
}
