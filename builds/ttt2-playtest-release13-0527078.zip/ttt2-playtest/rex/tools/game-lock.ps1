# One game at a time on this PC, whichever clone of the repo starts it: the test scripts play
# the game through its window and stop it when they are done, and two of them at once (two
# sessions, each in its own clone) would break each other's runs.
#
# The lock is a file, %USERPROFILE%\ttt2-game.lock, holding the clone's path, the id of the
# process that has it, that process's start time (ids are used again) and when it was taken.
# Taking it waits, with a message, while another live process has it; a lock whose process
# is gone is taken over. A script started by one that has the lock (runs.ps1 starts
# autotest-windows.ps1, which starts run-windows.ps1) sees that through the environment and
# neither waits nor releases.
#
# Dot-source it for the functions:
#   . "$PSScriptRoot\game-lock.ps1"            (from rex\tools; "$PSScriptRoot\tools\..." from rex)
#   $mine = Take-GameLock $rex
#   try { ... } finally { if ($mine) { Release-GameLock } }
# or run it:  game-lock.ps1 show | take | release
#
# Also here: which game is this clone's (rex\out\game-pid.txt, written by run-windows.ps1), so
# that a script stops the game it started and never every ttt2 process.
param([string]$Action)

$script:GameLockFile = Join-Path $env:USERPROFILE 'ttt2-game.lock'
# (Every take, takeover, hand-over, added game and release, one line each: the time, what, the clone's folder, the script,
# the process; so that a game that ends with no trace can be placed. The lead's order of 24 Oct, 576aa5c, after two games
# ended together on 23 Oct with nothing to say who. 1 MB, then one older file kept.)
# (The user's own local app data, not $env:LOCALAPPDATA: a test that points that at a scratch folder still logs here.)
$script:GameLockLog = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'TTT2Native\game-lock.log'

function Write-GameLockLog([string]$What, [string]$Clone, [int]$Process) {
    try {
        # (The outermost script that isn't this one: run-windows.ps1, a test script; this one when it was run by itself.)
        $caller = (Get-PSCallStack | Where-Object { $_.ScriptName -and $_.ScriptName -notlike '*\game-lock.ps1' } |
                   Select-Object -Last 1).ScriptName
        if (-not $caller) { $caller = $PSCommandPath }
        $dir = Split-Path $script:GameLockLog -Parent
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force $dir | Out-Null }
        if ((Test-Path -LiteralPath $script:GameLockLog) -and (Get-Item -LiteralPath $script:GameLockLog).Length -gt 1MB) {
            Move-Item -Force -LiteralPath $script:GameLockLog ($script:GameLockLog + '.old')
        }
        $line = '{0}  {1,-9} {2}  {3}  process {4} (from {5})' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'), $What, $Clone, $caller, $Process, $PID
        Add-Content -LiteralPath $script:GameLockLog -Value $line -Encoding UTF8
    } catch {}   # (the log never stops a run)
}

function Get-GameLock {
    if (-not (Test-Path -LiteralPath $script:GameLockFile)) { return $null }
    try { return Get-Content -LiteralPath $script:GameLockFile -Raw -ErrorAction Stop | ConvertFrom-Json } catch { return $null }
}

# Whether the process a lock names is still there (the same one: by its start time), or any of
# the others it lists (the pair mode: the script that started two games and both games; the
# lock is live while any of them is, so that a pair script that dies leaves no two games running
# with no live holder).
function Test-GameProcessLive([int]$Id, [long]$Started) {
    if (-not $Id) { return $false }
    $p = Get-Process -Id $Id -ErrorAction SilentlyContinue
    if (-not $p) { return $false }
    # (28 Oct: a reused pid may belong to another user's process, whose start time cannot be read: SearchFilterHost took a dead
    # test's pid and the lock read as live for hours while the owner's Play waited on it. Our games are our own processes,
    # always readable: an unreadable start time means the process is not ours, so the lock entry is dead. Unless it is named
    # as ours (the main line, 4.5): a game or script of ours run elevated can't be read either, and must not read as dead.)
    try { return $p.StartTime.ToFileTimeUtc() -eq $Started } catch { return ($p.ProcessName -in @('ttt2', 'powershell', 'pwsh')) }
}
function Test-GameLockLive($lock) {
    if (-not $lock -or -not $lock.pid) { return $false }
    if (Test-GameProcessLive ([int]$lock.pid) ([long]$lock.started)) { return $true }
    foreach ($other in @($lock.others)) {
        if ($other -and (Test-GameProcessLive ([int]$other.pid) ([long]$other.started))) { return $true }
    }
    return $false
}

function Write-GameLock([string]$Clone, [int]$Holder, [bool]$New, $Others = @()) {
    $p = Get-Process -Id $Holder -ErrorAction Stop
    $text = [pscustomobject]@{
        clone   = $Clone
        pid     = $Holder
        started = $p.StartTime.ToFileTimeUtc()
        taken   = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        others  = @($Others)
    } | ConvertTo-Json -Compress
    # (A new lock is made so that only one of two takers can make it.)
    $mode = if ($New) { [IO.FileMode]::CreateNew } else { [IO.FileMode]::Create }
    $file = [IO.File]::Open($script:GameLockFile, $mode, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try {
        $bytes = [Text.Encoding]::UTF8.GetBytes($text)
        $file.Write($bytes, 0, $bytes.Length)
    } finally { $file.Close() }
}

# Takes the lock for this process. Returns $true if it was taken here (and is to be released
# here), $false if a script that started this one has it already.
function Take-GameLock([string]$Clone) {
    $lock = Get-GameLock
    if ($env:TTT2_GAME_LOCK -and $lock -and "$($lock.pid)" -eq $env:TTT2_GAME_LOCK -and (Test-GameLockLive $lock)) {
        return $false
    }
    $said = $null
    while ($true) {
        $lock = Get-GameLock
        if ($lock -and (Test-GameLockLive $lock) -and [int]$lock.pid -ne $PID) {
            if (-not $said -or ((Get-Date) - $said).TotalSeconds -ge 30) {
                Write-Host "Waiting for the game lock: process $($lock.pid) has it since $($lock.taken), from $($lock.clone)" -ForegroundColor Yellow
                $said = Get-Date
            }
            Start-Sleep -Seconds 2
            continue
        }
        try {
            if (Test-Path -LiteralPath $script:GameLockFile) { Remove-Item -LiteralPath $script:GameLockFile -Force -ErrorAction Stop }
            Write-GameLock $Clone $PID $true
            if ($lock -and [int]$lock.pid -ne $PID) { Write-GameLockLog 'takeover' $lock.clone ([int]$lock.pid) }
            Write-GameLockLog 'take' $Clone $PID
            break
        } catch {
            # (Another taker was quicker: look again.)
            Start-Sleep -Milliseconds 300
        }
    }
    $env:TTT2_GAME_LOCK = "$PID"
    return $true
}

function Release-GameLock {
    $lock = Get-GameLock
    if ($lock -and [int]$lock.pid -eq $PID) {
        Remove-Item -LiteralPath $script:GameLockFile -Force -ErrorAction SilentlyContinue
        Write-GameLockLog 'release' $lock.clone $PID
    }
    if ($env:TTT2_GAME_LOCK -eq "$PID") { $env:TTT2_GAME_LOCK = $null }
}

# Adds a process (a game this script started) to the lock this process holds: the lock stays
# live while that process is, even after this script is gone (the pair mode).
function Add-GameLockProcess([int]$Id) {
    $lock = Get-GameLock
    if (-not $lock -or [int]$lock.pid -ne $PID) { return }
    $p = Get-Process -Id $Id -ErrorAction SilentlyContinue
    if (-not $p) { return }
    $others = @($lock.others) + @([pscustomobject]@{ pid = $Id; started = $p.StartTime.ToFileTimeUtc() })
    Write-GameLock $lock.clone $PID $false $others
    Write-GameLockLog 'add game' $lock.clone $Id
}

# Hands a lock this process has to another process (the game itself, when it is started by
# hand: the lock is then held for as long as the game runs).
function Move-GameLock([int]$Holder) {
    $lock = Get-GameLock
    if ($lock -and [int]$lock.pid -eq $PID) {
        Write-GameLock $lock.clone $Holder $false
        Write-GameLockLog 'hand to' $lock.clone $Holder
        $env:TTT2_GAME_LOCK = $null
    }
}

# This clone's game: the process run-windows.ps1 started last, if it is still running.
function Get-OwnGame([string]$Rex) {
    $file = if ($env:TTT2_GAME_PID_FILE) { $env:TTT2_GAME_PID_FILE } else { Join-Path $Rex 'out\game-pid.txt' }
    if (-not (Test-Path -LiteralPath $file)) { return $null }
    $parts = "$(Get-Content -LiteralPath $file -Raw)".Trim() -split ' '
    if ($parts.Count -lt 2) { return $null }
    $p = Get-Process -Id ([int]$parts[0]) -ErrorAction SilentlyContinue
    if (-not $p -or $p.ProcessName -ne 'ttt2') { return $null }
    try { if ($p.StartTime.ToFileTimeUtc() -ne [long]$parts[1]) { return $null } } catch {}
    return $p
}

function Stop-OwnGame([string]$Rex) {
    $p = Get-OwnGame $Rex
    if ($p) {
        Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
        try { $p.WaitForExit(5000) | Out-Null } catch {}
    }
}

if ($Action) {
    $rexFolder = Split-Path $PSScriptRoot -Parent
    switch ($Action) {
        'show' {
            $lock = Get-GameLock
            if (-not $lock) { 'No game lock.' }
            else { "The game lock: process $($lock.pid), since $($lock.taken), from $($lock.clone); live: $(Test-GameLockLive $lock)$(if ($lock.others) { '; with it: ' + ((@($lock.others) | ForEach-Object { "$($_.pid)" }) -join ', ') })" }
        }
        'take' { if (Take-GameLock $rexFolder) { "Taken by process $PID." } else { 'Held already by the script that started this one.' } }
        'release' { Release-GameLock; 'Released.' }
        default { throw "game-lock.ps1 show | take | release" }
    }
}
