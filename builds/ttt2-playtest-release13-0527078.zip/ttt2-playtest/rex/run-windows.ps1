# Starts TTT2 on Windows. The first time, it asks for your game folder: the one with
# default.xex and the data*.bin files from your disc. It remembers the answer in
# rex\game-folder.txt (not part of the repo).
#
#   powershell -ExecutionPolicy Bypass -File rex\run-windows.ps1
#
# Anything after the script name goes to the game, e.g. --log_level=debug.

$ErrorActionPreference = 'Stop'
$Rex = $PSScriptRoot
$exe = Join-Path $Rex 'out\build\win-amd64-release\ttt2.exe'
if (-not (Test-Path -LiteralPath $exe)) { throw 'ttt2.exe is not built yet. Run rex\build-windows.ps1 first.' }

$saved = Join-Path $Rex 'game-folder.txt'
$game = if (Test-Path -LiteralPath $saved) { (Get-Content -LiteralPath $saved -Raw).Trim() } else { '' }
while (-not $game -or -not (Test-Path -LiteralPath (Join-Path $game 'default.xex'))) {
    if ($game) { Write-Host "No default.xex in $game" -ForegroundColor Yellow }
    if ($env:TTT2_NO_PROMPT) { throw "No default.xex in the game folder ($(if ($game) { $game } else { 'none chosen' })). In Start Here, run step 2 again and choose your game." }
    $game = (Read-Host 'Path to your TTT2 game folder (the one with default.xex)').Trim().Trim('"')
}
Set-Content -LiteralPath $saved -Value $game

# The game is built from the disc's executable with the title update applied (version 0.0.3.2),
# and the runtime loads the game's image from that file in the game folder: put there once,
# beside the disc's default.xex, from the repo's gamedata\default_tu.xex.
$patched = Join-Path $game 'default_tu.xex'
if (-not (Test-Path -LiteralPath $patched)) {
    $source = Join-Path (Split-Path $Rex -Parent) 'gamedata\default_tu.xex'
    if (-not (Test-Path -LiteralPath $source)) { throw "gamedata\default_tu.xex is missing: run rex\prepare-game.ps1 first (it makes it from your own game files)." }
    Write-Host "Copying default_tu.xex (the game with its title update applied) into $game"
    Copy-Item -LiteralPath $source $patched
}

# The title update's files (Default.xexp, data100.bin, data100.ofs), which the game opens as
# update:\ : a folder "update" beside the game folder if there is one, or the repo's
# gamedata\update.
$update = Join-Path (Split-Path $game -Parent) 'update'
if (-not (Test-Path -LiteralPath (Join-Path $update 'data100.bin'))) {
    $update = Join-Path (Split-Path $Rex -Parent) 'gamedata\update'
}
if (-not (Test-Path -LiteralPath (Join-Path $update 'data100.bin'))) { throw "The title update's files are not in $update." }

$userData = Join-Path $Rex 'userdata'
# (Another folder for a test, as of a first start on a PC: given twice on the command line,
# the switch makes the game fail at its start.)
if ($env:TTT2_USER_DATA) { $userData = $env:TTT2_USER_DATA }
# The player's profile (the XUID and its key, the save data, the name) in %LOCALAPPDATA%\TTT2Native\profile, outside the game folder
# (tools/profile-folder.ps1, SDK patch 51): a new build or a deleted folder no longer loses it. Copied there from this game folder
# the first time. A test's own user data folder (TTT2_USER_DATA) keeps its profile inside it, as before.
$profileDir = $null
$profileArgs = @()
if (-not $env:TTT2_USER_DATA -and -not ($args | Where-Object { "$_" -like '--profile_data_root*' })) {
    . (Join-Path $Rex 'tools/profile-folder.ps1')
    $profileDir = Get-ProfileFolder
    Copy-ProfileOnce $userData $profileDir
    $profileArgs = @("--profile_data_root=$profileDir")
}
# A first start: the render targets seen on other PCs (their keys: numbers of the runtime's, no
# game data), so that the runtime makes them at the start and not in the middle of the first
# match (STATUS.md, "The first tag of a match"). The runtime adds to the file as it meets more.
$renderTargets = Join-Path $userData 'cache/render_targets_4E4D0859.txt'
if (-not (Test-Path -LiteralPath $renderTargets) -and (Test-Path -LiteralPath (Join-Path $Rex 'render-targets-seed.txt'))) {
    New-Item -ItemType Directory -Force (Split-Path $renderTargets -Parent) | Out-Null
    Copy-Item -LiteralPath (Join-Path $Rex 'render-targets-seed.txt') $renderTargets
}

# Controller mappings for SDL: the community SDL_GameControllerDB (rex\gamecontrollerdb.txt, zlib
# licence in rex\gamecontrollerdb-LICENSE.txt). DirectInput pads, fight sticks and adapters work as
# controllers only if SDL knows their mapping, and L2/R2 only if it maps them as the triggers. A
# player's own mapping lines go in userdata\my-controllers.txt (kept across package updates):
# they're added after the database's, so they win for the same controller.
$mappingArgs = @()
$mappings = Join-Path $Rex 'gamecontrollerdb.txt'
if ((Test-Path -LiteralPath $mappings) -and -not ($args | Where-Object { "$_" -like '--hid_mappings_file*' })) {
    $ownMappings = Join-Path $userData 'my-controllers.txt'
    if (Test-Path -LiteralPath $ownMappings) {
        $merged = Join-Path $userData 'cache/gamecontrollerdb.txt'
        New-Item -ItemType Directory -Force (Split-Path $merged -Parent) | Out-Null
        Get-Content -LiteralPath $mappings, $ownMappings | Set-Content -LiteralPath $merged
        $mappings = $merged
    }
    $mappingArgs = @("--hid_mappings_file=$mappings")
}

# The player's name (the gamertag the game shows), from rex\userdata\player-name.txt (Start Here asks for it the
# first time Play is pressed), unless the caller passed --user_name itself.
$nameArgs = @()
$nameFile = Join-Path $(if ($profileDir) { $profileDir } else { $userData }) 'player-name.txt'   # (the profile folder's, 23 October)
if ((Test-Path -LiteralPath $nameFile) -and -not ($args | Where-Object { "$_" -like '--user_name*' })) {
    $playerName = "$(Get-Content -LiteralPath $nameFile -Raw)".Trim()
    if ($playerName) { $nameArgs = @("--user_name=$playerName") }
}

# The display: Start Here's "Display" choice and "Allow tearing" box (rex\userdata\launcher-settings.txt:
# display=borderless|fullscreen|windowed-<W>x<H>, borderless when unset, an old plain "windowed" taken as the
# 1920x1080 window (1280x720 on a smaller monitor); tearing=true|false, false when unset), passed as the
# runtime's switches unless the caller passed --fullscreen or --present_tearing itself. A window never
# tears: tearing asked with a window size (a settings file edited by hand) is turned off, and said so.
$displayArgs = @()
$settingsFile = Join-Path $userData 'launcher-settings.txt'
$display = 'borderless'
$tearing = 'false'
if (Test-Path -LiteralPath $settingsFile) {
    foreach ($line in Get-Content -LiteralPath $settingsFile) {
        if ($line -match '^display=(.*)$') { $display = $Matches[1].Trim().ToLower() }
        if ($line -match '^tearing=(.*)$') { $tearing = $Matches[1].Trim().ToLower() }
    }
}
$windowSize = $null
if ($display -match '^windowed-(\d+)x(\d+)$') {
    $windowSize = @([int]$Matches[1], [int]$Matches[2])
} elseif ($display -eq 'windowed') {
    Add-Type -Namespace TTT2Run -Name Screen -MemberDefinition @'
[DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr h);
[DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr h, IntPtr dc);
[DllImport("gdi32.dll")] public static extern int GetDeviceCaps(IntPtr dc, int index);
'@
    $dc = [TTT2Run.Screen]::GetDC([IntPtr]::Zero)
    $big = [TTT2Run.Screen]::GetDeviceCaps($dc, 118) -ge 1920 -and [TTT2Run.Screen]::GetDeviceCaps($dc, 117) -ge 1080
    [void][TTT2Run.Screen]::ReleaseDC([IntPtr]::Zero, $dc)
    $windowSize = if ($big) { @(1920, 1080) } else { @(1280, 720) }
}
if (-not ($args | Where-Object { "$_" -like '--fullscreen*' })) {
    if ($windowSize) {
        $displayArgs += @('--fullscreen=false', '--fullscreen_exclusive=false',
                          "--window_pixel_width=$($windowSize[0])", "--window_pixel_height=$($windowSize[1])")
    } else {
        $displayArgs += '--fullscreen=true'
        $displayArgs += "--fullscreen_exclusive=$(if ($display -eq 'fullscreen') { 'true' } else { 'false' })"
    }
}
if (-not ($args | Where-Object { "$_" -like '--present_tearing*' })) {
    if ($windowSize -and $tearing -eq 'true') {
        Write-Host "Tearing is off: the game is in a $($windowSize[0])x$($windowSize[1]) window, and a window never tears (Allow tearing needs a fullscreen choice)."
        $tearing = 'false'
    }
    $displayArgs += "--present_tearing=$(if ($tearing -eq 'true') { 'true' } else { 'false' })"
}
Write-Host "Display: $display$(if ($windowSize) { " ($($windowSize[0])x$($windowSize[1]) window)" }), tearing $tearing"

# One game at a time on this PC (tools/game-lock.ps1): the lock is taken here unless the script
# that started this one has it, and is then handed to the game itself, so that it is held for
# as long as the game runs. Which process the game is goes into out/game-pid.txt, for the test
# scripts to stop the game they started and no other.
. (Join-Path $Rex "tools/game-lock.ps1")
$mine = Take-GameLock $Rex
$handed = $false
try {
    $before = Get-Date
    # (The exact command line the game is started with, for a tester to send: userdata\last-launch.txt,
    # written at every launch.)
    $launchArgs = @("--game_data_root=$game", "--update_data_root=$update", "--user_data_root=$userData") + $profileArgs + $mappingArgs + $nameArgs + $displayArgs + @($args)
    try {
        $quoted = $launchArgs | ForEach-Object { if ("$_" -match '\s') { '"' + "$_" + '"' } else { "$_" } }
        Set-Content -LiteralPath (Join-Path $userData 'last-launch.txt') ('"' + $exe + '" ' + ($quoted -join ' ')) -Encoding utf8
    } catch { Write-Host "last-launch.txt not written: $($_.Exception.Message)" }
    # (Each switch as a plain string: with this script started by -File, Windows PowerShell 5.1 passed a "--name=value"
    # with a space unquoted, so the game got "--ttt2_release_name=Release" and a stray "4.1"; 24 Oct.)
    $passArgs = @($args | ForEach-Object { "$_" })
    & $exe "--game_data_root=$game" "--update_data_root=$update" "--user_data_root=$userData" @profileArgs @mappingArgs @nameArgs @displayArgs @passArgs
    $started = $null
    $deadline = (Get-Date).AddSeconds(20)
    while (-not $started -and (Get-Date) -lt $deadline) {
        $started = Get-Process ttt2 -ErrorAction SilentlyContinue |
            Where-Object { $_.Path -eq $exe -and $_.StartTime -ge $before.AddSeconds(-2) } |
            Sort-Object StartTime | Select-Object -Last 1
        if (-not $started) { Start-Sleep -Milliseconds 100 }
    }
    New-Item -ItemType Directory -Force (Join-Path $Rex 'out') | Out-Null
    if ($started) {
        # (The pair mode names a file an instance: TTT2_GAME_PID_FILE; else this clone's one file.)
        $pidFile = if ($env:TTT2_GAME_PID_FILE) { $env:TTT2_GAME_PID_FILE } else { Join-Path $Rex "out/game-pid.txt" }
        Set-Content -LiteralPath $pidFile -Value "$($started.Id) $($started.StartTime.ToFileTimeUtc())"
        if ($mine) { Move-GameLock $started.Id; $handed = $true }
        # Online replays to the server (21 October): the game saves each finished online match as replays\<date>-online.ttt2replay;
        # tools\replay-uploader.ps1, hidden beside the game, sends each file unchanged and ends when the game does. Only for an online
        # start with a server; "replay_upload=false" in launcher-settings.txt turns it off.
        $online = @($args | Where-Object { "$_" -eq '--ttt2_live_net=true' }).Count -gt 0
        $workerArg = @($args | Where-Object { "$_" -like '--ttt2_live_worker=*' } | Select-Object -Last 1)
        $worker = if ($workerArg.Count) { ("$($workerArg[0])" -replace '^--ttt2_live_worker=', '').Trim('"') } else { 'https://elo.bluespark.site' }
        $uploadOff = (Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'replay_upload=false')
        $uploader = Join-Path $Rex 'tools\replay-uploader.ps1'
        if ($online -and $worker -and -not $uploadOff -and (Test-Path -LiteralPath $uploader)) {
            try {
                $uploaderArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$uploader`"",
                    '-UserData', "`"$userData`"", '-Worker', $worker, '-GamePid', $started.Id)
                if ($profileDir) { $uploaderArgs += @('-ProfileDir', "`"$profileDir`"") }   # (the identity is in the profile folder since 23 October)
                Start-Process powershell -WindowStyle Hidden -ArgumentList $uploaderArgs | Out-Null
            } catch { Write-Host "The replay uploader did not start: $($_.Exception.Message)" }
        }
    }
} finally {
    if ($mine -and -not $handed) { Release-GameLock }
}
