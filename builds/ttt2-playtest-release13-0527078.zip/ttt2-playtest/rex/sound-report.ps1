# Report a sound problem: plays the game with its sound recorders on, and afterwards packs what
# is needed to find the fault into two zip files on the Desktop.
#
#   powershell -ExecutionPolicy Bypass -File rex\sound-report.ps1
#
# What the player does: plays until the fault is heard, presses F9 (or clicks both sticks in)
# each time it is heard, then closes the game and answers four questions.
#
# What is gathered (nothing of the game's own files, and nothing personal but the PC's parts):
#   - the game's log of the session, with the sound's own counters (--audio_stats), every
#     change of state of the music and sound decoders (--xma_trace), and the game's messages
#     to the console's music player (--ttt2_xmsg_trace);
#   - what the game handed to the sound device, and the frames the game's mixer made, looked
#     through for silence, repeated frames and each channel's level ten seconds at a time;
#   - short clips of both as WAV files around each F9 press (or the session's last seconds);
#   - the PC: Windows, processor, graphics card, sound devices and their formats; the build.
#
# For the main session's own checks: -Seconds n closes the game after n seconds, -NoQuestions
# skips the questions, -GameArgs passes more switches to the game, -OutDir instead of the Desktop.
param(
    [int]$Seconds = 0,
    [switch]$NoQuestions,
    [string[]]$GameArgs = @(),
    [string]$OutDir = ''
)
$ErrorActionPreference = 'Stop'
$Rex = $PSScriptRoot
. (Join-Path $Rex 'tools\remove-folder.ps1')   # (Remove-Ttt2Folder: deletes through .NET, safe in a non-ASCII install folder)
$exeDir = Join-Path $Rex 'out\build\win-amd64-release'
$exe = Join-Path $exeDir 'ttt2.exe'
if (-not (Test-Path -LiteralPath $exe)) { throw 'The game is not built yet: use Start Here first.' }
if (-not $OutDir) { $OutDir = [Environment]::GetFolderPath('Desktop') }

# How long a clip is: this many seconds before a press of F9 and after it; at most so many presses.
$ClipBefore = 20
$ClipAfter = 5
$MostClips = 4

Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Text;

public static class Ttt2SoundReport {
  static float BigFloat(byte[] b, int at) {
    byte[] four = new byte[4];
    four[0] = b[at + 3]; four[1] = b[at + 2]; four[2] = b[at + 1]; four[3] = b[at];
    return BitConverter.ToSingle(four, 0);
  }

  // The frames the game's mixer made (--audio_dump_mix): six channels of 256 big-endian floats,
  // one channel after another, 187.5 frames a second. Ten seconds at a time: frames that are
  // all silence, frames that are the frame two before again (a stale one: the crunch found in
  // October), and each channel's level in thousandths of full scale.
  public static string Mix(string path) {
    const int frameBytes = 6 * 256 * 4, block = 1875;
    StringBuilder text = new StringBuilder();
    text.AppendLine("seconds  frames  silent  stale  level of each channel (thousandths of full scale), peak");
    byte[] frame = new byte[frameBytes], one = new byte[frameBytes], two = new byte[frameBytes];
    long frames = 0, silentAll = 0, staleAll = 0;
    int inBlock = 0, silent = 0, stale = 0;
    double[] squares = new double[6];
    float peak = 0;
    using (FileStream file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite, 1 << 20)) {
      while (true) {
        int got = 0;
        while (got < frameBytes) {
          int n = file.Read(frame, got, frameBytes - got);
          if (n <= 0) break;
          got += n;
        }
        bool whole = got == frameBytes;
        if (whole) {
          bool isSilent = true, isStale = frames >= 2;
          for (int i = 0; i < frameBytes; ++i) {
            if (frame[i] != 0) isSilent = false;
            if (frame[i] != two[i]) isStale = false;
          }
          if (isSilent) { ++silent; ++silentAll; }
          else if (isStale) { ++stale; ++staleAll; }
          for (int c = 0; c < 6; ++c) {
            for (int s = 0; s < 256; ++s) {
              float v = BigFloat(frame, (c * 256 + s) * 4);
              squares[c] += (double)v * v;
              if (Math.Abs(v) > peak) peak = Math.Abs(v);
            }
          }
          byte[] swap = two; two = one; one = frame; frame = swap;
          ++frames; ++inBlock;
        }
        if (inBlock == block || (!whole && inBlock > 0)) {
          text.AppendFormat("{0,7:0}  {1,6}  {2,6}  {3,5} ", frames / 187.5, inBlock, silent, stale);
          for (int c = 0; c < 6; ++c) {
            text.AppendFormat(" {0,4:0}", 1000 * Math.Sqrt(squares[c] / (inBlock * 256.0)));
            squares[c] = 0;
          }
          text.AppendFormat("  {0:0.000}", peak);
          text.AppendLine();
          inBlock = 0; silent = 0; stale = 0; peak = 0;
        }
        if (!whole) break;
      }
    }
    text.AppendFormat("in all: {0} frames ({1:0} s), {2} silent, {3} stale", frames, frames / 187.5, silentAll, staleAll);
    text.AppendLine();
    return text.ToString();
  }

  // What went to the sound device (--audio_dump): little-endian floats, interleaved. Ten
  // seconds at a time: the level, the peak, samples at full scale, and stretches of exact
  // silence (64 samples or more) with sound on both sides.
  public static string Device(string path, int channels, int rate) {
    StringBuilder text = new StringBuilder();
    text.AppendLine("seconds  level (thousandths)  peak  at full scale  gaps of silence inside sound");
    int block = rate * channels * 10;
    byte[] buffer = new byte[1 << 20];
    long samples = 0, gapsAll = 0, clippedAll = 0;
    int inBlock = 0, gaps = 0, clipped = 0, zeros = 0;
    bool soundBefore = false;
    double squares = 0;
    float peak = 0;
    using (FileStream file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite, 1 << 20)) {
      int n, kept = 0;
      while ((n = file.Read(buffer, kept, buffer.Length - kept)) > 0) {
        int have = kept + n, at = 0;
        for (; at + 4 <= have; at += 4) {
          float v = BitConverter.ToSingle(buffer, at);
          if (v == 0) {
            ++zeros;
          } else {
            if (zeros >= 64 * channels && soundBefore) { ++gaps; ++gapsAll; }
            zeros = 0;
            soundBefore = true;
          }
          float a = Math.Abs(v);
          if (a > peak) peak = a;
          if (a >= 0.999f) { ++clipped; ++clippedAll; }
          squares += (double)v * v;
          ++samples;
          if (++inBlock == block) {
            text.AppendFormat("{0,7:0}  {1,6:0}  {2:0.000}  {3,6}  {4,5}", samples / (double)(rate * channels),
                              1000 * Math.Sqrt(squares / inBlock), peak, clipped, gaps);
            text.AppendLine();
            inBlock = 0; gaps = 0; clipped = 0; squares = 0; peak = 0;
          }
        }
        kept = have - at;
        Array.Copy(buffer, at, buffer, 0, kept);
      }
    }
    text.AppendFormat("in all: {0:0} s, {1} samples at full scale, {2} gaps of silence inside sound",
                      samples / (double)(rate * channels), clippedAll, gapsAll);
    text.AppendLine();
    return text.ToString();
  }

  static void WavHeader(BinaryWriter w, int channels, int rate, long dataBytes) {
    w.Write(Encoding.ASCII.GetBytes("RIFF")); w.Write((int)(36 + dataBytes));
    w.Write(Encoding.ASCII.GetBytes("WAVEfmt ")); w.Write(16); w.Write((short)1); w.Write((short)channels);
    w.Write(rate); w.Write(rate * channels * 2); w.Write((short)(channels * 2)); w.Write((short)16);
    w.Write(Encoding.ASCII.GetBytes("data")); w.Write((int)dataBytes);
  }
  static short Sixteen(float v) {
    if (v > 1) v = 1;
    if (v < -1) v = -1;
    return (short)Math.Round(v * 32767);
  }

  // A stretch of the device's file as a 16-bit WAV: from and to are parts of the whole (0 to 1).
  public static void DeviceClip(string path, int channels, int rate, double from, double to, string wav) {
    using (FileStream file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)) {
      long unit = 4L * channels, units = file.Length / unit;
      long first = Math.Max(0, (long)(from * units)), last = Math.Min(units, (long)(to * units));
      if (last <= first) return;
      byte[] data = new byte[(last - first) * unit];
      file.Seek(first * unit, SeekOrigin.Begin);
      int got = 0, n;
      while (got < data.Length && (n = file.Read(data, got, data.Length - got)) > 0) got += n;
      using (BinaryWriter w = new BinaryWriter(File.Create(wav))) {
        WavHeader(w, channels, rate, got / 2);
        for (int at = 0; at + 4 <= got; at += 4) w.Write(Sixteen(BitConverter.ToSingle(data, at)));
      }
    }
  }

  // And of the mixer's frames, as a 16-bit WAV of six channels at 48 kHz.
  public static void MixClip(string path, double from, double to, string wav) {
    const int frameBytes = 6 * 256 * 4;
    using (FileStream file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)) {
      long frames = file.Length / frameBytes;
      long first = Math.Max(0, (long)(from * frames)), last = Math.Min(frames, (long)(to * frames));
      if (last <= first) return;
      byte[] frame = new byte[frameBytes];
      file.Seek(first * frameBytes, SeekOrigin.Begin);
      using (BinaryWriter w = new BinaryWriter(File.Create(wav))) {
        WavHeader(w, 6, 48000, (last - first) * 256 * 6 * 2);
        for (long f = first; f < last; ++f) {
          int got = 0, n;
          while (got < frameBytes && (n = file.Read(frame, got, frameBytes - got)) > 0) got += n;
          if (got < frameBytes) Array.Clear(frame, got, frameBytes - got);
          for (int s = 0; s < 256; ++s)
            for (int c = 0; c < 6; ++c) w.Write(Sixteen(BigFloat(frame, (c * 256 + s) * 4)));
        }
      }
    }
  }
}
'@

function Say($text, $color = 'White') { Write-Host $text -ForegroundColor $color }

# ---- Before the game -------------------------------------------------------------------------
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$work = Join-Path $Rex 'out\sound-report'
# (The recordings are large, some 3 MB a second: only the last session's are kept.)
$null = Remove-Ttt2Folder $work -Quiet
$session = Join-Path $work $stamp
$small = Join-Path $session 'report'
$clips = Join-Path $session 'clips'
New-Item -ItemType Directory -Force $small, $clips | Out-Null

Say ''
Say '  TTT2: report a sound problem' Cyan
Say '  ----------------------------'
Say '  The game starts now, recording its own sound.'
Say ''
Say '  1. Play until you hear the problem (crackle, music stopping, anything).'
Say '  2. EACH TIME you hear it, press F9 on the keyboard, or click BOTH STICKS in' Yellow
Say '     on the controller. That marks the moment.' Yellow
Say '  3. A few seconds after the last mark, close the game (Alt+F4 or the X).'
Say ''
Say '  Keep it under about 10 minutes: the recording takes some 200 MB of disk a minute'
Say '  (it is deleted the next time you run this).'
Say ''
if (-not $NoQuestions) { [void](Read-Host '  Press Enter to start the game') }

$logs = Join-Path $exeDir 'logs'
$began = Get-Date
$switches = @("--audio_dump=$(Join-Path $session 'device')", "--audio_dump_mix=$(Join-Path $session 'mix')",
              '--audio_stats=true', '--xma_trace=true', '--ttt2_xmsg_trace=true',
              '--ttt2_file_trace=true') + @($GameArgs | Where-Object { $_ })
# (--ttt2_file_trace too: the message trace only logs through its watch on kernel calls.)
& (Join-Path $Rex 'run-windows.ps1') @switches

$game = $null
$pidFile = Join-Path $Rex 'out\game-pid.txt'
if (Test-Path -LiteralPath $pidFile) {
    $id = [int](((Get-Content -LiteralPath $pidFile -Raw).Trim() -split ' ')[0])
    $game = Get-Process -Id $id -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $exe }
}
if (-not $game) { throw 'The game did not start. Try Play from Start Here first; if that works, tell the friend who gave you this.' }
Say '  The game is running. This window waits until you close it.'
if ($Seconds -gt 0) {
    if (-not $game.WaitForExit($Seconds * 1000)) { [void]$game.CloseMainWindow(); if (-not $game.WaitForExit(10000)) { $game.Kill() } }
} else {
    $game.WaitForExit()
}
$ended = Get-Date
Start-Sleep -Seconds 1

# ---- After it: the questions (while it is fresh) ---------------------------------------------
$answers = @("Session: $began to $ended")
if (-not $NoQuestions) {
    Say ''
    Say '  Four short questions (Enter skips one):' Cyan
    foreach ($q in @('What did you hear, in your own words?',
                     'Which mode, stage and characters? What was happening when it went wrong (a hit, a tag, two voices at once)?',
                     'What do you listen through (TV or monitor over HDMI, headphones in the PC, USB or Bluetooth headset, speakers, a receiver)?',
                     'Does it happen every match or only sometimes? Anything else running (Discord, a stream, a browser)?')) {
        $answers += "Q: $q"
        $answers += "A: $(Read-Host "  $q`n  >")"
    }
}
Set-Content -LiteralPath (Join-Path $small 'answers.txt') $answers -Encoding utf8
Say ''
Say '  Putting the report together (a minute or so)...'

# ---- The log, and the marks in it ------------------------------------------------------------
$sessionLogs = @(Get-ChildItem -LiteralPath $logs -Filter 'ttt2_*.log' -ErrorAction SilentlyContinue |
                 Where-Object { $_.LastWriteTime -ge $began.AddSeconds(-5) } | Sort-Object LastWriteTime)
foreach ($log in $sessionLogs) { Copy-Item -LiteralPath $log.FullName $small }
$marks = @()
foreach ($log in $sessionLogs) {
    foreach ($line in (Select-String -LiteralPath $log.FullName -Pattern 'OWNER MARK' -SimpleMatch)) {
        if ($line.Line -match '^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d+)\]') {
            $marks += [datetime]::ParseExact($Matches[1].Substring(0, 23), 'yyyy-MM-dd HH:mm:ss.fff', $null)
        }
    }
}
# (Presses within the same clip are one.)
$marks = @($marks | Sort-Object)
$kept = @()
foreach ($mark in $marks) { if (-not $kept.Count -or ($mark - $kept[-1]).TotalSeconds -gt $ClipAfter) { $kept += $mark } }
$summary = @("TTT2 sound report, $stamp", "F9 marks: $($marks.Count) (as moments: $($kept.Count))")
$summary += $kept | ForEach-Object { "  mark at $($_.ToString('HH:mm:ss.fff'))" }
$noMarks = $kept.Count -eq 0
if ($noMarks) {
    $summary += "  no mark: the clips are the session's last $($ClipBefore + $ClipAfter) seconds"
    $kept = @($ended.AddSeconds(-$ClipAfter - 2))
}
$kept = @($kept | Select-Object -Last $MostClips)

# ---- The recordings: looked through, and clipped ---------------------------------------------
# (Where in a file a moment is: by its share of the time between the file's making and its
# last write. The device's file runs from the device's opening without a break.)
function Share($file, [datetime]$moment) {
    $span = ($file.LastWriteTime - $file.CreationTime).TotalSeconds
    if ($span -le 0) { return 0.0 }
    return [Math]::Min(1.0, [Math]::Max(0.0, ($moment - $file.CreationTime).TotalSeconds / $span))
}
foreach ($file in @(Get-ChildItem -LiteralPath $session -Filter 'mix*.mix.f32be' -ErrorAction SilentlyContinue)) {
    $name = $file.BaseName -replace '\.mix$', ''
    $summary += '', "== The mixer's frames, $($file.Name) ($([Math]::Round($file.Length / 1MB)) MB, made $($file.CreationTime.ToString('HH:mm:ss')), last written $($file.LastWriteTime.ToString('HH:mm:ss')))"
    try { $summary += [Ttt2SoundReport]::Mix($file.FullName) } catch { $summary += "could not be read: $_" }
    $n = 0
    foreach ($mark in $kept) {
        $n++
        try { [Ttt2SoundReport]::MixClip($file.FullName, (Share $file $mark.AddSeconds(-$ClipBefore)), (Share $file $mark.AddSeconds($ClipAfter)), (Join-Path $clips "$name-mark$n-6ch.wav")) } catch { $summary += "clip $n failed: $_" }
    }
}
foreach ($file in @(Get-ChildItem -LiteralPath $session -Filter 'device*.f32' -ErrorAction SilentlyContinue)) {
    # (How many channels the device took: by the file's size over its time, at 48 kHz.)
    $span = ($file.LastWriteTime - $file.CreationTime).TotalSeconds
    $channels = if ($span -gt 1) { [int][Math]::Round($file.Length / (4.0 * 48000 * $span)) } else { 2 }
    if ($channels -lt 1 -or $channels -gt 8) { $channels = 2 }
    $summary += '', "== To the sound device, $($file.Name) ($([Math]::Round($file.Length / 1MB)) MB over $([Math]::Round($span)) s: taken as $channels channels at 48 kHz)"
    try { $summary += [Ttt2SoundReport]::Device($file.FullName, $channels, 48000) } catch { $summary += "could not be read: $_" }
    $n = 0
    foreach ($mark in $kept) {
        $n++
        try { [Ttt2SoundReport]::DeviceClip($file.FullName, $channels, 48000, (Share $file $mark.AddSeconds(-$ClipBefore)), (Share $file $mark.AddSeconds($ClipAfter)), (Join-Path $clips "$($file.BaseName)-mark$n.wav")) } catch { $summary += "clip $n failed: $_" }
    }
}
if (-not (Get-ChildItem -LiteralPath $session -Filter '*.f32*' -ErrorAction SilentlyContinue)) {
    $summary += '', 'NO RECORDING WAS MADE: this build has not the recorders (older than 13 October), or the game made no sound.'
}

# ---- The log's own lines on the sound --------------------------------------------------------
$picked = @()
foreach ($log in $sessionLogs) {
    $picked += Select-String -LiteralPath $log.FullName -Pattern 'OWNER MARK|Audio|audio|XMA|Xma|XMsg|Sound:|SDL|speaker|underrun|silence' |
        ForEach-Object { $_.Line }
}
Set-Content -LiteralPath (Join-Path $small 'sound-lines.txt') $picked -Encoding utf8

# ---- The PC and the build --------------------------------------------------------------------
$pc = @()
function Try-Add($title, [scriptblock]$what) {
    $script:pc += '', "== $title"
    try { $script:pc += (& $what | Out-String).Trim() } catch { $script:pc += "not available: $_" }
}
Try-Add 'The build' {
    $version = Join-Path (Split-Path $Rex -Parent) 'VERSION.txt'
    if (Test-Path -LiteralPath $version) { Get-Content -LiteralPath $version }
    $git = Get-Command git -ErrorAction SilentlyContinue
    if ($git -and (Test-Path -LiteralPath (Join-Path (Split-Path $Rex -Parent) '.git'))) { "git: $(& git -C $Rex log -1 --format='%h %ci %s')" }
    "ttt2.exe: $((Get-Item -LiteralPath $exe).LastWriteTime), $((Get-Item -LiteralPath $exe).Length) bytes"
    $prebuiltManifest = Join-Path $Rex 'prebuilt\manifest.txt'
    if (Test-Path -LiteralPath $prebuiltManifest) {
        # (The prebuilt package: no rex\patches; the release's manifest names them and the toolchain.)
        Get-Content -LiteralPath $prebuiltManifest | Where-Object { $_ -match '^(release|build_id|toolchain|patches)=' }
    } else {
        'patches in this folder: ' + ((Get-ChildItem -LiteralPath (Join-Path $Rex 'patches') -Filter *.patch | ForEach-Object { $_.Name.Substring(0, 2) }) -join ' ')
    }
    # (Which patches the runtime in use was built with: the sound's mend is patch 20.)
    $records = Get-ChildItem -LiteralPath $env:USERPROFILE -Directory -Filter 'rexsdk*' -ErrorAction SilentlyContinue |
        ForEach-Object { Join-Path $_.FullName 'install\ttt2-patches.txt' } | Where-Object { Test-Path -LiteralPath $_ }
    foreach ($record in @($records | ForEach-Object { Get-Item -LiteralPath $_ })) {
        "runtime $($record.Directory.Parent.Name), built $($record.LastWriteTime): patches " +
            (((Get-Content -LiteralPath $record.FullName -Raw) -split ';' | ForEach-Object { $_.Trim().Substring(0, 2) }) -join ' ')
    }
    "rexruntime.dll beside the game: $((Get-Item -LiteralPath (Join-Path $exeDir 'rexruntime.dll') -ErrorAction SilentlyContinue).LastWriteTime)"
    "the game's switches: $($switches -join ' ')"
}
Try-Add 'Windows' { Get-CimInstance Win32_OperatingSystem | Format-List Caption, Version, BuildNumber, OSArchitecture }
Try-Add 'Processor and memory' {
    Get-CimInstance Win32_Processor | Format-List Name, NumberOfCores, NumberOfLogicalProcessors, MaxClockSpeed
    "memory: $([Math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)) GB"
}
Try-Add 'Graphics' { Get-CimInstance Win32_VideoController | Format-List Name, DriverVersion, CurrentHorizontalResolution, CurrentVerticalResolution, CurrentRefreshRate }
Try-Add 'Power plan' { powercfg /getactivescheme }
Try-Add 'Sound devices (drivers)' { Get-CimInstance Win32_SoundDevice | Format-Table Name, Manufacturer, Status -AutoSize }
Try-Add 'Playback devices that are active, and the format Windows mixes each at' {
    $root = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices\Audio\Render'
    foreach ($key in Get-ChildItem -LiteralPath $root) {
        if ((Get-ItemProperty -LiteralPath $key.PSPath).DeviceState -ne 1) { continue }
        $p = Get-ItemProperty -LiteralPath (Join-Path $key.PSPath 'Properties') -ErrorAction SilentlyContinue
        $name = "$($p.'{a45c254e-df1c-4efd-8020-67d146a850e0},2') ($($p.'{b3f8fa53-0004-438e-9003-51a46e139bfc},6'))"
        $format = $p.'{f19f064d-082c-4e27-bc73-6882a1bb8e4c},0'
        if ($format -and $format.Length -ge 24) {
            "{0}: {1} channels, {2} Hz, {3} bits" -f $name, [BitConverter]::ToUInt16($format, 10), [BitConverter]::ToUInt32($format, 12), [BitConverter]::ToUInt16($format, 22)
        } else { "${name}: format not readable" }
    }
}
Try-Add 'Programs running that often touch sound or the screen' {
    Get-Process | Where-Object { $_.ProcessName -match 'discord|obs|steam|chrome|firefox|msedge|spotify|voicemeeter|nahimic|sonic|dolby|dts|realtek|nvidia.*broadcast|equalizer|wave|razer|logi|corsair|steelseries|medal|overwolf' } |
        Group-Object ProcessName | ForEach-Object { "$($_.Name) x$($_.Count)" }
}
Set-Content -LiteralPath (Join-Path $small 'pc.txt') $pc -Encoding utf8
Set-Content -LiteralPath (Join-Path $small 'summary.txt') $summary -Encoding utf8

# ---- The two zips ----------------------------------------------------------------------------
$zipSmall = Join-Path $OutDir "ttt2-sound-report-$stamp.zip"
$zipClips = Join-Path $OutDir "ttt2-sound-clips-$stamp.zip"
Compress-Archive -LiteralPath @(Get-ChildItem -LiteralPath $small -Force | ForEach-Object { $_.FullName }) -DestinationPath $zipSmall -Force
$haveClips = @(Get-ChildItem -LiteralPath $clips -Filter *.wav -ErrorAction SilentlyContinue).Count -gt 0
if ($haveClips) { Compress-Archive -LiteralPath @(Get-ChildItem -LiteralPath $clips -Force | ForEach-Object { $_.FullName }) -DestinationPath $zipClips -Force }

Say ''
Say '  Done. Please send these (they are on your Desktop):' Green
Say "    1. $(Split-Path $zipSmall -Leaf)   ($([Math]::Round((Get-Item -LiteralPath $zipSmall).Length / 1MB, 1)) MB: the report)"
if ($haveClips) {
    Say "    2. $(Split-Path $zipClips -Leaf)   ($([Math]::Round((Get-Item -LiteralPath $zipClips).Length / 1MB, 1)) MB: the sound itself, as WAV files)"
    Say '       If it is too big for Discord, use a file share (Google Drive, WeTransfer), or send the report alone first.'
}
if ($noMarks) { Say "  No F9 mark was seen: the clips are the last $($ClipBefore + $ClipAfter) seconds before you closed the game." Yellow }
Say ''
Say '  If you can, listen to a "device" WAV in the clips: if it sounds CLEAN there but was'
Say '  crunchy while you played, say so. That alone tells us a lot.'
if (-not $NoQuestions) {
    Start-Process explorer.exe "/select,`"$zipSmall`""
    [void](Read-Host '  Press Enter to close')
}
