@echo off
rem Opens the TTT2 launcher window. This console shows until the window is up (the launcher then hides it), so a start
rem that fails says why here (4.5: before, it was a hidden window and any failure was a flash and nothing).
if exist "%~dp0rex\launcher.ps1" goto run
echo.
echo   Start Here can't find rex\launcher.ps1 beside it.
echo   Unzip the WHOLE zip into a folder first (right-click the zip, Extract All),
echo   then run Start Here.cmd from that folder, not from inside the zip.
echo.
pause
exit /b 1
:run
echo Opening Start Here...
set "TTT2ERR=%LOCALAPPDATA%\TTT2Native\logs\start-here-error.txt"
if not exist "%LOCALAPPDATA%\TTT2Native\logs" mkdir "%LOCALAPPDATA%\TTT2Native\logs"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0rex\launcher.ps1" 2> "%TTT2ERR%"
if not errorlevel 1 exit /b 0
echo.
type "%TTT2ERR%"
echo.
echo   Start Here couldn't open. Send a screenshot of this window to the Discord.
echo.
pause
