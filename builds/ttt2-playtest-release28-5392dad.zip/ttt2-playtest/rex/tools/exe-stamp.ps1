# The game program (ttt2.exe) and the package it was made from (24 Nov, 5.1.2, 5.2-9, the lead's order).
# A tester unzipped 5.1.1 over a 5.0 folder: the folder said 5.1.1 (package-info patch 26) but ttt2.exe was 5.0's, and Play started it with 5.1.1's switch list. The build step only relinked when the last build's copy of the
# manifest (out\build\...\prebuilt-manifest.txt) existed and differed: with no copy, nothing was relinked and the build step then wrote its "package-version" marker anyway.
# THE RULE NOW: a prebuilt package's exe carries a stamp, out\build\win-amd64-release\exe-package.txt = "<SHA-256 of rex\prebuilt\manifest.txt>|<the exe's size>|<its last-write ticks>", written by build-windows.ps1 right after a link.
# The stamp is valid only for THIS manifest and THIS exe file. An exe with no valid stamp is never started (run-windows.ps1), the setup says "build" (Step-Status, Step-LaunchCheck), and Step-Build relinks it first.
#   . rex\tools\exe-stamp.ps1
#   Get-Ttt2ExeStampState $Rex   -> 'ok' | 'missing' (no stamp) | 'other' (a stamp for another manifest or another exe file) | 'none' (not a prebuilt package or no exe: nothing to say)
function Get-Ttt2ExeStampLine([string]$Rex) {
    $manifest = Join-Path $Rex 'prebuilt\manifest.txt'
    $exe = Join-Path $Rex 'out\build\win-amd64-release\ttt2.exe'
    if (-not (Test-Path -LiteralPath $manifest) -or -not (Test-Path -LiteralPath $exe)) { return '' }
    $item = Get-Item -LiteralPath $exe
    "$((Get-FileHash -LiteralPath $manifest -Algorithm SHA256).Hash)|$($item.Length)|$($item.LastWriteTimeUtc.Ticks)"
}
function Get-Ttt2ExeStampState([string]$Rex) {
    $now = Get-Ttt2ExeStampLine $Rex
    if (-not $now) { return 'none' }
    $file = Join-Path $Rex 'out\build\win-amd64-release\exe-package.txt'
    if (-not (Test-Path -LiteralPath $file)) { return 'missing' }
    $was = "$(Get-Content -LiteralPath $file -Raw -ErrorAction SilentlyContinue)".Trim()
    if ($was -eq $now) { 'ok' } else { 'other' }
}
function Write-Ttt2ExeStamp([string]$Rex) {
    $line = Get-Ttt2ExeStampLine $Rex
    if (-not $line) { return $false }
    Set-Content -LiteralPath (Join-Path $Rex 'out\build\win-amd64-release\exe-package.txt') $line -Encoding ascii
    $true
}
