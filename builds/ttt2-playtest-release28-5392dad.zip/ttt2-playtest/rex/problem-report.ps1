# Report a problem: packs what is needed to look into a crash, a hang, a failed build or anything else
# into one zip on the Desktop, for whoever gave out the build. Nothing is played or changed.
#
#   powershell -ExecutionPolicy Bypass -File rex\problem-report.ps1 [-OutDir <folder>] [-NoPause] [-ResultFile <file>]
#
# -ResultFile (BlueSpark's REPORT A PROBLEM card, 14 Nov): when the zip is made the script writes "OK <the zip's file name>" into that file, and "FAIL" if it could not be made,
# so the game can tell the player where it is. Nothing else changes.
#
# What goes in:
#   - the newest run's game log and its newest parts, 4 at most, and the two runs before it (their live logs only: with
#     the BlueSpark client a game is started each time the client is, so the run that showed the problem may not be
#     the newest) (rex\out\build\win-amd64-release\logs), and the newest 3 crash dumps of the
#     last 14 days (rex\out\dumps, --ttt2_crash_dump's), and the hang dumps of the last 14 days (profile\hang.txt and hang-2.txt, hang-3.txt..., 20 at most,
#     --ttt2_hang_dump's: where every thread was when the game stopped updating; the alt-tab freeze, 24 Oct);
#   - Start Here's own logs (%LOCALAPPDATA%\TTT2Native\logs: the newest 8 step logs (Play's too) with their .err, and
#     update-check.log), and the BlueSpark client's log always (fastclient.log, and fastclient.log.old: the one before
#     it, past 2 MB);
#   - VERSION.txt, rex\package-info.txt, prebuilt\manifest.txt's release line, the display and tearing
#     settings (those two lines of rex\userdata\launcher-settings.txt, nothing else of it);
#   - the PC: Windows, the processor, memory, the graphics card and its driver, each monitor's size, the game controllers Windows sees (vendor:product IDs only, no names).
# Every text file is masked first, as log_upload.cpp masks its own upload: each IPv4 address -> ip-N (lan-ip-N for a local one; the same
# N for the same address within one report), invite codes (they hold an address), the Windows user name. Crash dumps stay as they are.
# What NEVER goes in: the identity and its key, the saves, the profile backup, the replays, or anything
# else of rex\userdata (the player's name, the settings file itself): only the paths above are read.
param([string]$OutDir = '', [switch]$NoPause, [string]$ResultFile = '')
$ErrorActionPreference = 'Stop'
# (a failure anywhere: the answer "FAIL" for the game's card, then the error as before)
trap { if ($ResultFile) { try { Set-Content -LiteralPath $ResultFile 'FAIL' -Encoding ascii } catch {} }; break }
$Rex = $PSScriptRoot
. (Join-Path $Rex 'tools\remove-folder.ps1')   # (Remove-Ttt2Folder: deletes through .NET, safe in a non-ASCII install folder)
$Root = Split-Path $Rex -Parent
if (-not $OutDir) { $OutDir = [Environment]::GetFolderPath('Desktop') }

function Say($text, $color = 'White') { Write-Host $text -ForegroundColor $color }

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
# (4.5.1, B: in our own temp folder, not %TEMP%: an 8.3 short %TEMP% (a user name with a space) breaks Windows PowerShell 5.1's -LiteralPath.)
$work = Join-Path (Join-Path $env:LOCALAPPDATA 'TTT2Native\tmp') "ttt2-problem-report-$stamp"
New-Item -ItemType Directory -Force $work | Out-Null
$summary = @("TTT2 problem report, $stamp", "folder: $Root", '')

# The newest files of a folder matching a filter, copied under a subfolder of the report.
function Take([string]$from, [string]$filter, [int]$count, [string]$to, [int]$days = 0) {
    if (-not (Test-Path -LiteralPath $from)) { $script:summary += "${to}: none ($from is not there)"; return }
    $files = @(Get-ChildItem -LiteralPath $from -Filter $filter -File -ErrorAction SilentlyContinue |
               Where-Object { $days -le 0 -or $_.LastWriteTime -ge (Get-Date).AddDays(-$days) } |
               Sort-Object LastWriteTime -Descending | Select-Object -First $count)
    if (-not $files.Count) { $script:summary += "${to}: none"; return }
    $dir = Join-Path $work $to
    New-Item -ItemType Directory -Force $dir | Out-Null
    foreach ($f in $files) {
        Copy-Item -LiteralPath $f.FullName $dir
        $script:summary += "${to}\$($f.Name)  ($([Math]::Round($f.Length / 1KB)) KB, $($f.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')))"
    }
}

# The game's logs: the newest run's live log (ttt2_NNN.log, the highest NNN), then that run's newest cut parts
# (ttt2_NNN.1.log ...), 4 files at most. (Not by file time: a log the game still has open can keep an old time, and two
# reports in a row, 26 Oct, took the run's cut parts and left out the live log, which held the freeze.) Read shared, as
# the game may be writing it.
function TakeGameLogs([string]$from, [string]$to, [int]$count = 4) {
    if (-not (Test-Path -LiteralPath $from)) { $script:summary += "${to}: none ($from is not there)"; return }
    $runs = @(Get-ChildItem -LiteralPath $from -Filter 'ttt2_*.log' -File -ErrorAction SilentlyContinue |
              Where-Object { $_.Name -match '^ttt2_(\d+)\.log$' } | Sort-Object { [int]($_.Name -replace '^ttt2_(\d+)\.log$', '$1') } -Descending)
    if (-not $runs.Count) { $script:summary += "${to}: none"; return }
    $run = $runs[0].Name -replace '\.log$', ''
    $parts = @(Get-ChildItem -LiteralPath $from -Filter "$run.*.log" -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    $files = @(@($runs[0]) + $parts | Select-Object -First $count)
    # (The two runs before it, their live logs only: the BlueSpark client starts a game each time it is started, so the
    # run that showed a problem is often not the newest one (the fast client lead, 31 Oct).)
    $files += @($runs | Select-Object -Skip 1 -First 2)
    # (24 Nov, 5.1: a run's log rotates at 5 MB into ttt2_N.1.log, .2.log ...; the base file is only its NEWEST part. The two earlier runs gave the base alone, so a long run's first part, boot included, was left out: each one's newest rotated part (.1.log) goes in too.)
    foreach ($earlier in @($runs | Select-Object -Skip 1 -First 2)) {
        $one = Join-Path $from (($earlier.Name -replace '\.log$', '') + '.1.log')
        if (Test-Path -LiteralPath $one) { $files += @(Get-Item -LiteralPath $one) }
    }
    $dir = Join-Path $work $to
    New-Item -ItemType Directory -Force $dir | Out-Null
    foreach ($f in $files) {
        try {
            $in = [IO.File]::Open($f.FullName, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
            try { $out = [IO.File]::Create((Join-Path $dir $f.Name)); try { $in.CopyTo($out) } finally { $out.Dispose() } } finally { $in.Dispose() }
            $script:summary += "${to}\$($f.Name)  ($([Math]::Round($f.Length / 1KB)) KB, $($f.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')))"
        } catch {
            $script:summary += "${to}\$($f.Name): not read ($($_.Exception.Message))"
        }
    }
}

# The report's masking, the rules of log_upload.cpp's Redactor: one pass over a file's text, so nothing is replaced twice.
$script:maskIps = @{}
function Get-MaskPattern {
    $byte = '(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])'
    $parts = @("(?<ip>(?<![0-9.])$byte(?:\.$byte){3}(?![0-9]|\.[0-9]))",
               '(?<code>(?<![0-9A-Z-])[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}(?![0-9A-Z-]))')
    if ($env:USERPROFILE -and $env:USERPROFILE.Length -gt 3) { $parts += "(?<profile>(?i:$([regex]::Escape($env:USERPROFILE))))" }
    $parts += '(?<other>(?i:[\\/]Users[\\/])[^\\/"'' \r\n]+)'
    if ($env:USERNAME -and $env:USERNAME.Length -ge 3) { $parts += "(?<user>(?i:$([regex]::Escape($env:USERNAME))))" }
    $parts -join '|'
}
function Get-MaskedAddress([string]$address) {
    if ($address -eq '0.0.0.0') { return $address }
    if (-not $script:maskIps.ContainsKey($address)) { $script:maskIps[$address] = $script:maskIps.Count + 1 }
    $o = @($address.Split('.') | ForEach-Object { [int]$_ })
    $local = $o[0] -eq 10 -or $o[0] -eq 127 -or ($o[0] -eq 192 -and $o[1] -eq 168) -or ($o[0] -eq 172 -and $o[1] -ge 16 -and $o[1] -lt 32) -or
             ($o[0] -eq 169 -and $o[1] -eq 254) -or ($o[0] -eq 100 -and $o[1] -ge 64 -and $o[1] -lt 128)
    "$(if ($local) { 'lan-' } else { '' })ip-$($script:maskIps[$address])"
}
# Every file of the report but the dumps, rewritten masked. A file that can't be masked is left out, never packed as it is.
function Invoke-MaskReport([string]$folder) {
    $regex = New-Object System.Text.RegularExpressions.Regex (Get-MaskPattern)
    $evaluator = [System.Text.RegularExpressions.MatchEvaluator] {
        param($m)
        if ($m.Groups['ip'].Success) { return Get-MaskedAddress $m.Value }
        if ($m.Groups['code'].Success) { return 'invite-code' }
        if ($m.Groups['profile'].Success) { return '%USERPROFILE%' }
        if ($m.Groups['other'].Success) { return $m.Value.Substring(0, 7) + '%USERNAME%' }
        '%USERNAME%'
    }
    $utf8 = New-Object System.Text.UTF8Encoding $false
    foreach ($file in @(Get-ChildItem -LiteralPath $folder -Recurse -File | Where-Object { $_.Extension -ne '.dmp' })) {
        try {
            [IO.File]::WriteAllText($file.FullName, $regex.Replace([IO.File]::ReadAllText($file.FullName), $evaluator), $utf8)
        } catch {
            Remove-Item -LiteralPath $file.FullName -Force
            $script:maskFailed += $file.Name
        }
    }
}
$script:maskFailed = @()

Say ''
Say '  TTT2: report a problem' Cyan
Say '  ----------------------'
Say '  Putting the report together...'

TakeGameLogs (Join-Path $Rex 'out\build\win-amd64-release\logs') 'game-logs'
Take (Join-Path $Rex 'out\dumps') 'ttt2_*.dmp' 3 'crash-dumps' 14
Take (Join-Path $Rex 'out\build\win-amd64-release\profile') 'hang*.txt' 20 'hang-dump' 14   # (hang.txt and every hang-N.txt after it: the lead, 30 Oct)
$setupLogs = Join-Path $env:LOCALAPPDATA 'TTT2Native\logs'
Take $setupLogs '*.log' 8 'start-here-logs'
# (each step log's .err beside it)
foreach ($f in @(Get-ChildItem -LiteralPath (Join-Path $work 'start-here-logs') -Filter '*.log' -ErrorAction SilentlyContinue)) {
    $err = Join-Path $setupLogs "$($f.Name).err"
    if (Test-Path -LiteralPath $err) { Copy-Item -LiteralPath $err (Join-Path $work 'start-here-logs') }
}
# (Start Here.cmd's own error file (4.5): what stopped the launcher before its window opened.)
$startError = Join-Path $setupLogs 'start-here-error.txt'
if (Test-Path -LiteralPath $startError) {
    New-Item -ItemType Directory -Force (Join-Path $work 'start-here-logs') | Out-Null
    Copy-Item -LiteralPath $startError (Join-Path $work 'start-here-logs')
}
# (CMake's configure logs, the game's and the SDK's (3 Nov: a player's Install stopped at the compiler's own feature test, whose
# reason is only in CMakeConfigureLog.yaml). Masked with the rest.)
foreach ($pair in @(@((Join-Path $Rex 'out\build\win-amd64-release\CMakeFiles'), 'cmake-game'),
                    @((Join-Path $env:USERPROFILE 'rexsdk\src\out\build\win-amd64\CMakeFiles'), 'cmake-sdk'),
                    @((Join-Path $env:USERPROFILE 'rexsdk-portable\src\out\build\win-amd64\CMakeFiles'), 'cmake-sdk-portable'))) {
    $cf = Join-Path $pair[0] 'CMakeConfigureLog.yaml'
    if (Test-Path -LiteralPath $cf) {
        $d = Join-Path $work $pair[1]
        New-Item -ItemType Directory -Force $d | Out-Null
        Copy-Item -LiteralPath $cf $d
        $script:summary += "$($pair[1])\CMakeConfigureLog.yaml  ($([Math]::Round((Get-Item -LiteralPath $cf).Length / 1KB)) KB)"
    }
}
# (The BlueSpark client's log always, and the one before it: the newest 8 above may leave them out.)
Take $setupLogs 'fastclient.log*' 2 'fastclient-logs'
$updateCheck = Join-Path $setupLogs 'update-check.log'
if ((Test-Path -LiteralPath $updateCheck) -and -not (Test-Path -LiteralPath (Join-Path $work 'start-here-logs\update-check.log'))) {
    New-Item -ItemType Directory -Force (Join-Path $work 'start-here-logs') | Out-Null
    Copy-Item -LiteralPath $updateCheck (Join-Path $work 'start-here-logs')
}

# ---- The build and the settings ---------------------------------------------------------------
$build = @('== The build')
foreach ($file in @((Join-Path $Root 'VERSION.txt'), (Join-Path $Rex 'package-info.txt'))) {
    if (Test-Path -LiteralPath $file) { $build += "-- $(Split-Path $file -Leaf):"; $build += Get-Content -LiteralPath $file } else { $build += "-- $(Split-Path $file -Leaf): not there" }
}
$manifest = Join-Path $Rex 'prebuilt\manifest.txt'
if (Test-Path -LiteralPath $manifest) { $build += '-- prebuilt\manifest.txt:'; $build += Get-Content -LiteralPath $manifest | Where-Object { $_ -match '^(release|toolchain)=' } }
else { $build += 'prebuilt\manifest.txt: not there (a build from source)' }
$exe = Join-Path $Rex 'out\build\win-amd64-release\ttt2.exe'
if (Test-Path -LiteralPath $exe) { $build += "ttt2.exe: $((Get-Item -LiteralPath $exe).LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')), $((Get-Item -LiteralPath $exe).Length) bytes" }
else { $build += 'ttt2.exe: not built' }
$build += '', '== Display settings (BlueSpark)'
$settings = Join-Path $Rex 'userdata\launcher-settings.txt'
$shown = @()
if (Test-Path -LiteralPath $settings) { $shown = @(Get-Content -LiteralPath $settings | Where-Object { $_ -match '^(display|tearing)=' }) }
$build += $(if ($shown.Count) { $shown } else { 'the defaults (no display or tearing setting saved)' })

# ---- The PC -----------------------------------------------------------------------------------
$pc = @()
function Try-Add($title, [scriptblock]$what) {
    $script:pc += '', "== $title"
    try { $script:pc += (& $what | Out-String).Trim() } catch { $script:pc += "not available: $_" }
}
Try-Add 'Windows' { Get-CimInstance Win32_OperatingSystem | Format-List Caption, Version, BuildNumber, OSArchitecture }
Try-Add 'Smart App Control (0 off, 1 on, 2 evaluation)' { "state: $((Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy' -Name VerifiedAndReputablePolicyState -ErrorAction Stop).VerifiedAndReputablePolicyState)" }
Try-Add 'Processor and memory' {
    Get-CimInstance Win32_Processor | Format-List Name, NumberOfCores, NumberOfLogicalProcessors, MaxClockSpeed
    "memory: $([Math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)) GB"
}
Try-Add 'Graphics' { Get-CimInstance Win32_VideoController | Format-List Name, DriverVersion, DriverDate, CurrentHorizontalResolution, CurrentVerticalResolution, CurrentRefreshRate }
Try-Add 'Monitors' {
    # (DPI-aware first: otherwise Windows' scaling shrinks the sizes, 3840 x 2160 at 200% read as 1920 x 1080.)
    Add-Type -Name Dpi -Namespace Ttt2Report -MemberDefinition '[DllImport("user32.dll")] public static extern bool SetProcessDPIAware();'
    [void][Ttt2Report.Dpi]::SetProcessDPIAware()
    Add-Type -AssemblyName System.Windows.Forms
    foreach ($s in [System.Windows.Forms.Screen]::AllScreens) {
        "{0}: {1} x {2}{3}" -f $s.DeviceName, $s.Bounds.Width, $s.Bounds.Height, $(if ($s.Primary) { ' (main)' } else { '' })
    }
    Get-CimInstance -Namespace root\wmi -ClassName WmiMonitorBasicDisplayParams -ErrorAction SilentlyContinue |
        ForEach-Object { "panel: {0} x {1} cm" -f $_.MaxHorizontalImageSize, $_.MaxVerticalImageSize }
}
Try-Add 'Power plan' { powercfg /getactivescheme }
# (Game controllers Windows sees, the helper lead's job 41, 14 Nov: vendor:product IDs only, never a device name or serial. Windows' own game-controller entries (HID game controllers, Xbox/XInput
# ones, Bluetooth ones) are matched by name, but only their VID and PID are written.)
Try-Add 'game controllers Windows sees (vendor:product IDs only)' {
    $ids = @()
    foreach ($d in @(Get-CimInstance Win32_PnPEntity -ErrorAction Stop | Where-Object { $_.Present -ne $false -and ($_.Name -match 'game controller|gamepad|joystick|xbox|wireless controller|dualshock|dualsense|pro controller' -or $_.PNPDeviceID -match '^(XUSBIF|XINPUT)') })) {
        $id = "$($d.DeviceID)"
        if ($id -match 'VID_([0-9A-Fa-f]{4})&PID_([0-9A-Fa-f]{4})') { $ids += ('{0}:{1}' -f $Matches[1].ToLower(), $Matches[2].ToLower()) }
        elseif ($id -match 'VID&[0-9A-Fa-f]{2}([0-9A-Fa-f]{4})_PID&([0-9A-Fa-f]{4})') { $ids += ('{0}:{1}' -f $Matches[1].ToLower(), $Matches[2].ToLower()) }
    }
    $ids = @($ids | Sort-Object -Unique)
    if ($ids.Count) { $ids } else { 'none seen' }
}
# (D2, the lead's D, 27 Oct: which of our files are missing, from the package's own list: missing-files.txt. No antivirus
# is asked anything (4.4.2). The Windows user's folder written as %USERPROFILE%.)
$missingScript = Join-Path $Rex 'tools\missing-files.ps1'
if (Test-Path -LiteralPath $missingScript) {
    try {
        . (Join-Path $Rex 'tools\data-folder.ps1')
        if (Test-Path -LiteralPath (Join-Path $Rex 'tools\toolchain.ps1')) { . (Join-Path $Rex 'tools\toolchain.ps1') }
        . $missingScript
        $missing = @(Get-Ttt2MissingFiles $Root)
        $lines = @("missing files: $(if ($missing.Count) { $missing.Count } else { 'none' })") + @($missing | ForEach-Object { "  $_" })
        $lines += "the tools and game files: $(Get-Ttt2DataFolder)"
        Set-Content -LiteralPath (Join-Path $work 'missing-files.txt') ($lines | ForEach-Object { $_.Replace($env:USERPROFILE, '%USERPROFILE%') }) -Encoding utf8
        $summary += "missing-files.txt: $($lines[0])"
    } catch { $summary += "missing-files.txt: not made ($($_.Exception.Message))" }
}

# (24 Nov, 5.1.2, 5.2-7 and E5, the lead's order after reports 51 and 53: a crash that left no log of ours can still be in Windows' own Application log, and a report can come from an install that never ran the game.)
# 1) Windows' Application Error / Application Hang / Windows Error Reporting entries for ttt2.exe, the newest 10 of the last 14 days: application-errors.txt (time, provider, the entry's text: the faulting module, the exception
#    code, the fault offset and the faulting application's path). Read only; any failure is said in the summary.
# 2) The install this report ran from, named in the summary, and a WARNING when it holds no game log, or when the newest entry's faulting path is another folder (a second, unbuilt copy: report 51).
try {
    $since = (Get-Date).AddDays(-14)
    $events = @(Get-WinEvent -FilterHashtable @{ LogName = 'Application'; StartTime = $since } -MaxEvents 3000 -ErrorAction Stop |
                Where-Object { ($_.ProviderName -in @('Application Error', 'Application Hang', 'Windows Error Reporting', '.NET Runtime')) -and ($_.Message -match 'ttt2\.exe') } |
                Select-Object -First 10)
    if ($events.Count) {
        $out = foreach ($e in $events) { "[$($e.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss'))] $($e.ProviderName) (id $($e.Id))"; ($e.Message -split "`r?`n" | ForEach-Object { "  $_" }); '' }
        Set-Content -LiteralPath (Join-Path $work 'application-errors.txt') $out -Encoding utf8
        $summary += "application-errors.txt: $($events.Count) Windows Application log entries for ttt2.exe in the last 14 days (newest $($events[0].TimeCreated.ToString('yyyy-MM-dd HH:mm:ss')))"
        $path = [regex]::Match("$($events[0].Message)", '(?im)(?:Faulting application path|Application Path|Path):\s*(.+?ttt2\.exe)').Groups[1].Value
        if ($path -and -not $path.StartsWith($Root, [StringComparison]::OrdinalIgnoreCase)) {
            $summary += "WARNING: the newest ttt2.exe error in Windows' log is from another folder ($($path.Replace($env:USERPROFILE, '%USERPROFILE%'))), not this install ($Root): this report may come from the wrong copy."
        }
    } else {
        $summary += 'application-errors.txt: no Windows Application log entry for ttt2.exe in the last 14 days'
    }
} catch {
    if ("$($_.Exception.Message)" -match 'No events were found') { $summary += 'application-errors.txt: no Windows Application log entry for ttt2.exe in the last 14 days' }
    else { $summary += "application-errors.txt: not made ($($_.Exception.Message))" }
}
$gameLogs = @(Get-ChildItem -LiteralPath (Join-Path $Rex 'out\build\win-amd64-release\logs') -Filter 'ttt2_*.log' -File -ErrorAction SilentlyContinue)
$summary += "this report ran from the install: $Root"
if (-not $gameLogs.Count) { $summary += "WARNING: this install has NO game log (rex\out\build\win-amd64-release\logs): the game did not run from here, or it was never built here. Run the report from the install the game was started from." }
# (E1, 24 Nov: the "Match timing:" lines of the newest runs' logs, the last 6, so "slower" is a number in the summary.)
$timing = @()
foreach ($lg in @($gameLogs | Sort-Object Name -Descending | Select-Object -First 3)) {
    try {
        $fs = [IO.File]::Open($lg.FullName, 'Open', 'Read', 'ReadWrite'); $sr = New-Object IO.StreamReader($fs)
        $txt = $sr.ReadToEnd(); $sr.Dispose(); $fs.Dispose()
        $timing = @($txt -split "`r?`n" | Where-Object { $_ -match 'Match timing:' } | ForEach-Object { ($_ -replace '^.*?Match timing:', 'Match timing:') }) + $timing
    } catch { }
}
if ($timing.Count) { $summary += '', "Match timing (the last $([Math]::Min(6, $timing.Count))):"; $summary += @($timing | Select-Object -Last 6 | ForEach-Object { "  $_" }) }
Set-Content -LiteralPath (Join-Path $work 'build.txt') $build -Encoding utf8
Set-Content -LiteralPath (Join-Path $work 'pc.txt') $pc -Encoding utf8
$summary += '', 'Not included: the identity and its key, the saves, the profile backup, the replays, the rest of rex\userdata.'
$summary += 'Masked in the text files: IP addresses (ip-N, lan-ip-N for local ones), invite codes and the Windows user name. Crash dumps are not masked and may hold an address.'
Set-Content -LiteralPath (Join-Path $work 'summary.txt') $summary -Encoding utf8
Invoke-MaskReport $work
if ($script:maskFailed.Count) { Add-Content -LiteralPath (Join-Path $work 'summary.txt') "Left out, not masked: $($script:maskFailed -join ', ')" -Encoding utf8 }

$zip = Join-Path $OutDir "ttt2-problem-report-$stamp.zip"
Compress-Archive -LiteralPath @(Get-ChildItem -LiteralPath $work -Force | ForEach-Object { $_.FullName }) -DestinationPath $zip -Force
$null = Remove-Ttt2Folder $work -Quiet

if ($ResultFile) { Set-Content -LiteralPath $ResultFile "OK $(Split-Path $zip -Leaf)" -Encoding ascii }

Say ''
Say '  Done. Please send this file (it is on your Desktop), with a few words on what went wrong:' Green
Say "    $(Split-Path $zip -Leaf)   ($([Math]::Round((Get-Item -LiteralPath $zip).Length / 1MB, 1)) MB)"
Say '  It holds the game''s and BlueSpark''s logs, any crash dumps, the build''s version and your PC''s'
Say '  parts. Not your identity, saves, replays or settings. Addresses and your Windows user name are masked in the'
Say '  logs; a crash dump may still hold an address.'
if (-not $NoPause) {
    Start-Process explorer.exe "/select,`"$zip`""
    [void](Read-Host '  Press Enter to close')
}
