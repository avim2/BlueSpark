# The video memory of this PC's biggest graphics card, in MB (0: not known). The game renders on the high-performance adapter
# (patch 43), which is the one with the most dedicated memory on a PC with two. Read from the display adapters' registry key
# (HardwareInformation.qwMemorySize: 64 bits, right above 4 GB), else Win32_VideoController's AdapterRAM (32 bits: at most 4 GB, so
# only trusted below that). TTT2_TEST_VRAM_MB (tests): that number instead, to try a small card's path on a big one.
#   . rex\tools\gpu-memory.ps1; Get-Ttt2GpuMemoryMB
function Get-Ttt2GpuMemoryMB {
    if ($env:TTT2_TEST_VRAM_MB) { return [int]$env:TTT2_TEST_VRAM_MB }
    $best = [double]0
    try {
        $class = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}'
        foreach ($k in @(Get-ChildItem -LiteralPath $class -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -match '^\d{4}$' })) {
            $v = (Get-ItemProperty -LiteralPath $k.PSPath -Name 'HardwareInformation.qwMemorySize' -ErrorAction SilentlyContinue).'HardwareInformation.qwMemorySize'
            if ($v -is [byte[]] -and $v.Length -ge 8) { $v = [BitConverter]::ToUInt64($v, 0) }
            if ($v -and [double]$v -gt $best) { $best = [double]$v }
        }
    } catch { }
    if ($best -le 0) {
        try {
            foreach ($c in @(Get-CimInstance Win32_VideoController -ErrorAction Stop)) {
                if ($c.AdapterRAM -and [double]$c.AdapterRAM -gt $best) { $best = [double]$c.AdapterRAM }
            }
        } catch { }
    }
    return [int][math]::Round($best / 1MB)
}

# How many render-target keys this card's video memory allows (the main line's lead, 5 Nov, from the helper's measures on an RX
# 7900 XTX: the game alone 1,310 MB, the 142-key seed 2,543 MB, a player's 227 keys 3,614 MB, so ~12.6 MB a key; 2,350 MB = that base
# plus ~1 GB for Windows and the game's own growth): floor((V - 2350) / 12.6), 0 to 512. About 48 on a 3 GB card, 139 on 4 GB, 302
# on 6 GB, 460 on 8 GB, 512 from ~9 GB up.
function Get-Ttt2RenderTargetBudget([int]$vramMB) {
    if ($vramMB -le 0) { return 512 }
    [int][math]::Max(0, [math]::Min(512, [math]::Floor(($vramMB - 2350) / 12.6)))
}

# The render targets' list (user data's cache\render_targets_4E4D0859.txt, patch 18's key cache) at Play. Patch 18's LoadKeyCache makes
# every listed key's render target at the first draw, for the whole run: a player's GTX 1060 3GB ran ~7 fps from boot with 227 keys
# (deleting the file gave him 60 fps back). So the list is held to the card's budget (Get-Ttt2RenderTargetBudget): the seed when the
# player has none, as before; longer than the budget, its first N lines kept (the seed's come first, so the seed stays as far as it
# fits); a budget of 0, the key cache off (--render_target_key_cache=false). Video memory not known: as before.
# Returns @{ Lines = the lines to log; Args = switches for the game }.
function Update-Ttt2RenderTargetList([string]$userData, [string]$seed) {
    $out = @{ Lines = @(); Args = @() }
    $list = Join-Path $userData 'cache\render_targets_4E4D0859.txt'
    if (-not (Test-Path -LiteralPath $list) -and (Test-Path -LiteralPath $seed)) {
        New-Item -ItemType Directory -Force (Split-Path $list -Parent) | Out-Null
        Copy-Item -LiteralPath $seed $list
    }
    $vramMB = Get-Ttt2GpuMemoryMB
    if ($vramMB -le 0) { $out.Lines += "The render targets' list: as the game keeps it (the video memory isn't known)"; return $out }
    $budget = Get-Ttt2RenderTargetBudget $vramMB
    if ($budget -le 0) {
        $out.Args += '--render_target_key_cache=false'
        $out.Lines += "The render targets' list: off ($vramMB MB of video memory: no room for any key)"
        return $out
    }
    if (-not (Test-Path -LiteralPath $list)) { $out.Lines += "The render targets' list: none yet ($vramMB MB of video memory, room for $budget keys)"; return $out }
    $all = @([IO.File]::ReadAllLines($list) | Where-Object { "$_".Trim() })
    if ($all.Count -le $budget) {
        $out.Lines += "The render targets' list: $($all.Count) keys, kept ($vramMB MB of video memory, room for $budget)"
        return $out
    }
    [IO.File]::WriteAllLines($list, [string[]]($all | Select-Object -First $budget), (New-Object Text.UTF8Encoding $false))
    $out.Lines += "The render targets' list: cut from $($all.Count) keys to its first $budget ($vramMB MB of video memory)"
    return $out
}
