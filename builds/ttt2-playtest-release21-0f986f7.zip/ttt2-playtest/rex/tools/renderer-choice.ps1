# The renderer choice (native-gfx, 8 Nov: 4.7's option B, then called 5.0; the renderer toggle): which renderer Play asks for, and why.
# Dot-sourced by run-windows.ps1 (it passes the switches) and launcher.ps1 (Settings' RENDERER row).
#
# In order, the first that says one:
#   1. rex\out\renderer.txt, "native" or "emulated": a tester's override (the packaging PC slot's checks use it);
#   2. the player's choice, renderer= in launcher-settings.txt (Settings' RENDERER box writes it);
#   3. $Ttt2DefaultRenderer below: the package's default. **Turning native on for everyone is this one line**, when the
#      owner says so; a player who chose emulated keeps it, and the box always offers the way back.
# Whatever is chosen, native also needs the package's shader cache (run-windows.ps1 checks its stamp); without it, or if
# the game finds native unusable (NativeGfxChooseAtSetup: a lost GPU device in an earlier game, a cache it can't read),
# the game plays emulated and says so.

$Ttt2DefaultRenderer = 'emulated'   # (4.7-test2, the owner, 9 Nov: back to emulated after his hand tests; native is 4.8's, once its input delay, stutter and brightness are fixed)
# (4.7, the owner, 9 Nov: native is not offered at all: no Settings row, no Install shader step, and renderer.txt or an old renderer=native give emulated.
# Its code and the shader tools stay in the package, unused. 4.8 turns this back on with the default above.)
$Ttt2NativeOffered = $false

function Get-Ttt2RendererChoice([string]$Rex, [string]$SettingsFile) {
    if (-not $Ttt2NativeOffered) { return @{ Renderer = 'emulated'; From = 'this release (native not offered)' } }
    $override = Join-Path $Rex 'out\renderer.txt'
    if (Test-Path -LiteralPath $override) {
        $v = "$(Get-Content -LiteralPath $override -TotalCount 1)".Trim().ToLower()
        if ($v -in @('native', 'emulated')) { return @{ Renderer = $v; From = 'out\renderer.txt' } }
    }
    if ($SettingsFile -and (Test-Path -LiteralPath $SettingsFile)) {
        foreach ($line in Get-Content -LiteralPath $SettingsFile) {
            if ($line -match '^renderer=(native|emulated)\s*$') { return @{ Renderer = $Matches[1]; From = 'Settings' } }
        }
    }
    return @{ Renderer = $Ttt2DefaultRenderer; From = 'default' }
}

# Can this install draw natively at all? A package with the shader tools, or a source checkout's native build.
function Test-Ttt2NativeAvailable([string]$Rex) {
    if (-not $Ttt2NativeOffered) { return $false }   # (4.7: Settings' RENDERER row is hidden)
    return (Test-Path -LiteralPath (Join-Path $Rex 'prebuilt\tools\shaders\VERSION.txt')) -or
           (Test-Path -LiteralPath (Join-Path $Rex 'out\native-shaders.bin.stamp'))
}

# The native shader cache's state, for Settings' note: ready, being made, not yet made, failed to translate, or set aside after a lost device.
function Get-Ttt2NativeCacheState([string]$Rex) {
    $cache = Join-Path $Rex 'out\native-shaders.bin'
    if (Test-Path -LiteralPath "$cache.device-lost") { return 'device-lost' }
    if (Test-Path -LiteralPath "$cache.building") {   # (the lock holds its builder's process id: a closed window's stale lock doesn't count)
        $holder = "$(Get-Content -LiteralPath "$cache.building" -TotalCount 1)".Trim()
        if ($holder -match '^\d+$' -and (Get-Process -Id ([int]$holder) -ErrorAction SilentlyContinue)) { return 'building' }
    }
    if (-not (Test-Path -LiteralPath $cache) -or -not (Test-Path -LiteralPath "$cache.stamp")) {
        if (Test-Path -LiteralPath "$cache.failed") {   # (C3: failed with these tools: Install tries again; new tools, the next Play)
            $versionFile = Join-Path $Rex 'prebuilt\tools\shaders\VERSION.txt'
            $want = if (Test-Path -LiteralPath $versionFile) {
                ("$(Get-Content -LiteralPath $versionFile | Where-Object { $_ -like 'stamp=*' } | Select-Object -First 1)" -replace '^stamp=', '').Trim()
            } else { '' }
            if ("$(Get-Content -LiteralPath "$cache.failed" -TotalCount 1)".Trim() -eq $want) { return 'failed' }
        }
        return 'none'
    }
    $versionFile = Join-Path $Rex 'prebuilt\tools\shaders\VERSION.txt'
    if (Test-Path -LiteralPath $versionFile) {
        $want = ("$(Get-Content -LiteralPath $versionFile | Where-Object { $_ -like 'stamp=*' } | Select-Object -First 1)" -replace '^stamp=', '').Trim()
        $have = "$(Get-Content -LiteralPath "$cache.stamp" -TotalCount 1)".Trim()
        if ($want -and $have -ne $want) { return 'old' }
    }
    return 'ready'
}
