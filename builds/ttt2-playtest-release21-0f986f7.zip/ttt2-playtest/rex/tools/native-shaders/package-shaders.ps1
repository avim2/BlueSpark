# Packaging B (NATIVE_PLAN N5 step 4; the owner's approval, 7 Nov): the native renderer's shader tools in the
# prebuilt package, and the player's shader cache made at setup from the player's own game files.
#
# Dot-sourced by rex\build-prebuilt.ps1 (Build-NativeShaderTools) and rex\setup-steps.ps1 (Invoke-NativeShaderCache).
#
#   Build-NativeShaderTools -Rex <rex> -Work <folder> -Dest <prebuilt\tools\shaders> -Licences <source\licenses>
#       XenosRecomp (reblue's fork, MIT, hedge-dev and contributors) at the pinned commit with xenosrecomp-ttt2.patch,
#       DXIL off (the renderer uses only the SPIR-V), built with the pinned portable toolchain (rex\tools\toolchain.ps1);
#       Dest gets XenosRecomp.exe, dxcompiler.dll (DirectXShaderCompiler from the fork's dxc-bin submodule at its pinned
#       commit, University of Illinois/NCSA licence), shader_common.hlsli (the translation's header, read at every run),
#       ttt2unpack.exe (ours, formats\tools\ttt2unpack.c with the SDK's libmspack, LGPL-2.1) and VERSION.txt (the pins).
#       NOT dxil.dll: it signs DXIL, which the renderer never makes, and is Microsoft's own binary.
#       Licences gets XenosRecomp's MIT, DirectXShaderCompiler's licence. Returns the stamp line the cache will carry.
#
#   Invoke-NativeShaderCache -Rex <rex> -Tools <prebuilt\tools\shaders> -Out <cache file>
#       The game's data002/003 and the title update's data100 unpacked into a temporary folder with default_tu.xex beside
#       them, every shader translated on all cores (XenosRecomp runs them in parallel), the stamp written beside the
#       cache, the unpacked files deleted. Never throws: on any failure it says why and leaves no cache, and the game
#       starts on the emulated renderer (NativeGfxChooseAtSetup); the next setup tries again. Returns $true on a cache.

$script:NativeShaderXenosCommit = '339af41df2c23dbe3256c1c377716b81a0e0fe6b'
# (The pins, full (the main line's lead's review, 8 Nov): dxc-bin's commit and the dxcompiler.dll the package ships.)
$script:NativeShaderDxcCommit = '737ac9f51c3d06f0cd1ee7e14dc065bafd52310d'
$script:NativeShaderDxcompilerSha256 = '1220478c87af97551d2342906c5a08d888ee9fa26f6f99b6072d674801f492d1'
$script:NativeShaderXenosUrl = 'https://github.com/zolaware/reblue-XenosRecomp.git'

function Get-NativeShaderPatchStamp([string]$Rex) {
    # (The patch's hash as build-cache.sh/.ps1 compute it: the file with LF line ends, its first 12 hex digits.)
    $patch = Join-Path $Rex 'tools\native-shaders\xenosrecomp-ttt2.patch'
    $text = ([IO.File]::ReadAllText($patch)) -replace "`r", ''
    $sha = [Security.Cryptography.SHA256]::Create()
    $hash = -join ($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($text)) | ForEach-Object { $_.ToString('x2') })
    "xenosrecomp $($script:NativeShaderXenosCommit.Substring(0, 7)) patch $($hash.Substring(0, 12)) precise"
}

# (An exe's own imports (llvm-readobj), not the build folder's DLLs: anything but dxcompiler.dll and Windows' and the C
# runtime's own would be a missing file on a player's PC, so the release stops here instead. XenosRecomp.exe and, since the
# main line's review of 8 Nov, ttt2unpack.exe. msvcp140_atomic_wait.dll is the VC++ redistributable's (14.28 on), which
# Install-Ttt2VcRuntime already ensures; ttt2.exe imports it too (the packaging slot, 8 Nov).)
function Assert-NativeToolImports([string]$exe) {
    $name = Split-Path $exe -Leaf
    $imports = @(& llvm-readobj --coff-imports $exe 2>$null |
        ForEach-Object { if ($_ -match '^\s*Name:\s*(\S+\.dll)\s*$') { $Matches[1].ToLower() } } | Sort-Object -Unique)
    if (-not $imports.Count) { throw "$name's imports could not be read." }
    foreach ($dll in $imports) {
        if ($dll -notmatch '^(dxcompiler|kernel32|user32|advapi32|ole32|oleaut32|shell32|bcrypt|ws2_32|ucrtbase|vcruntime140(_1)?|msvcp140(_\d|_atomic_wait)?|api-ms-win-[a-z0-9-]+)\.dll$') {
            throw "$name imports $dll, which the package does not ship."
        }
    }
}

function Build-NativeShaderTools([string]$Rex, [string]$Work, [string]$Dest, [string]$Licences) {
    $Repo = Split-Path $Rex -Parent
    $xr = Join-Path $Work 'XenosRecomp'
    function Run {
        $saved = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        # (The output kept: a failing command's last 40 lines go to the console before the throw, so the log says why
        # (the packaging slot, 8 Nov: a cmake failure piped to Out-Null left nothing but "Failed (1)").)
        $lines = @()
        try { $lines = @(& $args[0] $args[1..($args.Count - 1)] 2>&1 | ForEach-Object { "$_" }) }
        finally { $ErrorActionPreference = $saved }
        if ($LASTEXITCODE -ne 0) {
            $lines | Select-Object -Last 40 | ForEach-Object { Write-Host "  | $_" }
            throw "Failed ($LASTEXITCODE): $($args -join ' ')"
        }
        $lines
    }
    if (Test-Path -LiteralPath $xr) { Remove-Item -LiteralPath $xr -Recurse -Force }
    New-Item -ItemType Directory -Force $Work, $Dest, $Licences | Out-Null
    # (A fresh checkout at the pinned commit, the patch applied: the release never builds from a working copy.)
    Run git -c core.longpaths=true clone -q $script:NativeShaderXenosUrl $xr
    Run git -C $xr checkout -q -f $script:NativeShaderXenosCommit
    Run git -C $xr submodule update -q --init --depth 1
    $head = (git -C $xr rev-parse HEAD).Trim()
    if ($head -ne $script:NativeShaderXenosCommit) { throw "XenosRecomp is at $head, not the pinned $script:NativeShaderXenosCommit." }
    $dxcHead = (git -C (Join-Path $xr 'thirdparty\dxc-bin') rev-parse HEAD).Trim()
    if ($dxcHead -ne $script:NativeShaderDxcCommit) { throw "dxc-bin is at $dxcHead, not the pinned $script:NativeShaderDxcCommit." }
    Run git -C $xr apply (Join-Path $Rex 'tools\native-shaders\xenosrecomp-ttt2.patch')
    $build = Join-Path $xr 'build'
    # (clang-cl under CMake's Ninja rules gets "-- <source>": the toolchain's CCC_OVERRIDE_OPTIONS "+" appends
    # -fms-compatibility-version after the "--", where clang-cl takes it as a file name (the packaging slot, 8 Nov). Here
    # it is prepended instead ("^"), the same flag, for this build only; restored after.)
    $override = $env:CCC_OVERRIDE_OPTIONS
    if ($override) { $env:CCC_OVERRIDE_OPTIONS = $override -replace '(^|\s)\+-fms-compatibility-version', '$1^-fms-compatibility-version' }
    try {
        # (CMAKE_TRY_COMPILE_CONFIGURATION: cmake's compiler checks build in Debug (/MDd) by default, and the portable CRT
        # has no debug libraries (msvcrtd.lib); as write-source-docs.ps1 does for the SDK. Main's fix, 8 Nov.)
        Run cmake -S $xr -B $build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_TRY_COMPILE_CONFIGURATION=Release `
            -DXENOS_RECOMP_DXIL=OFF -DCMAKE_C_COMPILER=clang-cl -DCMAKE_CXX_COMPILER=clang-cl | Out-Null
        Run ninja -C $build | Out-Null
    } finally { $env:CCC_OVERRIDE_OPTIONS = $override }
    $exeDir = Join-Path $build 'XenosRecomp'
    Copy-Item -LiteralPath (Join-Path $exeDir 'XenosRecomp.exe') $Dest
    $dxcompiler = Join-Path $xr 'thirdparty\dxc-bin\bin\x64\dxcompiler.dll'
    $got = (Get-FileHash -LiteralPath $dxcompiler -Algorithm SHA256).Hash.ToLower()
    if ($got -ne $script:NativeShaderDxcompilerSha256) { throw "dxcompiler.dll's SHA-256 is $got, not the pinned one." }
    Copy-Item -LiteralPath $dxcompiler $Dest
    # (As .hlsli: the package refuses a .h outside source/ and the SDK; XenosRecomp takes the header by its path.)
    Copy-Item -LiteralPath (Join-Path $xr 'XenosRecomp\shader_common.h') (Join-Path $Dest 'shader_common.hlsli')
    Assert-NativeToolImports (Join-Path $exeDir 'XenosRecomp.exe')
    # ttt2unpack (ours), with the SDK's libmspack sources (LZX), as build-cache.ps1 compiles it.
    $sdkFolderFile = Join-Path $Rex 'sdk-folder.txt'
    $sdkName = if (Test-Path $sdkFolderFile) { (Get-Content $sdkFolderFile -TotalCount 1).Trim() } else { 'rexsdk-portable' }
    $mspack = Join-Path $env:USERPROFILE "$sdkName\src\thirdparty\libmspack\libmspack\mspack"
    # (-fuse-ld=lld: the portable toolchain has no link.exe, which the plain driver calls for an msvc target; the slot, 8 Nov.)
    Run clang -O2 -w -fuse-ld=lld "-I$mspack" "-I$(Split-Path $mspack)" (Join-Path $Repo 'formats\tools\ttt2unpack.c') `
        (Join-Path $mspack 'lzxd.c') (Join-Path $mspack 'system.c') -o (Join-Path $Dest 'ttt2unpack.exe')
    Assert-NativeToolImports (Join-Path $Dest 'ttt2unpack.exe')
    $dxcCommit = (git -C (Join-Path $xr 'thirdparty\dxc-bin') rev-parse HEAD).Trim()
    $stamp = Get-NativeShaderPatchStamp $Rex
    [IO.File]::WriteAllLines((Join-Path $Dest 'VERSION.txt'), @(
        "stamp=$stamp", "xenosrecomp=$script:NativeShaderXenosCommit $script:NativeShaderXenosUrl",
        "dxc-bin=$dxcCommit", "dxcompiler.dll.sha256=$script:NativeShaderDxcompilerSha256",
        "patch=rex/tools/native-shaders/xenosrecomp-ttt2.patch"))
    # (Every licence, under fixed names: XenosRecomp's and the libraries it links (fmt, xxHash, zstd) or compiles in
    # (smol-v); DirectXShaderCompiler's, kept in our tree (dxc-bin carries none: LLVM's University of Illinois/NCSA licence
    # and Microsoft's third-party notices, from microsoft/DirectXShaderCompiler).)
    $licenceFiles = [ordered]@{
        'XenosRecomp-LICENSE.txt' = Join-Path $xr 'LICENSE.md'
        'fmt-LICENSE.txt' = Join-Path $xr 'thirdparty\fmt\LICENSE'
        'xxHash-LICENSE.txt' = Join-Path $xr 'thirdparty\xxHash\LICENSE'
        'zstd-LICENSE.txt' = Join-Path $xr 'thirdparty\zstd\LICENSE'
        'zstd-COPYING.txt' = Join-Path $xr 'thirdparty\zstd\COPYING'
        'smol-v-LICENSE.txt' = Join-Path $xr 'thirdparty\smol-v\license.txt'
        'DirectXShaderCompiler-LICENSE.txt' = Join-Path $Rex 'tools\native-shaders\licenses\DirectXShaderCompiler-LICENSE.txt'
        'DirectXShaderCompiler-ThirdPartyNotices.txt' = Join-Path $Rex 'tools\native-shaders\licenses\DirectXShaderCompiler-ThirdPartyNotices.txt'
    }
    foreach ($name in $licenceFiles.Keys) {
        if (-not (Test-Path -LiteralPath $licenceFiles[$name])) { throw "The licence $($licenceFiles[$name]) is missing: not packaged without it." }
        Copy-Item -LiteralPath $licenceFiles[$name] (Join-Path $Licences $name)
    }
    $stamp
}

# (A tool an antivirus took or blocked: the main line's wording, the folder to allow; never a failed install (the main
# line's lead's review, 8 Nov).)
function Get-NativeShaderAntivirusText([string]$Tools, [string]$file) {
    "Windows Security (or another antivirus) may have removed or blocked $file. If so, restore it in Windows Security, " +
        "Protection history, or allow the folder $Tools, then run Install again. Until then the game plays on the emulated renderer."
}

# The leftovers of a window closed during the step (the review's B2): the unpacked game files (~2 GB) and temp files, removed
# at every Build and Status (so at every Start Here start), unless a build is running now (its lock's process alive).
function Clear-NativeShaderLeftovers([string]$Rex) {
    $out = Join-Path $Rex 'out\native-shaders.bin'
    $lock = "$out.building"
    if (Test-Path -LiteralPath $lock) {
        $holder = "$(Get-Content -LiteralPath $lock -TotalCount 1 -ErrorAction SilentlyContinue)".Trim()
        if ($holder -match '^\d+$' -and (Get-Process -Id ([int]$holder) -ErrorAction SilentlyContinue)) { return }
        Remove-Item -LiteralPath $lock -Force -ErrorAction SilentlyContinue
    }
    Remove-Item -LiteralPath (Join-Path $Rex 'out\shader-src') -Recurse -Force -ErrorAction SilentlyContinue
    foreach ($f in "$out.new.bin", "$out.new", "$out.stamp.new") { Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue }
}

# The cache made once, its failure remembered (the main line's lead's C3, 8 Nov): a translation that failed leaves "$Out.failed" with the
# tools' stamp, and a Play (-FromPlay, run-windows.ps1's background build) doesn't try again with the same tools: only Install does (or new
# tools). Without it a failing translation ran at every Play, minutes on half the cores, an online match's included.
function Invoke-NativeShaderCache([string]$Rex, [string]$Tools, [string]$Out, [int]$Cores = [Environment]::ProcessorCount, [switch]$Idle, [switch]$FromPlay) {
    $failed = "$Out.failed"
    $versionFile = Join-Path $Tools 'VERSION.txt'
    $stamp = if (Test-Path -LiteralPath $versionFile) {
        ("$((Get-Content -LiteralPath $versionFile) | Where-Object { $_ -like 'stamp=*' } | Select-Object -First 1)" -replace '^stamp=', '').Trim()
    } else { '' }
    if ($FromPlay -and (Test-Path -LiteralPath $failed) -and "$(Get-Content -LiteralPath $failed -TotalCount 1)".Trim() -eq $stamp) {
        Write-Host 'Native shaders: the last translation failed with these tools; Install tries again. The game uses the emulated renderer.'
        return $false
    }
    $script:NativeShadersBusy = $false
    $made = Invoke-NativeShaderCacheOnce -Rex $Rex -Tools $Tools -Out $Out -Cores $Cores -Idle:$Idle
    if ($made) {
        Remove-Item -LiteralPath $failed -Force -ErrorAction SilentlyContinue
    } elseif (-not $script:NativeShadersBusy) {
        try { [IO.File]::WriteAllText($failed, "$stamp`n") } catch { }
    }
    return $made
}

function Invoke-NativeShaderCacheOnce([string]$Rex, [string]$Tools, [string]$Out, [int]$Cores = [Environment]::ProcessorCount, [switch]$Idle) {
    $say = { param($t) Write-Host "Native shaders: $t" }
    # (One build at a time: setup's and a Play's background one (run-windows.ps1) share this lock, its holder's process id.)
    $lock = "$Out.building"
    if (Test-Path -LiteralPath $lock) {
        $holder = "$(Get-Content -LiteralPath $lock -TotalCount 1)".Trim()
        if ($holder -match '^\d+$' -and [int]$holder -ne $PID -and (Get-Process -Id ([int]$holder) -ErrorAction SilentlyContinue)) {
            & $say 'already being made (another window).'
            $script:NativeShadersBusy = $true
            return $false
        }
    }
    New-Item -ItemType Directory -Force (Split-Path $Out) | Out-Null
    Set-Content -LiteralPath $lock $PID
    # (A window closed in the middle left the unpacked game files: removed before anything else, every time.)
    Remove-Item -LiteralPath (Join-Path $Rex 'out\shader-src') -Recurse -Force -ErrorAction SilentlyContinue
    try {
        foreach ($f in 'XenosRecomp.exe', 'dxcompiler.dll', 'shader_common.hlsli', 'ttt2unpack.exe', 'VERSION.txt') {
            if (-not (Test-Path -LiteralPath (Join-Path $Tools $f))) { & $say (Get-NativeShaderAntivirusText $Tools $f); return $false }
        }
        $stamp = ((Get-Content -LiteralPath (Join-Path $Tools 'VERSION.txt')) | Where-Object { $_ -like 'stamp=*' } | Select-Object -First 1) -replace '^stamp=', ''
        if ((Test-Path -LiteralPath $Out) -and (Test-Path -LiteralPath "$Out.stamp") -and
            ("$(Get-Content -LiteralPath "$Out.stamp" -TotalCount 1)".Trim() -eq $stamp)) {
            & $say 'the cache is up to date.'
            return $true
        }
        # (An old or partial cache is removed before anything else (the main line's lead's review, 8 Nov): a rebuild that
        # fails then leaves no cache, and the game runs emulated, never a stale translation.)
        foreach ($f in $Out, "$Out.stamp", "$Out.new.bin", "$Out.new", "$Out.stamp.new") { Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue }
        $gameFile = Join-Path $Rex 'game-folder.txt'
        if (-not (Test-Path -LiteralPath $gameFile)) { & $say 'no game folder yet.'; return $false }
        $game = (Get-Content -LiteralPath $gameFile -TotalCount 1).Trim()
        $update = Join-Path (Split-Path $game) 'update'
        if (-not (Test-Path -LiteralPath (Join-Path $update 'data100.bin'))) { $update = Join-Path (Split-Path $Rex) 'gamedata\update' }
        $xex = Join-Path $game 'default_tu.xex'
        if (-not (Test-Path -LiteralPath $xex)) { $xex = Join-Path (Split-Path $Rex) 'gamedata\default_tu.xex' }
        $work = Join-Path $Rex 'out\shader-src'
        # (The space first: the unpacked archives (~2 GB) and the cache (~250 MB), 3 GB to be safe.)
        if (-not (Get-Command Get-Ttt2FreeGB -ErrorAction SilentlyContinue)) { . (Join-Path $Rex 'tools\data-folder.ps1') }
        $free = Get-Ttt2FreeGB (Split-Path $Out)
        if ($free -ge 0 -and $free -lt 3) {
            & $say ("needs about 3 GB free on the drive of {0}, which has {1:N1} GB: the game uses the emulated renderer until there is room." -f (Split-Path $Out), $free)
            return $false
        }
        New-Item -ItemType Directory -Force $work | Out-Null
        $log = Join-Path $Rex 'out\native-shaders-tools.log'
        $started = Get-Date
        foreach ($archive in (Join-Path $game 'data002.bin'), (Join-Path $game 'data003.bin'), (Join-Path $update 'data100.bin')) {
            if (-not (Test-Path -LiteralPath $archive)) { & $say "$archive not found."; return $false }
            try {
                # (Its output, stderr too, kept in the log.)
                & (Join-Path $Tools 'ttt2unpack.exe') $archive (Join-Path $work ([IO.Path]::GetFileNameWithoutExtension($archive) + '.nrf')) *>> $log
            } catch { & $say (Get-NativeShaderAntivirusText $Tools 'ttt2unpack.exe'); return $false }
            if ($LASTEXITCODE -ne 0) { & $say "unpacking $archive failed ($LASTEXITCODE; $log)."; return $false }
        }
        Copy-Item -LiteralPath $xex (Join-Path $work 'default_tu.xex') -Force
        # (Every Install runs it, emulated players' too, so Start Here's line says what it is and that it is once per
        # package (the review's 9).)
        & $say "making the native renderer's shaders from your game files: once for this version of the package, about 10 minutes on $Cores of $([Environment]::ProcessorCount) processors..."
        # (Ending in .bin: our patch writes the binary cache only to a path ending in .bin, and C++ source to any other
        # (the packaging slot's check 4, 8 Nov: native-shaders.bin.new got XenosRecomp's source, and native fell back).)
        $temp = "$Out.new.bin"
        # (Started apart, its output to a file read every 15 s: its progress shown, and stopped after 40 minutes with no
        # progress (the review's 4: a silent window gets closed).)
        $progress = Join-Path $Rex 'out\native-shaders-progress.txt'
        try {
            $proc = Start-Process -FilePath (Join-Path $Tools 'XenosRecomp.exe') -PassThru -NoNewWindow `
                -ArgumentList @("`"$work`"", "`"$temp`"", "`"$(Join-Path $Tools 'shader_common.hlsli')`"") `
                -RedirectStandardOutput $progress -RedirectStandardError "$progress.err"
            # (Windows PowerShell 5.1: without the handle taken now, a -NoNewWindow process with redirected output reports
            # ExitCode $null after it ends, and every good translation would read as failed (the review's B1).)
            $null = $proc.Handle
            # (The cores: all of them at setup; a Play's background build (-Cores) leaves the game half, at idle priority
            # (the review's B6). XenosRecomp's threads take the process's affinity.)
            if ($Cores -lt [Environment]::ProcessorCount) {
                try { $proc.ProcessorAffinity = [IntPtr][long]((1L -shl $Cores) - 1) } catch { }
            }
            if ($Idle) { try { $proc.PriorityClass = 'Idle' } catch { } }
        } catch { & $say (Get-NativeShaderAntivirusText $Tools 'XenosRecomp.exe'); return $false }
        $lastSize = -1; $lastChange = Get-Date; $shown = ''
        while (-not $proc.WaitForExit(15000)) {
            $size = (Get-Item -LiteralPath $progress -ErrorAction SilentlyContinue).Length
            if ($size -ne $lastSize) { $lastSize = $size; $lastChange = Get-Date }
            $text = "$(Get-Content -LiteralPath $progress -Tail 1 -ErrorAction SilentlyContinue)"
            # (XenosRecomp prints "Recompiling shaders... N%" every 10 shaders, unbuffered with our patch: Start Here's bar
            # takes PROGRESS lines (launcher.ps1).)
            $percent = [regex]::Matches($text, '([\d.]+)%') | Select-Object -Last 1
            if ($percent) {
                $p = [int][math]::Min(99, [double]$percent.Groups[1].Value)
                if ("$p" -ne $shown) { $shown = "$p"; Write-Host "PROGRESS $p Making the native renderer's shaders (once)" }
            }
            if (((Get-Date) - $lastChange).TotalMinutes -gt 40) {
                try { $proc.Kill() } catch { }
                & $say 'the translation made no progress for 40 minutes and was stopped: the game uses the emulated renderer.'
                Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
                return $false
            }
        }
        Get-Content -LiteralPath "$progress.err" -ErrorAction SilentlyContinue | Add-Content -LiteralPath $log
        # (The cache's own magic, "TTT2SPV1", checked too: a file of the wrong kind (the source above) is never installed.)
        $magic = ''
        if (Test-Path -LiteralPath $temp) {
            try {
                $fs = [IO.File]::OpenRead($temp)
                try { $head = New-Object byte[] 8; $null = $fs.Read($head, 0, 8); $magic = [Text.Encoding]::ASCII.GetString($head) }
                finally { $fs.Dispose() }
            } catch { }
        }
        if ($proc.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $temp) -or (Get-Item -LiteralPath $temp).Length -lt 1MB -or $magic -ne 'TTT2SPV1') {
            & $say "the translation failed ($($proc.ExitCode); $log): the game uses the emulated renderer."
            Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
            return $false
        }
        [IO.File]::WriteAllText("$Out.stamp.new", "$stamp`n")
        Move-Item -LiteralPath $temp $Out -Force
        Move-Item -LiteralPath "$Out.stamp.new" "$Out.stamp" -Force
        # (A new cache clears an old lost-device marker: it fell back to emulated for the translation it was made with.)
        Remove-Item -LiteralPath "$Out.device-lost" -Force -ErrorAction SilentlyContinue
        # (Each argument in its own parentheses: -f binds before "/", so the size divided the formatted string, which threw
        # after the cache was in place and reported a good cache as failed (the packaging slot's check 3, 8 Nov).)
        & $say ("done in {0:N0} s ({1:N0} MB)." -f (((Get-Date) - $started).TotalSeconds), ((Get-Item -LiteralPath $Out).Length / 1MB))
        return $true
    } catch {
        & $say "failed: $_. The game uses the emulated renderer."
        return $false
    } finally {
        # (The unpacked files are game data: never kept.)
        Remove-Item -LiteralPath (Join-Path $Rex 'out\shader-src') -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $lock -Force -ErrorAction SilentlyContinue
    }
}
