# Starts TTT2 on Windows. The first time, it asks for your game folder: the one with
# default.xex and the data*.bin files from your disc. It remembers the answer in
# rex\game-folder.txt (not part of the repo).
#
#   powershell -ExecutionPolicy Bypass -File rex\run-windows.ps1
#
# Anything after the script name goes to the game, e.g. --log_level=debug.

$ErrorActionPreference = 'Stop'
$Rex = $PSScriptRoot
$exe = Join-Path $Rex 'out\build\win-amd64-release\ttt2.exe'
if (-not (Test-Path -LiteralPath $exe)) { throw 'ttt2.exe is not built yet. Run rex\build-windows.ps1 first.' }

$saved = Join-Path $Rex 'game-folder.txt'
$game = if (Test-Path -LiteralPath $saved) { (Get-Content -LiteralPath $saved -Raw).Trim() } else { '' }
while (-not $game -or -not (Test-Path -LiteralPath (Join-Path $game 'default.xex'))) {
    if ($game) { Write-Host "No default.xex in $game" -ForegroundColor Yellow }
    if ($env:TTT2_NO_PROMPT) { throw "No default.xex in the game folder ($(if ($game) { $game } else { 'none chosen' })). In Start Here, click 1. Choose my game + update, pick your game, then click Install." }
    $game = (Read-Host 'Path to your TTT2 game folder (the one with default.xex)').Trim().Trim('"')
}
Set-Content -LiteralPath $saved -Value $game

# The game is built from the disc's executable with the title update applied (version 0.0.3.2),
# and the runtime loads the game's image from that file in the game folder: put there once,
# beside the disc's default.xex, from the repo's gamedata\default_tu.xex.
$patched = Join-Path $game 'default_tu.xex'
if (-not (Test-Path -LiteralPath $patched)) {
    $source = Join-Path (Split-Path $Rex -Parent) 'gamedata\default_tu.xex'
    if (-not (Test-Path -LiteralPath $source)) { throw "gamedata\default_tu.xex is missing: run rex\prepare-game.ps1 first (it makes it from your own game files)." }
    Write-Host "Copying default_tu.xex (the game with its title update applied) into $game"
    Copy-Item -LiteralPath $source $patched
}

# The title update's files (Default.xexp, data100.bin, data100.ofs), which the game opens as
# update:\ : a folder "update" beside the game folder if there is one, or the repo's
# gamedata\update.
$update = Join-Path (Split-Path $game -Parent) 'update'
if (-not (Test-Path -LiteralPath (Join-Path $update 'data100.bin'))) {
    $update = Join-Path (Split-Path $Rex -Parent) 'gamedata\update'
}
if (-not (Test-Path -LiteralPath (Join-Path $update 'data100.bin'))) { throw "The title update's files are not in $update." }

$userData = Join-Path $Rex 'userdata'
# (Another folder for a test, as of a first start on a PC: given twice on the command line,
# the switch makes the game fail at its start.)
if ($env:TTT2_USER_DATA) { $userData = $env:TTT2_USER_DATA }
# The player's profile (the XUID and its key, the save data, the name) in %LOCALAPPDATA%\TTT2Native\profile, outside the game folder
# (tools/profile-folder.ps1, SDK patch 51): a new build or a deleted folder no longer loses it. Copied there from this game folder
# the first time. A test's own user data folder (TTT2_USER_DATA) keeps its profile inside it, as before.
$profileDir = $null
$profileArgs = @()
if (-not $env:TTT2_USER_DATA -and -not ($args | Where-Object { "$_" -like '--profile_data_root*' })) {
    . (Join-Path $Rex 'tools/profile-folder.ps1')
    $profileDir = Get-ProfileFolder
    Copy-ProfileOnce $userData $profileDir
    $profileArgs = @("--profile_data_root=$profileDir")
}
# A first start: the render targets seen on other PCs (their keys: numbers of the runtime's, no
# game data), so that the runtime makes them at the start and not in the middle of the first
# match (STATUS.md, "The first tag of a match"). The runtime adds to the file as it meets more.
# Held to the card's video memory at every Play (tools/gpu-memory.ps1, the main line's lead, 5 Nov): at most
# floor((V - 2350) / 12.6) keys, the list cut to that; no room at all, the key cache off.
$renderTargetArgs = @()
if (Test-Path -LiteralPath (Join-Path $Rex 'tools/gpu-memory.ps1')) {
    try {
        . (Join-Path $Rex 'tools/gpu-memory.ps1')
        $rt = Update-Ttt2RenderTargetList $userData (Join-Path $Rex 'render-targets-seed.txt')
        $rt.Lines | ForEach-Object { Write-Host $_ }
        if (-not ($args | Where-Object { "$_" -like '--render_target_key_cache*' })) { $renderTargetArgs = @($rt.Args) }
    } catch { Write-Host "The render targets' list: not checked ($($_.Exception.Message))" }
}
# Likewise the pipelines seen on other PCs (helper Task 4's A2, rex/PIPELINE_SEED.md): the runtime's stored pipeline
# descriptions (shader hashes and render state, no shader code or driver data), RTV and ROV. Copied when the player has
# none; otherwise the seed's records the player's file lacks are appended (a file of another translator version is left
# alone). The prewarm (--d3d12_pipeline_prewarm_stored) then queues them as their shaders load. Never stops Play.
if (Test-Path (Join-Path $Rex 'tools/pipeline-seed.ps1')) {
    try {
        . (Join-Path $Rex 'tools/pipeline-seed.ps1')
        foreach ($kind in 'rtv', 'rov') {
            Add-PipelineSeed (Join-Path $Rex "pipelines-seed.$kind.xpso") (Join-Path $userData "cache/shaders/shareable/4E4D0859.$kind.d3d12.xpso")
        }
    } catch { "Pipeline seed: not added ($($_.Exception.Message))" }
}

# Controller mappings for SDL: the community SDL_GameControllerDB (rex\gamecontrollerdb.txt, zlib
# licence in rex\gamecontrollerdb-LICENSE.txt). DirectInput pads, fight sticks and adapters work as
# controllers only if SDL knows their mapping, and L2/R2 only if it maps them as the triggers. A
# player's own mapping lines go in userdata\my-controllers.txt (kept across package updates):
# they're added after the database's, so they win for the same controller.
$mappingArgs = @()
$mappings = Join-Path $Rex 'gamecontrollerdb.txt'
if ((Test-Path -LiteralPath $mappings) -and -not ($args | Where-Object { "$_" -like '--hid_mappings_file*' })) {
    $ownMappings = Join-Path $userData 'my-controllers.txt'
    if (Test-Path -LiteralPath $ownMappings) {
        $merged = Join-Path $userData 'cache/gamecontrollerdb.txt'
        New-Item -ItemType Directory -Force (Split-Path $merged -Parent) | Out-Null
        Get-Content -LiteralPath $mappings, $ownMappings | Set-Content -LiteralPath $merged
        $mappings = $merged
    }
    $mappingArgs = @("--hid_mappings_file=$mappings")
}

# The player's name (the gamertag the game shows), from rex\userdata\player-name.txt (Start Here asks for it the
# first time Play is pressed), unless the caller passed --user_name itself.
$nameArgs = @()
$nameFile = Join-Path $(if ($profileDir) { $profileDir } else { $userData }) 'player-name.txt'   # (the profile folder's, 23 October)
if ((Test-Path -LiteralPath $nameFile) -and -not ($args | Where-Object { "$_" -like '--user_name*' })) {
    $playerName = "$(Get-Content -LiteralPath $nameFile -Raw)".Trim()
    if ($playerName) { $nameArgs = @("--user_name=$playerName") }
}

# The display: Start Here's "Display" choice and "Allow tearing" box (rex\userdata\launcher-settings.txt:
# display=borderless|fullscreen|windowed-<W>x<H>, borderless when unset, an old plain "windowed" taken as the
# 1920x1080 window (1280x720 on a smaller monitor); tearing=true|false, false when unset), passed as the
# runtime's switches unless the caller passed --fullscreen or --present_tearing itself. A window never
# tears: tearing asked with a window size (a settings file edited by hand) is turned off, and said so.
$displayArgs = @()
# (The file Start Here's Settings writes, rex\userdata's, launcher.ps1: also when a test's TTT2_USER_DATA points the game's data elsewhere.
# Before (the native lead, 8 Nov) it was read from TTT2_USER_DATA's folder, so a tester's Settings choices were ignored. A test that means its
# own settings file names it in TTT2_LAUNCHER_SETTINGS.)
$settingsFile = if ($env:TTT2_LAUNCHER_SETTINGS) { $env:TTT2_LAUNCHER_SETTINGS } else { Join-Path $Rex 'userdata\launcher-settings.txt' }
$display = 'borderless'
$tearing = 'false'
if (Test-Path -LiteralPath $settingsFile) {
    foreach ($line in Get-Content -LiteralPath $settingsFile) {
        if ($line -match '^display=(.*)$') { $display = $Matches[1].Trim().ToLower() }
        if ($line -match '^tearing=(.*)$') { $tearing = $Matches[1].Trim().ToLower() }
    }
}
$windowSize = $null
if ($display -match '^windowed-(\d+)x(\d+)$') {
    $windowSize = @([int]$Matches[1], [int]$Matches[2])
} elseif ($display -eq 'windowed') {
    Add-Type -Namespace TTT2Run -Name Screen -MemberDefinition @'
[DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr h);
[DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr h, IntPtr dc);
[DllImport("gdi32.dll")] public static extern int GetDeviceCaps(IntPtr dc, int index);
'@
    $dc = [TTT2Run.Screen]::GetDC([IntPtr]::Zero)
    $big = [TTT2Run.Screen]::GetDeviceCaps($dc, 118) -ge 1920 -and [TTT2Run.Screen]::GetDeviceCaps($dc, 117) -ge 1080
    [void][TTT2Run.Screen]::ReleaseDC([IntPtr]::Zero, $dc)
    $windowSize = if ($big) { @(1920, 1080) } else { @(1280, 720) }
}
if (-not ($args | Where-Object { "$_" -like '--fullscreen*' })) {
    if ($windowSize) {
        $displayArgs += @('--fullscreen=false', '--fullscreen_exclusive=false',
                          "--window_pixel_width=$($windowSize[0])", "--window_pixel_height=$($windowSize[1])")
    } else {
        $displayArgs += '--fullscreen=true'
        $displayArgs += "--fullscreen_exclusive=$(if ($display -eq 'fullscreen') { 'true' } else { 'false' })"
    }
}
if (-not ($args | Where-Object { "$_" -like '--present_tearing*' })) {
    if ($windowSize -and $tearing -eq 'true') {
        Write-Host "Tearing is off: the game is in a $($windowSize[0])x$($windowSize[1]) window, and a window never tears (Allow tearing needs a fullscreen choice)."
        $tearing = 'false'
    }
    $displayArgs += "--present_tearing=$(if ($tearing -eq 'true') { 'true' } else { 'false' })"
}
Write-Host "Display: $display$(if ($windowSize) { " ($($windowSize[0])x$($windowSize[1]) window)" }), tearing $tearing"

# The renderer (packaging B, 8 Nov; the toggle, 8 Nov): tools\renderer-choice.ps1 decides: out\renderer.txt (a tester's
# override), else Settings' choice (renderer= in launcher-settings.txt), else the package's default. Native needs the shader
# cache setup made (out\native-shaders.bin with its stamp); without it, or if the game finds it unusable, the game says so
# and uses the emulated renderer (NativeGfxChooseAtSetup). A caller's own --ttt2_native_gfx switch wins.
. (Join-Path $Rex 'tools\renderer-choice.ps1')
$rendererChoice = Get-Ttt2RendererChoice $Rex $settingsFile
$renderer = $rendererChoice.Renderer
$shaderCache = Join-Path $Rex 'out\native-shaders.bin'
# (The cache counts only with the stamp the package's tools make (prebuilt\tools\shaders\VERSION.txt's stamp=): an older
# translation is not used (the main line's lead's review, 8 Nov). A source checkout has no VERSION.txt: the stamp beside
# the cache is taken as it is.)
$versionFile = Join-Path $Rex 'prebuilt\tools\shaders\VERSION.txt'
$wantStamp = if (Test-Path -LiteralPath $versionFile) {
    ("$(Get-Content -LiteralPath $versionFile | Where-Object { $_ -like 'stamp=*' } | Select-Object -First 1)" -replace '^stamp=', '').Trim()
} else { '' }
$haveStamp = if (Test-Path -LiteralPath "$shaderCache.stamp") { "$(Get-Content -LiteralPath "$shaderCache.stamp" -TotalCount 1)".Trim() } else { '' }
$callerChose = [bool]($args | Where-Object { "$_" -match '^--(no)?ttt2_native_gfx(=|$)' })
if ($renderer -eq 'native' -and -not $callerChose) {
    if ((Test-Path -LiteralPath $shaderCache) -and $haveStamp -and (-not $wantStamp -or $haveStamp -eq $wantStamp)) {
        $displayArgs += @('--ttt2_native_gfx=true', "--ttt2_native_gfx_shader_cache=$shaderCache")
        Write-Host "Renderer: native ($($rendererChoice.From))"
    } else {
        # (The background fallback (the lead's design, 7 Nov): this game plays emulated; the cache is made now, hidden, below
        # normal priority (XenosRecomp inherits it), and the next start uses native. Also what a Start Here closed during
        # its shader step leaves to do.)
        $shaderTools = Join-Path $Rex 'prebuilt\tools\shaders'
        # (Only with every tool there: a quarantined or missing one makes nothing, and the line says so instead of
        # promising a build (the packaging slot's check 8, 8 Nov).)
        $missingTool = @('XenosRecomp.exe', 'dxcompiler.dll', 'shader_common.hlsli', 'ttt2unpack.exe', 'VERSION.txt') |
            Where-Object { -not (Test-Path -LiteralPath (Join-Path $shaderTools $_)) } | Select-Object -First 1
        $failedBefore = (Test-Path -LiteralPath "$shaderCache.failed") -and $wantStamp -and
            "$(Get-Content -LiteralPath "$shaderCache.failed" -TotalCount 1)".Trim() -eq $wantStamp
        if ($failedBefore) {
            # (C3: a translation that failed with these tools isn't tried again at every Play; Install tries again.)
            Write-Host 'Renderer: emulated; the native renderer''s shaders failed to translate last time (rex\out\native-shaders-build.log); Install tries again'
        } elseif ((Test-Path -LiteralPath $shaderTools) -and $missingTool) {
            Write-Host "Renderer: emulated; the native renderer's shader tools are incomplete ($missingTool missing: an antivirus may have removed it; Install again restores it)"
        } elseif (Test-Path -LiteralPath $shaderTools) {
            # (The paths go through the environment, never into the command's text: an apostrophe in the install folder
            # can't break it. Half the cores at idle priority, so a game played meanwhile (an online match) keeps the rest
            # (the main line's lead's review, B6).)
            $env:TTT2_SHADERS_REX = $Rex; $env:TTT2_SHADERS_TOOLS = $shaderTools; $env:TTT2_SHADERS_OUT = $shaderCache
            $env:TTT2_SHADERS_LOG = Join-Path $Rex 'out\native-shaders-build.log'
            $env:TTT2_SHADERS_CORES = "$([Math]::Max(1, [int]([Environment]::ProcessorCount / 2)))"
            $script = '. (Join-Path $env:TTT2_SHADERS_REX ''tools\native-shaders\package-shaders.ps1''); ' +
                '$null = Invoke-NativeShaderCache -Rex $env:TTT2_SHADERS_REX -Tools $env:TTT2_SHADERS_TOOLS -Out $env:TTT2_SHADERS_OUT ' +
                '-Cores ([int]$env:TTT2_SHADERS_CORES) -Idle -FromPlay *> $env:TTT2_SHADERS_LOG'
            $builder = Start-Process powershell -WindowStyle Hidden -PassThru -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', $script)
            try { $builder.PriorityClass = 'Idle' } catch { }
            foreach ($v in 'REX', 'TOOLS', 'OUT', 'LOG', 'CORES') { Remove-Item -LiteralPath "Env:TTT2_SHADERS_$v" -ErrorAction SilentlyContinue }
            Write-Host 'Renderer: emulated this time; the native renderer''s shaders are being made in the background (native from the next start)'
        } else {
            Write-Host 'Renderer: emulated (no native shader cache)'
        }
    }
} else {
    Write-Host "Renderer: $(if ($callerChose) { 'as the command line says' } else { "emulated ($($rendererChoice.From))" })"
}

# The game lock (tools/game-lock.ps1, docs/GAME_LOCK_RULES_20261102.md): taken here unless the script that started this one has
# it, and then handed to the game itself, so that it is held for as long as the game runs. Exclusive unless the caller says
# (TTT2_GAME_LOCK_KIND: shared, exclusive, quiet, or owner for Start Here's Play; TTT2_GAME_LOCK_PURPOSE). Which process the game
# is goes into out/game-pid.txt, for the test scripts to stop the game they started and no other.
. (Join-Path $Rex "tools/game-lock.ps1")
$lockPurpose = "$env:TTT2_GAME_LOCK_PURPOSE"
$mine = switch ("$env:TTT2_GAME_LOCK_KIND") {
    'shared' { Take-GameLock $Rex -Shared -Purpose $lockPurpose }
    'quiet'  { Take-GameLock $Rex -Exclusive -Quiet -Purpose $lockPurpose }
    'owner'  { Take-GameLock $Rex -Exclusive -Owner -Purpose 'the owner''s Play' }
    default  { Take-GameLock $Rex -Exclusive -Purpose $lockPurpose }
}
$handed = $false
# (Games started together from one build: one at a time from the start until the game and its log are known, or the search
# below could take the other's. Named by the exe, so another clone doesn't wait.)
$startMutex = New-Object Threading.Mutex($false, "Local\ttt2-game-start-$(($exe -replace '[\\:]', '_').ToLower())")
$startHeld = $false
try { $startHeld = $startMutex.WaitOne(60000) } catch [Threading.AbandonedMutexException] { $startHeld = $true }
try {
    $before = Get-Date
    # (The exact command line the game is started with, for a tester to send: userdata\last-launch.txt,
    # written at every launch.)
    $launchArgs = @("--game_data_root=$game", "--update_data_root=$update", "--user_data_root=$userData") + $profileArgs + $mappingArgs + $nameArgs + $displayArgs + $renderTargetArgs + @($args)
    try {
        $quoted = $launchArgs | ForEach-Object { if ("$_" -match '\s') { '"' + "$_" + '"' } else { "$_" } }
        Set-Content -LiteralPath (Join-Path $userData 'last-launch.txt') ('"' + $exe + '" ' + ($quoted -join ' ')) -Encoding utf8
    } catch { Write-Host "last-launch.txt not written: $($_.Exception.Message)" }
    # (Each switch as a plain string: with this script started by -File, Windows PowerShell 5.1 passed a "--name=value"
    # with a space unquoted, so the game got "--ttt2_release_name=Release" and a stray "4.1"; 24 Oct.)
    $passArgs = @($args | ForEach-Object { "$_" })
    & $exe "--game_data_root=$game" "--update_data_root=$update" "--user_data_root=$userData" @profileArgs @mappingArgs @nameArgs @displayArgs @renderTargetArgs @passArgs
    $started = $null
    $deadline = (Get-Date).AddSeconds(20)
    while (-not $started -and (Get-Date) -lt $deadline) {
        $started = Get-Process ttt2 -ErrorAction SilentlyContinue |
            Where-Object { $_.Path -eq $exe -and $_.StartTime -ge $before.AddSeconds(-2) } |
            Sort-Object StartTime | Select-Object -Last 1
        if (-not $started) { Start-Sleep -Milliseconds 100 }
    }
    New-Item -ItemType Directory -Force (Join-Path $Rex 'out') | Out-Null
    # (Its start time read now, while it runs: Install's pipeline warm-up game makes its pipelines and quits in ~3 s, before the wait for
    # its log below ends (with --log_file there is no numbered log to wait for), and an exited process's StartTime is null: the
    # "null-valued expression" that skipped the warm-up's own lines in 4.6.2, 4 Nov.)
    $startedAt = if ($started) { try { $started.StartTime.ToFileTimeUtc() } catch { 0 } } else { 0 }
    if ($started) {
        # (The pair mode names a file an instance: TTT2_GAME_PID_FILE; else this clone's one file.)
        $pidFile = if ($env:TTT2_GAME_PID_FILE) { $env:TTT2_GAME_PID_FILE } else { Join-Path $Rex "out/game-pid.txt" }
        # (Its log's name third, for runs that share the logs folder with another game: the newest log may be the other's.)
        $ownLog = $null
        $logDeadline = (Get-Date).AddSeconds(5)
        while (-not $ownLog -and (Get-Date) -lt $logDeadline) {
            $ownLog = Get-ChildItem -LiteralPath (Join-Path (Split-Path $exe -Parent) 'logs') -Filter 'ttt2_*.log' -ErrorAction SilentlyContinue |
                Where-Object { $_.CreationTime -ge $before.AddSeconds(-2) -and $_.Name -notmatch '\.\d+\.log$' } | Sort-Object CreationTime | Select-Object -Last 1
            if (-not $ownLog) { Start-Sleep -Milliseconds 100 }
        }
        Set-Content -LiteralPath $pidFile -Value "$($started.Id) $startedAt $(if ($ownLog) { $ownLog.FullName })".Trim()
        # (A game already gone (the warm-up's, above): no lock to hand it; this run's own lock is let go below as for a game that never started.)
        try { if ($mine) { Move-GameLock $started.Id; $handed = $true } else { Add-GameLockProcess $started.Id } }
        catch { if (Get-Process -Id $started.Id -ErrorAction SilentlyContinue) { throw } }
        # Online replays to the server (21 October): the game saves each finished online match as replays\<date>-online.ttt2replay;
        # tools\replay-uploader.ps1, hidden beside the game, sends each file unchanged and ends when the game does. Only for an online
        # start with a server; "replay_upload=false" in launcher-settings.txt turns it off.
        $online = @($args | Where-Object { "$_" -eq '--ttt2_live_net=true' }).Count -gt 0
        $workerArg = @($args | Where-Object { "$_" -like '--ttt2_live_worker=*' } | Select-Object -Last 1)
        $worker = if ($workerArg.Count) { ("$($workerArg[0])" -replace '^--ttt2_live_worker=', '').Trim('"') } else { 'https://elo.bluespark.site' }
        $uploadOff = (Test-Path -LiteralPath $settingsFile) -and (@(Get-Content -LiteralPath $settingsFile) -contains 'replay_upload=false')
        $uploader = Join-Path $Rex 'tools\replay-uploader.ps1'
        if ($online -and $worker -and -not $uploadOff -and (Test-Path -LiteralPath $uploader)) {
            try {
                $uploaderArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$uploader`"",
                    '-UserData', "`"$userData`"", '-Worker', $worker, '-GamePid', $started.Id)
                if ($profileDir) { $uploaderArgs += @('-ProfileDir', "`"$profileDir`"") }   # (the identity is in the profile folder since 23 October)
                Start-Process powershell -WindowStyle Hidden -ArgumentList $uploaderArgs | Out-Null
            } catch { Write-Host "The replay uploader did not start: $($_.Exception.Message)" }
        }
    }
} finally {
    if ($startHeld) { try { $startMutex.ReleaseMutex() } catch {} }
    $startMutex.Dispose()
    if ($mine -and -not $handed) { Release-GameLock }
}
