# Plan B's watcher (20 Nov, the helper lead): --ttt2_return_relaunch=true, off by default. run-windows.ps1 returns as always and leaves this script hidden and detached: it waits for
# the game and, on exit code 78 (the end card's RETURN TO MENU in a walk's set, ttt2fc::kExitReturnRelaunch), runs run-windows.ps1 again with the same switches, 50 rounds at most.
# The switches come from a file (one per line), so no quoting is lost on the way.
# (20 Nov, the lead's order after forf2, where one side's watcher did not relaunch and nothing said why: every step is written to rex\out\relaunch-watch-<game pid>.log.)
param([Parameter(Mandatory)][int]$GamePid, [Parameter(Mandatory)][string]$RunWindows, [Parameter(Mandatory)][string]$ArgsFile, [int]$Round = 0)
$ErrorActionPreference = 'Stop'
$logFile = $null
# (20 Nov, the classic restart: a classic game's watcher is given the parked game's switches in TTT2_RELAUNCH_ORIG_ARGS (a file), to start that game again on the marker "parked".)
$origFile = $env:TTT2_RELAUNCH_ORIG_ARGS
$env:TTT2_RELAUNCH_ORIG_ARGS = $null
try { $logFile = Join-Path (Split-Path -Parent (Split-Path -Parent $PSCommandPath)) "out\relaunch-watch-$GamePid.log" } catch { }
function Log([string]$m) { if ($logFile) { try { Add-Content -LiteralPath $logFile -Value ("{0} {1}" -f (Get-Date -Format 'HH:mm:ss.fff'), $m) -Encoding UTF8 } catch { } } }
Log "watcher up: game $GamePid, round $Round, args file $ArgsFile, run-windows $RunWindows"
$p = Get-Process -Id $GamePid -ErrorAction SilentlyContinue
if (-not $p) { Log "the game is not running at the start: nothing to watch"; Remove-Item -LiteralPath $ArgsFile -Force -ErrorAction SilentlyContinue; exit 0 }
$handleOk = $true
try { $null = $p.Handle } catch { $handleOk = $false }   # (opened at once, so the exit code can be read after the end)
Log "handle opened: $handleOk"
$null = $p.WaitForExit()
$code = try { $p.ExitCode } catch { $null }
Log "the game ended, exit code $code"
$argList = @(Get-Content -LiteralPath $ArgsFile -Encoding UTF8 | Where-Object { $_ -ne '' })
Log "args read: $($argList.Count)"
Remove-Item -LiteralPath $ArgsFile -Force -ErrorAction SilentlyContinue
# (20 Nov, the lead's order: the game's exit 78 writes the marker file ttt2-relaunch-<pid>.flag in TEMP first. Relaunch on the code 78 OR that marker, which is then deleted, never on anything else; the log says which.)
$flag = Join-Path $env:TEMP "ttt2-relaunch-$GamePid.flag"
$hasFlag = Test-Path -LiteralPath $flag
$kind = ''
if ($hasFlag) {
    try { $kind = (Get-Content -LiteralPath $flag -Raw -ErrorAction Stop).Trim() } catch { }
    Remove-Item -LiteralPath $flag -Force -ErrorAction SilentlyContinue
}
Log "exit code $code, marker $hasFlag ($kind)"
# (20 Nov, the classic restart, the helper lead's GO: the marker text "classic" = the next start drops exactly the parked bundle's switches and keeps every other one (renderer, mute, user data),
# is the classic session (--ttt2_classic_session) with the home page closed; "parked" = the next start is the parked game's own switches again, kept in $origFile. Anything else: the same switches.)
$bundleRe = '^--ttt2_(stage_c_direct_bundle|parked_practice|queue_from_practice|parked_show|parked_turbo_load|return_relaunch|abort_relaunch|parked_early_home)(=.*)?$'
$classicRe = '^--ttt2_(classic_session|bluespark_test_page_closed)(=.*)?$'
if ($kind -eq 'classic') {
    $keep = Join-Path $env:TEMP "ttt2-relaunch-orig-$GamePid.txt"
    Set-Content -LiteralPath $keep -Value $argList -Encoding UTF8
    $env:TTT2_RELAUNCH_ORIG_ARGS = $keep
    $argList = @($argList | Where-Object { $_ -notmatch $bundleRe -and $_ -notmatch $classicRe }) + @('--ttt2_classic_session=true', '--ttt2_bluespark_test_page_closed=true')
    Log "classic: the bundle's switches dropped, the rest kept ($($argList.Count) args); the parked game's switches kept in $keep"
} elseif ($kind -like 'parked*') {
    if ($origFile -and (Test-Path -LiteralPath $origFile)) {
        $argList = @(Get-Content -LiteralPath $origFile -Encoding UTF8 | Where-Object { $_ -ne '' })
        if ($kind -match '^parked:(ranked|quick)$') { $argList += "--ttt2_home_focus=$($Matches[1])" }   # (the classic menu's Ranked / Quick BEGIN SEARCH: the home opens on that FIND)
        Log "parked: the parked game's switches read again from $origFile ($($argList.Count) args)"
    } else {
        $argList = @($argList | Where-Object { $_ -notmatch $classicRe })
        Log "parked: NO saved switches (orig file '$origFile'): the classic ones dropped, the rest kept"
    }
}
if ($origFile -and $kind -ne 'classic') { Remove-Item -LiteralPath $origFile -Force -ErrorAction SilentlyContinue }
if (($code -eq 78 -or $hasFlag) -and $Round -lt 50) {
    Log "the reason: $(if ($code -eq 78 -and $hasFlag) { 'exit code 78 and the marker' } elseif ($code -eq 78) { 'exit code 78' } else { 'the marker only (the code read as ' + $code + ')' })"
    $env:TTT2_PLAY_RELAUNCH_COUNT = [string]($Round + 1)
    Log "relaunching: round $($Round + 1)"
    try { & $RunWindows @argList *>&1 | Out-File -LiteralPath ($logFile + ".out") -Append -Encoding UTF8; Log "run-windows returned, last exit $LASTEXITCODE (its output: relaunch-watch-$GamePid.log.out)" } catch { Log "run-windows failed: $($_.Exception.Message)" }
} else {
    Log "no relaunch (exit code $code, round $Round)"
}
